package Mudeexooxai0;

import aeng3zazoo4T.esohshee3Pau;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ieseir3Choge implements Iterable {

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final C0020ieseir3Choge f1678Jah0aiP1ki6y = new C0020ieseir3Choge(null);

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final int f1679Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final int f1680ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final int f1681kuedujio7Aev;

    /* renamed from: Mudeexooxai0.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0020ieseir3Choge {
        public C0020ieseir3Choge() {
        }

        public final ieseir3Choge ieseir3Choge(int i, int i2, int i3) {
            return new ieseir3Choge(i, i2, i3);
        }

        public /* synthetic */ C0020ieseir3Choge(thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
            this();
        }
    }

    public ieseir3Choge(int i, int i2, int i3) {
        if (i3 != 0) {
            if (i3 != Integer.MIN_VALUE) {
                this.f1680ieheiQu9sho5 = i;
                this.f1681kuedujio7Aev = Eiy6sei0yi7d.ieseir3Choge.thooCoci9zae(i, i2, i3);
                this.f1679Aicohm8ieYoo = i3;
                return;
            }
            throw new IllegalArgumentException("Step must be greater than Int.MIN_VALUE to avoid overflow on negation.");
        }
        throw new IllegalArgumentException("Step must be non-zero.");
    }

    public final int ahthoK6usais() {
        return this.f1679Aicohm8ieYoo;
    }

    public boolean equals(Object obj) {
        if (obj instanceof ieseir3Choge) {
            if (!isEmpty() || !((ieseir3Choge) obj).isEmpty()) {
                ieseir3Choge ieseir3choge = (ieseir3Choge) obj;
                if (this.f1680ieheiQu9sho5 != ieseir3choge.f1680ieheiQu9sho5 || this.f1681kuedujio7Aev != ieseir3choge.f1681kuedujio7Aev || this.f1679Aicohm8ieYoo != ieseir3choge.f1679Aicohm8ieYoo) {
                }
            }
            return true;
        }
        return false;
    }

    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (((this.f1680ieheiQu9sho5 * 31) + this.f1681kuedujio7Aev) * 31) + this.f1679Aicohm8ieYoo;
    }

    public boolean isEmpty() {
        if (this.f1679Aicohm8ieYoo > 0) {
            if (this.f1680ieheiQu9sho5 <= this.f1681kuedujio7Aev) {
                return false;
            }
        } else if (this.f1680ieheiQu9sho5 >= this.f1681kuedujio7Aev) {
            return false;
        }
        return true;
    }

    public final int ko7aiFeiqu3s() {
        return this.f1680ieheiQu9sho5;
    }

    @Override // java.lang.Iterable
    /* renamed from: mi5Iecheimie, reason: merged with bridge method [inline-methods] */
    public esohshee3Pau iterator() {
        return new thooCoci9zae(this.f1680ieheiQu9sho5, this.f1681kuedujio7Aev, this.f1679Aicohm8ieYoo);
    }

    public final int ruNgecai1pae() {
        return this.f1681kuedujio7Aev;
    }

    public String toString() {
        StringBuilder sb;
        int i;
        if (this.f1679Aicohm8ieYoo > 0) {
            sb = new StringBuilder();
            sb.append(this.f1680ieheiQu9sho5);
            sb.append("..");
            sb.append(this.f1681kuedujio7Aev);
            sb.append(" step ");
            i = this.f1679Aicohm8ieYoo;
        } else {
            sb = new StringBuilder();
            sb.append(this.f1680ieheiQu9sho5);
            sb.append(" downTo ");
            sb.append(this.f1681kuedujio7Aev);
            sb.append(" step ");
            i = -this.f1679Aicohm8ieYoo;
        }
        sb.append(i);
        return sb.toString();
    }
}
