package Mudeexooxai0;

import aeng3zazoo4T.esohshee3Pau;
import java.util.NoSuchElementException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class thooCoci9zae extends esohshee3Pau {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public boolean f1684Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public int f1685Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final int f1686ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final int f1687kuedujio7Aev;

    public thooCoci9zae(int i, int i2, int i3) {
        this.f1686ieheiQu9sho5 = i3;
        this.f1687kuedujio7Aev = i2;
        boolean z = false;
        if (i3 <= 0 ? i >= i2 : i <= i2) {
            z = true;
        }
        this.f1684Aicohm8ieYoo = z;
        this.f1685Jah0aiP1ki6y = z ? i : i2;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        return this.f1684Aicohm8ieYoo;
    }

    @Override // aeng3zazoo4T.esohshee3Pau
    public int thooCoci9zae() {
        int i = this.f1685Jah0aiP1ki6y;
        if (i == this.f1687kuedujio7Aev) {
            if (this.f1684Aicohm8ieYoo) {
                this.f1684Aicohm8ieYoo = false;
            } else {
                throw new NoSuchElementException();
            }
        } else {
            this.f1685Jah0aiP1ki6y = this.f1686ieheiQu9sho5 + i;
        }
        return i;
    }
}
