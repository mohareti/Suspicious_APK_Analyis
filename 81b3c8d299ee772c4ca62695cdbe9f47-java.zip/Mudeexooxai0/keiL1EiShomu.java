package Mudeexooxai0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class keiL1EiShomu extends Mudeexooxai0.ieseir3Choge {

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public static final ieseir3Choge f1682niah0Shohtha = new ieseir3Choge(null);

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final keiL1EiShomu f1683ohv5Shie7AeZ = new keiL1EiShomu(1, 0);

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {
        public ieseir3Choge() {
        }

        public /* synthetic */ ieseir3Choge(thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
            this();
        }
    }

    public keiL1EiShomu(int i, int i2) {
        super(i, i2, 1);
    }

    @Override // Mudeexooxai0.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj instanceof keiL1EiShomu) {
            if (!isEmpty() || !((keiL1EiShomu) obj).isEmpty()) {
                keiL1EiShomu keil1eishomu = (keiL1EiShomu) obj;
                if (ko7aiFeiqu3s() != keil1eishomu.ko7aiFeiqu3s() || ruNgecai1pae() != keil1eishomu.ruNgecai1pae()) {
                }
            }
            return true;
        }
        return false;
    }

    @Override // Mudeexooxai0.ieseir3Choge
    public int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (ko7aiFeiqu3s() * 31) + ruNgecai1pae();
    }

    @Override // Mudeexooxai0.ieseir3Choge
    public boolean isEmpty() {
        if (ko7aiFeiqu3s() > ruNgecai1pae()) {
            return true;
        }
        return false;
    }

    @Override // Mudeexooxai0.ieseir3Choge
    public String toString() {
        return ko7aiFeiqu3s() + ".." + ruNgecai1pae();
    }
}
