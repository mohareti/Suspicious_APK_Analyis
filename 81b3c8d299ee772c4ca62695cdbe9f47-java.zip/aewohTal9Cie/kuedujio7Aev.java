package aewohTal9Cie;

import java.io.Closeable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class kuedujio7Aev implements Closeable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final kuedujio7Aev f2767ieheiQu9sho5 = new kuedujio7Aev();

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        keiL1EiShomu.Jah0aiP1ki6y();
    }
}
