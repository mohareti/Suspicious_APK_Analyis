package aewohTal9Cie;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ieseir3Choge f2766ieseir3Choge;

    /* JADX WARN: Removed duplicated region for block: B:10:0x0043 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:20:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0039  */
    static {
        Object obj;
        Class<?> cls;
        ieseir3Choge ieseir3choge;
        try {
            cls = Class.forName("io.perfmark.impl.SecretPerfMarkImpl$PerfMarkImpl");
            obj = null;
        } catch (Throwable th) {
            obj = th;
            cls = null;
        }
        if (cls != null) {
            try {
                ieseir3choge = (ieseir3Choge) cls.asSubclass(ieseir3Choge.class).getConstructor(ieheiQu9sho5.class).newInstance(ieseir3Choge.f2764ieseir3Choge);
            } catch (Throwable th2) {
                obj = th2;
            }
            if (ieseir3choge == null) {
                ieseir3choge = new ieseir3Choge(ieseir3Choge.f2764ieseir3Choge);
            }
            f2766ieseir3Choge = ieseir3choge;
            if (obj == null) {
                try {
                    if (Boolean.getBoolean("io.perfmark.PerfMark.debug")) {
                        Class<?> cls2 = Class.forName("java.util.logging.Logger");
                        Object invoke = cls2.getMethod("getLogger", String.class).invoke(null, keiL1EiShomu.class.getName());
                        Class<?> cls3 = Class.forName("java.util.logging.Level");
                        cls2.getMethod("log", cls3, String.class, Throwable.class).invoke(invoke, cls3.getField("FINE").get(null), "Error during PerfMark.<clinit>", obj);
                        return;
                    }
                    return;
                } catch (Throwable unused) {
                    return;
                }
            }
            return;
        }
        ieseir3choge = null;
        if (ieseir3choge == null) {
        }
        f2766ieseir3Choge = ieseir3choge;
        if (obj == null) {
        }
    }

    public static thooCoci9zae Aicohm8ieYoo() {
        return f2766ieseir3Choge.kuedujio7Aev();
    }

    public static void Jah0aiP1ki6y() {
        f2766ieseir3Choge.Jah0aiP1ki6y();
    }

    public static void ieheiQu9sho5(String str, ieheiQu9sho5 ieheiqu9sho5) {
        f2766ieseir3Choge.keiL1EiShomu(str, ieheiqu9sho5);
    }

    public static void ieseir3Choge(ieheiQu9sho5 ieheiqu9sho5) {
        f2766ieseir3Choge.ieseir3Choge(ieheiqu9sho5);
    }

    public static ieheiQu9sho5 keiL1EiShomu(String str, long j) {
        return f2766ieseir3Choge.thooCoci9zae(str, j);
    }

    public static void kuedujio7Aev(thooCoci9zae thoococi9zae) {
        f2766ieseir3Choge.ieheiQu9sho5(thoococi9zae);
    }

    public static kuedujio7Aev niah0Shohtha(String str) {
        f2766ieseir3Choge.Aicohm8ieYoo(str);
        return kuedujio7Aev.f2767ieheiQu9sho5;
    }

    public static ieheiQu9sho5 thooCoci9zae(String str) {
        return f2766ieseir3Choge.thooCoci9zae(str, Long.MIN_VALUE);
    }
}
