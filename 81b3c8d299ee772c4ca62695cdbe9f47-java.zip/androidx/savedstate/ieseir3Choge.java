package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.Jah0aiP1ki6y;
import androidx.lifecycle.ahthoK6usais;
import androidx.lifecycle.ko7aiFeiqu3s;
import androidx.savedstate.Recreator;
import java.util.Iterator;
import java.util.Map;
import ko7aiFeiqu3s.thooCoci9zae;
import oote1Ahvo8Ai.ieheiQu9sho5;
import thiet5ees7Wu.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieseir3Choge {

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final thooCoci9zae f3894Jah0aiP1ki6y = new thooCoci9zae(null);

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public boolean f3896ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public Bundle f3898keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public Recreator.thooCoci9zae f3899kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public boolean f3900thooCoci9zae;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ko7aiFeiqu3s.thooCoci9zae f3897ieseir3Choge = new ko7aiFeiqu3s.thooCoci9zae();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public boolean f3895Aicohm8ieYoo = true;

    /* renamed from: androidx.savedstate.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface InterfaceC0060ieseir3Choge {
        void ieseir3Choge(ieheiQu9sho5 ieheiqu9sho5);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface keiL1EiShomu {
        Bundle ieseir3Choge();
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {
        public thooCoci9zae() {
        }

        public /* synthetic */ thooCoci9zae(thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
            this();
        }
    }

    public static final void ieheiQu9sho5(ieseir3Choge ieseir3choge, ahthoK6usais ahthok6usais, Jah0aiP1ki6y.ieseir3Choge ieseir3choge2) {
        boolean z;
        Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "this$0");
        Aicohm8ieYoo.kuedujio7Aev(ahthok6usais, "<anonymous parameter 0>");
        Aicohm8ieYoo.kuedujio7Aev(ieseir3choge2, "event");
        if (ieseir3choge2 == Jah0aiP1ki6y.ieseir3Choge.ON_START) {
            z = true;
        } else if (ieseir3choge2 != Jah0aiP1ki6y.ieseir3Choge.ON_STOP) {
            return;
        } else {
            z = false;
        }
        ieseir3choge.f3895Aicohm8ieYoo = z;
    }

    public final void Aicohm8ieYoo(Bundle bundle) {
        if (!this.f3900thooCoci9zae) {
            throw new IllegalStateException("You must call performAttach() before calling performRestore(Bundle).".toString());
        }
        if (!(!this.f3896ieheiQu9sho5)) {
            throw new IllegalStateException("SavedStateRegistry was already restored.".toString());
        }
        this.f3898keiL1EiShomu = bundle != null ? bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key") : null;
        this.f3896ieheiQu9sho5 = true;
    }

    public final void Jah0aiP1ki6y(Bundle bundle) {
        Aicohm8ieYoo.kuedujio7Aev(bundle, "outBundle");
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = this.f3898keiL1EiShomu;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        thooCoci9zae.ieheiQu9sho5 ahthoK6usais2 = this.f3897ieseir3Choge.ahthoK6usais();
        Aicohm8ieYoo.ieheiQu9sho5(ahthoK6usais2, "this.components.iteratorWithAdditions()");
        while (ahthoK6usais2.hasNext()) {
            Map.Entry entry = (Map.Entry) ahthoK6usais2.next();
            bundle2.putBundle((String) entry.getKey(), ((keiL1EiShomu) entry.getValue()).ieseir3Choge());
        }
        if (bundle2.isEmpty()) {
            return;
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }

    public final keiL1EiShomu keiL1EiShomu(String str) {
        Aicohm8ieYoo.kuedujio7Aev(str, "key");
        Iterator it = this.f3897ieseir3Choge.iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry) it.next();
            Aicohm8ieYoo.ieheiQu9sho5(entry, "components");
            String str2 = (String) entry.getKey();
            keiL1EiShomu keil1eishomu = (keiL1EiShomu) entry.getValue();
            if (Aicohm8ieYoo.ieseir3Choge(str2, str)) {
                return keil1eishomu;
            }
        }
        return null;
    }

    public final void kuedujio7Aev(Jah0aiP1ki6y jah0aiP1ki6y) {
        Aicohm8ieYoo.kuedujio7Aev(jah0aiP1ki6y, "lifecycle");
        if (!(!this.f3900thooCoci9zae)) {
            throw new IllegalStateException("SavedStateRegistry was already attached.".toString());
        }
        jah0aiP1ki6y.ieseir3Choge(new ko7aiFeiqu3s() { // from class: oote1Ahvo8Ai.thooCoci9zae
            @Override // androidx.lifecycle.ko7aiFeiqu3s
            public final void kuedujio7Aev(ahthoK6usais ahthok6usais, Jah0aiP1ki6y.ieseir3Choge ieseir3choge) {
                androidx.savedstate.ieseir3Choge.ieheiQu9sho5(androidx.savedstate.ieseir3Choge.this, ahthok6usais, ieseir3choge);
            }
        });
        this.f3900thooCoci9zae = true;
    }

    public final void niah0Shohtha(String str, keiL1EiShomu keil1eishomu) {
        Aicohm8ieYoo.kuedujio7Aev(str, "key");
        Aicohm8ieYoo.kuedujio7Aev(keil1eishomu, "provider");
        if (((keiL1EiShomu) this.f3897ieseir3Choge.AeJiPo4of6Sh(str, keil1eishomu)) != null) {
            throw new IllegalArgumentException("SavedStateProvider with the given key is already registered".toString());
        }
    }

    public final void ohv5Shie7AeZ(Class cls) {
        Aicohm8ieYoo.kuedujio7Aev(cls, "clazz");
        if (!this.f3895Aicohm8ieYoo) {
            throw new IllegalStateException("Can not perform this action after onSaveInstanceState".toString());
        }
        Recreator.thooCoci9zae thoococi9zae = this.f3899kuedujio7Aev;
        if (thoococi9zae == null) {
            thoococi9zae = new Recreator.thooCoci9zae(this);
        }
        this.f3899kuedujio7Aev = thoococi9zae;
        try {
            cls.getDeclaredConstructor(null);
            Recreator.thooCoci9zae thoococi9zae2 = this.f3899kuedujio7Aev;
            if (thoococi9zae2 != null) {
                String name = cls.getName();
                Aicohm8ieYoo.ieheiQu9sho5(name, "clazz.name");
                thoococi9zae2.thooCoci9zae(name);
            }
        } catch (NoSuchMethodException e) {
            throw new IllegalArgumentException("Class " + cls.getSimpleName() + " must have default constructor in order to be automatically recreated", e);
        }
    }

    public final Bundle thooCoci9zae(String str) {
        Aicohm8ieYoo.kuedujio7Aev(str, "key");
        if (!this.f3896ieheiQu9sho5) {
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component".toString());
        }
        Bundle bundle = this.f3898keiL1EiShomu;
        if (bundle == null) {
            return null;
        }
        Bundle bundle2 = bundle != null ? bundle.getBundle(str) : null;
        Bundle bundle3 = this.f3898keiL1EiShomu;
        if (bundle3 != null) {
            bundle3.remove(str);
        }
        Bundle bundle4 = this.f3898keiL1EiShomu;
        if (bundle4 == null || bundle4.isEmpty()) {
            this.f3898keiL1EiShomu = null;
        }
        return bundle2;
    }
}
