package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import androidx.emoji2.text.Aicohm8ieYoo;
import androidx.emoji2.text.ruNgecai1pae;
import esohshee3Pau.niah0Shohtha;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ruNgecai1pae extends Aicohm8ieYoo.keiL1EiShomu {

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public static final ieseir3Choge f3406ruNgecai1pae = new ieseir3Choge();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public Typeface ieseir3Choge(Context context, niah0Shohtha.thooCoci9zae thoococi9zae) {
            return esohshee3Pau.niah0Shohtha.ieseir3Choge(context, null, new niah0Shohtha.thooCoci9zae[]{thoococi9zae});
        }

        public void keiL1EiShomu(Context context, ContentObserver contentObserver) {
            context.getContentResolver().unregisterContentObserver(contentObserver);
        }

        public niah0Shohtha.ieseir3Choge thooCoci9zae(Context context, esohshee3Pau.Aicohm8ieYoo aicohm8ieYoo) {
            return esohshee3Pau.niah0Shohtha.thooCoci9zae(context, null, aicohm8ieYoo);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae implements Aicohm8ieYoo.niah0Shohtha {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public Executor f3407Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public ThreadPoolExecutor f3408Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final Object f3409ieheiQu9sho5 = new Object();

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Context f3410ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final ieseir3Choge f3411keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public Runnable f3412ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public Handler f3413kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public Aicohm8ieYoo.ohv5Shie7AeZ f3414niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public ContentObserver f3415ohv5Shie7AeZ;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final esohshee3Pau.Aicohm8ieYoo f3416thooCoci9zae;

        public thooCoci9zae(Context context, esohshee3Pau.Aicohm8ieYoo aicohm8ieYoo, ieseir3Choge ieseir3choge) {
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(context, "Context cannot be null");
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(aicohm8ieYoo, "FontRequest cannot be null");
            this.f3410ieseir3Choge = context.getApplicationContext();
            this.f3416thooCoci9zae = aicohm8ieYoo;
            this.f3411keiL1EiShomu = ieseir3choge;
        }

        public void Aicohm8ieYoo(Executor executor) {
            synchronized (this.f3409ieheiQu9sho5) {
                this.f3407Aicohm8ieYoo = executor;
            }
        }

        public void ieheiQu9sho5() {
            synchronized (this.f3409ieheiQu9sho5) {
                try {
                    if (this.f3414niah0Shohtha == null) {
                        return;
                    }
                    if (this.f3407Aicohm8ieYoo == null) {
                        ThreadPoolExecutor thooCoci9zae2 = keiL1EiShomu.thooCoci9zae("emojiCompat");
                        this.f3408Jah0aiP1ki6y = thooCoci9zae2;
                        this.f3407Aicohm8ieYoo = thooCoci9zae2;
                    }
                    this.f3407Aicohm8ieYoo.execute(new Runnable() { // from class: androidx.emoji2.text.ahthoK6usais
                        @Override // java.lang.Runnable
                        public final void run() {
                            ruNgecai1pae.thooCoci9zae.this.keiL1EiShomu();
                        }
                    });
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // androidx.emoji2.text.Aicohm8ieYoo.niah0Shohtha
        public void ieseir3Choge(Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez) {
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(ohv5shie7aez, "LoaderCallback cannot be null");
            synchronized (this.f3409ieheiQu9sho5) {
                this.f3414niah0Shohtha = ohv5shie7aez;
            }
            ieheiQu9sho5();
        }

        public void keiL1EiShomu() {
            synchronized (this.f3409ieheiQu9sho5) {
                try {
                    if (this.f3414niah0Shohtha == null) {
                        return;
                    }
                    try {
                        niah0Shohtha.thooCoci9zae kuedujio7Aev2 = kuedujio7Aev();
                        int thooCoci9zae2 = kuedujio7Aev2.thooCoci9zae();
                        if (thooCoci9zae2 == 2) {
                            synchronized (this.f3409ieheiQu9sho5) {
                            }
                        }
                        if (thooCoci9zae2 != 0) {
                            throw new RuntimeException("fetchFonts result is not OK. (" + thooCoci9zae2 + ")");
                        }
                        try {
                            rojaiZ9aeRee.ahthoK6usais.ieseir3Choge("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                            Typeface ieseir3Choge2 = this.f3411keiL1EiShomu.ieseir3Choge(this.f3410ieseir3Choge, kuedujio7Aev2);
                            ByteBuffer Aicohm8ieYoo2 = eetheKaevie8.oYe2ma2she1j.Aicohm8ieYoo(this.f3410ieseir3Choge, null, kuedujio7Aev2.ieheiQu9sho5());
                            if (Aicohm8ieYoo2 == null || ieseir3Choge2 == null) {
                                throw new RuntimeException("Unable to open file.");
                            }
                            ruwiepo7ooVu thooCoci9zae3 = ruwiepo7ooVu.thooCoci9zae(ieseir3Choge2, Aicohm8ieYoo2);
                            rojaiZ9aeRee.ahthoK6usais.thooCoci9zae();
                            synchronized (this.f3409ieheiQu9sho5) {
                                try {
                                    Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez = this.f3414niah0Shohtha;
                                    if (ohv5shie7aez != null) {
                                        ohv5shie7aez.thooCoci9zae(thooCoci9zae3);
                                    }
                                } finally {
                                }
                            }
                            thooCoci9zae();
                        } catch (Throwable th) {
                            rojaiZ9aeRee.ahthoK6usais.thooCoci9zae();
                            throw th;
                        }
                    } catch (Throwable th2) {
                        synchronized (this.f3409ieheiQu9sho5) {
                            try {
                                Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez2 = this.f3414niah0Shohtha;
                                if (ohv5shie7aez2 != null) {
                                    ohv5shie7aez2.ieseir3Choge(th2);
                                }
                                thooCoci9zae();
                            } finally {
                            }
                        }
                    }
                } finally {
                }
            }
        }

        public final niah0Shohtha.thooCoci9zae kuedujio7Aev() {
            try {
                niah0Shohtha.ieseir3Choge thooCoci9zae2 = this.f3411keiL1EiShomu.thooCoci9zae(this.f3410ieseir3Choge, this.f3416thooCoci9zae);
                if (thooCoci9zae2.keiL1EiShomu() == 0) {
                    niah0Shohtha.thooCoci9zae[] thooCoci9zae3 = thooCoci9zae2.thooCoci9zae();
                    if (thooCoci9zae3 != null && thooCoci9zae3.length != 0) {
                        return thooCoci9zae3[0];
                    }
                    throw new RuntimeException("fetchFonts failed (empty result)");
                }
                throw new RuntimeException("fetchFonts failed (" + thooCoci9zae2.keiL1EiShomu() + ")");
            } catch (PackageManager.NameNotFoundException e) {
                throw new RuntimeException("provider not found", e);
            }
        }

        public final void thooCoci9zae() {
            synchronized (this.f3409ieheiQu9sho5) {
                try {
                    this.f3414niah0Shohtha = null;
                    ContentObserver contentObserver = this.f3415ohv5Shie7AeZ;
                    if (contentObserver != null) {
                        this.f3411keiL1EiShomu.keiL1EiShomu(this.f3410ieseir3Choge, contentObserver);
                        this.f3415ohv5Shie7AeZ = null;
                    }
                    Handler handler = this.f3413kuedujio7Aev;
                    if (handler != null) {
                        handler.removeCallbacks(this.f3412ko7aiFeiqu3s);
                    }
                    this.f3413kuedujio7Aev = null;
                    ThreadPoolExecutor threadPoolExecutor = this.f3408Jah0aiP1ki6y;
                    if (threadPoolExecutor != null) {
                        threadPoolExecutor.shutdown();
                    }
                    this.f3407Aicohm8ieYoo = null;
                    this.f3408Jah0aiP1ki6y = null;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    public ruNgecai1pae(Context context, esohshee3Pau.Aicohm8ieYoo aicohm8ieYoo) {
        super(new thooCoci9zae(context, aicohm8ieYoo, f3406ruNgecai1pae));
    }

    public ruNgecai1pae keiL1EiShomu(Executor executor) {
        ((thooCoci9zae) ieseir3Choge()).Aicohm8ieYoo(executor);
        return this;
    }
}
