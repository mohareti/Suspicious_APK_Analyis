package androidx.emoji2.text;

import android.os.Build;
import android.text.Editable;
import android.text.SpanWatcher;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class AeJiPo4of6Sh extends SpannableStringBuilder {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Class f3322ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final List f3323kuedujio7Aev;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge implements TextWatcher, SpanWatcher {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Object f3324ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final AtomicInteger f3325thooCoci9zae = new AtomicInteger(0);

        public ieseir3Choge(Object obj) {
            this.f3324ieseir3Choge = obj;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
            ((TextWatcher) this.f3324ieseir3Choge).afterTextChanged(editable);
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            ((TextWatcher) this.f3324ieseir3Choge).beforeTextChanged(charSequence, i, i2, i3);
        }

        public final void ieseir3Choge() {
            this.f3325thooCoci9zae.incrementAndGet();
        }

        public final void keiL1EiShomu() {
            this.f3325thooCoci9zae.decrementAndGet();
        }

        @Override // android.text.SpanWatcher
        public void onSpanAdded(Spannable spannable, Object obj, int i, int i2) {
            if (this.f3325thooCoci9zae.get() <= 0 || !thooCoci9zae(obj)) {
                ((SpanWatcher) this.f3324ieseir3Choge).onSpanAdded(spannable, obj, i, i2);
            }
        }

        @Override // android.text.SpanWatcher
        public void onSpanChanged(Spannable spannable, Object obj, int i, int i2, int i3, int i4) {
            int i5;
            int i6;
            if (this.f3325thooCoci9zae.get() <= 0 || !thooCoci9zae(obj)) {
                if (Build.VERSION.SDK_INT < 28) {
                    if (i > i2) {
                        i = 0;
                    }
                    if (i3 > i4) {
                        i5 = i;
                        i6 = 0;
                        ((SpanWatcher) this.f3324ieseir3Choge).onSpanChanged(spannable, obj, i5, i2, i6, i4);
                    }
                }
                i5 = i;
                i6 = i3;
                ((SpanWatcher) this.f3324ieseir3Choge).onSpanChanged(spannable, obj, i5, i2, i6, i4);
            }
        }

        @Override // android.text.SpanWatcher
        public void onSpanRemoved(Spannable spannable, Object obj, int i, int i2) {
            if (this.f3325thooCoci9zae.get() <= 0 || !thooCoci9zae(obj)) {
                ((SpanWatcher) this.f3324ieseir3Choge).onSpanRemoved(spannable, obj, i, i2);
            }
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            ((TextWatcher) this.f3324ieseir3Choge).onTextChanged(charSequence, i, i2, i3);
        }

        public final boolean thooCoci9zae(Object obj) {
            return obj instanceof ko7aiFeiqu3s;
        }
    }

    public AeJiPo4of6Sh(Class cls, CharSequence charSequence) {
        super(charSequence);
        this.f3323kuedujio7Aev = new ArrayList();
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(cls, "watcherClass cannot be null");
        this.f3322ieheiQu9sho5 = cls;
    }

    public static AeJiPo4of6Sh keiL1EiShomu(Class cls, CharSequence charSequence) {
        return new AeJiPo4of6Sh(cls, charSequence);
    }

    public final ieseir3Choge Aicohm8ieYoo(Object obj) {
        for (int i = 0; i < this.f3323kuedujio7Aev.size(); i++) {
            ieseir3Choge ieseir3choge = (ieseir3Choge) this.f3323kuedujio7Aev.get(i);
            if (ieseir3choge.f3324ieseir3Choge == obj) {
                return ieseir3choge;
            }
        }
        return null;
    }

    public final boolean Jah0aiP1ki6y(Class cls) {
        return this.f3322ieheiQu9sho5 == cls;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanEnd(Object obj) {
        ieseir3Choge Aicohm8ieYoo2;
        if (niah0Shohtha(obj) && (Aicohm8ieYoo2 = Aicohm8ieYoo(obj)) != null) {
            obj = Aicohm8ieYoo2;
        }
        return super.getSpanEnd(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanFlags(Object obj) {
        ieseir3Choge Aicohm8ieYoo2;
        if (niah0Shohtha(obj) && (Aicohm8ieYoo2 = Aicohm8ieYoo(obj)) != null) {
            obj = Aicohm8ieYoo2;
        }
        return super.getSpanFlags(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int getSpanStart(Object obj) {
        ieseir3Choge Aicohm8ieYoo2;
        if (niah0Shohtha(obj) && (Aicohm8ieYoo2 = Aicohm8ieYoo(obj)) != null) {
            obj = Aicohm8ieYoo2;
        }
        return super.getSpanStart(obj);
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public Object[] getSpans(int i, int i2, Class cls) {
        if (!Jah0aiP1ki6y(cls)) {
            return super.getSpans(i, i2, cls);
        }
        ieseir3Choge[] ieseir3chogeArr = (ieseir3Choge[]) super.getSpans(i, i2, ieseir3Choge.class);
        Object[] objArr = (Object[]) Array.newInstance((Class<?>) cls, ieseir3chogeArr.length);
        for (int i3 = 0; i3 < ieseir3chogeArr.length; i3++) {
            objArr[i3] = ieseir3chogeArr[i3].f3324ieseir3Choge;
        }
        return objArr;
    }

    public void ieheiQu9sho5() {
        ohv5Shie7AeZ();
        kuedujio7Aev();
    }

    public void ieseir3Choge() {
        thooCoci9zae();
    }

    public final void kuedujio7Aev() {
        for (int i = 0; i < this.f3323kuedujio7Aev.size(); i++) {
            ((ieseir3Choge) this.f3323kuedujio7Aev.get(i)).onTextChanged(this, 0, length(), length());
        }
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spanned
    public int nextSpanTransition(int i, int i2, Class cls) {
        if (cls == null || Jah0aiP1ki6y(cls)) {
            cls = ieseir3Choge.class;
        }
        return super.nextSpanTransition(i, i2, cls);
    }

    public final boolean niah0Shohtha(Object obj) {
        return obj != null && Jah0aiP1ki6y(obj.getClass());
    }

    public final void ohv5Shie7AeZ() {
        for (int i = 0; i < this.f3323kuedujio7Aev.size(); i++) {
            ((ieseir3Choge) this.f3323kuedujio7Aev.get(i)).keiL1EiShomu();
        }
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spannable
    public void removeSpan(Object obj) {
        ieseir3Choge ieseir3choge;
        if (niah0Shohtha(obj)) {
            ieseir3choge = Aicohm8ieYoo(obj);
            if (ieseir3choge != null) {
                obj = ieseir3choge;
            }
        } else {
            ieseir3choge = null;
        }
        super.removeSpan(obj);
        if (ieseir3choge != null) {
            this.f3323kuedujio7Aev.remove(ieseir3choge);
        }
    }

    @Override // android.text.SpannableStringBuilder, android.text.Spannable
    public void setSpan(Object obj, int i, int i2, int i3) {
        if (niah0Shohtha(obj)) {
            ieseir3Choge ieseir3choge = new ieseir3Choge(obj);
            this.f3323kuedujio7Aev.add(ieseir3choge);
            obj = ieseir3choge;
        }
        super.setSpan(obj, i, i2, i3);
    }

    @Override // android.text.SpannableStringBuilder, java.lang.CharSequence
    public CharSequence subSequence(int i, int i2) {
        return new AeJiPo4of6Sh(this.f3322ieheiQu9sho5, this, i, i2);
    }

    public final void thooCoci9zae() {
        for (int i = 0; i < this.f3323kuedujio7Aev.size(); i++) {
            ((ieseir3Choge) this.f3323kuedujio7Aev.get(i)).ieseir3Choge();
        }
    }

    public AeJiPo4of6Sh(Class cls, CharSequence charSequence, int i, int i2) {
        super(charSequence, i, i2);
        this.f3323kuedujio7Aev = new ArrayList();
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(cls, "watcherClass cannot be null");
        this.f3322ieheiQu9sho5 = cls;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder delete(int i, int i2) {
        super.delete(i, i2);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder insert(int i, CharSequence charSequence) {
        super.insert(i, charSequence);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder replace(int i, int i2, CharSequence charSequence) {
        thooCoci9zae();
        super.replace(i, i2, charSequence);
        ohv5Shie7AeZ();
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(char c) {
        super.append(c);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder insert(int i, CharSequence charSequence, int i2, int i3) {
        super.insert(i, charSequence, i2, i3);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable
    public SpannableStringBuilder replace(int i, int i2, CharSequence charSequence, int i3, int i4) {
        thooCoci9zae();
        super.replace(i, i2, charSequence, i3, i4);
        ohv5Shie7AeZ();
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(CharSequence charSequence) {
        super.append(charSequence);
        return this;
    }

    @Override // android.text.SpannableStringBuilder, android.text.Editable, java.lang.Appendable
    public SpannableStringBuilder append(CharSequence charSequence, int i, int i2) {
        super.append(charSequence, i, i2);
        return this;
    }

    @Override // android.text.SpannableStringBuilder
    public SpannableStringBuilder append(CharSequence charSequence, Object obj, int i) {
        super.append(charSequence, obj, i);
        return this;
    }
}
