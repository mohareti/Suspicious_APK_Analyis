package androidx.emoji2.text;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.os.Build;
import android.util.Log;
import androidx.emoji2.text.Aicohm8ieYoo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {

    /* renamed from: androidx.emoji2.text.ieheiQu9sho5$ieheiQu9sho5, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0050ieheiQu9sho5 extends keiL1EiShomu {
        @Override // androidx.emoji2.text.ieheiQu9sho5.thooCoci9zae
        public Signature[] thooCoci9zae(PackageManager packageManager, String str) {
            return packageManager.getPackageInfo(str, 64).signatures;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final thooCoci9zae f3372ieseir3Choge;

        public ieseir3Choge(thooCoci9zae thoococi9zae) {
            this.f3372ieseir3Choge = thoococi9zae == null ? kuedujio7Aev() : thoococi9zae;
        }

        public static thooCoci9zae kuedujio7Aev() {
            return Build.VERSION.SDK_INT >= 28 ? new C0050ieheiQu9sho5() : new keiL1EiShomu();
        }

        public final boolean Aicohm8ieYoo(ProviderInfo providerInfo) {
            ApplicationInfo applicationInfo;
            return (providerInfo == null || (applicationInfo = providerInfo.applicationInfo) == null || (applicationInfo.flags & 1) != 1) ? false : true;
        }

        public final ProviderInfo Jah0aiP1ki6y(PackageManager packageManager) {
            Iterator it = this.f3372ieseir3Choge.keiL1EiShomu(packageManager, new Intent("androidx.content.action.LOAD_EMOJI_FONT"), 0).iterator();
            while (it.hasNext()) {
                ProviderInfo ieseir3Choge2 = this.f3372ieseir3Choge.ieseir3Choge((ResolveInfo) it.next());
                if (Aicohm8ieYoo(ieseir3Choge2)) {
                    return ieseir3Choge2;
                }
            }
            return null;
        }

        public final esohshee3Pau.Aicohm8ieYoo ieheiQu9sho5(ProviderInfo providerInfo, PackageManager packageManager) {
            String str = providerInfo.authority;
            String str2 = providerInfo.packageName;
            return new esohshee3Pau.Aicohm8ieYoo(str, str2, "emojicompat-emoji-font", thooCoci9zae(this.f3372ieseir3Choge.thooCoci9zae(packageManager, str2)));
        }

        public final Aicohm8ieYoo.keiL1EiShomu ieseir3Choge(Context context, esohshee3Pau.Aicohm8ieYoo aicohm8ieYoo) {
            if (aicohm8ieYoo == null) {
                return null;
            }
            return new ruNgecai1pae(context, aicohm8ieYoo);
        }

        public Aicohm8ieYoo.keiL1EiShomu keiL1EiShomu(Context context) {
            return ieseir3Choge(context, niah0Shohtha(context));
        }

        public esohshee3Pau.Aicohm8ieYoo niah0Shohtha(Context context) {
            PackageManager packageManager = context.getPackageManager();
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(packageManager, "Package manager required to locate emoji font provider");
            ProviderInfo Jah0aiP1ki6y2 = Jah0aiP1ki6y(packageManager);
            if (Jah0aiP1ki6y2 == null) {
                return null;
            }
            try {
                return ieheiQu9sho5(Jah0aiP1ki6y2, packageManager);
            } catch (PackageManager.NameNotFoundException e) {
                Log.wtf("emoji2.text.DefaultEmojiConfig", e);
                return null;
            }
        }

        public final List thooCoci9zae(Signature[] signatureArr) {
            ArrayList arrayList = new ArrayList();
            for (Signature signature : signatureArr) {
                arrayList.add(signature.toByteArray());
            }
            return Collections.singletonList(arrayList);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu extends thooCoci9zae {
        @Override // androidx.emoji2.text.ieheiQu9sho5.thooCoci9zae
        public ProviderInfo ieseir3Choge(ResolveInfo resolveInfo) {
            return resolveInfo.providerInfo;
        }

        @Override // androidx.emoji2.text.ieheiQu9sho5.thooCoci9zae
        public List keiL1EiShomu(PackageManager packageManager, Intent intent, int i) {
            return packageManager.queryIntentContentProviders(intent, i);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {
        public abstract ProviderInfo ieseir3Choge(ResolveInfo resolveInfo);

        public abstract List keiL1EiShomu(PackageManager packageManager, Intent intent, int i);

        public Signature[] thooCoci9zae(PackageManager packageManager, String str) {
            return packageManager.getPackageInfo(str, 64).signatures;
        }
    }

    public static ruNgecai1pae ieseir3Choge(Context context) {
        return (ruNgecai1pae) new ieseir3Choge(null).keiL1EiShomu(context);
    }
}
