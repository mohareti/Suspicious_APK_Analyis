package androidx.emoji2.text;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract /* synthetic */ class zoojiiKaht3i {
}
