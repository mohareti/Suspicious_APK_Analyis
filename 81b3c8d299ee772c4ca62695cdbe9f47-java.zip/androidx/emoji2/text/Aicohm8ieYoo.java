package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Aicohm8ieYoo {

    /* renamed from: eetheKaevie8, reason: collision with root package name */
    public static volatile Aicohm8ieYoo f3327eetheKaevie8;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final niah0Shohtha f3329Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final ko7aiFeiqu3s f3330Jah0aiP1ki6y;

    /* renamed from: ahthoK6usais, reason: collision with root package name */
    public final int f3331ahthoK6usais;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public final int[] f3335ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final thooCoci9zae f3336kuedujio7Aev;

    /* renamed from: mi5Iecheimie, reason: collision with root package name */
    public final int f3337mi5Iecheimie;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final boolean f3338niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public final boolean f3339ohv5Shie7AeZ;

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public final boolean f3340ruNgecai1pae;

    /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
    public final kuedujio7Aev f3341ruwiepo7ooVu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Set f3342thooCoci9zae;

    /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
    public static final Object f3326AeJiPo4of6Sh = new Object();

    /* renamed from: oYe2ma2she1j, reason: collision with root package name */
    public static final Object f3328oYe2ma2she1j = new Object();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ReadWriteLock f3333ieseir3Choge = new ReentrantReadWriteLock();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public volatile int f3334keiL1EiShomu = 3;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Handler f3332ieheiQu9sho5 = new Handler(Looper.getMainLooper());

    /* renamed from: androidx.emoji2.text.Aicohm8ieYoo$Aicohm8ieYoo, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class AbstractC0048Aicohm8ieYoo {
        public void ieseir3Choge(Throwable th) {
        }

        public void thooCoci9zae() {
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class Jah0aiP1ki6y implements Runnable {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public final int f3343Aicohm8ieYoo;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final List f3344ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final Throwable f3345kuedujio7Aev;

        public Jah0aiP1ki6y(AbstractC0048Aicohm8ieYoo abstractC0048Aicohm8ieYoo, int i) {
            this(Arrays.asList((AbstractC0048Aicohm8ieYoo) ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(abstractC0048Aicohm8ieYoo, "initCallback cannot be null")), i, null);
        }

        @Override // java.lang.Runnable
        public void run() {
            int size = this.f3344ieheiQu9sho5.size();
            int i = 0;
            if (this.f3343Aicohm8ieYoo != 1) {
                while (i < size) {
                    ((AbstractC0048Aicohm8ieYoo) this.f3344ieheiQu9sho5.get(i)).ieseir3Choge(this.f3345kuedujio7Aev);
                    i++;
                }
            } else {
                while (i < size) {
                    ((AbstractC0048Aicohm8ieYoo) this.f3344ieheiQu9sho5.get(i)).thooCoci9zae();
                    i++;
                }
            }
        }

        public Jah0aiP1ki6y(Collection collection, int i) {
            this(collection, i, null);
        }

        public Jah0aiP1ki6y(Collection collection, int i, Throwable th) {
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(collection, "initCallbacks cannot be null");
            this.f3344ieheiQu9sho5 = new ArrayList(collection);
            this.f3343Aicohm8ieYoo = i;
            this.f3345kuedujio7Aev = th;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieheiQu9sho5 implements ko7aiFeiqu3s {
        @Override // androidx.emoji2.text.Aicohm8ieYoo.ko7aiFeiqu3s
        public androidx.emoji2.text.ko7aiFeiqu3s ieseir3Choge(oYe2ma2she1j oye2ma2she1j) {
            return new eetheKaevie8(oye2ma2she1j);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge extends thooCoci9zae {

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public volatile ruwiepo7ooVu f3346keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public volatile androidx.emoji2.text.ohv5Shie7AeZ f3347thooCoci9zae;

        /* renamed from: androidx.emoji2.text.Aicohm8ieYoo$ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public class C0049ieseir3Choge extends ohv5Shie7AeZ {
            public C0049ieseir3Choge() {
            }

            @Override // androidx.emoji2.text.Aicohm8ieYoo.ohv5Shie7AeZ
            public void ieseir3Choge(Throwable th) {
                ieseir3Choge.this.f3359ieseir3Choge.ruwiepo7ooVu(th);
            }

            @Override // androidx.emoji2.text.Aicohm8ieYoo.ohv5Shie7AeZ
            public void thooCoci9zae(ruwiepo7ooVu ruwiepo7oovu) {
                ieseir3Choge.this.ieheiQu9sho5(ruwiepo7oovu);
            }
        }

        public ieseir3Choge(Aicohm8ieYoo aicohm8ieYoo) {
            super(aicohm8ieYoo);
        }

        public void ieheiQu9sho5(ruwiepo7ooVu ruwiepo7oovu) {
            if (ruwiepo7oovu == null) {
                this.f3359ieseir3Choge.ruwiepo7ooVu(new IllegalArgumentException("metadataRepo cannot be null"));
                return;
            }
            this.f3346keiL1EiShomu = ruwiepo7oovu;
            ruwiepo7ooVu ruwiepo7oovu2 = this.f3346keiL1EiShomu;
            ko7aiFeiqu3s ko7aifeiqu3s = this.f3359ieseir3Choge.f3330Jah0aiP1ki6y;
            kuedujio7Aev kuedujio7aev = this.f3359ieseir3Choge.f3341ruwiepo7ooVu;
            Aicohm8ieYoo aicohm8ieYoo = this.f3359ieseir3Choge;
            this.f3347thooCoci9zae = new androidx.emoji2.text.ohv5Shie7AeZ(ruwiepo7oovu2, ko7aifeiqu3s, kuedujio7aev, aicohm8ieYoo.f3339ohv5Shie7AeZ, aicohm8ieYoo.f3335ko7aiFeiqu3s, androidx.emoji2.text.niah0Shohtha.ieseir3Choge());
            this.f3359ieseir3Choge.AeJiPo4of6Sh();
        }

        @Override // androidx.emoji2.text.Aicohm8ieYoo.thooCoci9zae
        public void ieseir3Choge() {
            try {
                this.f3359ieseir3Choge.f3329Aicohm8ieYoo.ieseir3Choge(new C0049ieseir3Choge());
            } catch (Throwable th) {
                this.f3359ieseir3Choge.ruwiepo7ooVu(th);
            }
        }

        @Override // androidx.emoji2.text.Aicohm8ieYoo.thooCoci9zae
        public void keiL1EiShomu(EditorInfo editorInfo) {
            editorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.f3346keiL1EiShomu.kuedujio7Aev());
            editorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", this.f3359ieseir3Choge.f3338niah0Shohtha);
        }

        @Override // androidx.emoji2.text.Aicohm8ieYoo.thooCoci9zae
        public CharSequence thooCoci9zae(CharSequence charSequence, int i, int i2, int i3, boolean z) {
            return this.f3347thooCoci9zae.niah0Shohtha(charSequence, i, i2, i3, z);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class keiL1EiShomu {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public Set f3349Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public boolean f3350Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public boolean f3351ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final niah0Shohtha f3352ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public boolean f3353keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public int[] f3355kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public ko7aiFeiqu3s f3358thooCoci9zae;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public int f3356niah0Shohtha = -16711936;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public int f3357ohv5Shie7AeZ = 0;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public kuedujio7Aev f3354ko7aiFeiqu3s = new androidx.emoji2.text.kuedujio7Aev();

        public keiL1EiShomu(niah0Shohtha niah0shohtha) {
            ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(niah0shohtha, "metadataLoader cannot be null.");
            this.f3352ieseir3Choge = niah0shohtha;
        }

        public final niah0Shohtha ieseir3Choge() {
            return this.f3352ieseir3Choge;
        }

        public keiL1EiShomu thooCoci9zae(int i) {
            this.f3357ohv5Shie7AeZ = i;
            return this;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ko7aiFeiqu3s {
        androidx.emoji2.text.ko7aiFeiqu3s ieseir3Choge(oYe2ma2she1j oye2ma2she1j);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface kuedujio7Aev {
        boolean ieseir3Choge(CharSequence charSequence, int i, int i2, int i3);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface niah0Shohtha {
        void ieseir3Choge(ohv5Shie7AeZ ohv5shie7aez);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ohv5Shie7AeZ {
        public abstract void ieseir3Choge(Throwable th);

        public abstract void thooCoci9zae(ruwiepo7ooVu ruwiepo7oovu);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Aicohm8ieYoo f3359ieseir3Choge;

        public thooCoci9zae(Aicohm8ieYoo aicohm8ieYoo) {
            this.f3359ieseir3Choge = aicohm8ieYoo;
        }

        public abstract void ieseir3Choge();

        public abstract void keiL1EiShomu(EditorInfo editorInfo);

        public abstract CharSequence thooCoci9zae(CharSequence charSequence, int i, int i2, int i3, boolean z);
    }

    public Aicohm8ieYoo(keiL1EiShomu keil1eishomu) {
        this.f3338niah0Shohtha = keil1eishomu.f3353keiL1EiShomu;
        this.f3339ohv5Shie7AeZ = keil1eishomu.f3351ieheiQu9sho5;
        this.f3335ko7aiFeiqu3s = keil1eishomu.f3355kuedujio7Aev;
        this.f3340ruNgecai1pae = keil1eishomu.f3350Jah0aiP1ki6y;
        this.f3331ahthoK6usais = keil1eishomu.f3356niah0Shohtha;
        this.f3329Aicohm8ieYoo = keil1eishomu.f3352ieseir3Choge;
        this.f3337mi5Iecheimie = keil1eishomu.f3357ohv5Shie7AeZ;
        this.f3341ruwiepo7ooVu = keil1eishomu.f3354ko7aiFeiqu3s;
        ruNgecai1pae.thooCoci9zae thoococi9zae = new ruNgecai1pae.thooCoci9zae();
        this.f3342thooCoci9zae = thoococi9zae;
        ko7aiFeiqu3s ko7aifeiqu3s = keil1eishomu.f3358thooCoci9zae;
        this.f3330Jah0aiP1ki6y = ko7aifeiqu3s == null ? new ieheiQu9sho5() : ko7aifeiqu3s;
        Set set = keil1eishomu.f3349Aicohm8ieYoo;
        if (set != null && !set.isEmpty()) {
            thoococi9zae.addAll(keil1eishomu.f3349Aicohm8ieYoo);
        }
        this.f3336kuedujio7Aev = new ieseir3Choge(this);
        mi5Iecheimie();
    }

    public static boolean Aicohm8ieYoo(InputConnection inputConnection, Editable editable, int i, int i2, boolean z) {
        return androidx.emoji2.text.ohv5Shie7AeZ.thooCoci9zae(inputConnection, editable, i, i2, z);
    }

    public static boolean Jah0aiP1ki6y(Editable editable, int i, KeyEvent keyEvent) {
        return androidx.emoji2.text.ohv5Shie7AeZ.keiL1EiShomu(editable, i, keyEvent);
    }

    public static Aicohm8ieYoo keiL1EiShomu() {
        Aicohm8ieYoo aicohm8ieYoo;
        synchronized (f3326AeJiPo4of6Sh) {
            aicohm8ieYoo = f3327eetheKaevie8;
            ohthie9thieG.ieheiQu9sho5.Aicohm8ieYoo(aicohm8ieYoo != null, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        }
        return aicohm8ieYoo;
    }

    public static Aicohm8ieYoo niah0Shohtha(keiL1EiShomu keil1eishomu) {
        Aicohm8ieYoo aicohm8ieYoo = f3327eetheKaevie8;
        if (aicohm8ieYoo == null) {
            synchronized (f3326AeJiPo4of6Sh) {
                try {
                    aicohm8ieYoo = f3327eetheKaevie8;
                    if (aicohm8ieYoo == null) {
                        aicohm8ieYoo = new Aicohm8ieYoo(keil1eishomu);
                        f3327eetheKaevie8 = aicohm8ieYoo;
                    }
                } finally {
                }
            }
        }
        return aicohm8ieYoo;
    }

    public static boolean ohv5Shie7AeZ() {
        return f3327eetheKaevie8 != null;
    }

    public void AeJiPo4of6Sh() {
        ArrayList arrayList = new ArrayList();
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            this.f3334keiL1EiShomu = 1;
            arrayList.addAll(this.f3342thooCoci9zae);
            this.f3342thooCoci9zae.clear();
            this.f3333ieseir3Choge.writeLock().unlock();
            this.f3332ieheiQu9sho5.post(new Jah0aiP1ki6y(arrayList, this.f3334keiL1EiShomu));
        } catch (Throwable th) {
            this.f3333ieseir3Choge.writeLock().unlock();
            throw th;
        }
    }

    public CharSequence aac1eTaexee6(CharSequence charSequence, int i, int i2, int i3, int i4) {
        boolean z;
        ohthie9thieG.ieheiQu9sho5.Aicohm8ieYoo(ruNgecai1pae(), "Not initialized yet");
        ohthie9thieG.ieheiQu9sho5.keiL1EiShomu(i, "start cannot be negative");
        ohthie9thieG.ieheiQu9sho5.keiL1EiShomu(i2, "end cannot be negative");
        ohthie9thieG.ieheiQu9sho5.keiL1EiShomu(i3, "maxEmojiCount cannot be negative");
        ohthie9thieG.ieheiQu9sho5.ieseir3Choge(i <= i2, "start should be <= than end");
        if (charSequence == null) {
            return null;
        }
        ohthie9thieG.ieheiQu9sho5.ieseir3Choge(i <= charSequence.length(), "start should be < than charSequence length");
        ohthie9thieG.ieheiQu9sho5.ieseir3Choge(i2 <= charSequence.length(), "end should be < than charSequence length");
        if (charSequence.length() == 0 || i == i2) {
            return charSequence;
        }
        if (i4 != 1) {
            z = i4 != 2 ? this.f3338niah0Shohtha : false;
        } else {
            z = true;
        }
        return this.f3336kuedujio7Aev.thooCoci9zae(charSequence, i, i2, i3, z);
    }

    public void ahthoK6usais() {
        ohthie9thieG.ieheiQu9sho5.Aicohm8ieYoo(this.f3337mi5Iecheimie == 1, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        if (ruNgecai1pae()) {
            return;
        }
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            if (this.f3334keiL1EiShomu == 0) {
                return;
            }
            this.f3334keiL1EiShomu = 0;
            this.f3333ieseir3Choge.writeLock().unlock();
            this.f3336kuedujio7Aev.ieseir3Choge();
        } finally {
            this.f3333ieseir3Choge.writeLock().unlock();
        }
    }

    public CharSequence eetheKaevie8(CharSequence charSequence, int i, int i2) {
        return zoojiiKaht3i(charSequence, i, i2, Integer.MAX_VALUE);
    }

    public void esohshee3Pau(EditorInfo editorInfo) {
        if (!ruNgecai1pae() || editorInfo == null) {
            return;
        }
        if (editorInfo.extras == null) {
            editorInfo.extras = new Bundle();
        }
        this.f3336kuedujio7Aev.keiL1EiShomu(editorInfo);
    }

    public int ieheiQu9sho5() {
        return this.f3331ahthoK6usais;
    }

    public boolean ko7aiFeiqu3s() {
        return this.f3340ruNgecai1pae;
    }

    public int kuedujio7Aev() {
        this.f3333ieseir3Choge.readLock().lock();
        try {
            return this.f3334keiL1EiShomu;
        } finally {
            this.f3333ieseir3Choge.readLock().unlock();
        }
    }

    public void laej2zeez5Ja(AbstractC0048Aicohm8ieYoo abstractC0048Aicohm8ieYoo) {
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(abstractC0048Aicohm8ieYoo, "initCallback cannot be null");
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            if (this.f3334keiL1EiShomu != 1 && this.f3334keiL1EiShomu != 2) {
                this.f3342thooCoci9zae.add(abstractC0048Aicohm8ieYoo);
                this.f3333ieseir3Choge.writeLock().unlock();
            }
            this.f3332ieheiQu9sho5.post(new Jah0aiP1ki6y(abstractC0048Aicohm8ieYoo, this.f3334keiL1EiShomu));
            this.f3333ieseir3Choge.writeLock().unlock();
        } catch (Throwable th) {
            this.f3333ieseir3Choge.writeLock().unlock();
            throw th;
        }
    }

    public final void mi5Iecheimie() {
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            if (this.f3337mi5Iecheimie == 0) {
                this.f3334keiL1EiShomu = 0;
            }
            this.f3333ieseir3Choge.writeLock().unlock();
            if (kuedujio7Aev() == 0) {
                this.f3336kuedujio7Aev.ieseir3Choge();
            }
        } catch (Throwable th) {
            this.f3333ieseir3Choge.writeLock().unlock();
            throw th;
        }
    }

    public CharSequence oYe2ma2she1j(CharSequence charSequence) {
        return eetheKaevie8(charSequence, 0, charSequence == null ? 0 : charSequence.length());
    }

    public void rojaiZ9aeRee(AbstractC0048Aicohm8ieYoo abstractC0048Aicohm8ieYoo) {
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(abstractC0048Aicohm8ieYoo, "initCallback cannot be null");
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            this.f3342thooCoci9zae.remove(abstractC0048Aicohm8ieYoo);
        } finally {
            this.f3333ieseir3Choge.writeLock().unlock();
        }
    }

    public final boolean ruNgecai1pae() {
        return kuedujio7Aev() == 1;
    }

    public void ruwiepo7ooVu(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f3333ieseir3Choge.writeLock().lock();
        try {
            this.f3334keiL1EiShomu = 2;
            arrayList.addAll(this.f3342thooCoci9zae);
            this.f3342thooCoci9zae.clear();
            this.f3333ieseir3Choge.writeLock().unlock();
            this.f3332ieheiQu9sho5.post(new Jah0aiP1ki6y(arrayList, this.f3334keiL1EiShomu, th));
        } catch (Throwable th2) {
            this.f3333ieseir3Choge.writeLock().unlock();
            throw th2;
        }
    }

    public CharSequence zoojiiKaht3i(CharSequence charSequence, int i, int i2, int i3) {
        return aac1eTaexee6(charSequence, i, i2, i3, 0);
    }
}
