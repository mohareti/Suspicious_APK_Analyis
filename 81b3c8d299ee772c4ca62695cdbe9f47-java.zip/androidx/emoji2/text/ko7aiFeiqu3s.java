package androidx.emoji2.text;

import android.graphics.Paint;
import android.text.style.ReplacementSpan;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ko7aiFeiqu3s extends ReplacementSpan {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final oYe2ma2she1j f3378thooCoci9zae;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Paint.FontMetricsInt f3375ieseir3Choge = new Paint.FontMetricsInt();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public short f3376keiL1EiShomu = -1;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public short f3374ieheiQu9sho5 = -1;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public float f3377kuedujio7Aev = 1.0f;

    public ko7aiFeiqu3s(oYe2ma2she1j oye2ma2she1j) {
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(oye2ma2she1j, "rasterizer cannot be null");
        this.f3378thooCoci9zae = oye2ma2she1j;
    }

    @Override // android.text.style.ReplacementSpan
    public int getSize(Paint paint, CharSequence charSequence, int i, int i2, Paint.FontMetricsInt fontMetricsInt) {
        paint.getFontMetricsInt(this.f3375ieseir3Choge);
        Paint.FontMetricsInt fontMetricsInt2 = this.f3375ieseir3Choge;
        this.f3377kuedujio7Aev = (Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f) / this.f3378thooCoci9zae.kuedujio7Aev();
        this.f3374ieheiQu9sho5 = (short) (this.f3378thooCoci9zae.kuedujio7Aev() * this.f3377kuedujio7Aev);
        short ohv5Shie7AeZ2 = (short) (this.f3378thooCoci9zae.ohv5Shie7AeZ() * this.f3377kuedujio7Aev);
        this.f3376keiL1EiShomu = ohv5Shie7AeZ2;
        if (fontMetricsInt != null) {
            Paint.FontMetricsInt fontMetricsInt3 = this.f3375ieseir3Choge;
            fontMetricsInt.ascent = fontMetricsInt3.ascent;
            fontMetricsInt.descent = fontMetricsInt3.descent;
            fontMetricsInt.top = fontMetricsInt3.top;
            fontMetricsInt.bottom = fontMetricsInt3.bottom;
        }
        return ohv5Shie7AeZ2;
    }

    public final oYe2ma2she1j ieseir3Choge() {
        return this.f3378thooCoci9zae;
    }

    public final int thooCoci9zae() {
        return this.f3376keiL1EiShomu;
    }
}
