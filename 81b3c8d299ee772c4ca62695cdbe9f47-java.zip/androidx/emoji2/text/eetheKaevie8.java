package androidx.emoji2.text;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.style.CharacterStyle;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eetheKaevie8 extends ko7aiFeiqu3s {

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static Paint f3370Jah0aiP1ki6y;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public TextPaint f3371Aicohm8ieYoo;

    public eetheKaevie8(oYe2ma2she1j oye2ma2she1j) {
        super(oye2ma2she1j);
    }

    public static Paint kuedujio7Aev() {
        if (f3370Jah0aiP1ki6y == null) {
            TextPaint textPaint = new TextPaint();
            f3370Jah0aiP1ki6y = textPaint;
            textPaint.setColor(Aicohm8ieYoo.keiL1EiShomu().ieheiQu9sho5());
            f3370Jah0aiP1ki6y.setStyle(Paint.Style.FILL);
        }
        return f3370Jah0aiP1ki6y;
    }

    @Override // android.text.style.ReplacementSpan
    public void draw(Canvas canvas, CharSequence charSequence, int i, int i2, float f, int i3, int i4, int i5, Paint paint) {
        Paint paint2 = paint;
        TextPaint keiL1EiShomu2 = keiL1EiShomu(charSequence, i, i2, paint2);
        if (keiL1EiShomu2 != null && keiL1EiShomu2.bgColor != 0) {
            ieheiQu9sho5(canvas, keiL1EiShomu2, f, f + thooCoci9zae(), i3, i5);
        }
        if (Aicohm8ieYoo.keiL1EiShomu().ko7aiFeiqu3s()) {
            canvas.drawRect(f, i3, f + thooCoci9zae(), i5, kuedujio7Aev());
        }
        oYe2ma2she1j ieseir3Choge2 = ieseir3Choge();
        float f2 = i4;
        if (keiL1EiShomu2 != null) {
            paint2 = keiL1EiShomu2;
        }
        ieseir3Choge2.ieseir3Choge(canvas, f, f2, paint2);
    }

    public void ieheiQu9sho5(Canvas canvas, TextPaint textPaint, float f, float f2, float f3, float f4) {
        int color = textPaint.getColor();
        Paint.Style style = textPaint.getStyle();
        textPaint.setColor(textPaint.bgColor);
        textPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(f, f3, f2, f4, textPaint);
        textPaint.setStyle(style);
        textPaint.setColor(color);
    }

    public final TextPaint keiL1EiShomu(CharSequence charSequence, int i, int i2, Paint paint) {
        if (!(charSequence instanceof Spanned)) {
            if (paint instanceof TextPaint) {
                return (TextPaint) paint;
            }
            return null;
        }
        CharacterStyle[] characterStyleArr = (CharacterStyle[]) ((Spanned) charSequence).getSpans(i, i2, CharacterStyle.class);
        if (characterStyleArr.length != 0) {
            if (characterStyleArr.length != 1 || characterStyleArr[0] != this) {
                TextPaint textPaint = this.f3371Aicohm8ieYoo;
                if (textPaint == null) {
                    textPaint = new TextPaint();
                    this.f3371Aicohm8ieYoo = textPaint;
                }
                textPaint.set(paint);
                for (CharacterStyle characterStyle : characterStyleArr) {
                    characterStyle.updateDrawState(textPaint);
                }
                return textPaint;
            }
        }
        if (paint instanceof TextPaint) {
            return (TextPaint) paint;
        }
        return null;
    }
}
