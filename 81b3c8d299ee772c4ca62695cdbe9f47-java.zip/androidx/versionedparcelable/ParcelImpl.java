package androidx.versionedparcelable;

import Ohah9Nai3tha.keiL1EiShomu;
import Ohah9Nai3tha.thooCoci9zae;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new ieseir3Choge();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final keiL1EiShomu f3901ieseir3Choge;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge implements Parcelable.Creator {
        @Override // android.os.Parcelable.Creator
        /* renamed from: ieseir3Choge, reason: merged with bridge method [inline-methods] */
        public ParcelImpl createFromParcel(Parcel parcel) {
            return new ParcelImpl(parcel);
        }

        @Override // android.os.Parcelable.Creator
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public ParcelImpl[] newArray(int i) {
            return new ParcelImpl[i];
        }
    }

    public ParcelImpl(Parcel parcel) {
        this.f3901ieseir3Choge = new thooCoci9zae(parcel).rojaiZ9aeRee();
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        new thooCoci9zae(parcel).iecioL2LieVa(this.f3901ieseir3Choge);
    }
}
