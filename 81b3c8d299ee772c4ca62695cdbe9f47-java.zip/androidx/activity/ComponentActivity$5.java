package androidx.activity;

import androidx.lifecycle.Jah0aiP1ki6y;
import androidx.lifecycle.ahthoK6usais;
import androidx.lifecycle.ko7aiFeiqu3s;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
class ComponentActivity$5 implements ko7aiFeiqu3s {
    @Override // androidx.lifecycle.ko7aiFeiqu3s
    public void kuedujio7Aev(ahthoK6usais ahthok6usais, Jah0aiP1ki6y.ieseir3Choge ieseir3choge) {
        throw null;
    }
}
