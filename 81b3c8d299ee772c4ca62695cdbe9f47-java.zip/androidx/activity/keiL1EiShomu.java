package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import thiet5ees7Wu.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public boolean f2876ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public ieth4gahmaH8.ieseir3Choge f2877keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final CopyOnWriteArrayList f2878thooCoci9zae = new CopyOnWriteArrayList();

    public keiL1EiShomu(boolean z) {
        this.f2876ieseir3Choge = z;
    }

    public final void ieseir3Choge() {
        Iterator it = this.f2878thooCoci9zae.iterator();
        while (it.hasNext()) {
            ((ieseir3Choge) it.next()).keiL1EiShomu();
        }
    }

    public final void keiL1EiShomu(boolean z) {
        this.f2876ieseir3Choge = z;
        ieth4gahmaH8.ieseir3Choge ieseir3choge = this.f2877keiL1EiShomu;
        if (ieseir3choge != null) {
            ieseir3choge.ieseir3Choge();
        }
    }

    public final void thooCoci9zae(ieseir3Choge ieseir3choge) {
        Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "cancellable");
        this.f2878thooCoci9zae.remove(ieseir3choge);
    }
}
