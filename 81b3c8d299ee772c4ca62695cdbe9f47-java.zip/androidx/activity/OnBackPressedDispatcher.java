package androidx.activity;

import androidx.lifecycle.Jah0aiP1ki6y;
import androidx.lifecycle.ahthoK6usais;
import androidx.lifecycle.ko7aiFeiqu3s;
import thiet5ees7Wu.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class OnBackPressedDispatcher {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public final class LifecycleOnBackPressedCancellable implements ko7aiFeiqu3s, ieseir3Choge {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final /* synthetic */ OnBackPressedDispatcher f2872ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Jah0aiP1ki6y f2873ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public ieseir3Choge f2874keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final keiL1EiShomu f2875thooCoci9zae;

        @Override // androidx.activity.ieseir3Choge
        public void keiL1EiShomu() {
            this.f2873ieseir3Choge.keiL1EiShomu(this);
            this.f2875thooCoci9zae.thooCoci9zae(this);
            ieseir3Choge ieseir3choge = this.f2874keiL1EiShomu;
            if (ieseir3choge != null) {
                ieseir3choge.keiL1EiShomu();
            }
            this.f2874keiL1EiShomu = null;
        }

        @Override // androidx.lifecycle.ko7aiFeiqu3s
        public void kuedujio7Aev(ahthoK6usais ahthok6usais, Jah0aiP1ki6y.ieseir3Choge ieseir3choge) {
            Aicohm8ieYoo.kuedujio7Aev(ahthok6usais, "source");
            Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "event");
            if (ieseir3choge == Jah0aiP1ki6y.ieseir3Choge.ON_START) {
                this.f2874keiL1EiShomu = this.f2872ieheiQu9sho5.ieseir3Choge(this.f2875thooCoci9zae);
                return;
            }
            if (ieseir3choge != Jah0aiP1ki6y.ieseir3Choge.ON_STOP) {
                if (ieseir3choge == Jah0aiP1ki6y.ieseir3Choge.ON_DESTROY) {
                    keiL1EiShomu();
                }
            } else {
                ieseir3Choge ieseir3choge2 = this.f2874keiL1EiShomu;
                if (ieseir3choge2 != null) {
                    ieseir3choge2.keiL1EiShomu();
                }
            }
        }
    }

    public abstract ieseir3Choge ieseir3Choge(keiL1EiShomu keil1eishomu);
}
