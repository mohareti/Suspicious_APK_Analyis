package androidx.profileinstaller;

import HaeYeFaep1if.ahthoK6usais;
import HaeYeFaep1if.mi5Iecheimie;
import android.content.res.AssetManager;
import android.os.Build;
import androidx.profileinstaller.keiL1EiShomu;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class thooCoci9zae {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final String f3880Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final String f3881Jah0aiP1ki6y;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final AssetManager f3883ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final keiL1EiShomu.InterfaceC0059keiL1EiShomu f3884keiL1EiShomu;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public HaeYeFaep1if.keiL1EiShomu[] f3885ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final File f3886kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final String f3887niah0Shohtha;

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public byte[] f3889ruNgecai1pae;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Executor f3890thooCoci9zae;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public boolean f3888ohv5Shie7AeZ = false;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final byte[] f3882ieheiQu9sho5 = ieheiQu9sho5();

    public thooCoci9zae(AssetManager assetManager, Executor executor, keiL1EiShomu.InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu, String str, String str2, String str3, File file) {
        this.f3883ieseir3Choge = assetManager;
        this.f3890thooCoci9zae = executor;
        this.f3884keiL1EiShomu = interfaceC0059keiL1EiShomu;
        this.f3880Aicohm8ieYoo = str;
        this.f3881Jah0aiP1ki6y = str2;
        this.f3887niah0Shohtha = str3;
        this.f3886kuedujio7Aev = file;
    }

    public static byte[] ieheiQu9sho5() {
        int i = Build.VERSION.SDK_INT;
        if (i < 24 || i > 34) {
            return null;
        }
        switch (i) {
            case 24:
            case 25:
                return mi5Iecheimie.f1505kuedujio7Aev;
            case 26:
                return mi5Iecheimie.f1502ieheiQu9sho5;
            case 27:
                return mi5Iecheimie.f1504keiL1EiShomu;
            case 28:
            case 29:
            case 30:
                return mi5Iecheimie.f1506thooCoci9zae;
            case 31:
            case 32:
            case 33:
            case 34:
                return mi5Iecheimie.f1503ieseir3Choge;
            default:
                return null;
        }
    }

    public static boolean ruNgecai1pae() {
        int i = Build.VERSION.SDK_INT;
        if (i < 24 || i > 34) {
            return false;
        }
        if (i != 24 && i != 25) {
            switch (i) {
                case 31:
                case 32:
                case 33:
                case 34:
                    break;
                default:
                    return false;
            }
        }
        return true;
    }

    public final InputStream Aicohm8ieYoo(AssetManager assetManager) {
        keiL1EiShomu.InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu;
        int i;
        try {
            return niah0Shohtha(assetManager, this.f3881Jah0aiP1ki6y);
        } catch (FileNotFoundException e) {
            e = e;
            interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
            i = 6;
            interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
            return null;
        } catch (IOException e2) {
            e = e2;
            interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
            i = 7;
            interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
            return null;
        }
    }

    public final /* synthetic */ void Jah0aiP1ki6y(int i, Object obj) {
        this.f3884keiL1EiShomu.thooCoci9zae(i, obj);
    }

    public final void ahthoK6usais(final int i, final Object obj) {
        this.f3890thooCoci9zae.execute(new Runnable() { // from class: HaeYeFaep1if.thooCoci9zae
            @Override // java.lang.Runnable
            public final void run() {
                androidx.profileinstaller.thooCoci9zae.this.Jah0aiP1ki6y(i, obj);
            }
        });
    }

    public final void keiL1EiShomu() {
        if (!this.f3888ohv5Shie7AeZ) {
            throw new IllegalStateException("This device doesn't support aot. Did you call deviceSupportsAotProfile()?");
        }
    }

    public final HaeYeFaep1if.keiL1EiShomu[] ko7aiFeiqu3s(InputStream inputStream) {
        try {
            try {
                try {
                    try {
                        HaeYeFaep1if.keiL1EiShomu[] oph9lahCh6uo2 = ahthoK6usais.oph9lahCh6uo(inputStream, ahthoK6usais.AeJiPo4of6Sh(inputStream, ahthoK6usais.f1481ieseir3Choge), this.f3880Aicohm8ieYoo);
                        try {
                            inputStream.close();
                            return oph9lahCh6uo2;
                        } catch (IOException e) {
                            this.f3884keiL1EiShomu.thooCoci9zae(7, e);
                            return oph9lahCh6uo2;
                        }
                    } catch (IOException e2) {
                        this.f3884keiL1EiShomu.thooCoci9zae(7, e2);
                        return null;
                    }
                } catch (IllegalStateException e3) {
                    this.f3884keiL1EiShomu.thooCoci9zae(8, e3);
                    inputStream.close();
                    return null;
                }
            } catch (IOException e4) {
                this.f3884keiL1EiShomu.thooCoci9zae(7, e4);
                inputStream.close();
                return null;
            }
        } catch (Throwable th) {
            try {
                inputStream.close();
            } catch (IOException e5) {
                this.f3884keiL1EiShomu.thooCoci9zae(7, e5);
            }
            throw th;
        }
    }

    public boolean kuedujio7Aev() {
        if (this.f3882ieheiQu9sho5 == null) {
            ahthoK6usais(3, Integer.valueOf(Build.VERSION.SDK_INT));
            return false;
        }
        if (!this.f3886kuedujio7Aev.exists()) {
            try {
                this.f3886kuedujio7Aev.createNewFile();
            } catch (IOException unused) {
                ahthoK6usais(4, null);
                return false;
            }
        } else if (!this.f3886kuedujio7Aev.canWrite()) {
            ahthoK6usais(4, null);
            return false;
        }
        this.f3888ohv5Shie7AeZ = true;
        return true;
    }

    public thooCoci9zae mi5Iecheimie() {
        keiL1EiShomu.InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu;
        int i;
        ByteArrayOutputStream byteArrayOutputStream;
        HaeYeFaep1if.keiL1EiShomu[] keil1eishomuArr = this.f3885ko7aiFeiqu3s;
        byte[] bArr = this.f3882ieheiQu9sho5;
        if (keil1eishomuArr != null && bArr != null) {
            keiL1EiShomu();
            try {
                byteArrayOutputStream = new ByteArrayOutputStream();
                try {
                    ahthoK6usais.IengaiSahh8H(byteArrayOutputStream, bArr);
                } catch (Throwable th) {
                    try {
                        byteArrayOutputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } catch (IOException e) {
                e = e;
                interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
                i = 7;
                interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
                this.f3885ko7aiFeiqu3s = null;
                return this;
            } catch (IllegalStateException e2) {
                e = e2;
                interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
                i = 8;
                interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
                this.f3885ko7aiFeiqu3s = null;
                return this;
            }
            if (!ahthoK6usais.ahz5eechei8U(byteArrayOutputStream, bArr, keil1eishomuArr)) {
                this.f3884keiL1EiShomu.thooCoci9zae(5, null);
                this.f3885ko7aiFeiqu3s = null;
                byteArrayOutputStream.close();
                return this;
            }
            this.f3889ruNgecai1pae = byteArrayOutputStream.toByteArray();
            byteArrayOutputStream.close();
            this.f3885ko7aiFeiqu3s = null;
        }
        return this;
    }

    public final InputStream niah0Shohtha(AssetManager assetManager, String str) {
        try {
            return assetManager.openFd(str).createInputStream();
        } catch (FileNotFoundException e) {
            String message = e.getMessage();
            if (message != null && message.contains("compressed")) {
                this.f3884keiL1EiShomu.ieseir3Choge(5, null);
            }
            return null;
        }
    }

    public thooCoci9zae ohv5Shie7AeZ() {
        thooCoci9zae thooCoci9zae2;
        keiL1EiShomu();
        if (this.f3882ieheiQu9sho5 == null) {
            return this;
        }
        InputStream Aicohm8ieYoo2 = Aicohm8ieYoo(this.f3883ieseir3Choge);
        if (Aicohm8ieYoo2 != null) {
            this.f3885ko7aiFeiqu3s = ko7aiFeiqu3s(Aicohm8ieYoo2);
        }
        HaeYeFaep1if.keiL1EiShomu[] keil1eishomuArr = this.f3885ko7aiFeiqu3s;
        return (keil1eishomuArr == null || !ruNgecai1pae() || (thooCoci9zae2 = thooCoci9zae(keil1eishomuArr, this.f3882ieheiQu9sho5)) == null) ? this : thooCoci9zae2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public boolean ruwiepo7ooVu() {
        byte[] bArr = this.f3889ruNgecai1pae;
        if (bArr == null) {
            return false;
        }
        keiL1EiShomu();
        try {
            try {
                ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(this.f3886kuedujio7Aev);
                    try {
                        HaeYeFaep1if.ieheiQu9sho5.ahthoK6usais(byteArrayInputStream, fileOutputStream);
                        ahthoK6usais(1, null);
                        fileOutputStream.close();
                        byteArrayInputStream.close();
                        return true;
                    } finally {
                    }
                } catch (Throwable th) {
                    try {
                        byteArrayInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } finally {
                this.f3889ruNgecai1pae = null;
                this.f3885ko7aiFeiqu3s = null;
            }
        } catch (FileNotFoundException e) {
            ahthoK6usais(6, e);
            return false;
        } catch (IOException e2) {
            ahthoK6usais(7, e2);
            return false;
        }
    }

    public final thooCoci9zae thooCoci9zae(HaeYeFaep1if.keiL1EiShomu[] keil1eishomuArr, byte[] bArr) {
        keiL1EiShomu.InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu;
        int i;
        InputStream niah0Shohtha2;
        try {
            niah0Shohtha2 = niah0Shohtha(this.f3883ieseir3Choge, this.f3887niah0Shohtha);
        } catch (FileNotFoundException e) {
            e = e;
            interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
            i = 9;
            interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
            return null;
        } catch (IOException e2) {
            e = e2;
            interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
            i = 7;
            interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
            return null;
        } catch (IllegalStateException e3) {
            e = e3;
            this.f3885ko7aiFeiqu3s = null;
            interfaceC0059keiL1EiShomu = this.f3884keiL1EiShomu;
            i = 8;
            interfaceC0059keiL1EiShomu.thooCoci9zae(i, e);
            return null;
        }
        if (niah0Shohtha2 != null) {
            try {
                this.f3885ko7aiFeiqu3s = ahthoK6usais.eetheKaevie8(niah0Shohtha2, ahthoK6usais.AeJiPo4of6Sh(niah0Shohtha2, ahthoK6usais.f1482thooCoci9zae), bArr, keil1eishomuArr);
                niah0Shohtha2.close();
                return this;
            } catch (Throwable th) {
                try {
                    niah0Shohtha2.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
        if (niah0Shohtha2 != null) {
            niah0Shohtha2.close();
        }
        return null;
    }
}
