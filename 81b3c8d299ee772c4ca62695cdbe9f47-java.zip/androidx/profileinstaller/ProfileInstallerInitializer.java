package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import androidx.profileinstaller.ProfileInstallerInitializer;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ProfileInstallerInitializer implements lo8zieZoeseb.thooCoci9zae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static void keiL1EiShomu(final Runnable runnable) {
            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() { // from class: HaeYeFaep1if.ruNgecai1pae
                @Override // android.view.Choreographer.FrameCallback
                public final void doFrame(long j) {
                    runnable.run();
                }
            });
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {
        public static Handler ieseir3Choge(Looper looper) {
            Handler createAsync;
            createAsync = Handler.createAsync(looper);
            return createAsync;
        }
    }

    public static void ahthoK6usais(final Context context) {
        new ThreadPoolExecutor(0, 1, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue()).execute(new Runnable() { // from class: HaeYeFaep1if.ko7aiFeiqu3s
            @Override // java.lang.Runnable
            public final void run() {
                androidx.profileinstaller.keiL1EiShomu.ohv5Shie7AeZ(context);
            }
        });
    }

    @Override // lo8zieZoeseb.thooCoci9zae
    /* renamed from: Aicohm8ieYoo, reason: merged with bridge method [inline-methods] */
    public keiL1EiShomu thooCoci9zae(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return new keiL1EiShomu();
        }
        Jah0aiP1ki6y(context.getApplicationContext());
        return new keiL1EiShomu();
    }

    public void Jah0aiP1ki6y(final Context context) {
        ieseir3Choge.keiL1EiShomu(new Runnable() { // from class: HaeYeFaep1if.niah0Shohtha
            @Override // java.lang.Runnable
            public final void run() {
                ProfileInstallerInitializer.this.ohv5Shie7AeZ(context);
            }
        });
    }

    @Override // lo8zieZoeseb.thooCoci9zae
    public List ieseir3Choge() {
        return Collections.emptyList();
    }

    /* renamed from: niah0Shohtha, reason: merged with bridge method [inline-methods] */
    public void ohv5Shie7AeZ(final Context context) {
        (Build.VERSION.SDK_INT >= 28 ? thooCoci9zae.ieseir3Choge(Looper.getMainLooper()) : new Handler(Looper.getMainLooper())).postDelayed(new Runnable() { // from class: HaeYeFaep1if.ohv5Shie7AeZ
            @Override // java.lang.Runnable
            public final void run() {
                ProfileInstallerInitializer.ahthoK6usais(context);
            }
        }, new Random().nextInt(Math.max(1000, 1)) + 5000);
    }
}
