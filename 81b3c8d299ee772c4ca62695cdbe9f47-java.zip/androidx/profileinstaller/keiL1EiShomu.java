package androidx.profileinstaller;

import HaeYeFaep1if.Aicohm8ieYoo;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.util.Log;
import androidx.profileinstaller.keiL1EiShomu;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.Executor;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.user.DeviceProto;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final InterfaceC0059keiL1EiShomu f3878ieseir3Choge = new ieseir3Choge();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final InterfaceC0059keiL1EiShomu f3879thooCoci9zae = new thooCoci9zae();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements InterfaceC0059keiL1EiShomu {
        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void ieseir3Choge(int i, Object obj) {
        }

        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void thooCoci9zae(int i, Object obj) {
        }
    }

    /* renamed from: androidx.profileinstaller.keiL1EiShomu$keiL1EiShomu, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface InterfaceC0059keiL1EiShomu {
        void ieseir3Choge(int i, Object obj);

        void thooCoci9zae(int i, Object obj);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class thooCoci9zae implements InterfaceC0059keiL1EiShomu {
        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void ieseir3Choge(int i, Object obj) {
            Log.d("ProfileInstaller", i != 1 ? i != 2 ? i != 3 ? i != 4 ? i != 5 ? BuildConfig.FLAVOR : "DIAGNOSTIC_PROFILE_IS_COMPRESSED" : "DIAGNOSTIC_REF_PROFILE_DOES_NOT_EXIST" : "DIAGNOSTIC_REF_PROFILE_EXISTS" : "DIAGNOSTIC_CURRENT_PROFILE_DOES_NOT_EXIST" : "DIAGNOSTIC_CURRENT_PROFILE_EXISTS");
        }

        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void thooCoci9zae(int i, Object obj) {
            String str;
            switch (i) {
                case 1:
                    str = "RESULT_INSTALL_SUCCESS";
                    break;
                case 2:
                    str = "RESULT_ALREADY_INSTALLED";
                    break;
                case 3:
                    str = "RESULT_UNSUPPORTED_ART_VERSION";
                    break;
                case 4:
                    str = "RESULT_NOT_WRITABLE";
                    break;
                case 5:
                    str = "RESULT_DESIRED_FORMAT_UNSUPPORTED";
                    break;
                case DeviceProto.MAXCPUFREQUENCY_FIELD_NUMBER /* 6 */:
                    str = "RESULT_BASELINE_PROFILE_NOT_FOUND";
                    break;
                case DeviceProto.NUMOFCORES_FIELD_NUMBER /* 7 */:
                    str = "RESULT_IO_EXCEPTION";
                    break;
                case 8:
                    str = "RESULT_PARSE_EXCEPTION";
                    break;
                case 9:
                default:
                    str = BuildConfig.FLAVOR;
                    break;
                case 10:
                    str = "RESULT_INSTALL_SKIP_FILE_SUCCESS";
                    break;
                case 11:
                    str = "RESULT_DELETE_SKIP_FILE_SUCCESS";
                    break;
            }
            if (i == 6 || i == 7 || i == 8) {
                Log.e("ProfileInstaller", str, (Throwable) obj);
            } else {
                Log.d("ProfileInstaller", str);
            }
        }
    }

    public static void Aicohm8ieYoo(PackageInfo packageInfo, File file) {
        try {
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(new File(file, "profileinstaller_profileWrittenFor_lastUpdateTime.dat")));
            try {
                dataOutputStream.writeLong(packageInfo.lastUpdateTime);
                dataOutputStream.close();
            } finally {
            }
        } catch (IOException unused) {
        }
    }

    public static void Jah0aiP1ki6y(Executor executor, final InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu, final int i, final Object obj) {
        executor.execute(new Runnable() { // from class: HaeYeFaep1if.Jah0aiP1ki6y
            @Override // java.lang.Runnable
            public final void run() {
                keiL1EiShomu.InterfaceC0059keiL1EiShomu.this.thooCoci9zae(i, obj);
            }
        });
    }

    public static void ahthoK6usais(Context context, Executor executor, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        try {
            Aicohm8ieYoo(context.getPackageManager().getPackageInfo(context.getApplicationContext().getPackageName(), 0), context.getFilesDir());
            Jah0aiP1ki6y(executor, interfaceC0059keiL1EiShomu, 10, null);
        } catch (PackageManager.NameNotFoundException e) {
            Jah0aiP1ki6y(executor, interfaceC0059keiL1EiShomu, 7, e);
        }
    }

    public static boolean ieheiQu9sho5(PackageInfo packageInfo, File file, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        File file2 = new File(file, "profileinstaller_profileWrittenFor_lastUpdateTime.dat");
        if (!file2.exists()) {
            return false;
        }
        try {
            DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file2));
            try {
                long readLong = dataInputStream.readLong();
                dataInputStream.close();
                boolean z = readLong == packageInfo.lastUpdateTime;
                if (z) {
                    interfaceC0059keiL1EiShomu.thooCoci9zae(2, null);
                }
                return z;
            } finally {
            }
        } catch (IOException unused) {
            return false;
        }
    }

    public static void keiL1EiShomu(Context context, Executor executor, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        thooCoci9zae(context.getFilesDir());
        Jah0aiP1ki6y(executor, interfaceC0059keiL1EiShomu, 11, null);
    }

    public static void ko7aiFeiqu3s(Context context, Executor executor, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        ruNgecai1pae(context, executor, interfaceC0059keiL1EiShomu, false);
    }

    public static boolean niah0Shohtha(AssetManager assetManager, String str, PackageInfo packageInfo, File file, String str2, Executor executor, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        androidx.profileinstaller.thooCoci9zae thoococi9zae = new androidx.profileinstaller.thooCoci9zae(assetManager, executor, interfaceC0059keiL1EiShomu, str2, "dexopt/baseline.prof", "dexopt/baseline.profm", new File(new File("/data/misc/profiles/cur/0", str), "primary.prof"));
        if (!thoococi9zae.kuedujio7Aev()) {
            return false;
        }
        boolean ruwiepo7ooVu2 = thoococi9zae.ohv5Shie7AeZ().mi5Iecheimie().ruwiepo7ooVu();
        if (ruwiepo7ooVu2) {
            Aicohm8ieYoo(packageInfo, file);
        }
        return ruwiepo7ooVu2;
    }

    public static void ohv5Shie7AeZ(Context context) {
        ko7aiFeiqu3s(context, new Aicohm8ieYoo(), f3878ieseir3Choge);
    }

    public static void ruNgecai1pae(Context context, Executor executor, InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu, boolean z) {
        Context applicationContext = context.getApplicationContext();
        String packageName = applicationContext.getPackageName();
        ApplicationInfo applicationInfo = applicationContext.getApplicationInfo();
        AssetManager assets = applicationContext.getAssets();
        String name = new File(applicationInfo.sourceDir).getName();
        boolean z2 = false;
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
            File filesDir = context.getFilesDir();
            if (z || !ieheiQu9sho5(packageInfo, filesDir, interfaceC0059keiL1EiShomu)) {
                Log.d("ProfileInstaller", "Installing profile for " + context.getPackageName());
                if (niah0Shohtha(assets, packageName, packageInfo, filesDir, name, executor, interfaceC0059keiL1EiShomu) && z) {
                    z2 = true;
                }
            } else {
                Log.d("ProfileInstaller", "Skipping profile installation for " + context.getPackageName());
            }
            ieheiQu9sho5.keiL1EiShomu(context, z2);
        } catch (PackageManager.NameNotFoundException e) {
            interfaceC0059keiL1EiShomu.thooCoci9zae(7, e);
            ieheiQu9sho5.keiL1EiShomu(context, false);
        }
    }

    public static boolean thooCoci9zae(File file) {
        return new File(file, "profileinstaller_profileWrittenFor_lastUpdateTime.dat").delete();
    }
}
