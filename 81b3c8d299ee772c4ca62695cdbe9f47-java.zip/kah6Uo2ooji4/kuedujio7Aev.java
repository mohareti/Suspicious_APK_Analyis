package kah6Uo2ooji4;

import android.view.View;
import android.widget.PopupWindow;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class kuedujio7Aev {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static void ieheiQu9sho5(PopupWindow popupWindow, int i) {
            popupWindow.setWindowLayoutType(i);
        }

        public static boolean ieseir3Choge(PopupWindow popupWindow) {
            return popupWindow.getOverlapAnchor();
        }

        public static void keiL1EiShomu(PopupWindow popupWindow, boolean z) {
            popupWindow.setOverlapAnchor(z);
        }

        public static int thooCoci9zae(PopupWindow popupWindow) {
            return popupWindow.getWindowLayoutType();
        }
    }

    public static void ieseir3Choge(PopupWindow popupWindow, boolean z) {
        ieseir3Choge.keiL1EiShomu(popupWindow, z);
    }

    public static void keiL1EiShomu(PopupWindow popupWindow, View view, int i, int i2, int i3) {
        popupWindow.showAsDropDown(view, i, i2, i3);
    }

    public static void thooCoci9zae(PopupWindow popupWindow, int i) {
        ieseir3Choge.ieheiQu9sho5(popupWindow, i);
    }
}
