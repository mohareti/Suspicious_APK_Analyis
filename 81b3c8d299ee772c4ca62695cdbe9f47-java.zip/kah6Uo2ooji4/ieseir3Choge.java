package kah6Uo2ooji4;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import eyei9eigh3Ie.ohthie9thieG;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieseir3Choge implements View.OnTouchListener {

    /* renamed from: zoojiiKaht3i, reason: collision with root package name */
    public static final int f6916zoojiiKaht3i = ViewConfiguration.getTapTimeout();

    /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
    public boolean f6917AeJiPo4of6Sh;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public int f6919Jah0aiP1ki6y;

    /* renamed from: ahthoK6usais, reason: collision with root package name */
    public boolean f6920ahthoK6usais;

    /* renamed from: eetheKaevie8, reason: collision with root package name */
    public boolean f6921eetheKaevie8;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public Runnable f6922ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final View f6924keiL1EiShomu;

    /* renamed from: mi5Iecheimie, reason: collision with root package name */
    public boolean f6927mi5Iecheimie;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public int f6928niah0Shohtha;

    /* renamed from: oYe2ma2she1j, reason: collision with root package name */
    public boolean f6929oYe2ma2she1j;

    /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
    public boolean f6932ruwiepo7ooVu;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final C0095ieseir3Choge f6923ieseir3Choge = new C0095ieseir3Choge();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Interpolator f6933thooCoci9zae = new AccelerateInterpolator();

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public float[] f6926kuedujio7Aev = {0.0f, 0.0f};

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public float[] f6918Aicohm8ieYoo = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public float[] f6930ohv5Shie7AeZ = {0.0f, 0.0f};

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public float[] f6925ko7aiFeiqu3s = {0.0f, 0.0f};

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public float[] f6931ruNgecai1pae = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* renamed from: kah6Uo2ooji4.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0095ieseir3Choge {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public float f6936ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public int f6937ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public float f6938keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public float f6939ko7aiFeiqu3s;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public int f6943ruNgecai1pae;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public int f6944thooCoci9zae;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public long f6940kuedujio7Aev = Long.MIN_VALUE;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public long f6942ohv5Shie7AeZ = -1;

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public long f6934Aicohm8ieYoo = 0;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public int f6935Jah0aiP1ki6y = 0;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public int f6941niah0Shohtha = 0;

        public int Aicohm8ieYoo() {
            float f = this.f6936ieheiQu9sho5;
            return (int) (f / Math.abs(f));
        }

        public final float Jah0aiP1ki6y(float f) {
            return ((-4.0f) * f * f) + (f * 4.0f);
        }

        public void ahthoK6usais(float f, float f2) {
            this.f6938keiL1EiShomu = f;
            this.f6936ieheiQu9sho5 = f2;
        }

        public int ieheiQu9sho5() {
            float f = this.f6938keiL1EiShomu;
            return (int) (f / Math.abs(f));
        }

        public void ieseir3Choge() {
            if (this.f6934Aicohm8ieYoo != 0) {
                long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
                float Jah0aiP1ki6y2 = Jah0aiP1ki6y(kuedujio7Aev(currentAnimationTimeMillis));
                long j = currentAnimationTimeMillis - this.f6934Aicohm8ieYoo;
                this.f6934Aicohm8ieYoo = currentAnimationTimeMillis;
                float f = ((float) j) * Jah0aiP1ki6y2;
                this.f6935Jah0aiP1ki6y = (int) (this.f6938keiL1EiShomu * f);
                this.f6941niah0Shohtha = (int) (f * this.f6936ieheiQu9sho5);
                return;
            }
            throw new RuntimeException("Cannot compute scroll delta before calling start()");
        }

        public int keiL1EiShomu() {
            return this.f6941niah0Shohtha;
        }

        public void ko7aiFeiqu3s(int i) {
            this.f6944thooCoci9zae = i;
        }

        public final float kuedujio7Aev(long j) {
            long j2 = this.f6940kuedujio7Aev;
            if (j < j2) {
                return 0.0f;
            }
            long j3 = this.f6942ohv5Shie7AeZ;
            if (j3 >= 0 && j >= j3) {
                float f = this.f6939ko7aiFeiqu3s;
                return (1.0f - f) + (f * ieseir3Choge.kuedujio7Aev(((float) (j - j3)) / this.f6943ruNgecai1pae, 0.0f, 1.0f));
            }
            return ieseir3Choge.kuedujio7Aev(((float) (j - j2)) / this.f6937ieseir3Choge, 0.0f, 1.0f) * 0.5f;
        }

        public void mi5Iecheimie() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f6940kuedujio7Aev = currentAnimationTimeMillis;
            this.f6942ohv5Shie7AeZ = -1L;
            this.f6934Aicohm8ieYoo = currentAnimationTimeMillis;
            this.f6939ko7aiFeiqu3s = 0.5f;
            this.f6935Jah0aiP1ki6y = 0;
            this.f6941niah0Shohtha = 0;
        }

        public boolean niah0Shohtha() {
            if (this.f6942ohv5Shie7AeZ > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f6942ohv5Shie7AeZ + this.f6943ruNgecai1pae) {
                return true;
            }
            return false;
        }

        public void ohv5Shie7AeZ() {
            long currentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f6943ruNgecai1pae = ieseir3Choge.Aicohm8ieYoo((int) (currentAnimationTimeMillis - this.f6940kuedujio7Aev), 0, this.f6944thooCoci9zae);
            this.f6939ko7aiFeiqu3s = kuedujio7Aev(currentAnimationTimeMillis);
            this.f6942ohv5Shie7AeZ = currentAnimationTimeMillis;
        }

        public void ruNgecai1pae(int i) {
            this.f6937ieseir3Choge = i;
        }

        public int thooCoci9zae() {
            return this.f6935Jah0aiP1ki6y;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class thooCoci9zae implements Runnable {
        public thooCoci9zae() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ieseir3Choge ieseir3choge = ieseir3Choge.this;
            if (!ieseir3choge.f6917AeJiPo4of6Sh) {
                return;
            }
            if (ieseir3choge.f6927mi5Iecheimie) {
                ieseir3choge.f6927mi5Iecheimie = false;
                ieseir3choge.f6923ieseir3Choge.mi5Iecheimie();
            }
            C0095ieseir3Choge c0095ieseir3Choge = ieseir3Choge.this.f6923ieseir3Choge;
            if (!c0095ieseir3Choge.niah0Shohtha() && ieseir3Choge.this.rojaiZ9aeRee()) {
                ieseir3Choge ieseir3choge2 = ieseir3Choge.this;
                if (ieseir3choge2.f6932ruwiepo7ooVu) {
                    ieseir3choge2.f6932ruwiepo7ooVu = false;
                    ieseir3choge2.keiL1EiShomu();
                }
                c0095ieseir3Choge.ieseir3Choge();
                ieseir3Choge.this.ko7aiFeiqu3s(c0095ieseir3Choge.thooCoci9zae(), c0095ieseir3Choge.keiL1EiShomu());
                ohthie9thieG.oph9lahCh6uo(ieseir3Choge.this.f6924keiL1EiShomu, this);
                return;
            }
            ieseir3Choge.this.f6917AeJiPo4of6Sh = false;
        }
    }

    public ieseir3Choge(View view) {
        this.f6924keiL1EiShomu = view;
        float f = Resources.getSystem().getDisplayMetrics().density;
        float f2 = (int) ((1575.0f * f) + 0.5f);
        AeJiPo4of6Sh(f2, f2);
        float f3 = (int) ((f * 315.0f) + 0.5f);
        oYe2ma2she1j(f3, f3);
        ahthoK6usais(1);
        ruwiepo7ooVu(Float.MAX_VALUE, Float.MAX_VALUE);
        aac1eTaexee6(0.2f, 0.2f);
        laej2zeez5Ja(1.0f, 1.0f);
        ruNgecai1pae(f6916zoojiiKaht3i);
        zoojiiKaht3i(500);
        eetheKaevie8(500);
    }

    public static int Aicohm8ieYoo(int i, int i2, int i3) {
        if (i > i3) {
            return i3;
        }
        if (i < i2) {
            return i2;
        }
        return i;
    }

    public static float kuedujio7Aev(float f, float f2, float f3) {
        if (f > f3) {
            return f3;
        }
        if (f < f2) {
            return f2;
        }
        return f;
    }

    public ieseir3Choge AeJiPo4of6Sh(float f, float f2) {
        float[] fArr = this.f6931ruNgecai1pae;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public final float Jah0aiP1ki6y(float f, float f2) {
        if (f2 == 0.0f) {
            return 0.0f;
        }
        int i = this.f6919Jah0aiP1ki6y;
        if (i != 0 && i != 1) {
            if (i == 2 && f < 0.0f) {
                return f / (-f2);
            }
        } else if (f < f2) {
            if (f >= 0.0f) {
                return 1.0f - (f / f2);
            }
            if (this.f6917AeJiPo4of6Sh && i == 1) {
                return 1.0f;
            }
        }
        return 0.0f;
    }

    public ieseir3Choge aac1eTaexee6(float f, float f2) {
        float[] fArr = this.f6926kuedujio7Aev;
        fArr[0] = f;
        fArr[1] = f2;
        return this;
    }

    public ieseir3Choge ahthoK6usais(int i) {
        this.f6919Jah0aiP1ki6y = i;
        return this;
    }

    public ieseir3Choge eetheKaevie8(int i) {
        this.f6923ieseir3Choge.ko7aiFeiqu3s(i);
        return this;
    }

    public final void esohshee3Pau() {
        int i;
        if (this.f6922ieheiQu9sho5 == null) {
            this.f6922ieheiQu9sho5 = new thooCoci9zae();
        }
        this.f6917AeJiPo4of6Sh = true;
        this.f6927mi5Iecheimie = true;
        if (!this.f6920ahthoK6usais && (i = this.f6928niah0Shohtha) > 0) {
            ohthie9thieG.ohthie9thieG(this.f6924keiL1EiShomu, this.f6922ieheiQu9sho5, i);
        } else {
            this.f6922ieheiQu9sho5.run();
        }
        this.f6920ahthoK6usais = true;
    }

    public final float ieheiQu9sho5(int i, float f, float f2, float f3) {
        float niah0Shohtha2 = niah0Shohtha(this.f6926kuedujio7Aev[i], f2, this.f6918Aicohm8ieYoo[i], f);
        if (niah0Shohtha2 == 0.0f) {
            return 0.0f;
        }
        float f4 = this.f6930ohv5Shie7AeZ[i];
        float f5 = this.f6925ko7aiFeiqu3s[i];
        float f6 = this.f6931ruNgecai1pae[i];
        float f7 = f4 * f3;
        if (niah0Shohtha2 > 0.0f) {
            return kuedujio7Aev(niah0Shohtha2 * f7, f5, f6);
        }
        return -kuedujio7Aev((-niah0Shohtha2) * f7, f5, f6);
    }

    public abstract boolean ieseir3Choge(int i);

    public void keiL1EiShomu() {
        long uptimeMillis = SystemClock.uptimeMillis();
        MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
        this.f6924keiL1EiShomu.onTouchEvent(obtain);
        obtain.recycle();
    }

    public abstract void ko7aiFeiqu3s(int i, int i2);

    public ieseir3Choge laej2zeez5Ja(float f, float f2) {
        float[] fArr = this.f6930ohv5Shie7AeZ;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public ieseir3Choge mi5Iecheimie(boolean z) {
        if (this.f6929oYe2ma2she1j && !z) {
            ohv5Shie7AeZ();
        }
        this.f6929oYe2ma2she1j = z;
        return this;
    }

    public final float niah0Shohtha(float f, float f2, float f3, float f4) {
        float interpolation;
        float kuedujio7Aev2 = kuedujio7Aev(f * f2, 0.0f, f3);
        float Jah0aiP1ki6y2 = Jah0aiP1ki6y(f2 - f4, kuedujio7Aev2) - Jah0aiP1ki6y(f4, kuedujio7Aev2);
        if (Jah0aiP1ki6y2 < 0.0f) {
            interpolation = -this.f6933thooCoci9zae.getInterpolation(-Jah0aiP1ki6y2);
        } else {
            if (Jah0aiP1ki6y2 <= 0.0f) {
                return 0.0f;
            }
            interpolation = this.f6933thooCoci9zae.getInterpolation(Jah0aiP1ki6y2);
        }
        return kuedujio7Aev(interpolation, -1.0f, 1.0f);
    }

    public ieseir3Choge oYe2ma2she1j(float f, float f2) {
        float[] fArr = this.f6925ko7aiFeiqu3s;
        fArr[0] = f / 1000.0f;
        fArr[1] = f2 / 1000.0f;
        return this;
    }

    public final void ohv5Shie7AeZ() {
        if (this.f6927mi5Iecheimie) {
            this.f6917AeJiPo4of6Sh = false;
        } else {
            this.f6923ieseir3Choge.ohv5Shie7AeZ();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x0013, code lost:
    
        if (r0 != 3) goto L20;
     */
    @Override // android.view.View.OnTouchListener
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.f6929oYe2ma2she1j) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked != 1) {
                if (actionMasked != 2) {
                }
            }
            ohv5Shie7AeZ();
            if (!this.f6921eetheKaevie8 && this.f6917AeJiPo4of6Sh) {
                return true;
            }
        }
        this.f6932ruwiepo7ooVu = true;
        this.f6920ahthoK6usais = false;
        this.f6923ieseir3Choge.ahthoK6usais(ieheiQu9sho5(0, motionEvent.getX(), view.getWidth(), this.f6924keiL1EiShomu.getWidth()), ieheiQu9sho5(1, motionEvent.getY(), view.getHeight(), this.f6924keiL1EiShomu.getHeight()));
        if (!this.f6917AeJiPo4of6Sh && rojaiZ9aeRee()) {
            esohshee3Pau();
        }
        return !this.f6921eetheKaevie8 ? false : false;
    }

    public boolean rojaiZ9aeRee() {
        C0095ieseir3Choge c0095ieseir3Choge = this.f6923ieseir3Choge;
        int Aicohm8ieYoo2 = c0095ieseir3Choge.Aicohm8ieYoo();
        int ieheiQu9sho52 = c0095ieseir3Choge.ieheiQu9sho5();
        if ((Aicohm8ieYoo2 != 0 && thooCoci9zae(Aicohm8ieYoo2)) || (ieheiQu9sho52 != 0 && ieseir3Choge(ieheiQu9sho52))) {
            return true;
        }
        return false;
    }

    public ieseir3Choge ruNgecai1pae(int i) {
        this.f6928niah0Shohtha = i;
        return this;
    }

    public ieseir3Choge ruwiepo7ooVu(float f, float f2) {
        float[] fArr = this.f6918Aicohm8ieYoo;
        fArr[0] = f;
        fArr[1] = f2;
        return this;
    }

    public abstract boolean thooCoci9zae(int i);

    public ieseir3Choge zoojiiKaht3i(int i) {
        this.f6923ieseir3Choge.ruNgecai1pae(i);
        return this;
    }
}
