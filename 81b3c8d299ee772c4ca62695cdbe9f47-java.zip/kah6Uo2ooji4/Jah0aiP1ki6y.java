package kah6Uo2ooji4;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface Jah0aiP1ki6y {
    void setSupportCompoundDrawablesTintList(ColorStateList colorStateList);

    void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode);
}
