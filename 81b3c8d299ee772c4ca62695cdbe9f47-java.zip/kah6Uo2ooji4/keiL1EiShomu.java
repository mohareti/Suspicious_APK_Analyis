package kah6Uo2ooji4;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.widget.ImageView;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static void ieheiQu9sho5(ImageView imageView, PorterDuff.Mode mode) {
            imageView.setImageTintMode(mode);
        }

        public static ColorStateList ieseir3Choge(ImageView imageView) {
            return imageView.getImageTintList();
        }

        public static void keiL1EiShomu(ImageView imageView, ColorStateList colorStateList) {
            imageView.setImageTintList(colorStateList);
        }

        public static PorterDuff.Mode thooCoci9zae(ImageView imageView) {
            return imageView.getImageTintMode();
        }
    }

    public static void ieheiQu9sho5(ImageView imageView, PorterDuff.Mode mode) {
        ieseir3Choge.ieheiQu9sho5(imageView, mode);
    }

    public static ColorStateList ieseir3Choge(ImageView imageView) {
        return ieseir3Choge.ieseir3Choge(imageView);
    }

    public static void keiL1EiShomu(ImageView imageView, ColorStateList colorStateList) {
        ieseir3Choge.keiL1EiShomu(imageView, colorStateList);
    }

    public static PorterDuff.Mode thooCoci9zae(ImageView imageView) {
        return ieseir3Choge.thooCoci9zae(imageView);
    }
}
