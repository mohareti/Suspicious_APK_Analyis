package kah6Uo2ooji4;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.EdgeEffect;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class thooCoci9zae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static void ieseir3Choge(EdgeEffect edgeEffect, float f, float f2) {
            edgeEffect.onPull(f, f2);
        }
    }

    /* renamed from: kah6Uo2ooji4.thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0096thooCoci9zae {
        public static EdgeEffect ieseir3Choge(Context context, AttributeSet attributeSet) {
            try {
                return new EdgeEffect(context, attributeSet);
            } catch (Throwable unused) {
                return new EdgeEffect(context);
            }
        }

        public static float keiL1EiShomu(EdgeEffect edgeEffect, float f, float f2) {
            try {
                return edgeEffect.onPullDistance(f, f2);
            } catch (Throwable unused) {
                edgeEffect.onPull(f, f2);
                return 0.0f;
            }
        }

        public static float thooCoci9zae(EdgeEffect edgeEffect) {
            try {
                return edgeEffect.getDistance();
            } catch (Throwable unused) {
                return 0.0f;
            }
        }
    }

    public static float ieheiQu9sho5(EdgeEffect edgeEffect, float f, float f2) {
        if (Build.VERSION.SDK_INT >= 31) {
            return C0096thooCoci9zae.keiL1EiShomu(edgeEffect, f, f2);
        }
        keiL1EiShomu(edgeEffect, f, f2);
        return f;
    }

    public static EdgeEffect ieseir3Choge(Context context, AttributeSet attributeSet) {
        if (Build.VERSION.SDK_INT >= 31) {
            return C0096thooCoci9zae.ieseir3Choge(context, attributeSet);
        }
        return new EdgeEffect(context);
    }

    public static void keiL1EiShomu(EdgeEffect edgeEffect, float f, float f2) {
        ieseir3Choge.ieseir3Choge(edgeEffect, f, f2);
    }

    public static float thooCoci9zae(EdgeEffect edgeEffect) {
        if (Build.VERSION.SDK_INT >= 31) {
            return C0096thooCoci9zae.thooCoci9zae(edgeEffect);
        }
        return 0.0f;
    }
}
