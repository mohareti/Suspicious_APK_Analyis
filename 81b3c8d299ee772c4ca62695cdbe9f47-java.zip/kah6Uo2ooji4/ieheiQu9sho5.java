package kah6Uo2ooji4;

import android.widget.ListView;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ieheiQu9sho5 extends ieseir3Choge {

    /* renamed from: aac1eTaexee6, reason: collision with root package name */
    public final ListView f6915aac1eTaexee6;

    public ieheiQu9sho5(ListView listView) {
        super(listView);
        this.f6915aac1eTaexee6 = listView;
    }

    @Override // kah6Uo2ooji4.ieseir3Choge
    public boolean ieseir3Choge(int i) {
        return false;
    }

    @Override // kah6Uo2ooji4.ieseir3Choge
    public void ko7aiFeiqu3s(int i, int i2) {
        this.f6915aac1eTaexee6.scrollListBy(i2);
    }

    @Override // kah6Uo2ooji4.ieseir3Choge
    public boolean thooCoci9zae(int i) {
        ListView listView = this.f6915aac1eTaexee6;
        int count = listView.getCount();
        if (count == 0) {
            return false;
        }
        int childCount = listView.getChildCount();
        int firstVisiblePosition = listView.getFirstVisiblePosition();
        int i2 = firstVisiblePosition + childCount;
        if (i > 0) {
            if (i2 >= count && listView.getChildAt(childCount - 1).getBottom() <= listView.getHeight()) {
                return false;
            }
        } else {
            if (i >= 0) {
                return false;
            }
            if (firstVisiblePosition <= 0 && listView.getChildAt(0).getTop() >= 0) {
                return false;
            }
        }
        return true;
    }
}
