package kah6Uo2ooji4;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.icu.text.DecimalFormatSymbols;
import android.os.Build;
import android.text.Editable;
import android.text.PrecomputedText;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import android.text.method.PasswordTransformationMethod;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import oph9lahCh6uo.ahthoK6usais;
import org.uasecurity.mining.proto.user.DeviceProto;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Aicohm8ieYoo {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieheiQu9sho5 {
        public static void ieseir3Choge(TextView textView, int i, float f) {
            textView.setLineHeight(i, f);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static void Aicohm8ieYoo(TextView textView, ColorStateList colorStateList) {
            textView.setCompoundDrawableTintList(colorStateList);
        }

        public static void Jah0aiP1ki6y(TextView textView, PorterDuff.Mode mode) {
            textView.setCompoundDrawableTintMode(mode);
        }

        public static int ieheiQu9sho5(TextView textView) {
            return textView.getHyphenationFrequency();
        }

        public static int ieseir3Choge(TextView textView) {
            return textView.getBreakStrategy();
        }

        public static PorterDuff.Mode keiL1EiShomu(TextView textView) {
            return textView.getCompoundDrawableTintMode();
        }

        public static void kuedujio7Aev(TextView textView, int i) {
            textView.setBreakStrategy(i);
        }

        public static void niah0Shohtha(TextView textView, int i) {
            textView.setHyphenationFrequency(i);
        }

        public static ColorStateList thooCoci9zae(TextView textView) {
            return textView.getCompoundDrawableTintList();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class kuedujio7Aev implements ActionMode.Callback {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public boolean f6909Aicohm8ieYoo = false;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public Method f6910ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final ActionMode.Callback f6911ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public Class f6912keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public boolean f6913kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final TextView f6914thooCoci9zae;

        public kuedujio7Aev(ActionMode.Callback callback, TextView textView) {
            this.f6911ieseir3Choge = callback;
            this.f6914thooCoci9zae = textView;
        }

        public final boolean Aicohm8ieYoo(ResolveInfo resolveInfo, Context context) {
            if (context.getPackageName().equals(resolveInfo.activityInfo.packageName)) {
                return true;
            }
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            if (!activityInfo.exported) {
                return false;
            }
            String str = activityInfo.permission;
            if (str == null || context.checkSelfPermission(str) == 0) {
                return true;
            }
            return false;
        }

        public final void Jah0aiP1ki6y(Menu menu) {
            Method declaredMethod;
            Context context = this.f6914thooCoci9zae.getContext();
            PackageManager packageManager = context.getPackageManager();
            if (!this.f6909Aicohm8ieYoo) {
                this.f6909Aicohm8ieYoo = true;
                try {
                    Class<?> cls = Class.forName("com.android.internal.view.menu.MenuBuilder");
                    this.f6912keiL1EiShomu = cls;
                    this.f6910ieheiQu9sho5 = cls.getDeclaredMethod("removeItemAt", Integer.TYPE);
                    this.f6913kuedujio7Aev = true;
                } catch (ClassNotFoundException | NoSuchMethodException unused) {
                    this.f6912keiL1EiShomu = null;
                    this.f6910ieheiQu9sho5 = null;
                    this.f6913kuedujio7Aev = false;
                }
            }
            try {
                if (this.f6913kuedujio7Aev && this.f6912keiL1EiShomu.isInstance(menu)) {
                    declaredMethod = this.f6910ieheiQu9sho5;
                } else {
                    declaredMethod = menu.getClass().getDeclaredMethod("removeItemAt", Integer.TYPE);
                }
                for (int size = menu.size() - 1; size >= 0; size--) {
                    MenuItem item = menu.getItem(size);
                    if (item.getIntent() != null && "android.intent.action.PROCESS_TEXT".equals(item.getIntent().getAction())) {
                        declaredMethod.invoke(menu, Integer.valueOf(size));
                    }
                }
                List keiL1EiShomu2 = keiL1EiShomu(context, packageManager);
                for (int i = 0; i < keiL1EiShomu2.size(); i++) {
                    ResolveInfo resolveInfo = (ResolveInfo) keiL1EiShomu2.get(i);
                    menu.add(0, 0, i + 100, resolveInfo.loadLabel(packageManager)).setIntent(thooCoci9zae(resolveInfo, this.f6914thooCoci9zae)).setShowAsAction(1);
                }
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException unused2) {
            }
        }

        public ActionMode.Callback ieheiQu9sho5() {
            return this.f6911ieseir3Choge;
        }

        public final Intent ieseir3Choge() {
            return new Intent().setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
        }

        public final List keiL1EiShomu(Context context, PackageManager packageManager) {
            ArrayList arrayList = new ArrayList();
            if (!(context instanceof Activity)) {
                return arrayList;
            }
            for (ResolveInfo resolveInfo : packageManager.queryIntentActivities(ieseir3Choge(), 0)) {
                if (Aicohm8ieYoo(resolveInfo, context)) {
                    arrayList.add(resolveInfo);
                }
            }
            return arrayList;
        }

        public final boolean kuedujio7Aev(TextView textView) {
            if ((textView instanceof Editable) && textView.onCheckIsTextEditor() && textView.isEnabled()) {
                return true;
            }
            return false;
        }

        @Override // android.view.ActionMode.Callback
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            return this.f6911ieseir3Choge.onActionItemClicked(actionMode, menuItem);
        }

        @Override // android.view.ActionMode.Callback
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            return this.f6911ieseir3Choge.onCreateActionMode(actionMode, menu);
        }

        @Override // android.view.ActionMode.Callback
        public void onDestroyActionMode(ActionMode actionMode) {
            this.f6911ieseir3Choge.onDestroyActionMode(actionMode);
        }

        @Override // android.view.ActionMode.Callback
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            Jah0aiP1ki6y(menu);
            return this.f6911ieseir3Choge.onPrepareActionMode(actionMode, menu);
        }

        public final Intent thooCoci9zae(ResolveInfo resolveInfo, TextView textView) {
            Intent putExtra = ieseir3Choge().putExtra("android.intent.extra.PROCESS_TEXT_READONLY", !kuedujio7Aev(textView));
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            return putExtra.setClassName(activityInfo.packageName, activityInfo.name);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {
        public static DecimalFormatSymbols ieseir3Choge(Locale locale) {
            return DecimalFormatSymbols.getInstance(locale);
        }
    }

    public static ActionMode.Callback AeJiPo4of6Sh(TextView textView, ActionMode.Callback callback) {
        int i = Build.VERSION.SDK_INT;
        if (i >= 26 && i <= 27 && !(callback instanceof kuedujio7Aev) && callback != null) {
            return new kuedujio7Aev(callback, textView);
        }
        return callback;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Aicohm8ieYoo(TextView textView, ColorStateList colorStateList) {
        ohthie9thieG.ieheiQu9sho5.ieheiQu9sho5(textView);
        if (Build.VERSION.SDK_INT >= 24) {
            ieseir3Choge.Aicohm8ieYoo(textView, colorStateList);
        } else if (textView instanceof Jah0aiP1ki6y) {
            ((Jah0aiP1ki6y) textView).setSupportCompoundDrawablesTintList(colorStateList);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void Jah0aiP1ki6y(TextView textView, PorterDuff.Mode mode) {
        ohthie9thieG.ieheiQu9sho5.ieheiQu9sho5(textView);
        if (Build.VERSION.SDK_INT >= 24) {
            ieseir3Choge.Jah0aiP1ki6y(textView, mode);
        } else if (textView instanceof Jah0aiP1ki6y) {
            ((Jah0aiP1ki6y) textView).setSupportCompoundDrawablesTintMode(mode);
        }
    }

    public static void ahthoK6usais(TextView textView, ahthoK6usais ahthok6usais) {
        if (Build.VERSION.SDK_INT >= 29) {
            throw null;
        }
        kuedujio7Aev(textView);
        throw null;
    }

    public static TextDirectionHeuristic ieheiQu9sho5(TextView textView) {
        if (textView.getTransformationMethod() instanceof PasswordTransformationMethod) {
            return TextDirectionHeuristics.LTR;
        }
        boolean z = true;
        if (Build.VERSION.SDK_INT >= 28 && (textView.getInputType() & 15) == 3) {
            byte directionality = Character.getDirectionality(keiL1EiShomu.thooCoci9zae(thooCoci9zae.ieseir3Choge(textView.getTextLocale()))[0].codePointAt(0));
            if (directionality != 1 && directionality != 2) {
                return TextDirectionHeuristics.LTR;
            }
            return TextDirectionHeuristics.RTL;
        }
        if (textView.getLayoutDirection() != 1) {
            z = false;
        }
        switch (textView.getTextDirection()) {
            case 2:
                return TextDirectionHeuristics.ANYRTL_LTR;
            case 3:
                return TextDirectionHeuristics.LTR;
            case 4:
                return TextDirectionHeuristics.RTL;
            case 5:
                return TextDirectionHeuristics.LOCALE;
            case DeviceProto.MAXCPUFREQUENCY_FIELD_NUMBER /* 6 */:
                return TextDirectionHeuristics.FIRSTSTRONG_LTR;
            case DeviceProto.NUMOFCORES_FIELD_NUMBER /* 7 */:
                return TextDirectionHeuristics.FIRSTSTRONG_RTL;
            default:
                if (z) {
                    return TextDirectionHeuristics.FIRSTSTRONG_RTL;
                }
                return TextDirectionHeuristics.FIRSTSTRONG_LTR;
        }
    }

    public static int ieseir3Choge(TextView textView) {
        return textView.getPaddingTop() - textView.getPaint().getFontMetricsInt().top;
    }

    public static int keiL1EiShomu(TextDirectionHeuristic textDirectionHeuristic) {
        TextDirectionHeuristic textDirectionHeuristic2;
        TextDirectionHeuristic textDirectionHeuristic3 = TextDirectionHeuristics.FIRSTSTRONG_RTL;
        if (textDirectionHeuristic == textDirectionHeuristic3 || textDirectionHeuristic == (textDirectionHeuristic2 = TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            return 1;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
            return 2;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
            return 3;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
            return 4;
        }
        if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
            return 5;
        }
        if (textDirectionHeuristic == textDirectionHeuristic2) {
            return 6;
        }
        if (textDirectionHeuristic != textDirectionHeuristic3) {
            return 1;
        }
        return 7;
    }

    public static void ko7aiFeiqu3s(TextView textView, int i) {
        ohthie9thieG.ieheiQu9sho5.thooCoci9zae(i);
        if (i != textView.getPaint().getFontMetricsInt(null)) {
            textView.setLineSpacing(i - r0, 1.0f);
        }
    }

    public static ahthoK6usais.ieseir3Choge kuedujio7Aev(TextView textView) {
        if (Build.VERSION.SDK_INT >= 28) {
            return new ahthoK6usais.ieseir3Choge(keiL1EiShomu.keiL1EiShomu(textView));
        }
        ahthoK6usais.ieseir3Choge.C0103ieseir3Choge c0103ieseir3Choge = new ahthoK6usais.ieseir3Choge.C0103ieseir3Choge(new TextPaint(textView.getPaint()));
        c0103ieseir3Choge.thooCoci9zae(ieseir3Choge.ieseir3Choge(textView));
        c0103ieseir3Choge.keiL1EiShomu(ieseir3Choge.ieheiQu9sho5(textView));
        c0103ieseir3Choge.ieheiQu9sho5(ieheiQu9sho5(textView));
        return c0103ieseir3Choge.ieseir3Choge();
    }

    public static void mi5Iecheimie(TextView textView, ahthoK6usais.ieseir3Choge ieseir3choge) {
        textView.setTextDirection(keiL1EiShomu(ieseir3choge.ieheiQu9sho5()));
        textView.getPaint().set(ieseir3choge.kuedujio7Aev());
        ieseir3Choge.kuedujio7Aev(textView, ieseir3choge.thooCoci9zae());
        ieseir3Choge.niah0Shohtha(textView, ieseir3choge.keiL1EiShomu());
    }

    public static void niah0Shohtha(TextView textView, int i) {
        int i2;
        ohthie9thieG.ieheiQu9sho5.thooCoci9zae(i);
        if (Build.VERSION.SDK_INT >= 28) {
            keiL1EiShomu.ieheiQu9sho5(textView, i);
            return;
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        if (textView.getIncludeFontPadding()) {
            i2 = fontMetricsInt.top;
        } else {
            i2 = fontMetricsInt.ascent;
        }
        if (i > Math.abs(i2)) {
            textView.setPadding(textView.getPaddingLeft(), i + i2, textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }

    public static void ohv5Shie7AeZ(TextView textView, int i) {
        int i2;
        ohthie9thieG.ieheiQu9sho5.thooCoci9zae(i);
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        if (textView.getIncludeFontPadding()) {
            i2 = fontMetricsInt.bottom;
        } else {
            i2 = fontMetricsInt.descent;
        }
        if (i > Math.abs(i2)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), i - i2);
        }
    }

    public static void ruNgecai1pae(TextView textView, int i, float f) {
        if (Build.VERSION.SDK_INT >= 34) {
            ieheiQu9sho5.ieseir3Choge(textView, i, f);
        } else {
            ko7aiFeiqu3s(textView, Math.round(TypedValue.applyDimension(i, f, textView.getResources().getDisplayMetrics())));
        }
    }

    public static ActionMode.Callback ruwiepo7ooVu(ActionMode.Callback callback) {
        if ((callback instanceof kuedujio7Aev) && Build.VERSION.SDK_INT >= 26) {
            return ((kuedujio7Aev) callback).ieheiQu9sho5();
        }
        return callback;
    }

    public static int thooCoci9zae(TextView textView) {
        return textView.getPaddingBottom() + textView.getPaint().getFontMetricsInt().bottom;
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu {
        public static void ieheiQu9sho5(TextView textView, int i) {
            textView.setFirstBaselineToTopHeight(i);
        }

        public static PrecomputedText.Params keiL1EiShomu(TextView textView) {
            return textView.getTextMetricsParams();
        }

        public static String[] thooCoci9zae(DecimalFormatSymbols decimalFormatSymbols) {
            return decimalFormatSymbols.getDigitStrings();
        }

        public static CharSequence ieseir3Choge(PrecomputedText precomputedText) {
            return precomputedText;
        }
    }
}
