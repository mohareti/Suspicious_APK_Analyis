package jieva9Aoj2uv;

import java.io.Serializable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Aicohm8ieYoo implements keiL1EiShomu, Serializable {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final Object f6894Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public ieth4gahmaH8.ieseir3Choge f6895ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public volatile Object f6896kuedujio7Aev;

    public Aicohm8ieYoo(ieth4gahmaH8.ieseir3Choge ieseir3choge, Object obj) {
        thiet5ees7Wu.Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "initializer");
        this.f6895ieheiQu9sho5 = ieseir3choge;
        this.f6896kuedujio7Aev = niah0Shohtha.f6905ieseir3Choge;
        this.f6894Aicohm8ieYoo = obj == null ? this : obj;
    }

    @Override // jieva9Aoj2uv.keiL1EiShomu
    public Object getValue() {
        Object obj;
        Object obj2 = this.f6896kuedujio7Aev;
        niah0Shohtha niah0shohtha = niah0Shohtha.f6905ieseir3Choge;
        if (obj2 != niah0shohtha) {
            return obj2;
        }
        synchronized (this.f6894Aicohm8ieYoo) {
            obj = this.f6896kuedujio7Aev;
            if (obj == niah0shohtha) {
                ieth4gahmaH8.ieseir3Choge ieseir3choge = this.f6895ieheiQu9sho5;
                thiet5ees7Wu.Aicohm8ieYoo.thooCoci9zae(ieseir3choge);
                obj = ieseir3choge.ieseir3Choge();
                this.f6896kuedujio7Aev = obj;
                this.f6895ieheiQu9sho5 = null;
            }
        }
        return obj;
    }

    public boolean ieseir3Choge() {
        if (this.f6896kuedujio7Aev != niah0Shohtha.f6905ieseir3Choge) {
            return true;
        }
        return false;
    }

    public String toString() {
        if (ieseir3Choge()) {
            return String.valueOf(getValue());
        }
        return "Lazy value not initialized yet.";
    }

    public /* synthetic */ Aicohm8ieYoo(ieth4gahmaH8.ieseir3Choge ieseir3choge, Object obj, int i, thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
        this(ieseir3choge, (i & 2) != 0 ? null : obj);
    }
}
