package jieva9Aoj2uv;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Jah0aiP1ki6y {
    public static final kuedujio7Aev ieseir3Choge(Object obj, Object obj2) {
        return new kuedujio7Aev(obj, obj2);
    }
}
