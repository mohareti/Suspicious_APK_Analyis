package jieva9Aoj2uv;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieseir3Choge implements Comparable {

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public static final C0094ieseir3Choge f6897niah0Shohtha = new C0094ieseir3Choge(null);

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final ieseir3Choge f6898ohv5Shie7AeZ = thooCoci9zae.ieseir3Choge();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final int f6899Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final int f6900Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final int f6901ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final int f6902kuedujio7Aev;

    /* renamed from: jieva9Aoj2uv.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0094ieseir3Choge {
        public C0094ieseir3Choge() {
        }

        public /* synthetic */ C0094ieseir3Choge(thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
            this();
        }
    }

    public ieseir3Choge(int i, int i2, int i3) {
        this.f6901ieheiQu9sho5 = i;
        this.f6902kuedujio7Aev = i2;
        this.f6899Aicohm8ieYoo = i3;
        this.f6900Jah0aiP1ki6y = Jah0aiP1ki6y(i, i2, i3);
    }

    public final int Jah0aiP1ki6y(int i, int i2, int i3) {
        if (i >= 0 && i < 256 && i2 >= 0 && i2 < 256 && i3 >= 0 && i3 < 256) {
            return (i << 16) + (i2 << 8) + i3;
        }
        throw new IllegalArgumentException(("Version components are out of range: " + i + '.' + i2 + '.' + i3).toString());
    }

    public boolean equals(Object obj) {
        ieseir3Choge ieseir3choge;
        if (this == obj) {
            return true;
        }
        if (obj instanceof ieseir3Choge) {
            ieseir3choge = (ieseir3Choge) obj;
        } else {
            ieseir3choge = null;
        }
        if (ieseir3choge != null && this.f6900Jah0aiP1ki6y == ieseir3choge.f6900Jah0aiP1ki6y) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return this.f6900Jah0aiP1ki6y;
    }

    @Override // java.lang.Comparable
    /* renamed from: ieseir3Choge, reason: merged with bridge method [inline-methods] */
    public int compareTo(ieseir3Choge ieseir3choge) {
        thiet5ees7Wu.Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "other");
        return this.f6900Jah0aiP1ki6y - ieseir3choge.f6900Jah0aiP1ki6y;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f6901ieheiQu9sho5);
        sb.append('.');
        sb.append(this.f6902kuedujio7Aev);
        sb.append('.');
        sb.append(this.f6899Aicohm8ieYoo);
        return sb.toString();
    }
}
