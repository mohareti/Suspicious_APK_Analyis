package ieph3Uteimah;

import android.content.Context;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {
    public static Interpolator ieseir3Choge(Context context, int i) {
        return AnimationUtils.loadInterpolator(context, i);
    }
}
