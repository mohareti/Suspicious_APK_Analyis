package ieph3Uteimah;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import eetheKaevie8.niah0Shohtha;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import oYe2ma2she1j.ruNgecai1pae;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Jah0aiP1ki6y extends ieph3Uteimah.Aicohm8ieYoo {

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public static final PorterDuff.Mode f6378ruNgecai1pae = PorterDuff.Mode.SRC_IN;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public boolean f6379Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public Drawable.ConstantState f6380Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public ColorFilter f6381ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public PorterDuffColorFilter f6382keiL1EiShomu;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public final Rect f6383ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public boolean f6384kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final float[] f6385niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public final Matrix f6386ohv5Shie7AeZ;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public niah0Shohtha f6387thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class Aicohm8ieYoo extends kuedujio7Aev {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public int f6388ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public niah0Shohtha.thooCoci9zae[] f6389ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public int f6390keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public String f6391thooCoci9zae;

        public Aicohm8ieYoo() {
            super();
            this.f6389ieseir3Choge = null;
            this.f6390keiL1EiShomu = 0;
        }

        public niah0Shohtha.thooCoci9zae[] getPathData() {
            return this.f6389ieseir3Choge;
        }

        public String getPathName() {
            return this.f6391thooCoci9zae;
        }

        public void ieheiQu9sho5(Path path) {
            path.reset();
            niah0Shohtha.thooCoci9zae[] thoococi9zaeArr = this.f6389ieseir3Choge;
            if (thoococi9zaeArr != null) {
                niah0Shohtha.thooCoci9zae.ohv5Shie7AeZ(thoococi9zaeArr, path);
            }
        }

        public boolean keiL1EiShomu() {
            return false;
        }

        public void setPathData(niah0Shohtha.thooCoci9zae[] thoococi9zaeArr) {
            if (!eetheKaevie8.niah0Shohtha.thooCoci9zae(this.f6389ieseir3Choge, thoococi9zaeArr)) {
                this.f6389ieseir3Choge = eetheKaevie8.niah0Shohtha.Aicohm8ieYoo(thoococi9zaeArr);
            } else {
                eetheKaevie8.niah0Shohtha.ruNgecai1pae(this.f6389ieseir3Choge, thoococi9zaeArr);
            }
        }

        public Aicohm8ieYoo(Aicohm8ieYoo aicohm8ieYoo) {
            super();
            this.f6389ieseir3Choge = null;
            this.f6390keiL1EiShomu = 0;
            this.f6391thooCoci9zae = aicohm8ieYoo.f6391thooCoci9zae;
            this.f6388ieheiQu9sho5 = aicohm8ieYoo.f6388ieheiQu9sho5;
            this.f6389ieseir3Choge = eetheKaevie8.niah0Shohtha.Aicohm8ieYoo(aicohm8ieYoo.f6389ieseir3Choge);
        }
    }

    /* renamed from: ieph3Uteimah.Jah0aiP1ki6y$Jah0aiP1ki6y, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0087Jah0aiP1ki6y {

        /* renamed from: eetheKaevie8, reason: collision with root package name */
        public static final Matrix f6392eetheKaevie8 = new Matrix();

        /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
        public Boolean f6393AeJiPo4of6Sh;

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public PathMeasure f6394Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public int f6395Jah0aiP1ki6y;

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public float f6396ahthoK6usais;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public Paint f6397ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Path f6398ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Matrix f6399keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public float f6400ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public Paint f6401kuedujio7Aev;

        /* renamed from: mi5Iecheimie, reason: collision with root package name */
        public int f6402mi5Iecheimie;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public final ieheiQu9sho5 f6403niah0Shohtha;

        /* renamed from: oYe2ma2she1j, reason: collision with root package name */
        public final ruNgecai1pae.ieseir3Choge f6404oYe2ma2she1j;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public float f6405ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public float f6406ruNgecai1pae;

        /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
        public String f6407ruwiepo7ooVu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Path f6408thooCoci9zae;

        public C0087Jah0aiP1ki6y() {
            this.f6399keiL1EiShomu = new Matrix();
            this.f6405ohv5Shie7AeZ = 0.0f;
            this.f6400ko7aiFeiqu3s = 0.0f;
            this.f6406ruNgecai1pae = 0.0f;
            this.f6396ahthoK6usais = 0.0f;
            this.f6402mi5Iecheimie = 255;
            this.f6407ruwiepo7ooVu = null;
            this.f6393AeJiPo4of6Sh = null;
            this.f6404oYe2ma2she1j = new ruNgecai1pae.ieseir3Choge();
            this.f6403niah0Shohtha = new ieheiQu9sho5();
            this.f6398ieseir3Choge = new Path();
            this.f6408thooCoci9zae = new Path();
        }

        public static float ieseir3Choge(float f, float f2, float f3, float f4) {
            return (f * f4) - (f2 * f3);
        }

        public boolean Aicohm8ieYoo() {
            if (this.f6393AeJiPo4of6Sh == null) {
                this.f6393AeJiPo4of6Sh = Boolean.valueOf(this.f6403niah0Shohtha.ieseir3Choge());
            }
            return this.f6393AeJiPo4of6Sh.booleanValue();
        }

        public boolean Jah0aiP1ki6y(int[] iArr) {
            return this.f6403niah0Shohtha.thooCoci9zae(iArr);
        }

        public float getAlpha() {
            return getRootAlpha() / 255.0f;
        }

        public int getRootAlpha() {
            return this.f6402mi5Iecheimie;
        }

        public final void ieheiQu9sho5(ieheiQu9sho5 ieheiqu9sho5, Aicohm8ieYoo aicohm8ieYoo, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            Path.FillType fillType;
            Path.FillType fillType2;
            float f = i / this.f6406ruNgecai1pae;
            float f2 = i2 / this.f6396ahthoK6usais;
            float min = Math.min(f, f2);
            Matrix matrix = ieheiqu9sho5.f6413ieseir3Choge;
            this.f6399keiL1EiShomu.set(matrix);
            this.f6399keiL1EiShomu.postScale(f, f2);
            float kuedujio7Aev2 = kuedujio7Aev(matrix);
            if (kuedujio7Aev2 == 0.0f) {
                return;
            }
            aicohm8ieYoo.ieheiQu9sho5(this.f6398ieseir3Choge);
            Path path = this.f6398ieseir3Choge;
            this.f6408thooCoci9zae.reset();
            if (aicohm8ieYoo.keiL1EiShomu()) {
                Path path2 = this.f6408thooCoci9zae;
                if (aicohm8ieYoo.f6390keiL1EiShomu == 0) {
                    fillType2 = Path.FillType.WINDING;
                } else {
                    fillType2 = Path.FillType.EVEN_ODD;
                }
                path2.setFillType(fillType2);
                this.f6408thooCoci9zae.addPath(path, this.f6399keiL1EiShomu);
                canvas.clipPath(this.f6408thooCoci9zae);
                return;
            }
            keiL1EiShomu keil1eishomu = (keiL1EiShomu) aicohm8ieYoo;
            float f3 = keil1eishomu.f6432ruNgecai1pae;
            if (f3 != 0.0f || keil1eishomu.f6425ahthoK6usais != 1.0f) {
                float f4 = keil1eishomu.f6428mi5Iecheimie;
                float f5 = (f3 + f4) % 1.0f;
                float f6 = (keil1eishomu.f6425ahthoK6usais + f4) % 1.0f;
                if (this.f6394Aicohm8ieYoo == null) {
                    this.f6394Aicohm8ieYoo = new PathMeasure();
                }
                this.f6394Aicohm8ieYoo.setPath(this.f6398ieseir3Choge, false);
                float length = this.f6394Aicohm8ieYoo.getLength();
                float f7 = f5 * length;
                float f8 = f6 * length;
                path.reset();
                if (f7 > f8) {
                    this.f6394Aicohm8ieYoo.getSegment(f7, length, path, true);
                    this.f6394Aicohm8ieYoo.getSegment(0.0f, f8, path, true);
                } else {
                    this.f6394Aicohm8ieYoo.getSegment(f7, f8, path, true);
                }
                path.rLineTo(0.0f, 0.0f);
            }
            this.f6408thooCoci9zae.addPath(path, this.f6399keiL1EiShomu);
            if (keil1eishomu.f6429niah0Shohtha.ahthoK6usais()) {
                oYe2ma2she1j.ieheiQu9sho5 ieheiqu9sho52 = keil1eishomu.f6429niah0Shohtha;
                if (this.f6401kuedujio7Aev == null) {
                    Paint paint = new Paint(1);
                    this.f6401kuedujio7Aev = paint;
                    paint.setStyle(Paint.Style.FILL);
                }
                Paint paint2 = this.f6401kuedujio7Aev;
                if (ieheiqu9sho52.niah0Shohtha()) {
                    Shader Aicohm8ieYoo2 = ieheiqu9sho52.Aicohm8ieYoo();
                    Aicohm8ieYoo2.setLocalMatrix(this.f6399keiL1EiShomu);
                    paint2.setShader(Aicohm8ieYoo2);
                    paint2.setAlpha(Math.round(keil1eishomu.f6426ko7aiFeiqu3s * 255.0f));
                } else {
                    paint2.setShader(null);
                    paint2.setAlpha(255);
                    paint2.setColor(Jah0aiP1ki6y.ieseir3Choge(ieheiqu9sho52.kuedujio7Aev(), keil1eishomu.f6426ko7aiFeiqu3s));
                }
                paint2.setColorFilter(colorFilter);
                Path path3 = this.f6408thooCoci9zae;
                if (keil1eishomu.f6390keiL1EiShomu == 0) {
                    fillType = Path.FillType.WINDING;
                } else {
                    fillType = Path.FillType.EVEN_ODD;
                }
                path3.setFillType(fillType);
                canvas.drawPath(this.f6408thooCoci9zae, paint2);
            }
            if (keil1eishomu.f6423Aicohm8ieYoo.ahthoK6usais()) {
                oYe2ma2she1j.ieheiQu9sho5 ieheiqu9sho53 = keil1eishomu.f6423Aicohm8ieYoo;
                if (this.f6397ieheiQu9sho5 == null) {
                    Paint paint3 = new Paint(1);
                    this.f6397ieheiQu9sho5 = paint3;
                    paint3.setStyle(Paint.Style.STROKE);
                }
                Paint paint4 = this.f6397ieheiQu9sho5;
                Paint.Join join = keil1eishomu.f6422AeJiPo4of6Sh;
                if (join != null) {
                    paint4.setStrokeJoin(join);
                }
                Paint.Cap cap = keil1eishomu.f6433ruwiepo7ooVu;
                if (cap != null) {
                    paint4.setStrokeCap(cap);
                }
                paint4.setStrokeMiter(keil1eishomu.f6430oYe2ma2she1j);
                if (ieheiqu9sho53.niah0Shohtha()) {
                    Shader Aicohm8ieYoo3 = ieheiqu9sho53.Aicohm8ieYoo();
                    Aicohm8ieYoo3.setLocalMatrix(this.f6399keiL1EiShomu);
                    paint4.setShader(Aicohm8ieYoo3);
                    paint4.setAlpha(Math.round(keil1eishomu.f6431ohv5Shie7AeZ * 255.0f));
                } else {
                    paint4.setShader(null);
                    paint4.setAlpha(255);
                    paint4.setColor(Jah0aiP1ki6y.ieseir3Choge(ieheiqu9sho53.kuedujio7Aev(), keil1eishomu.f6431ohv5Shie7AeZ));
                }
                paint4.setColorFilter(colorFilter);
                paint4.setStrokeWidth(keil1eishomu.f6424Jah0aiP1ki6y * min * kuedujio7Aev2);
                canvas.drawPath(this.f6408thooCoci9zae, paint4);
            }
        }

        public final void keiL1EiShomu(ieheiQu9sho5 ieheiqu9sho5, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            ieheiqu9sho5.f6413ieseir3Choge.set(matrix);
            ieheiqu9sho5.f6413ieseir3Choge.preConcat(ieheiqu9sho5.f6415ko7aiFeiqu3s);
            canvas.save();
            for (int i3 = 0; i3 < ieheiqu9sho5.f6421thooCoci9zae.size(); i3++) {
                kuedujio7Aev kuedujio7aev = (kuedujio7Aev) ieheiqu9sho5.f6421thooCoci9zae.get(i3);
                if (kuedujio7aev instanceof ieheiQu9sho5) {
                    keiL1EiShomu((ieheiQu9sho5) kuedujio7aev, ieheiqu9sho5.f6413ieseir3Choge, canvas, i, i2, colorFilter);
                } else if (kuedujio7aev instanceof Aicohm8ieYoo) {
                    ieheiQu9sho5(ieheiqu9sho5, (Aicohm8ieYoo) kuedujio7aev, canvas, i, i2, colorFilter);
                }
            }
            canvas.restore();
        }

        public final float kuedujio7Aev(Matrix matrix) {
            float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(fArr);
            float hypot = (float) Math.hypot(fArr[0], fArr[1]);
            float hypot2 = (float) Math.hypot(fArr[2], fArr[3]);
            float ieseir3Choge2 = ieseir3Choge(fArr[0], fArr[1], fArr[2], fArr[3]);
            float max = Math.max(hypot, hypot2);
            if (max <= 0.0f) {
                return 0.0f;
            }
            return Math.abs(ieseir3Choge2) / max;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public void setRootAlpha(int i) {
            this.f6402mi5Iecheimie = i;
        }

        public void thooCoci9zae(Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            keiL1EiShomu(this.f6403niah0Shohtha, f6392eetheKaevie8, canvas, i, i2, colorFilter);
        }

        public C0087Jah0aiP1ki6y(C0087Jah0aiP1ki6y c0087Jah0aiP1ki6y) {
            this.f6399keiL1EiShomu = new Matrix();
            this.f6405ohv5Shie7AeZ = 0.0f;
            this.f6400ko7aiFeiqu3s = 0.0f;
            this.f6406ruNgecai1pae = 0.0f;
            this.f6396ahthoK6usais = 0.0f;
            this.f6402mi5Iecheimie = 255;
            this.f6407ruwiepo7ooVu = null;
            this.f6393AeJiPo4of6Sh = null;
            ruNgecai1pae.ieseir3Choge ieseir3choge = new ruNgecai1pae.ieseir3Choge();
            this.f6404oYe2ma2she1j = ieseir3choge;
            this.f6403niah0Shohtha = new ieheiQu9sho5(c0087Jah0aiP1ki6y.f6403niah0Shohtha, ieseir3choge);
            this.f6398ieseir3Choge = new Path(c0087Jah0aiP1ki6y.f6398ieseir3Choge);
            this.f6408thooCoci9zae = new Path(c0087Jah0aiP1ki6y.f6408thooCoci9zae);
            this.f6405ohv5Shie7AeZ = c0087Jah0aiP1ki6y.f6405ohv5Shie7AeZ;
            this.f6400ko7aiFeiqu3s = c0087Jah0aiP1ki6y.f6400ko7aiFeiqu3s;
            this.f6406ruNgecai1pae = c0087Jah0aiP1ki6y.f6406ruNgecai1pae;
            this.f6396ahthoK6usais = c0087Jah0aiP1ki6y.f6396ahthoK6usais;
            this.f6395Jah0aiP1ki6y = c0087Jah0aiP1ki6y.f6395Jah0aiP1ki6y;
            this.f6402mi5Iecheimie = c0087Jah0aiP1ki6y.f6402mi5Iecheimie;
            this.f6407ruwiepo7ooVu = c0087Jah0aiP1ki6y.f6407ruwiepo7ooVu;
            String str = c0087Jah0aiP1ki6y.f6407ruwiepo7ooVu;
            if (str != null) {
                ieseir3choge.put(str, this);
            }
            this.f6393AeJiPo4of6Sh = c0087Jah0aiP1ki6y.f6393AeJiPo4of6Sh;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieheiQu9sho5 extends kuedujio7Aev {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public float f6409Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public float f6410Jah0aiP1ki6y;

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public int[] f6411ahthoK6usais;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public float f6412ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Matrix f6413ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public float f6414keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public final Matrix f6415ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public float f6416kuedujio7Aev;

        /* renamed from: mi5Iecheimie, reason: collision with root package name */
        public String f6417mi5Iecheimie;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public float f6418niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public float f6419ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public int f6420ruNgecai1pae;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final ArrayList f6421thooCoci9zae;

        public ieheiQu9sho5() {
            super();
            this.f6413ieseir3Choge = new Matrix();
            this.f6421thooCoci9zae = new ArrayList();
            this.f6414keiL1EiShomu = 0.0f;
            this.f6412ieheiQu9sho5 = 0.0f;
            this.f6416kuedujio7Aev = 0.0f;
            this.f6409Aicohm8ieYoo = 1.0f;
            this.f6410Jah0aiP1ki6y = 1.0f;
            this.f6418niah0Shohtha = 0.0f;
            this.f6419ohv5Shie7AeZ = 0.0f;
            this.f6415ko7aiFeiqu3s = new Matrix();
            this.f6417mi5Iecheimie = null;
        }

        public String getGroupName() {
            return this.f6417mi5Iecheimie;
        }

        public Matrix getLocalMatrix() {
            return this.f6415ko7aiFeiqu3s;
        }

        public float getPivotX() {
            return this.f6412ieheiQu9sho5;
        }

        public float getPivotY() {
            return this.f6416kuedujio7Aev;
        }

        public float getRotation() {
            return this.f6414keiL1EiShomu;
        }

        public float getScaleX() {
            return this.f6409Aicohm8ieYoo;
        }

        public float getScaleY() {
            return this.f6410Jah0aiP1ki6y;
        }

        public float getTranslateX() {
            return this.f6418niah0Shohtha;
        }

        public float getTranslateY() {
            return this.f6419ohv5Shie7AeZ;
        }

        public final void ieheiQu9sho5() {
            this.f6415ko7aiFeiqu3s.reset();
            this.f6415ko7aiFeiqu3s.postTranslate(-this.f6412ieheiQu9sho5, -this.f6416kuedujio7Aev);
            this.f6415ko7aiFeiqu3s.postScale(this.f6409Aicohm8ieYoo, this.f6410Jah0aiP1ki6y);
            this.f6415ko7aiFeiqu3s.postRotate(this.f6414keiL1EiShomu, 0.0f, 0.0f);
            this.f6415ko7aiFeiqu3s.postTranslate(this.f6418niah0Shohtha + this.f6412ieheiQu9sho5, this.f6419ohv5Shie7AeZ + this.f6416kuedujio7Aev);
        }

        @Override // ieph3Uteimah.Jah0aiP1ki6y.kuedujio7Aev
        public boolean ieseir3Choge() {
            for (int i = 0; i < this.f6421thooCoci9zae.size(); i++) {
                if (((kuedujio7Aev) this.f6421thooCoci9zae.get(i)).ieseir3Choge()) {
                    return true;
                }
            }
            return false;
        }

        public void keiL1EiShomu(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6459thooCoci9zae);
            kuedujio7Aev(ruNgecai1pae2, xmlPullParser);
            ruNgecai1pae2.recycle();
        }

        public final void kuedujio7Aev(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.f6411ahthoK6usais = null;
            this.f6414keiL1EiShomu = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "rotation", 5, this.f6414keiL1EiShomu);
            this.f6412ieheiQu9sho5 = typedArray.getFloat(1, this.f6412ieheiQu9sho5);
            this.f6416kuedujio7Aev = typedArray.getFloat(2, this.f6416kuedujio7Aev);
            this.f6409Aicohm8ieYoo = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "scaleX", 3, this.f6409Aicohm8ieYoo);
            this.f6410Jah0aiP1ki6y = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "scaleY", 4, this.f6410Jah0aiP1ki6y);
            this.f6418niah0Shohtha = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "translateX", 6, this.f6418niah0Shohtha);
            this.f6419ohv5Shie7AeZ = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "translateY", 7, this.f6419ohv5Shie7AeZ);
            String string = typedArray.getString(0);
            if (string != null) {
                this.f6417mi5Iecheimie = string;
            }
            ieheiQu9sho5();
        }

        public void setPivotX(float f) {
            if (f != this.f6412ieheiQu9sho5) {
                this.f6412ieheiQu9sho5 = f;
                ieheiQu9sho5();
            }
        }

        public void setPivotY(float f) {
            if (f != this.f6416kuedujio7Aev) {
                this.f6416kuedujio7Aev = f;
                ieheiQu9sho5();
            }
        }

        public void setRotation(float f) {
            if (f != this.f6414keiL1EiShomu) {
                this.f6414keiL1EiShomu = f;
                ieheiQu9sho5();
            }
        }

        public void setScaleX(float f) {
            if (f != this.f6409Aicohm8ieYoo) {
                this.f6409Aicohm8ieYoo = f;
                ieheiQu9sho5();
            }
        }

        public void setScaleY(float f) {
            if (f != this.f6410Jah0aiP1ki6y) {
                this.f6410Jah0aiP1ki6y = f;
                ieheiQu9sho5();
            }
        }

        public void setTranslateX(float f) {
            if (f != this.f6418niah0Shohtha) {
                this.f6418niah0Shohtha = f;
                ieheiQu9sho5();
            }
        }

        public void setTranslateY(float f) {
            if (f != this.f6419ohv5Shie7AeZ) {
                this.f6419ohv5Shie7AeZ = f;
                ieheiQu9sho5();
            }
        }

        @Override // ieph3Uteimah.Jah0aiP1ki6y.kuedujio7Aev
        public boolean thooCoci9zae(int[] iArr) {
            boolean z = false;
            for (int i = 0; i < this.f6421thooCoci9zae.size(); i++) {
                z |= ((kuedujio7Aev) this.f6421thooCoci9zae.get(i)).thooCoci9zae(iArr);
            }
            return z;
        }

        public ieheiQu9sho5(ieheiQu9sho5 ieheiqu9sho5, ruNgecai1pae.ieseir3Choge ieseir3choge) {
            super();
            Aicohm8ieYoo thoococi9zae;
            this.f6413ieseir3Choge = new Matrix();
            this.f6421thooCoci9zae = new ArrayList();
            this.f6414keiL1EiShomu = 0.0f;
            this.f6412ieheiQu9sho5 = 0.0f;
            this.f6416kuedujio7Aev = 0.0f;
            this.f6409Aicohm8ieYoo = 1.0f;
            this.f6410Jah0aiP1ki6y = 1.0f;
            this.f6418niah0Shohtha = 0.0f;
            this.f6419ohv5Shie7AeZ = 0.0f;
            Matrix matrix = new Matrix();
            this.f6415ko7aiFeiqu3s = matrix;
            this.f6417mi5Iecheimie = null;
            this.f6414keiL1EiShomu = ieheiqu9sho5.f6414keiL1EiShomu;
            this.f6412ieheiQu9sho5 = ieheiqu9sho5.f6412ieheiQu9sho5;
            this.f6416kuedujio7Aev = ieheiqu9sho5.f6416kuedujio7Aev;
            this.f6409Aicohm8ieYoo = ieheiqu9sho5.f6409Aicohm8ieYoo;
            this.f6410Jah0aiP1ki6y = ieheiqu9sho5.f6410Jah0aiP1ki6y;
            this.f6418niah0Shohtha = ieheiqu9sho5.f6418niah0Shohtha;
            this.f6419ohv5Shie7AeZ = ieheiqu9sho5.f6419ohv5Shie7AeZ;
            this.f6411ahthoK6usais = ieheiqu9sho5.f6411ahthoK6usais;
            String str = ieheiqu9sho5.f6417mi5Iecheimie;
            this.f6417mi5Iecheimie = str;
            this.f6420ruNgecai1pae = ieheiqu9sho5.f6420ruNgecai1pae;
            if (str != null) {
                ieseir3choge.put(str, this);
            }
            matrix.set(ieheiqu9sho5.f6415ko7aiFeiqu3s);
            ArrayList arrayList = ieheiqu9sho5.f6421thooCoci9zae;
            for (int i = 0; i < arrayList.size(); i++) {
                Object obj = arrayList.get(i);
                if (obj instanceof ieheiQu9sho5) {
                    this.f6421thooCoci9zae.add(new ieheiQu9sho5((ieheiQu9sho5) obj, ieseir3choge));
                } else {
                    if (obj instanceof keiL1EiShomu) {
                        thoococi9zae = new keiL1EiShomu((keiL1EiShomu) obj);
                    } else {
                        if (!(obj instanceof thooCoci9zae)) {
                            throw new IllegalStateException("Unknown object in the tree!");
                        }
                        thoococi9zae = new thooCoci9zae((thooCoci9zae) obj);
                    }
                    this.f6421thooCoci9zae.add(thoococi9zae);
                    Object obj2 = thoococi9zae.f6391thooCoci9zae;
                    if (obj2 != null) {
                        ieseir3choge.put(obj2, thoococi9zae);
                    }
                }
            }
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu extends Aicohm8ieYoo {

        /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
        public Paint.Join f6422AeJiPo4of6Sh;

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public oYe2ma2she1j.ieheiQu9sho5 f6423Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public float f6424Jah0aiP1ki6y;

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public float f6425ahthoK6usais;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public float f6426ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public int[] f6427kuedujio7Aev;

        /* renamed from: mi5Iecheimie, reason: collision with root package name */
        public float f6428mi5Iecheimie;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public oYe2ma2she1j.ieheiQu9sho5 f6429niah0Shohtha;

        /* renamed from: oYe2ma2she1j, reason: collision with root package name */
        public float f6430oYe2ma2she1j;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public float f6431ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public float f6432ruNgecai1pae;

        /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
        public Paint.Cap f6433ruwiepo7ooVu;

        public keiL1EiShomu() {
            this.f6424Jah0aiP1ki6y = 0.0f;
            this.f6431ohv5Shie7AeZ = 1.0f;
            this.f6426ko7aiFeiqu3s = 1.0f;
            this.f6432ruNgecai1pae = 0.0f;
            this.f6425ahthoK6usais = 1.0f;
            this.f6428mi5Iecheimie = 0.0f;
            this.f6433ruwiepo7ooVu = Paint.Cap.BUTT;
            this.f6422AeJiPo4of6Sh = Paint.Join.MITER;
            this.f6430oYe2ma2she1j = 4.0f;
        }

        public final Paint.Join Aicohm8ieYoo(int i, Paint.Join join) {
            if (i != 0) {
                if (i != 1) {
                    if (i != 2) {
                        return join;
                    }
                    return Paint.Join.BEVEL;
                }
                return Paint.Join.ROUND;
            }
            return Paint.Join.MITER;
        }

        public void Jah0aiP1ki6y(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6453keiL1EiShomu);
            niah0Shohtha(ruNgecai1pae2, xmlPullParser, theme);
            ruNgecai1pae2.recycle();
        }

        public float getFillAlpha() {
            return this.f6426ko7aiFeiqu3s;
        }

        public int getFillColor() {
            return this.f6429niah0Shohtha.kuedujio7Aev();
        }

        public float getStrokeAlpha() {
            return this.f6431ohv5Shie7AeZ;
        }

        public int getStrokeColor() {
            return this.f6423Aicohm8ieYoo.kuedujio7Aev();
        }

        public float getStrokeWidth() {
            return this.f6424Jah0aiP1ki6y;
        }

        public float getTrimPathEnd() {
            return this.f6425ahthoK6usais;
        }

        public float getTrimPathOffset() {
            return this.f6428mi5Iecheimie;
        }

        public float getTrimPathStart() {
            return this.f6432ruNgecai1pae;
        }

        @Override // ieph3Uteimah.Jah0aiP1ki6y.kuedujio7Aev
        public boolean ieseir3Choge() {
            if (!this.f6429niah0Shohtha.ohv5Shie7AeZ() && !this.f6423Aicohm8ieYoo.ohv5Shie7AeZ()) {
                return false;
            }
            return true;
        }

        public final Paint.Cap kuedujio7Aev(int i, Paint.Cap cap) {
            if (i != 0) {
                if (i != 1) {
                    if (i != 2) {
                        return cap;
                    }
                    return Paint.Cap.SQUARE;
                }
                return Paint.Cap.ROUND;
            }
            return Paint.Cap.BUTT;
        }

        public final void niah0Shohtha(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
            this.f6427kuedujio7Aev = null;
            if (!ruNgecai1pae.ko7aiFeiqu3s(xmlPullParser, "pathData")) {
                return;
            }
            String string = typedArray.getString(0);
            if (string != null) {
                this.f6391thooCoci9zae = string;
            }
            String string2 = typedArray.getString(2);
            if (string2 != null) {
                this.f6389ieseir3Choge = eetheKaevie8.niah0Shohtha.ieheiQu9sho5(string2);
            }
            this.f6429niah0Shohtha = ruNgecai1pae.kuedujio7Aev(typedArray, xmlPullParser, theme, "fillColor", 1, 0);
            this.f6426ko7aiFeiqu3s = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "fillAlpha", 12, this.f6426ko7aiFeiqu3s);
            this.f6433ruwiepo7ooVu = kuedujio7Aev(ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.f6433ruwiepo7ooVu);
            this.f6422AeJiPo4of6Sh = Aicohm8ieYoo(ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.f6422AeJiPo4of6Sh);
            this.f6430oYe2ma2she1j = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.f6430oYe2ma2she1j);
            this.f6423Aicohm8ieYoo = ruNgecai1pae.kuedujio7Aev(typedArray, xmlPullParser, theme, "strokeColor", 3, 0);
            this.f6431ohv5Shie7AeZ = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "strokeAlpha", 11, this.f6431ohv5Shie7AeZ);
            this.f6424Jah0aiP1ki6y = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "strokeWidth", 4, this.f6424Jah0aiP1ki6y);
            this.f6425ahthoK6usais = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "trimPathEnd", 6, this.f6425ahthoK6usais);
            this.f6428mi5Iecheimie = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "trimPathOffset", 7, this.f6428mi5Iecheimie);
            this.f6432ruNgecai1pae = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "trimPathStart", 5, this.f6432ruNgecai1pae);
            this.f6390keiL1EiShomu = ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "fillType", 13, this.f6390keiL1EiShomu);
        }

        public void setFillAlpha(float f) {
            this.f6426ko7aiFeiqu3s = f;
        }

        public void setFillColor(int i) {
            this.f6429niah0Shohtha.ruNgecai1pae(i);
        }

        public void setStrokeAlpha(float f) {
            this.f6431ohv5Shie7AeZ = f;
        }

        public void setStrokeColor(int i) {
            this.f6423Aicohm8ieYoo.ruNgecai1pae(i);
        }

        public void setStrokeWidth(float f) {
            this.f6424Jah0aiP1ki6y = f;
        }

        public void setTrimPathEnd(float f) {
            this.f6425ahthoK6usais = f;
        }

        public void setTrimPathOffset(float f) {
            this.f6428mi5Iecheimie = f;
        }

        public void setTrimPathStart(float f) {
            this.f6432ruNgecai1pae = f;
        }

        @Override // ieph3Uteimah.Jah0aiP1ki6y.kuedujio7Aev
        public boolean thooCoci9zae(int[] iArr) {
            return this.f6423Aicohm8ieYoo.ko7aiFeiqu3s(iArr) | this.f6429niah0Shohtha.ko7aiFeiqu3s(iArr);
        }

        public keiL1EiShomu(keiL1EiShomu keil1eishomu) {
            super(keil1eishomu);
            this.f6424Jah0aiP1ki6y = 0.0f;
            this.f6431ohv5Shie7AeZ = 1.0f;
            this.f6426ko7aiFeiqu3s = 1.0f;
            this.f6432ruNgecai1pae = 0.0f;
            this.f6425ahthoK6usais = 1.0f;
            this.f6428mi5Iecheimie = 0.0f;
            this.f6433ruwiepo7ooVu = Paint.Cap.BUTT;
            this.f6422AeJiPo4of6Sh = Paint.Join.MITER;
            this.f6430oYe2ma2she1j = 4.0f;
            this.f6427kuedujio7Aev = keil1eishomu.f6427kuedujio7Aev;
            this.f6423Aicohm8ieYoo = keil1eishomu.f6423Aicohm8ieYoo;
            this.f6424Jah0aiP1ki6y = keil1eishomu.f6424Jah0aiP1ki6y;
            this.f6431ohv5Shie7AeZ = keil1eishomu.f6431ohv5Shie7AeZ;
            this.f6429niah0Shohtha = keil1eishomu.f6429niah0Shohtha;
            this.f6390keiL1EiShomu = keil1eishomu.f6390keiL1EiShomu;
            this.f6426ko7aiFeiqu3s = keil1eishomu.f6426ko7aiFeiqu3s;
            this.f6432ruNgecai1pae = keil1eishomu.f6432ruNgecai1pae;
            this.f6425ahthoK6usais = keil1eishomu.f6425ahthoK6usais;
            this.f6428mi5Iecheimie = keil1eishomu.f6428mi5Iecheimie;
            this.f6433ruwiepo7ooVu = keil1eishomu.f6433ruwiepo7ooVu;
            this.f6422AeJiPo4of6Sh = keil1eishomu.f6422AeJiPo4of6Sh;
            this.f6430oYe2ma2she1j = keil1eishomu.f6430oYe2ma2she1j;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class kuedujio7Aev {
        public kuedujio7Aev() {
        }

        public boolean ieseir3Choge() {
            return false;
        }

        public boolean thooCoci9zae(int[] iArr) {
            return false;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class niah0Shohtha extends Drawable.ConstantState {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public Bitmap f6434Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public ColorStateList f6435Jah0aiP1ki6y;

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public Paint f6436ahthoK6usais;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public PorterDuff.Mode f6437ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public int f6438ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public ColorStateList f6439keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public boolean f6440ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public boolean f6441kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public PorterDuff.Mode f6442niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public int f6443ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public boolean f6444ruNgecai1pae;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public C0087Jah0aiP1ki6y f6445thooCoci9zae;

        public niah0Shohtha() {
            this.f6439keiL1EiShomu = null;
            this.f6437ieheiQu9sho5 = Jah0aiP1ki6y.f6378ruNgecai1pae;
            this.f6445thooCoci9zae = new C0087Jah0aiP1ki6y();
        }

        public boolean Aicohm8ieYoo() {
            if (this.f6445thooCoci9zae.getRootAlpha() < 255) {
                return true;
            }
            return false;
        }

        public boolean Jah0aiP1ki6y() {
            return this.f6445thooCoci9zae.Aicohm8ieYoo();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f6438ieseir3Choge;
        }

        public void ieheiQu9sho5(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f6434Aicohm8ieYoo, (Rect) null, rect, kuedujio7Aev(colorFilter));
        }

        public boolean ieseir3Choge(int i, int i2) {
            if (i == this.f6434Aicohm8ieYoo.getWidth() && i2 == this.f6434Aicohm8ieYoo.getHeight()) {
                return true;
            }
            return false;
        }

        public void keiL1EiShomu(int i, int i2) {
            if (this.f6434Aicohm8ieYoo == null || !ieseir3Choge(i, i2)) {
                this.f6434Aicohm8ieYoo = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
                this.f6444ruNgecai1pae = true;
            }
        }

        public void ko7aiFeiqu3s(int i, int i2) {
            this.f6434Aicohm8ieYoo.eraseColor(0);
            this.f6445thooCoci9zae.thooCoci9zae(new Canvas(this.f6434Aicohm8ieYoo), i, i2, null);
        }

        public Paint kuedujio7Aev(ColorFilter colorFilter) {
            if (!Aicohm8ieYoo() && colorFilter == null) {
                return null;
            }
            if (this.f6436ahthoK6usais == null) {
                Paint paint = new Paint();
                this.f6436ahthoK6usais = paint;
                paint.setFilterBitmap(true);
            }
            this.f6436ahthoK6usais.setAlpha(this.f6445thooCoci9zae.getRootAlpha());
            this.f6436ahthoK6usais.setColorFilter(colorFilter);
            return this.f6436ahthoK6usais;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new Jah0aiP1ki6y(this);
        }

        public boolean niah0Shohtha(int[] iArr) {
            boolean Jah0aiP1ki6y2 = this.f6445thooCoci9zae.Jah0aiP1ki6y(iArr);
            this.f6444ruNgecai1pae |= Jah0aiP1ki6y2;
            return Jah0aiP1ki6y2;
        }

        public void ohv5Shie7AeZ() {
            this.f6435Jah0aiP1ki6y = this.f6439keiL1EiShomu;
            this.f6442niah0Shohtha = this.f6437ieheiQu9sho5;
            this.f6443ohv5Shie7AeZ = this.f6445thooCoci9zae.getRootAlpha();
            this.f6440ko7aiFeiqu3s = this.f6441kuedujio7Aev;
            this.f6444ruNgecai1pae = false;
        }

        public boolean thooCoci9zae() {
            if (!this.f6444ruNgecai1pae && this.f6435Jah0aiP1ki6y == this.f6439keiL1EiShomu && this.f6442niah0Shohtha == this.f6437ieheiQu9sho5 && this.f6440ko7aiFeiqu3s == this.f6441kuedujio7Aev && this.f6443ohv5Shie7AeZ == this.f6445thooCoci9zae.getRootAlpha()) {
                return true;
            }
            return false;
        }

        public niah0Shohtha(niah0Shohtha niah0shohtha) {
            this.f6439keiL1EiShomu = null;
            this.f6437ieheiQu9sho5 = Jah0aiP1ki6y.f6378ruNgecai1pae;
            if (niah0shohtha != null) {
                this.f6438ieseir3Choge = niah0shohtha.f6438ieseir3Choge;
                C0087Jah0aiP1ki6y c0087Jah0aiP1ki6y = new C0087Jah0aiP1ki6y(niah0shohtha.f6445thooCoci9zae);
                this.f6445thooCoci9zae = c0087Jah0aiP1ki6y;
                if (niah0shohtha.f6445thooCoci9zae.f6401kuedujio7Aev != null) {
                    c0087Jah0aiP1ki6y.f6401kuedujio7Aev = new Paint(niah0shohtha.f6445thooCoci9zae.f6401kuedujio7Aev);
                }
                if (niah0shohtha.f6445thooCoci9zae.f6397ieheiQu9sho5 != null) {
                    this.f6445thooCoci9zae.f6397ieheiQu9sho5 = new Paint(niah0shohtha.f6445thooCoci9zae.f6397ieheiQu9sho5);
                }
                this.f6439keiL1EiShomu = niah0shohtha.f6439keiL1EiShomu;
                this.f6437ieheiQu9sho5 = niah0shohtha.f6437ieheiQu9sho5;
                this.f6441kuedujio7Aev = niah0shohtha.f6441kuedujio7Aev;
            }
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new Jah0aiP1ki6y(this);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ohv5Shie7AeZ extends Drawable.ConstantState {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Drawable.ConstantState f6446ieseir3Choge;

        public ohv5Shie7AeZ(Drawable.ConstantState constantState) {
            this.f6446ieseir3Choge = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f6446ieseir3Choge.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f6446ieseir3Choge.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            Jah0aiP1ki6y jah0aiP1ki6y = new Jah0aiP1ki6y();
            jah0aiP1ki6y.f6377ieseir3Choge = (VectorDrawable) this.f6446ieseir3Choge.newDrawable();
            return jah0aiP1ki6y;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            Jah0aiP1ki6y jah0aiP1ki6y = new Jah0aiP1ki6y();
            jah0aiP1ki6y.f6377ieseir3Choge = (VectorDrawable) this.f6446ieseir3Choge.newDrawable(resources);
            return jah0aiP1ki6y;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            Jah0aiP1ki6y jah0aiP1ki6y = new Jah0aiP1ki6y();
            jah0aiP1ki6y.f6377ieseir3Choge = (VectorDrawable) this.f6446ieseir3Choge.newDrawable(resources, theme);
            return jah0aiP1ki6y;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae extends Aicohm8ieYoo {
        public thooCoci9zae() {
        }

        private void Aicohm8ieYoo(TypedArray typedArray, XmlPullParser xmlPullParser) {
            String string = typedArray.getString(0);
            if (string != null) {
                this.f6391thooCoci9zae = string;
            }
            String string2 = typedArray.getString(1);
            if (string2 != null) {
                this.f6389ieseir3Choge = eetheKaevie8.niah0Shohtha.ieheiQu9sho5(string2);
            }
            this.f6390keiL1EiShomu = ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "fillType", 2, 0);
        }

        @Override // ieph3Uteimah.Jah0aiP1ki6y.Aicohm8ieYoo
        public boolean keiL1EiShomu() {
            return true;
        }

        public void kuedujio7Aev(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            if (!ruNgecai1pae.ko7aiFeiqu3s(xmlPullParser, "pathData")) {
                return;
            }
            TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6451ieheiQu9sho5);
            Aicohm8ieYoo(ruNgecai1pae2, xmlPullParser);
            ruNgecai1pae2.recycle();
        }

        public thooCoci9zae(thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
        }
    }

    public Jah0aiP1ki6y() {
        this.f6379Aicohm8ieYoo = true;
        this.f6385niah0Shohtha = new float[9];
        this.f6386ohv5Shie7AeZ = new Matrix();
        this.f6383ko7aiFeiqu3s = new Rect();
        this.f6387thooCoci9zae = new niah0Shohtha();
    }

    public static PorterDuff.Mode Jah0aiP1ki6y(int i, PorterDuff.Mode mode) {
        if (i != 3) {
            if (i != 5) {
                if (i != 9) {
                    switch (i) {
                        case 14:
                            return PorterDuff.Mode.MULTIPLY;
                        case 15:
                            return PorterDuff.Mode.SCREEN;
                        case 16:
                            return PorterDuff.Mode.ADD;
                        default:
                            return mode;
                    }
                }
                return PorterDuff.Mode.SRC_ATOP;
            }
            return PorterDuff.Mode.SRC_IN;
        }
        return PorterDuff.Mode.SRC_OVER;
    }

    public static int ieseir3Choge(int i, float f) {
        return (i & 16777215) | (((int) (Color.alpha(i) * f)) << 24);
    }

    public static Jah0aiP1ki6y keiL1EiShomu(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        Jah0aiP1ki6y jah0aiP1ki6y = new Jah0aiP1ki6y();
        jah0aiP1ki6y.inflate(resources, xmlPullParser, attributeSet, theme);
        return jah0aiP1ki6y;
    }

    public static Jah0aiP1ki6y thooCoci9zae(Resources resources, int i, Resources.Theme theme) {
        int next;
        if (Build.VERSION.SDK_INT >= 24) {
            Jah0aiP1ki6y jah0aiP1ki6y = new Jah0aiP1ki6y();
            jah0aiP1ki6y.f6377ieseir3Choge = oYe2ma2she1j.niah0Shohtha.ieheiQu9sho5(resources, i, theme);
            jah0aiP1ki6y.f6380Jah0aiP1ki6y = new ohv5Shie7AeZ(jah0aiP1ki6y.f6377ieseir3Choge.getConstantState());
            return jah0aiP1ki6y;
        }
        try {
            XmlResourceParser xml = resources.getXml(i);
            AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
            do {
                next = xml.next();
                if (next == 2) {
                    break;
                }
            } while (next != 1);
            if (next == 2) {
                return keiL1EiShomu(resources, xml, asAttributeSet, theme);
            }
            throw new XmlPullParserException("No start tag found");
        } catch (IOException e) {
            e = e;
            Log.e("VectorDrawableCompat", "parser error", e);
            return null;
        } catch (XmlPullParserException e2) {
            e = e2;
            Log.e("VectorDrawableCompat", "parser error", e);
            return null;
        }
    }

    public final boolean Aicohm8ieYoo() {
        if (isAutoMirrored() && zoojiiKaht3i.ieseir3Choge.kuedujio7Aev(this) == 1) {
            return true;
        }
        return false;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void applyTheme(Resources.Theme theme) {
        super.applyTheme(theme);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.thooCoci9zae(drawable);
            return false;
        }
        return false;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        copyBounds(this.f6383ko7aiFeiqu3s);
        if (this.f6383ko7aiFeiqu3s.width() > 0 && this.f6383ko7aiFeiqu3s.height() > 0) {
            ColorFilter colorFilter = this.f6381ieheiQu9sho5;
            if (colorFilter == null) {
                colorFilter = this.f6382keiL1EiShomu;
            }
            canvas.getMatrix(this.f6386ohv5Shie7AeZ);
            this.f6386ohv5Shie7AeZ.getValues(this.f6385niah0Shohtha);
            float abs = Math.abs(this.f6385niah0Shohtha[0]);
            float abs2 = Math.abs(this.f6385niah0Shohtha[4]);
            float abs3 = Math.abs(this.f6385niah0Shohtha[1]);
            float abs4 = Math.abs(this.f6385niah0Shohtha[3]);
            if (abs3 != 0.0f || abs4 != 0.0f) {
                abs = 1.0f;
                abs2 = 1.0f;
            }
            int min = Math.min(2048, (int) (this.f6383ko7aiFeiqu3s.width() * abs));
            int min2 = Math.min(2048, (int) (this.f6383ko7aiFeiqu3s.height() * abs2));
            if (min > 0 && min2 > 0) {
                int save = canvas.save();
                Rect rect = this.f6383ko7aiFeiqu3s;
                canvas.translate(rect.left, rect.top);
                if (Aicohm8ieYoo()) {
                    canvas.translate(this.f6383ko7aiFeiqu3s.width(), 0.0f);
                    canvas.scale(-1.0f, 1.0f);
                }
                this.f6383ko7aiFeiqu3s.offsetTo(0, 0);
                this.f6387thooCoci9zae.keiL1EiShomu(min, min2);
                if (!this.f6379Aicohm8ieYoo) {
                    this.f6387thooCoci9zae.ko7aiFeiqu3s(min, min2);
                } else if (!this.f6387thooCoci9zae.thooCoci9zae()) {
                    this.f6387thooCoci9zae.ko7aiFeiqu3s(min, min2);
                    this.f6387thooCoci9zae.ohv5Shie7AeZ();
                }
                this.f6387thooCoci9zae.ieheiQu9sho5(canvas, colorFilter, this.f6383ko7aiFeiqu3s);
                canvas.restoreToCount(save);
            }
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.keiL1EiShomu(drawable);
        }
        return this.f6387thooCoci9zae.f6445thooCoci9zae.getRootAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.f6387thooCoci9zae.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.ieheiQu9sho5(drawable);
        }
        return this.f6381ieheiQu9sho5;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f6377ieseir3Choge != null && Build.VERSION.SDK_INT >= 24) {
            return new ohv5Shie7AeZ(this.f6377ieseir3Choge.getConstantState());
        }
        this.f6387thooCoci9zae.f6438ieseir3Choge = getChangingConfigurations();
        return this.f6387thooCoci9zae;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        return (int) this.f6387thooCoci9zae.f6445thooCoci9zae.f6400ko7aiFeiqu3s;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        return (int) this.f6387thooCoci9zae.f6445thooCoci9zae.f6405ohv5Shie7AeZ;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public Object ieheiQu9sho5(String str) {
        return this.f6387thooCoci9zae.f6445thooCoci9zae.f6404oYe2ma2she1j.get(str);
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.Jah0aiP1ki6y(drawable);
        }
        return this.f6387thooCoci9zae.f6441kuedujio7Aev;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        niah0Shohtha niah0shohtha;
        ColorStateList colorStateList;
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.isStateful();
        }
        if (!super.isStateful() && ((niah0shohtha = this.f6387thooCoci9zae) == null || (!niah0shohtha.Jah0aiP1ki6y() && ((colorStateList = this.f6387thooCoci9zae.f6439keiL1EiShomu) == null || !colorStateList.isStateful())))) {
            return false;
        }
        return true;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public PorterDuffColorFilter ko7aiFeiqu3s(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList != null && mode != null) {
            return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
        }
        return null;
    }

    public final void kuedujio7Aev(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        int i;
        int i2;
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        C0087Jah0aiP1ki6y c0087Jah0aiP1ki6y = niah0shohtha.f6445thooCoci9zae;
        ArrayDeque arrayDeque = new ArrayDeque();
        arrayDeque.push(c0087Jah0aiP1ki6y.f6403niah0Shohtha);
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        boolean z = true;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                ieheiQu9sho5 ieheiqu9sho5 = (ieheiQu9sho5) arrayDeque.peek();
                if ("path".equals(name)) {
                    keiL1EiShomu keil1eishomu = new keiL1EiShomu();
                    keil1eishomu.Jah0aiP1ki6y(resources, attributeSet, theme, xmlPullParser);
                    ieheiqu9sho5.f6421thooCoci9zae.add(keil1eishomu);
                    if (keil1eishomu.getPathName() != null) {
                        c0087Jah0aiP1ki6y.f6404oYe2ma2she1j.put(keil1eishomu.getPathName(), keil1eishomu);
                    }
                    niah0shohtha.f6438ieseir3Choge = keil1eishomu.f6388ieheiQu9sho5 | niah0shohtha.f6438ieseir3Choge;
                    z = false;
                } else {
                    if ("clip-path".equals(name)) {
                        thooCoci9zae thoococi9zae = new thooCoci9zae();
                        thoococi9zae.kuedujio7Aev(resources, attributeSet, theme, xmlPullParser);
                        ieheiqu9sho5.f6421thooCoci9zae.add(thoococi9zae);
                        if (thoococi9zae.getPathName() != null) {
                            c0087Jah0aiP1ki6y.f6404oYe2ma2she1j.put(thoococi9zae.getPathName(), thoococi9zae);
                        }
                        i = niah0shohtha.f6438ieseir3Choge;
                        i2 = thoococi9zae.f6388ieheiQu9sho5;
                    } else if ("group".equals(name)) {
                        ieheiQu9sho5 ieheiqu9sho52 = new ieheiQu9sho5();
                        ieheiqu9sho52.keiL1EiShomu(resources, attributeSet, theme, xmlPullParser);
                        ieheiqu9sho5.f6421thooCoci9zae.add(ieheiqu9sho52);
                        arrayDeque.push(ieheiqu9sho52);
                        if (ieheiqu9sho52.getGroupName() != null) {
                            c0087Jah0aiP1ki6y.f6404oYe2ma2she1j.put(ieheiqu9sho52.getGroupName(), ieheiqu9sho52);
                        }
                        i = niah0shohtha.f6438ieseir3Choge;
                        i2 = ieheiqu9sho52.f6420ruNgecai1pae;
                    }
                    niah0shohtha.f6438ieseir3Choge = i2 | i;
                }
            } else if (eventType == 3 && "group".equals(xmlPullParser.getName())) {
                arrayDeque.pop();
            }
            eventType = xmlPullParser.next();
        }
        if (!z) {
        } else {
            throw new XmlPullParserException("no path defined");
        }
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.f6384kuedujio7Aev && super.mutate() == this) {
            this.f6387thooCoci9zae = new niah0Shohtha(this.f6387thooCoci9zae);
            this.f6384kuedujio7Aev = true;
        }
        return this;
    }

    public void niah0Shohtha(boolean z) {
        this.f6379Aicohm8ieYoo = z;
    }

    public final void ohv5Shie7AeZ(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme) {
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        C0087Jah0aiP1ki6y c0087Jah0aiP1ki6y = niah0shohtha.f6445thooCoci9zae;
        niah0shohtha.f6437ieheiQu9sho5 = Jah0aiP1ki6y(ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "tintMode", 6, -1), PorterDuff.Mode.SRC_IN);
        ColorStateList keiL1EiShomu2 = ruNgecai1pae.keiL1EiShomu(typedArray, xmlPullParser, theme, "tint", 1);
        if (keiL1EiShomu2 != null) {
            niah0shohtha.f6439keiL1EiShomu = keiL1EiShomu2;
        }
        niah0shohtha.f6441kuedujio7Aev = ruNgecai1pae.ieseir3Choge(typedArray, xmlPullParser, "autoMirrored", 5, niah0shohtha.f6441kuedujio7Aev);
        c0087Jah0aiP1ki6y.f6406ruNgecai1pae = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "viewportWidth", 7, c0087Jah0aiP1ki6y.f6406ruNgecai1pae);
        float Aicohm8ieYoo2 = ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "viewportHeight", 8, c0087Jah0aiP1ki6y.f6396ahthoK6usais);
        c0087Jah0aiP1ki6y.f6396ahthoK6usais = Aicohm8ieYoo2;
        if (c0087Jah0aiP1ki6y.f6406ruNgecai1pae > 0.0f) {
            if (Aicohm8ieYoo2 > 0.0f) {
                c0087Jah0aiP1ki6y.f6405ohv5Shie7AeZ = typedArray.getDimension(3, c0087Jah0aiP1ki6y.f6405ohv5Shie7AeZ);
                float dimension = typedArray.getDimension(2, c0087Jah0aiP1ki6y.f6400ko7aiFeiqu3s);
                c0087Jah0aiP1ki6y.f6400ko7aiFeiqu3s = dimension;
                if (c0087Jah0aiP1ki6y.f6405ohv5Shie7AeZ > 0.0f) {
                    if (dimension > 0.0f) {
                        c0087Jah0aiP1ki6y.setAlpha(ruNgecai1pae.Aicohm8ieYoo(typedArray, xmlPullParser, "alpha", 4, c0087Jah0aiP1ki6y.getAlpha()));
                        String string = typedArray.getString(0);
                        if (string != null) {
                            c0087Jah0aiP1ki6y.f6407ruwiepo7ooVu = string;
                            c0087Jah0aiP1ki6y.f6404oYe2ma2she1j.put(string, c0087Jah0aiP1ki6y);
                            return;
                        }
                        return;
                    }
                    throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires height > 0");
                }
                throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires width > 0");
            }
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportHeight > 0");
        }
        throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportWidth > 0");
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        boolean z;
        PorterDuff.Mode mode;
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        ColorStateList colorStateList = niah0shohtha.f6439keiL1EiShomu;
        if (colorStateList != null && (mode = niah0shohtha.f6437ieheiQu9sho5) != null) {
            this.f6382keiL1EiShomu = ko7aiFeiqu3s(this.f6382keiL1EiShomu, colorStateList, mode);
            invalidateSelf();
            z = true;
        } else {
            z = false;
        }
        if (niah0shohtha.Jah0aiP1ki6y() && niah0shohtha.niah0Shohtha(iArr)) {
            invalidateSelf();
            return true;
        }
        return z;
    }

    @Override // android.graphics.drawable.Drawable
    public void scheduleSelf(Runnable runnable, long j) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else if (this.f6387thooCoci9zae.f6445thooCoci9zae.getRootAlpha() != i) {
            this.f6387thooCoci9zae.f6445thooCoci9zae.setRootAlpha(i);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.ohv5Shie7AeZ(drawable, z);
        } else {
            this.f6387thooCoci9zae.f6441kuedujio7Aev = z;
        }
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setColorFilter(int i, PorterDuff.Mode mode) {
        super.setColorFilter(i, mode);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.mi5Iecheimie(drawable, i);
        } else {
            setTintList(ColorStateList.valueOf(i));
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.ruwiepo7ooVu(drawable, colorStateList);
            return;
        }
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        if (niah0shohtha.f6439keiL1EiShomu != colorStateList) {
            niah0shohtha.f6439keiL1EiShomu = colorStateList;
            this.f6382keiL1EiShomu = ko7aiFeiqu3s(this.f6382keiL1EiShomu, colorStateList, niah0shohtha.f6437ieheiQu9sho5);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.AeJiPo4of6Sh(drawable, mode);
            return;
        }
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        if (niah0shohtha.f6437ieheiQu9sho5 != mode) {
            niah0shohtha.f6437ieheiQu9sho5 = mode;
            this.f6382keiL1EiShomu = ko7aiFeiqu3s(this.f6382keiL1EiShomu, niah0shohtha.f6439keiL1EiShomu, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.setVisible(z, z2);
        }
        return super.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Drawable
    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }

    public Jah0aiP1ki6y(niah0Shohtha niah0shohtha) {
        this.f6379Aicohm8ieYoo = true;
        this.f6385niah0Shohtha = new float[9];
        this.f6386ohv5Shie7AeZ = new Matrix();
        this.f6383ko7aiFeiqu3s = new Rect();
        this.f6387thooCoci9zae = niah0shohtha;
        this.f6382keiL1EiShomu = ko7aiFeiqu3s(this.f6382keiL1EiShomu, niah0shohtha.f6439keiL1EiShomu, niah0shohtha.f6437ieheiQu9sho5);
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.Aicohm8ieYoo(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        niah0Shohtha niah0shohtha = this.f6387thooCoci9zae;
        niah0shohtha.f6445thooCoci9zae = new C0087Jah0aiP1ki6y();
        TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6452ieseir3Choge);
        ohv5Shie7AeZ(ruNgecai1pae2, xmlPullParser, theme);
        ruNgecai1pae2.recycle();
        niah0shohtha.f6438ieseir3Choge = getChangingConfigurations();
        niah0shohtha.f6444ruNgecai1pae = true;
        kuedujio7Aev(resources, xmlPullParser, attributeSet, theme);
        this.f6382keiL1EiShomu = ko7aiFeiqu3s(this.f6382keiL1EiShomu, niah0shohtha.f6439keiL1EiShomu, niah0shohtha.f6437ieheiQu9sho5);
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.f6381ieheiQu9sho5 = colorFilter;
            invalidateSelf();
        }
    }
}
