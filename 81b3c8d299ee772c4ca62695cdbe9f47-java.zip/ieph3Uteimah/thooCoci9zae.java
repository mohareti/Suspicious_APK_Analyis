package ieph3Uteimah;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import java.util.ArrayList;
import oYe2ma2she1j.ruNgecai1pae;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class thooCoci9zae extends Aicohm8ieYoo implements Animatable {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public ArrayList f6461Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final Drawable.Callback f6462Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public ArgbEvaluator f6463ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public Context f6464keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public Animator.AnimatorListener f6465kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public C0088thooCoci9zae f6466thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements Drawable.Callback {
        public ieseir3Choge() {
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void invalidateDrawable(Drawable drawable) {
            thooCoci9zae.this.invalidateSelf();
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
            thooCoci9zae.this.scheduleSelf(runnable, j);
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            thooCoci9zae.this.unscheduleSelf(runnable);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu extends Drawable.ConstantState {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Drawable.ConstantState f6468ieseir3Choge;

        public keiL1EiShomu(Drawable.ConstantState constantState) {
            this.f6468ieseir3Choge = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f6468ieseir3Choge.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f6468ieseir3Choge.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            thooCoci9zae thoococi9zae = new thooCoci9zae();
            Drawable newDrawable = this.f6468ieseir3Choge.newDrawable();
            thoococi9zae.f6377ieseir3Choge = newDrawable;
            newDrawable.setCallback(thoococi9zae.f6462Jah0aiP1ki6y);
            return thoococi9zae;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            thooCoci9zae thoococi9zae = new thooCoci9zae();
            Drawable newDrawable = this.f6468ieseir3Choge.newDrawable(resources);
            thoococi9zae.f6377ieseir3Choge = newDrawable;
            newDrawable.setCallback(thoococi9zae.f6462Jah0aiP1ki6y);
            return thoococi9zae;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            thooCoci9zae thoococi9zae = new thooCoci9zae();
            Drawable newDrawable = this.f6468ieseir3Choge.newDrawable(resources, theme);
            thoococi9zae.f6377ieseir3Choge = newDrawable;
            newDrawable.setCallback(thoococi9zae.f6462Jah0aiP1ki6y);
            return thoococi9zae;
        }
    }

    /* renamed from: ieph3Uteimah.thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0088thooCoci9zae extends Drawable.ConstantState {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public ArrayList f6469ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public int f6470ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public AnimatorSet f6471keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public ruNgecai1pae.ieseir3Choge f6472kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Jah0aiP1ki6y f6473thooCoci9zae;

        public C0088thooCoci9zae(Context context, C0088thooCoci9zae c0088thooCoci9zae, Drawable.Callback callback, Resources resources) {
            Drawable newDrawable;
            if (c0088thooCoci9zae != null) {
                this.f6470ieseir3Choge = c0088thooCoci9zae.f6470ieseir3Choge;
                Jah0aiP1ki6y jah0aiP1ki6y = c0088thooCoci9zae.f6473thooCoci9zae;
                if (jah0aiP1ki6y != null) {
                    Drawable.ConstantState constantState = jah0aiP1ki6y.getConstantState();
                    if (resources != null) {
                        newDrawable = constantState.newDrawable(resources);
                    } else {
                        newDrawable = constantState.newDrawable();
                    }
                    this.f6473thooCoci9zae = (Jah0aiP1ki6y) newDrawable;
                    Jah0aiP1ki6y jah0aiP1ki6y2 = (Jah0aiP1ki6y) this.f6473thooCoci9zae.mutate();
                    this.f6473thooCoci9zae = jah0aiP1ki6y2;
                    jah0aiP1ki6y2.setCallback(callback);
                    this.f6473thooCoci9zae.setBounds(c0088thooCoci9zae.f6473thooCoci9zae.getBounds());
                    this.f6473thooCoci9zae.niah0Shohtha(false);
                }
                ArrayList arrayList = c0088thooCoci9zae.f6469ieheiQu9sho5;
                if (arrayList != null) {
                    int size = arrayList.size();
                    this.f6469ieheiQu9sho5 = new ArrayList(size);
                    this.f6472kuedujio7Aev = new ruNgecai1pae.ieseir3Choge(size);
                    for (int i = 0; i < size; i++) {
                        Animator animator = (Animator) c0088thooCoci9zae.f6469ieheiQu9sho5.get(i);
                        Animator clone = animator.clone();
                        String str = (String) c0088thooCoci9zae.f6472kuedujio7Aev.get(animator);
                        clone.setTarget(this.f6473thooCoci9zae.ieheiQu9sho5(str));
                        this.f6469ieheiQu9sho5.add(clone);
                        this.f6472kuedujio7Aev.put(clone, str);
                    }
                    ieseir3Choge();
                }
            }
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f6470ieseir3Choge;
        }

        public void ieseir3Choge() {
            if (this.f6471keiL1EiShomu == null) {
                this.f6471keiL1EiShomu = new AnimatorSet();
            }
            this.f6471keiL1EiShomu.playTogether(this.f6469ieheiQu9sho5);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }
    }

    public thooCoci9zae() {
        this(null, null, null);
    }

    public static thooCoci9zae ieseir3Choge(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        thooCoci9zae thoococi9zae = new thooCoci9zae(context);
        thoococi9zae.inflate(resources, xmlPullParser, attributeSet, theme);
        return thoococi9zae;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.ieseir3Choge(drawable, theme);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.thooCoci9zae(drawable);
        }
        return false;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        this.f6466thooCoci9zae.f6473thooCoci9zae.draw(canvas);
        if (this.f6466thooCoci9zae.f6471keiL1EiShomu.isStarted()) {
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.keiL1EiShomu(drawable);
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.getAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.f6466thooCoci9zae.f6470ieseir3Choge;
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.ieheiQu9sho5(drawable);
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.getColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f6377ieseir3Choge != null && Build.VERSION.SDK_INT >= 24) {
            return new keiL1EiShomu(this.f6377ieseir3Choge.getConstantState());
        }
        return null;
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getIntrinsicHeight();
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.getIntrinsicHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getIntrinsicWidth();
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.getIntrinsicWidth();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.getOpacity();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return zoojiiKaht3i.ieseir3Choge.Jah0aiP1ki6y(drawable);
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.isAutoMirrored();
    }

    @Override // android.graphics.drawable.Animatable
    public boolean isRunning() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return ((AnimatedVectorDrawable) drawable).isRunning();
        }
        return this.f6466thooCoci9zae.f6471keiL1EiShomu.isRunning();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.isStateful();
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.isStateful();
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.mutate();
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setBounds(rect);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setBounds(rect);
        }
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public boolean onLevelChange(int i) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.setLevel(i);
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.setLevel(i);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        return this.f6466thooCoci9zae.f6473thooCoci9zae.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setAlpha(i);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.ohv5Shie7AeZ(drawable, z);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setAutoMirrored(z);
        }
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setColorFilter(int i, PorterDuff.Mode mode) {
        super.setColorFilter(i, mode);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    @Override // ieph3Uteimah.Aicohm8ieYoo, android.graphics.drawable.Drawable
    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.mi5Iecheimie(drawable, i);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setTint(i);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.ruwiepo7ooVu(drawable, colorStateList);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setTintList(colorStateList);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.AeJiPo4of6Sh(drawable, mode);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setTintMode(mode);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            return drawable.setVisible(z, z2);
        }
        this.f6466thooCoci9zae.f6473thooCoci9zae.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Animatable
    public void start() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).start();
        } else {
            if (this.f6466thooCoci9zae.f6471keiL1EiShomu.isStarted()) {
                return;
            }
            this.f6466thooCoci9zae.f6471keiL1EiShomu.start();
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Animatable
    public void stop() {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).stop();
        } else {
            this.f6466thooCoci9zae.f6471keiL1EiShomu.end();
        }
    }

    public final void thooCoci9zae(String str, Animator animator) {
        animator.setTarget(this.f6466thooCoci9zae.f6473thooCoci9zae.ieheiQu9sho5(str));
        C0088thooCoci9zae c0088thooCoci9zae = this.f6466thooCoci9zae;
        if (c0088thooCoci9zae.f6469ieheiQu9sho5 == null) {
            c0088thooCoci9zae.f6469ieheiQu9sho5 = new ArrayList();
            this.f6466thooCoci9zae.f6472kuedujio7Aev = new ruNgecai1pae.ieseir3Choge();
        }
        this.f6466thooCoci9zae.f6469ieheiQu9sho5.add(animator);
        this.f6466thooCoci9zae.f6472kuedujio7Aev.put(animator, str);
    }

    public thooCoci9zae(Context context) {
        this(context, null, null);
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        TypedArray obtainAttributes;
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            zoojiiKaht3i.ieseir3Choge.Aicohm8ieYoo(drawable, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if ("animated-vector".equals(name)) {
                    obtainAttributes = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6455kuedujio7Aev);
                    int resourceId = obtainAttributes.getResourceId(0, 0);
                    if (resourceId != 0) {
                        Jah0aiP1ki6y thooCoci9zae2 = Jah0aiP1ki6y.thooCoci9zae(resources, resourceId, theme);
                        thooCoci9zae2.niah0Shohtha(false);
                        thooCoci9zae2.setCallback(this.f6462Jah0aiP1ki6y);
                        Jah0aiP1ki6y jah0aiP1ki6y = this.f6466thooCoci9zae.f6473thooCoci9zae;
                        if (jah0aiP1ki6y != null) {
                            jah0aiP1ki6y.setCallback(null);
                        }
                        this.f6466thooCoci9zae.f6473thooCoci9zae = thooCoci9zae2;
                    }
                } else if ("target".equals(name)) {
                    obtainAttributes = resources.obtainAttributes(attributeSet, ieph3Uteimah.ieseir3Choge.f6448Aicohm8ieYoo);
                    String string = obtainAttributes.getString(0);
                    int resourceId2 = obtainAttributes.getResourceId(1, 0);
                    if (resourceId2 != 0) {
                        Context context = this.f6464keiL1EiShomu;
                        if (context == null) {
                            obtainAttributes.recycle();
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                        thooCoci9zae(string, ieheiQu9sho5.ohv5Shie7AeZ(context, resourceId2));
                    }
                } else {
                    continue;
                }
                obtainAttributes.recycle();
            }
            eventType = xmlPullParser.next();
        }
        this.f6466thooCoci9zae.ieseir3Choge();
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f6377ieseir3Choge;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.f6466thooCoci9zae.f6473thooCoci9zae.setColorFilter(colorFilter);
        }
    }

    public thooCoci9zae(Context context, C0088thooCoci9zae c0088thooCoci9zae, Resources resources) {
        this.f6463ieheiQu9sho5 = null;
        this.f6465kuedujio7Aev = null;
        this.f6461Aicohm8ieYoo = null;
        ieseir3Choge ieseir3choge = new ieseir3Choge();
        this.f6462Jah0aiP1ki6y = ieseir3choge;
        this.f6464keiL1EiShomu = context;
        if (c0088thooCoci9zae != null) {
            this.f6466thooCoci9zae = c0088thooCoci9zae;
        } else {
            this.f6466thooCoci9zae = new C0088thooCoci9zae(context, c0088thooCoci9zae, ieseir3choge, resources);
        }
    }
}
