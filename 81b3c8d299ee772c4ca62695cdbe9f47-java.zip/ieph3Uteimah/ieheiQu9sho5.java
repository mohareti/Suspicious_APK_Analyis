package ieph3Uteimah;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import eetheKaevie8.niah0Shohtha;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import oYe2ma2she1j.ruNgecai1pae;
import org.conscrypt.BuildConfig;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge implements TypeEvaluator {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public niah0Shohtha.thooCoci9zae[] f6447ieseir3Choge;

        @Override // android.animation.TypeEvaluator
        /* renamed from: ieseir3Choge, reason: merged with bridge method [inline-methods] */
        public niah0Shohtha.thooCoci9zae[] evaluate(float f, niah0Shohtha.thooCoci9zae[] thoococi9zaeArr, niah0Shohtha.thooCoci9zae[] thoococi9zaeArr2) {
            if (niah0Shohtha.thooCoci9zae(thoococi9zaeArr, thoococi9zaeArr2)) {
                if (!niah0Shohtha.thooCoci9zae(this.f6447ieseir3Choge, thoococi9zaeArr)) {
                    this.f6447ieseir3Choge = niah0Shohtha.Aicohm8ieYoo(thoococi9zaeArr);
                }
                for (int i = 0; i < thoococi9zaeArr.length; i++) {
                    this.f6447ieseir3Choge[i].niah0Shohtha(thoococi9zaeArr[i], thoococi9zaeArr2[i], f);
                }
                return this.f6447ieseir3Choge;
            }
            throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
        }
    }

    public static PropertyValuesHolder AeJiPo4of6Sh(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, String str, int i) {
        int size;
        PropertyValuesHolder propertyValuesHolder = null;
        ArrayList arrayList = null;
        while (true) {
            int next = xmlPullParser.next();
            if (next == 3 || next == 1) {
                break;
            }
            if (xmlPullParser.getName().equals("keyframe")) {
                if (i == 4) {
                    i = Jah0aiP1ki6y(resources, theme, Xml.asAttributeSet(xmlPullParser), xmlPullParser);
                }
                Keyframe mi5Iecheimie2 = mi5Iecheimie(context, resources, theme, Xml.asAttributeSet(xmlPullParser), i, xmlPullParser);
                if (mi5Iecheimie2 != null) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(mi5Iecheimie2);
                }
                xmlPullParser.next();
            }
        }
        if (arrayList != null && (size = arrayList.size()) > 0) {
            Keyframe keyframe = (Keyframe) arrayList.get(0);
            Keyframe keyframe2 = (Keyframe) arrayList.get(size - 1);
            float fraction = keyframe2.getFraction();
            if (fraction < 1.0f) {
                if (fraction < 0.0f) {
                    keyframe2.setFraction(1.0f);
                } else {
                    arrayList.add(arrayList.size(), keiL1EiShomu(keyframe2, 1.0f));
                    size++;
                }
            }
            float fraction2 = keyframe.getFraction();
            if (fraction2 != 0.0f) {
                if (fraction2 < 0.0f) {
                    keyframe.setFraction(0.0f);
                } else {
                    arrayList.add(0, keiL1EiShomu(keyframe, 0.0f));
                    size++;
                }
            }
            Keyframe[] keyframeArr = new Keyframe[size];
            arrayList.toArray(keyframeArr);
            for (int i2 = 0; i2 < size; i2++) {
                Keyframe keyframe3 = keyframeArr[i2];
                if (keyframe3.getFraction() < 0.0f) {
                    if (i2 == 0) {
                        keyframe3.setFraction(0.0f);
                    } else {
                        int i3 = size - 1;
                        if (i2 == i3) {
                            keyframe3.setFraction(1.0f);
                        } else {
                            int i4 = i2;
                            for (int i5 = i2 + 1; i5 < i3 && keyframeArr[i5].getFraction() < 0.0f; i5++) {
                                i4 = i5;
                            }
                            ieheiQu9sho5(keyframeArr, keyframeArr[i4 + 1].getFraction() - keyframeArr[i2 - 1].getFraction(), i2, i4);
                        }
                    }
                }
            }
            propertyValuesHolder = PropertyValuesHolder.ofKeyframe(str, keyframeArr);
            if (i == 3) {
                propertyValuesHolder.setEvaluator(kuedujio7Aev.ieseir3Choge());
            }
        }
        return propertyValuesHolder;
    }

    public static int Aicohm8ieYoo(TypedArray typedArray, int i, int i2) {
        boolean z;
        int i3;
        int i4;
        TypedValue peekValue = typedArray.peekValue(i);
        boolean z2 = true;
        if (peekValue != null) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            i3 = peekValue.type;
        } else {
            i3 = 0;
        }
        TypedValue peekValue2 = typedArray.peekValue(i2);
        if (peekValue2 == null) {
            z2 = false;
        }
        if (z2) {
            i4 = peekValue2.type;
        } else {
            i4 = 0;
        }
        if ((!z || !niah0Shohtha(i3)) && (!z2 || !niah0Shohtha(i4))) {
            return 0;
        }
        return 3;
    }

    public static int Jah0aiP1ki6y(Resources resources, Resources.Theme theme, AttributeSet attributeSet, XmlPullParser xmlPullParser) {
        TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6454ko7aiFeiqu3s);
        int i = 0;
        TypedValue ahthoK6usais2 = ruNgecai1pae.ahthoK6usais(ruNgecai1pae2, xmlPullParser, "value", 0);
        if (ahthoK6usais2 != null && niah0Shohtha(ahthoK6usais2.type)) {
            i = 3;
        }
        ruNgecai1pae2.recycle();
        return i;
    }

    public static void aac1eTaexee6(Path path, ObjectAnimator objectAnimator, float f, String str, String str2) {
        PropertyValuesHolder propertyValuesHolder;
        PropertyValuesHolder propertyValuesHolder2;
        int i = 1;
        PathMeasure pathMeasure = new PathMeasure(path, false);
        ArrayList arrayList = new ArrayList();
        float f2 = 0.0f;
        arrayList.add(Float.valueOf(0.0f));
        float f3 = 0.0f;
        do {
            f3 += pathMeasure.getLength();
            arrayList.add(Float.valueOf(f3));
        } while (pathMeasure.nextContour());
        PathMeasure pathMeasure2 = new PathMeasure(path, false);
        int min = Math.min(100, ((int) (f3 / f)) + 1);
        float[] fArr = new float[min];
        float[] fArr2 = new float[min];
        float[] fArr3 = new float[2];
        float f4 = f3 / (min - 1);
        int i2 = 0;
        int i3 = 0;
        while (true) {
            propertyValuesHolder = null;
            if (i2 >= min) {
                break;
            }
            pathMeasure2.getPosTan(f2 - ((Float) arrayList.get(i3)).floatValue(), fArr3, null);
            fArr[i2] = fArr3[0];
            fArr2[i2] = fArr3[1];
            f2 += f4;
            int i4 = i3 + 1;
            if (i4 < arrayList.size() && f2 > ((Float) arrayList.get(i4)).floatValue()) {
                pathMeasure2.nextContour();
                i3 = i4;
            }
            i = 1;
            i2++;
        }
        if (str != null) {
            propertyValuesHolder2 = PropertyValuesHolder.ofFloat(str, fArr);
        } else {
            propertyValuesHolder2 = null;
        }
        if (str2 != null) {
            propertyValuesHolder = PropertyValuesHolder.ofFloat(str2, fArr2);
        }
        if (propertyValuesHolder2 == null) {
            PropertyValuesHolder[] propertyValuesHolderArr = new PropertyValuesHolder[i];
            propertyValuesHolderArr[0] = propertyValuesHolder;
            objectAnimator.setValues(propertyValuesHolderArr);
        } else if (propertyValuesHolder == null) {
            PropertyValuesHolder[] propertyValuesHolderArr2 = new PropertyValuesHolder[i];
            propertyValuesHolderArr2[0] = propertyValuesHolder2;
            objectAnimator.setValues(propertyValuesHolderArr2);
        } else {
            PropertyValuesHolder[] propertyValuesHolderArr3 = new PropertyValuesHolder[2];
            propertyValuesHolderArr3[0] = propertyValuesHolder2;
            propertyValuesHolderArr3[i] = propertyValuesHolder;
            objectAnimator.setValues(propertyValuesHolderArr3);
        }
    }

    public static ValueAnimator ahthoK6usais(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f, XmlPullParser xmlPullParser) {
        TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6449Jah0aiP1ki6y);
        TypedArray ruNgecai1pae3 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6458ruNgecai1pae);
        if (valueAnimator == null) {
            valueAnimator = new ValueAnimator();
        }
        eetheKaevie8(valueAnimator, ruNgecai1pae2, ruNgecai1pae3, f, xmlPullParser);
        int niah0Shohtha2 = ruNgecai1pae.niah0Shohtha(ruNgecai1pae2, xmlPullParser, "interpolator", 0, 0);
        if (niah0Shohtha2 > 0) {
            valueAnimator.setInterpolator(keiL1EiShomu.ieseir3Choge(context, niah0Shohtha2));
        }
        ruNgecai1pae2.recycle();
        if (ruNgecai1pae3 != null) {
            ruNgecai1pae3.recycle();
        }
        return valueAnimator;
    }

    public static void eetheKaevie8(ValueAnimator valueAnimator, TypedArray typedArray, TypedArray typedArray2, float f, XmlPullParser xmlPullParser) {
        long Jah0aiP1ki6y2 = ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "duration", 1, 300);
        long Jah0aiP1ki6y3 = ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "startOffset", 2, 0);
        int Jah0aiP1ki6y4 = ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "valueType", 7, 4);
        if (ruNgecai1pae.ko7aiFeiqu3s(xmlPullParser, "valueFrom") && ruNgecai1pae.ko7aiFeiqu3s(xmlPullParser, "valueTo")) {
            if (Jah0aiP1ki6y4 == 4) {
                Jah0aiP1ki6y4 = Aicohm8ieYoo(typedArray, 5, 6);
            }
            PropertyValuesHolder kuedujio7Aev2 = kuedujio7Aev(typedArray, Jah0aiP1ki6y4, 5, 6, BuildConfig.FLAVOR);
            if (kuedujio7Aev2 != null) {
                valueAnimator.setValues(kuedujio7Aev2);
            }
        }
        valueAnimator.setDuration(Jah0aiP1ki6y2);
        valueAnimator.setStartDelay(Jah0aiP1ki6y3);
        valueAnimator.setRepeatCount(ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "repeatCount", 3, 0));
        valueAnimator.setRepeatMode(ruNgecai1pae.Jah0aiP1ki6y(typedArray, xmlPullParser, "repeatMode", 4, 1));
        if (typedArray2 != null) {
            zoojiiKaht3i(valueAnimator, typedArray2, Jah0aiP1ki6y4, f, xmlPullParser);
        }
    }

    public static void ieheiQu9sho5(Keyframe[] keyframeArr, float f, int i, int i2) {
        float f2 = f / ((i2 - i) + 2);
        while (i <= i2) {
            keyframeArr[i].setFraction(keyframeArr[i - 1].getFraction() + f2);
            i++;
        }
    }

    public static Animator ieseir3Choge(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, float f) {
        return thooCoci9zae(context, resources, theme, xmlPullParser, Xml.asAttributeSet(xmlPullParser), null, 0, f);
    }

    public static Keyframe keiL1EiShomu(Keyframe keyframe, float f) {
        if (keyframe.getType() == Float.TYPE) {
            return Keyframe.ofFloat(f);
        }
        if (keyframe.getType() == Integer.TYPE) {
            return Keyframe.ofInt(f);
        }
        return Keyframe.ofObject(f);
    }

    public static Animator ko7aiFeiqu3s(Context context, Resources resources, Resources.Theme theme, int i) {
        return ruNgecai1pae(context, resources, theme, i, 1.0f);
    }

    public static PropertyValuesHolder kuedujio7Aev(TypedArray typedArray, int i, int i2, int i3, String str) {
        boolean z;
        int i4;
        boolean z2;
        int i5;
        boolean z3;
        kuedujio7Aev kuedujio7aev;
        int i6;
        int i7;
        int i8;
        float f;
        PropertyValuesHolder ofFloat;
        float f2;
        float f3;
        PropertyValuesHolder ofObject;
        TypedValue peekValue = typedArray.peekValue(i2);
        if (peekValue != null) {
            z = true;
        } else {
            z = false;
        }
        if (z) {
            i4 = peekValue.type;
        } else {
            i4 = 0;
        }
        TypedValue peekValue2 = typedArray.peekValue(i3);
        if (peekValue2 != null) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (z2) {
            i5 = peekValue2.type;
        } else {
            i5 = 0;
        }
        if (i == 4) {
            if ((z && niah0Shohtha(i4)) || (z2 && niah0Shohtha(i5))) {
                i = 3;
            } else {
                i = 0;
            }
        }
        if (i == 0) {
            z3 = true;
        } else {
            z3 = false;
        }
        PropertyValuesHolder propertyValuesHolder = null;
        if (i == 2) {
            String string = typedArray.getString(i2);
            String string2 = typedArray.getString(i3);
            niah0Shohtha.thooCoci9zae[] ieheiQu9sho52 = niah0Shohtha.ieheiQu9sho5(string);
            niah0Shohtha.thooCoci9zae[] ieheiQu9sho53 = niah0Shohtha.ieheiQu9sho5(string2);
            if (ieheiQu9sho52 == null && ieheiQu9sho53 == null) {
                return null;
            }
            if (ieheiQu9sho52 != null) {
                ieseir3Choge ieseir3choge = new ieseir3Choge();
                if (ieheiQu9sho53 != null) {
                    if (niah0Shohtha.thooCoci9zae(ieheiQu9sho52, ieheiQu9sho53)) {
                        ofObject = PropertyValuesHolder.ofObject(str, ieseir3choge, ieheiQu9sho52, ieheiQu9sho53);
                    } else {
                        throw new InflateException(" Can't morph from " + string + " to " + string2);
                    }
                } else {
                    ofObject = PropertyValuesHolder.ofObject(str, ieseir3choge, ieheiQu9sho52);
                }
                return ofObject;
            }
            if (ieheiQu9sho53 == null) {
                return null;
            }
            return PropertyValuesHolder.ofObject(str, new ieseir3Choge(), ieheiQu9sho53);
        }
        if (i == 3) {
            kuedujio7aev = kuedujio7Aev.ieseir3Choge();
        } else {
            kuedujio7aev = null;
        }
        if (z3) {
            if (z) {
                if (i4 == 5) {
                    f2 = typedArray.getDimension(i2, 0.0f);
                } else {
                    f2 = typedArray.getFloat(i2, 0.0f);
                }
                if (z2) {
                    if (i5 == 5) {
                        f3 = typedArray.getDimension(i3, 0.0f);
                    } else {
                        f3 = typedArray.getFloat(i3, 0.0f);
                    }
                    ofFloat = PropertyValuesHolder.ofFloat(str, f2, f3);
                } else {
                    ofFloat = PropertyValuesHolder.ofFloat(str, f2);
                }
            } else {
                if (i5 == 5) {
                    f = typedArray.getDimension(i3, 0.0f);
                } else {
                    f = typedArray.getFloat(i3, 0.0f);
                }
                ofFloat = PropertyValuesHolder.ofFloat(str, f);
            }
            propertyValuesHolder = ofFloat;
        } else if (z) {
            if (i4 == 5) {
                i7 = (int) typedArray.getDimension(i2, 0.0f);
            } else if (niah0Shohtha(i4)) {
                i7 = typedArray.getColor(i2, 0);
            } else {
                i7 = typedArray.getInt(i2, 0);
            }
            if (z2) {
                if (i5 == 5) {
                    i8 = (int) typedArray.getDimension(i3, 0.0f);
                } else if (niah0Shohtha(i5)) {
                    i8 = typedArray.getColor(i3, 0);
                } else {
                    i8 = typedArray.getInt(i3, 0);
                }
                propertyValuesHolder = PropertyValuesHolder.ofInt(str, i7, i8);
            } else {
                propertyValuesHolder = PropertyValuesHolder.ofInt(str, i7);
            }
        } else if (z2) {
            if (i5 == 5) {
                i6 = (int) typedArray.getDimension(i3, 0.0f);
            } else if (niah0Shohtha(i5)) {
                i6 = typedArray.getColor(i3, 0);
            } else {
                i6 = typedArray.getInt(i3, 0);
            }
            propertyValuesHolder = PropertyValuesHolder.ofInt(str, i6);
        }
        if (propertyValuesHolder != null && kuedujio7aev != null) {
            propertyValuesHolder.setEvaluator(kuedujio7aev);
            return propertyValuesHolder;
        }
        return propertyValuesHolder;
    }

    public static Keyframe mi5Iecheimie(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, int i, XmlPullParser xmlPullParser) {
        boolean z;
        Keyframe ofInt;
        TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6454ko7aiFeiqu3s);
        float Aicohm8ieYoo2 = ruNgecai1pae.Aicohm8ieYoo(ruNgecai1pae2, xmlPullParser, "fraction", 3, -1.0f);
        TypedValue ahthoK6usais2 = ruNgecai1pae.ahthoK6usais(ruNgecai1pae2, xmlPullParser, "value", 0);
        if (ahthoK6usais2 != null) {
            z = true;
        } else {
            z = false;
        }
        if (i == 4) {
            if (z && niah0Shohtha(ahthoK6usais2.type)) {
                i = 3;
            } else {
                i = 0;
            }
        }
        if (z) {
            if (i != 0) {
                if (i != 1 && i != 3) {
                    ofInt = null;
                } else {
                    ofInt = Keyframe.ofInt(Aicohm8ieYoo2, ruNgecai1pae.Jah0aiP1ki6y(ruNgecai1pae2, xmlPullParser, "value", 0, 0));
                }
            } else {
                ofInt = Keyframe.ofFloat(Aicohm8ieYoo2, ruNgecai1pae.Aicohm8ieYoo(ruNgecai1pae2, xmlPullParser, "value", 0, 0.0f));
            }
        } else if (i == 0) {
            ofInt = Keyframe.ofFloat(Aicohm8ieYoo2);
        } else {
            ofInt = Keyframe.ofInt(Aicohm8ieYoo2);
        }
        int niah0Shohtha2 = ruNgecai1pae.niah0Shohtha(ruNgecai1pae2, xmlPullParser, "interpolator", 1, 0);
        if (niah0Shohtha2 > 0) {
            ofInt.setInterpolator(keiL1EiShomu.ieseir3Choge(context, niah0Shohtha2));
        }
        ruNgecai1pae2.recycle();
        return ofInt;
    }

    public static boolean niah0Shohtha(int i) {
        if (i >= 28 && i <= 31) {
            return true;
        }
        return false;
    }

    public static PropertyValuesHolder[] oYe2ma2she1j(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        int i;
        PropertyValuesHolder[] propertyValuesHolderArr = null;
        ArrayList arrayList = null;
        while (true) {
            int eventType = xmlPullParser.getEventType();
            if (eventType == 3 || eventType == 1) {
                break;
            }
            if (eventType == 2 && xmlPullParser.getName().equals("propertyValuesHolder")) {
                TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6457ohv5Shie7AeZ);
                String ohv5Shie7AeZ2 = ruNgecai1pae.ohv5Shie7AeZ(ruNgecai1pae2, xmlPullParser, "propertyName", 3);
                int Jah0aiP1ki6y2 = ruNgecai1pae.Jah0aiP1ki6y(ruNgecai1pae2, xmlPullParser, "valueType", 2, 4);
                PropertyValuesHolder AeJiPo4of6Sh2 = AeJiPo4of6Sh(context, resources, theme, xmlPullParser, ohv5Shie7AeZ2, Jah0aiP1ki6y2);
                if (AeJiPo4of6Sh2 == null) {
                    AeJiPo4of6Sh2 = kuedujio7Aev(ruNgecai1pae2, Jah0aiP1ki6y2, 0, 1, ohv5Shie7AeZ2);
                }
                if (AeJiPo4of6Sh2 != null) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(AeJiPo4of6Sh2);
                }
                ruNgecai1pae2.recycle();
            }
            xmlPullParser.next();
        }
        if (arrayList != null) {
            int size = arrayList.size();
            propertyValuesHolderArr = new PropertyValuesHolder[size];
            for (i = 0; i < size; i++) {
                propertyValuesHolderArr[i] = (PropertyValuesHolder) arrayList.get(i);
            }
        }
        return propertyValuesHolderArr;
    }

    public static Animator ohv5Shie7AeZ(Context context, int i) {
        if (Build.VERSION.SDK_INT >= 24) {
            return AnimatorInflater.loadAnimator(context, i);
        }
        return ko7aiFeiqu3s(context, context.getResources(), context.getTheme(), i);
    }

    public static Animator ruNgecai1pae(Context context, Resources resources, Resources.Theme theme, int i, float f) {
        XmlResourceParser xmlResourceParser = null;
        try {
            try {
                try {
                    xmlResourceParser = resources.getAnimation(i);
                    return ieseir3Choge(context, resources, theme, xmlResourceParser, f);
                } catch (IOException e) {
                    Resources.NotFoundException notFoundException = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
                    notFoundException.initCause(e);
                    throw notFoundException;
                }
            } catch (XmlPullParserException e2) {
                Resources.NotFoundException notFoundException2 = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
                notFoundException2.initCause(e2);
                throw notFoundException2;
            }
        } finally {
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
        }
    }

    public static ObjectAnimator ruwiepo7ooVu(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, float f, XmlPullParser xmlPullParser) {
        ObjectAnimator objectAnimator = new ObjectAnimator();
        ahthoK6usais(context, resources, theme, attributeSet, objectAnimator, f, xmlPullParser);
        return objectAnimator;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static Animator thooCoci9zae(Context context, Resources resources, Resources.Theme theme, XmlPullParser xmlPullParser, AttributeSet attributeSet, AnimatorSet animatorSet, int i, float f) {
        int i2;
        int depth = xmlPullParser.getDepth();
        ValueAnimator valueAnimator = null;
        ArrayList arrayList = null;
        while (true) {
            int next = xmlPullParser.next();
            i2 = 0;
            if ((next != 3 || xmlPullParser.getDepth() > depth) && next != 1) {
                if (next == 2) {
                    String name = xmlPullParser.getName();
                    if (name.equals("objectAnimator")) {
                        valueAnimator = ruwiepo7ooVu(context, resources, theme, attributeSet, f, xmlPullParser);
                    } else if (name.equals("animator")) {
                        valueAnimator = ahthoK6usais(context, resources, theme, attributeSet, null, f, xmlPullParser);
                    } else {
                        if (name.equals("set")) {
                            AnimatorSet animatorSet2 = new AnimatorSet();
                            TypedArray ruNgecai1pae2 = ruNgecai1pae.ruNgecai1pae(resources, theme, attributeSet, ieph3Uteimah.ieseir3Choge.f6456niah0Shohtha);
                            thooCoci9zae(context, resources, theme, xmlPullParser, attributeSet, animatorSet2, ruNgecai1pae.Jah0aiP1ki6y(ruNgecai1pae2, xmlPullParser, "ordering", 0, 0), f);
                            ruNgecai1pae2.recycle();
                            valueAnimator = animatorSet2;
                        } else {
                            if (!name.equals("propertyValuesHolder")) {
                                throw new RuntimeException("Unknown animator name: " + xmlPullParser.getName());
                            }
                            PropertyValuesHolder[] oYe2ma2she1j2 = oYe2ma2she1j(context, resources, theme, xmlPullParser, Xml.asAttributeSet(xmlPullParser));
                            if (oYe2ma2she1j2 != null && (valueAnimator instanceof ValueAnimator)) {
                                valueAnimator.setValues(oYe2ma2she1j2);
                            }
                            i2 = 1;
                        }
                        if (animatorSet != null && i2 == 0) {
                            if (arrayList == null) {
                                arrayList = new ArrayList();
                            }
                            arrayList.add(valueAnimator);
                        }
                    }
                    if (animatorSet != null) {
                        if (arrayList == null) {
                        }
                        arrayList.add(valueAnimator);
                    }
                }
            }
        }
        if (animatorSet != null && arrayList != null) {
            Animator[] animatorArr = new Animator[arrayList.size()];
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                animatorArr[i2] = (Animator) it.next();
                i2++;
            }
            if (i == 0) {
                animatorSet.playTogether(animatorArr);
            } else {
                animatorSet.playSequentially(animatorArr);
            }
        }
        return valueAnimator;
    }

    public static void zoojiiKaht3i(ValueAnimator valueAnimator, TypedArray typedArray, int i, float f, XmlPullParser xmlPullParser) {
        ObjectAnimator objectAnimator = (ObjectAnimator) valueAnimator;
        String ohv5Shie7AeZ2 = ruNgecai1pae.ohv5Shie7AeZ(typedArray, xmlPullParser, "pathData", 1);
        if (ohv5Shie7AeZ2 != null) {
            String ohv5Shie7AeZ3 = ruNgecai1pae.ohv5Shie7AeZ(typedArray, xmlPullParser, "propertyXName", 2);
            String ohv5Shie7AeZ4 = ruNgecai1pae.ohv5Shie7AeZ(typedArray, xmlPullParser, "propertyYName", 3);
            if (i != 2) {
            }
            if (ohv5Shie7AeZ3 == null && ohv5Shie7AeZ4 == null) {
                throw new InflateException(typedArray.getPositionDescription() + " propertyXName or propertyYName is needed for PathData");
            }
            aac1eTaexee6(niah0Shohtha.kuedujio7Aev(ohv5Shie7AeZ2), objectAnimator, f * 0.5f, ohv5Shie7AeZ3, ohv5Shie7AeZ4);
            return;
        }
        objectAnimator.setPropertyName(ruNgecai1pae.ohv5Shie7AeZ(typedArray, xmlPullParser, "propertyName", 0));
    }
}
