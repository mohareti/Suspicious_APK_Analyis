package org.conscrypt;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
class NativeCryptoJni {
    private NativeCryptoJni() {
    }

    public static void init() {
        System.loadLibrary("com.google.android.gms.org.conscrypt".equals(NativeCrypto.class.getPackage().getName()) ? "conscrypt_gmscore_jni" : "conscrypt_jni");
    }
}
