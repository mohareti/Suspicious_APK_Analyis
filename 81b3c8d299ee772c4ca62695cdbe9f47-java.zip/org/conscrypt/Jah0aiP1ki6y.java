package org.conscrypt;

import javax.net.ssl.SNIServerName;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract /* synthetic */ class Jah0aiP1ki6y {
    public static /* bridge */ /* synthetic */ SNIServerName ieseir3Choge(Object obj) {
        return (SNIServerName) obj;
    }
}
