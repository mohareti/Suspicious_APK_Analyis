package org.conscrypt;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class BuildConfig {

    @Deprecated
    public static final String APPLICATION_ID = "org.conscrypt";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final String LIBRARY_PACKAGE_NAME = "org.conscrypt";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "2.5.3";
}
