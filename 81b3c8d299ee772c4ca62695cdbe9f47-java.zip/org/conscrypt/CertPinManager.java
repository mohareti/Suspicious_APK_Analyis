package org.conscrypt;

import java.security.cert.X509Certificate;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface CertPinManager {
    void checkChainPinning(String str, List<X509Certificate> list);
}
