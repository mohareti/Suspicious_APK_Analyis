package org.uasecurity.mining.proto.common;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Wee2wi3pheim;
import com.google.protobuf.chuYaeghie9C;
import com.google.protobuf.eY0iu1Go2aey;
import com.google.protobuf.woizoTie7shi;
import java.util.List;
import java.util.Map;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface EmptyOrBuilder extends chuYaeghie9C {
    /* synthetic */ List findInitializationErrors();

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ Map getAllFields();

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    /* bridge */ /* synthetic */ Wee2wi3pheim getDefaultInstanceForType();

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ woizoTie7shi getDefaultInstanceForType();

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ AeJiPo4of6Sh.thooCoci9zae getDescriptorForType();

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ Object getField(AeJiPo4of6Sh.Jah0aiP1ki6y jah0aiP1ki6y);

    /* synthetic */ String getInitializationErrorString();

    /* synthetic */ AeJiPo4of6Sh.Jah0aiP1ki6y getOneofFieldDescriptor(AeJiPo4of6Sh.ahthoK6usais ahthok6usais);

    /* synthetic */ Object getRepeatedField(AeJiPo4of6Sh.Jah0aiP1ki6y jah0aiP1ki6y, int i);

    /* synthetic */ int getRepeatedFieldCount(AeJiPo4of6Sh.Jah0aiP1ki6y jah0aiP1ki6y);

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ eY0iu1Go2aey getUnknownFields();

    @Override // com.google.protobuf.chuYaeghie9C
    /* synthetic */ boolean hasField(AeJiPo4of6Sh.Jah0aiP1ki6y jah0aiP1ki6y);

    /* synthetic */ boolean hasOneof(AeJiPo4of6Sh.ahthoK6usais ahthok6usais);

    @Override // com.google.protobuf.ooJahquoo9ei
    /* synthetic */ boolean isInitialized();
}
