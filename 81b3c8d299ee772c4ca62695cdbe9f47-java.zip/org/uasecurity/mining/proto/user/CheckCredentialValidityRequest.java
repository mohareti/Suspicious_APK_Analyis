package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Credential;
import org.uasecurity.mining.proto.common.CredentialOrBuilder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class CheckCredentialValidityRequest extends IengaiSahh8H implements CheckCredentialValidityRequestOrBuilder {
    public static final int CREDENTIAL_FIELD_NUMBER = 1;
    private static final CheckCredentialValidityRequest DEFAULT_INSTANCE;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private Credential credential_;
    private byte memoizedIsInitialized;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements CheckCredentialValidityRequestOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a credentialBuilder_;
        private Credential credential_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(CheckCredentialValidityRequest checkCredentialValidityRequest) {
            int i = 1;
            if ((this.bitField0_ & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
                checkCredentialValidityRequest.credential_ = aemuphahfe7a == null ? this.credential_ : (Credential) aemuphahfe7a.thooCoci9zae();
            } else {
                i = 0;
            }
            CheckCredentialValidityRequest.access$576(checkCredentialValidityRequest, i);
        }

        private aeMuPhahFe7a getCredentialFieldBuilder() {
            if (this.credentialBuilder_ == null) {
                this.credentialBuilder_ = new aeMuPhahFe7a(getCredential(), getParentForChildren(), isClean());
                this.credential_ = null;
            }
            return this.credentialBuilder_;
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_CheckCredentialValidityRequest_descriptor;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getCredentialFieldBuilder();
            }
        }

        public Builder clearCredential() {
            this.bitField0_ &= -2;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
        public Credential getCredential() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (Credential) aemuphahfe7a.kuedujio7Aev();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        public Credential.Builder getCredentialBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (Credential.Builder) getCredentialFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
        public CredentialOrBuilder getCredentialOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (CredentialOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_CheckCredentialValidityRequest_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
        public boolean hasCredential() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_CheckCredentialValidityRequest_fieldAccessorTable.ieheiQu9sho5(CheckCredentialValidityRequest.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeCredential(Credential credential) {
            Credential credential2;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(credential);
            } else if ((this.bitField0_ & 1) == 0 || (credential2 = this.credential_) == null || credential2 == Credential.getDefaultInstance()) {
                this.credential_ = credential;
            } else {
                getCredentialBuilder().mergeFrom(credential);
            }
            if (this.credential_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setCredential(Credential.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            Credential build = builder.build();
            if (aemuphahfe7a == null) {
                this.credential_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setCredential(Credential credential) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a == null) {
                credential.getClass();
                this.credential_ = credential;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(credential);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public CheckCredentialValidityRequest build() {
            CheckCredentialValidityRequest buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public CheckCredentialValidityRequest buildPartial() {
            CheckCredentialValidityRequest checkCredentialValidityRequest = new CheckCredentialValidityRequest(this);
            if (this.bitField0_ != 0) {
                buildPartial0(checkCredentialValidityRequest);
            }
            onBuilt();
            return checkCredentialValidityRequest;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public CheckCredentialValidityRequest getDefaultInstanceForType() {
            return CheckCredentialValidityRequest.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m43clear() {
            super.m36clear();
            this.bitField0_ = 0;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getCredentialFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof CheckCredentialValidityRequest) {
                return mergeFrom((CheckCredentialValidityRequest) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(CheckCredentialValidityRequest checkCredentialValidityRequest) {
            if (checkCredentialValidityRequest == CheckCredentialValidityRequest.getDefaultInstance()) {
                return this;
            }
            if (checkCredentialValidityRequest.hasCredential()) {
                mergeCredential(checkCredentialValidityRequest.getCredential());
            }
            m8mergeUnknownFields(checkCredentialValidityRequest.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, CheckCredentialValidityRequest.class.getName());
        DEFAULT_INSTANCE = new CheckCredentialValidityRequest();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.CheckCredentialValidityRequest.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public CheckCredentialValidityRequest parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = CheckCredentialValidityRequest.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private CheckCredentialValidityRequest() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$576(CheckCredentialValidityRequest checkCredentialValidityRequest, int i) {
        int i2 = i | checkCredentialValidityRequest.bitField0_;
        checkCredentialValidityRequest.bitField0_ = i2;
        return i2;
    }

    public static CheckCredentialValidityRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_CheckCredentialValidityRequest_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static CheckCredentialValidityRequest parseDelimitedFrom(InputStream inputStream) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static CheckCredentialValidityRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CheckCredentialValidityRequest)) {
            return super.equals(obj);
        }
        CheckCredentialValidityRequest checkCredentialValidityRequest = (CheckCredentialValidityRequest) obj;
        if (hasCredential() != checkCredentialValidityRequest.hasCredential()) {
            return false;
        }
        return (!hasCredential() || getCredential().equals(checkCredentialValidityRequest.getCredential())) && getUnknownFields().equals(checkCredentialValidityRequest.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
    public Credential getCredential() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
    public CredentialOrBuilder getCredentialOrBuilder() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = ((this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getCredential()) : 0) + getUnknownFields().getSerializedSize();
        this.memoizedSize = Meu0ophaeng12;
        return Meu0ophaeng12;
    }

    @Override // org.uasecurity.mining.proto.user.CheckCredentialValidityRequestOrBuilder
    public boolean hasCredential() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasCredential()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getCredential().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_CheckCredentialValidityRequest_fieldAccessorTable.ieheiQu9sho5(CheckCredentialValidityRequest.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getCredential());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private CheckCredentialValidityRequest(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(CheckCredentialValidityRequest checkCredentialValidityRequest) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(checkCredentialValidityRequest);
    }

    public static CheckCredentialValidityRequest parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static CheckCredentialValidityRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static CheckCredentialValidityRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public CheckCredentialValidityRequest getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static CheckCredentialValidityRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static CheckCredentialValidityRequest parseFrom(InputStream inputStream) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static CheckCredentialValidityRequest parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static CheckCredentialValidityRequest parseFrom(ByteBuffer byteBuffer) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(byteBuffer);
    }

    public static CheckCredentialValidityRequest parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static CheckCredentialValidityRequest parseFrom(byte[] bArr) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(bArr);
    }

    public static CheckCredentialValidityRequest parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (CheckCredentialValidityRequest) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
