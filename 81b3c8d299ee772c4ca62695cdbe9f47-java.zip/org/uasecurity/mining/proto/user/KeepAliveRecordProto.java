package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.ahk3OhSh9Ree;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class KeepAliveRecordProto extends IengaiSahh8H implements KeepAliveRecordProtoOrBuilder {
    private static final KeepAliveRecordProto DEFAULT_INSTANCE;
    public static final int DEVICEBATTERYLEVEL_FIELD_NUMBER = 2;
    public static final int ISHIGHPRIORITYFCMRECEIVED_FIELD_NUMBER = 4;
    public static final int ISMINING_FIELD_NUMBER = 1;
    public static final int ISONMOBILENETWORK_FIELD_NUMBER = 3;
    private static final Id9uvaegh4ai PARSER;
    public static final int SESSIONALIVESECONDS_FIELD_NUMBER = 5;
    private static final long serialVersionUID = 0;
    private int deviceBatteryLevel_;
    private boolean isHighPriorityFCMReceived_;
    private boolean isMining_;
    private boolean isOnMobileNetwork_;
    private byte memoizedIsInitialized;
    private int sessionAliveSeconds_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements KeepAliveRecordProtoOrBuilder {
        private int bitField0_;
        private int deviceBatteryLevel_;
        private boolean isHighPriorityFCMReceived_;
        private boolean isMining_;
        private boolean isOnMobileNetwork_;
        private int sessionAliveSeconds_;

        private Builder() {
        }

        private void buildPartial0(KeepAliveRecordProto keepAliveRecordProto) {
            int i = this.bitField0_;
            if ((i & 1) != 0) {
                keepAliveRecordProto.isMining_ = this.isMining_;
            }
            if ((i & 2) != 0) {
                keepAliveRecordProto.deviceBatteryLevel_ = this.deviceBatteryLevel_;
            }
            if ((i & 4) != 0) {
                keepAliveRecordProto.isOnMobileNetwork_ = this.isOnMobileNetwork_;
            }
            if ((i & 8) != 0) {
                keepAliveRecordProto.isHighPriorityFCMReceived_ = this.isHighPriorityFCMReceived_;
            }
            if ((i & 16) != 0) {
                keepAliveRecordProto.sessionAliveSeconds_ = this.sessionAliveSeconds_;
            }
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Keepalive.internal_static_KeepAliveRecordProto_descriptor;
        }

        public Builder clearDeviceBatteryLevel() {
            this.bitField0_ &= -3;
            this.deviceBatteryLevel_ = 0;
            onChanged();
            return this;
        }

        public Builder clearIsHighPriorityFCMReceived() {
            this.bitField0_ &= -9;
            this.isHighPriorityFCMReceived_ = false;
            onChanged();
            return this;
        }

        public Builder clearIsMining() {
            this.bitField0_ &= -2;
            this.isMining_ = false;
            onChanged();
            return this;
        }

        public Builder clearIsOnMobileNetwork() {
            this.bitField0_ &= -5;
            this.isOnMobileNetwork_ = false;
            onChanged();
            return this;
        }

        public Builder clearSessionAliveSeconds() {
            this.bitField0_ &= -17;
            this.sessionAliveSeconds_ = 0;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Keepalive.internal_static_KeepAliveRecordProto_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
        public int getDeviceBatteryLevel() {
            return this.deviceBatteryLevel_;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
        public boolean getIsHighPriorityFCMReceived() {
            return this.isHighPriorityFCMReceived_;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
        public boolean getIsMining() {
            return this.isMining_;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
        public boolean getIsOnMobileNetwork() {
            return this.isOnMobileNetwork_;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
        public int getSessionAliveSeconds() {
            return this.sessionAliveSeconds_;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Keepalive.internal_static_KeepAliveRecordProto_fieldAccessorTable.ieheiQu9sho5(KeepAliveRecordProto.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder setDeviceBatteryLevel(int i) {
            this.deviceBatteryLevel_ = i;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setIsHighPriorityFCMReceived(boolean z) {
            this.isHighPriorityFCMReceived_ = z;
            this.bitField0_ |= 8;
            onChanged();
            return this;
        }

        public Builder setIsMining(boolean z) {
            this.isMining_ = z;
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setIsOnMobileNetwork(boolean z) {
            this.isOnMobileNetwork_ = z;
            this.bitField0_ |= 4;
            onChanged();
            return this;
        }

        public Builder setSessionAliveSeconds(int i) {
            this.sessionAliveSeconds_ = i;
            this.bitField0_ |= 16;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveRecordProto build() {
            KeepAliveRecordProto buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveRecordProto buildPartial() {
            KeepAliveRecordProto keepAliveRecordProto = new KeepAliveRecordProto(this);
            if (this.bitField0_ != 0) {
                buildPartial0(keepAliveRecordProto);
            }
            onBuilt();
            return keepAliveRecordProto;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public KeepAliveRecordProto getDefaultInstanceForType() {
            return KeepAliveRecordProto.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m59clear() {
            super.m36clear();
            this.bitField0_ = 0;
            this.isMining_ = false;
            this.deviceBatteryLevel_ = 0;
            this.isOnMobileNetwork_ = false;
            this.isHighPriorityFCMReceived_ = false;
            this.sessionAliveSeconds_ = 0;
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 8) {
                                this.isMining_ = ko7aifeiqu3s.eetheKaevie8();
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 16) {
                                this.deviceBatteryLevel_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 2;
                            } else if (io4laQuei7sa2 == 24) {
                                this.isOnMobileNetwork_ = ko7aifeiqu3s.eetheKaevie8();
                                this.bitField0_ |= 4;
                            } else if (io4laQuei7sa2 == 32) {
                                this.isHighPriorityFCMReceived_ = ko7aifeiqu3s.eetheKaevie8();
                                this.bitField0_ |= 8;
                            } else if (io4laQuei7sa2 == 40) {
                                this.sessionAliveSeconds_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 16;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof KeepAliveRecordProto) {
                return mergeFrom((KeepAliveRecordProto) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(KeepAliveRecordProto keepAliveRecordProto) {
            if (keepAliveRecordProto == KeepAliveRecordProto.getDefaultInstance()) {
                return this;
            }
            if (keepAliveRecordProto.getIsMining()) {
                setIsMining(keepAliveRecordProto.getIsMining());
            }
            if (keepAliveRecordProto.getDeviceBatteryLevel() != 0) {
                setDeviceBatteryLevel(keepAliveRecordProto.getDeviceBatteryLevel());
            }
            if (keepAliveRecordProto.getIsOnMobileNetwork()) {
                setIsOnMobileNetwork(keepAliveRecordProto.getIsOnMobileNetwork());
            }
            if (keepAliveRecordProto.getIsHighPriorityFCMReceived()) {
                setIsHighPriorityFCMReceived(keepAliveRecordProto.getIsHighPriorityFCMReceived());
            }
            if (keepAliveRecordProto.getSessionAliveSeconds() != 0) {
                setSessionAliveSeconds(keepAliveRecordProto.getSessionAliveSeconds());
            }
            m8mergeUnknownFields(keepAliveRecordProto.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, KeepAliveRecordProto.class.getName());
        DEFAULT_INSTANCE = new KeepAliveRecordProto();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.KeepAliveRecordProto.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public KeepAliveRecordProto parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = KeepAliveRecordProto.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private KeepAliveRecordProto() {
        this.isMining_ = false;
        this.deviceBatteryLevel_ = 0;
        this.isOnMobileNetwork_ = false;
        this.isHighPriorityFCMReceived_ = false;
        this.sessionAliveSeconds_ = 0;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static KeepAliveRecordProto getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Keepalive.internal_static_KeepAliveRecordProto_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static KeepAliveRecordProto parseDelimitedFrom(InputStream inputStream) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static KeepAliveRecordProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (KeepAliveRecordProto) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof KeepAliveRecordProto)) {
            return super.equals(obj);
        }
        KeepAliveRecordProto keepAliveRecordProto = (KeepAliveRecordProto) obj;
        return getIsMining() == keepAliveRecordProto.getIsMining() && getDeviceBatteryLevel() == keepAliveRecordProto.getDeviceBatteryLevel() && getIsOnMobileNetwork() == keepAliveRecordProto.getIsOnMobileNetwork() && getIsHighPriorityFCMReceived() == keepAliveRecordProto.getIsHighPriorityFCMReceived() && getSessionAliveSeconds() == keepAliveRecordProto.getSessionAliveSeconds() && getUnknownFields().equals(keepAliveRecordProto.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
    public int getDeviceBatteryLevel() {
        return this.deviceBatteryLevel_;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
    public boolean getIsHighPriorityFCMReceived() {
        return this.isHighPriorityFCMReceived_;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
    public boolean getIsMining() {
        return this.isMining_;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
    public boolean getIsOnMobileNetwork() {
        return this.isOnMobileNetwork_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        boolean z = this.isMining_;
        int kuedujio7Aev2 = z ? com.google.protobuf.ahthoK6usais.kuedujio7Aev(1, z) : 0;
        int i2 = this.deviceBatteryLevel_;
        if (i2 != 0) {
            kuedujio7Aev2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(2, i2);
        }
        boolean z2 = this.isOnMobileNetwork_;
        if (z2) {
            kuedujio7Aev2 += com.google.protobuf.ahthoK6usais.kuedujio7Aev(3, z2);
        }
        boolean z3 = this.isHighPriorityFCMReceived_;
        if (z3) {
            kuedujio7Aev2 += com.google.protobuf.ahthoK6usais.kuedujio7Aev(4, z3);
        }
        int i3 = this.sessionAliveSeconds_;
        if (i3 != 0) {
            kuedujio7Aev2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(5, i3);
        }
        int serializedSize = kuedujio7Aev2 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRecordProtoOrBuilder
    public int getSessionAliveSeconds() {
        return this.sessionAliveSeconds_;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = ((((((((((((((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + ahk3OhSh9Ree.keiL1EiShomu(getIsMining())) * 37) + 2) * 53) + getDeviceBatteryLevel()) * 37) + 3) * 53) + ahk3OhSh9Ree.keiL1EiShomu(getIsOnMobileNetwork())) * 37) + 4) * 53) + ahk3OhSh9Ree.keiL1EiShomu(getIsHighPriorityFCMReceived())) * 37) + 5) * 53) + getSessionAliveSeconds()) * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode;
        return hashCode;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Keepalive.internal_static_KeepAliveRecordProto_fieldAccessorTable.ieheiQu9sho5(KeepAliveRecordProto.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        boolean z = this.isMining_;
        if (z) {
            ahthok6usais.quiBuGh8zigh(1, z);
        }
        int i = this.deviceBatteryLevel_;
        if (i != 0) {
            ahthok6usais.AexaNg2eecie(2, i);
        }
        boolean z2 = this.isOnMobileNetwork_;
        if (z2) {
            ahthok6usais.quiBuGh8zigh(3, z2);
        }
        boolean z3 = this.isHighPriorityFCMReceived_;
        if (z3) {
            ahthok6usais.quiBuGh8zigh(4, z3);
        }
        int i2 = this.sessionAliveSeconds_;
        if (i2 != 0) {
            ahthok6usais.AexaNg2eecie(5, i2);
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private KeepAliveRecordProto(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.isMining_ = false;
        this.deviceBatteryLevel_ = 0;
        this.isOnMobileNetwork_ = false;
        this.isHighPriorityFCMReceived_ = false;
        this.sessionAliveSeconds_ = 0;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(KeepAliveRecordProto keepAliveRecordProto) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(keepAliveRecordProto);
    }

    public static KeepAliveRecordProto parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveRecordProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static KeepAliveRecordProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public KeepAliveRecordProto getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static KeepAliveRecordProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static KeepAliveRecordProto parseFrom(InputStream inputStream) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static KeepAliveRecordProto parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveRecordProto parseFrom(ByteBuffer byteBuffer) {
        return (KeepAliveRecordProto) PARSER.parseFrom(byteBuffer);
    }

    public static KeepAliveRecordProto parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static KeepAliveRecordProto parseFrom(byte[] bArr) {
        return (KeepAliveRecordProto) PARSER.parseFrom(bArr);
    }

    public static KeepAliveRecordProto parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (KeepAliveRecordProto) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
