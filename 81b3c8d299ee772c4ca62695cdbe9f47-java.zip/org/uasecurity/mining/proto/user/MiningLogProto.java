package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class MiningLogProto extends IengaiSahh8H implements MiningLogProtoOrBuilder {
    private static final MiningLogProto DEFAULT_INSTANCE;
    public static final int MININGTOTALSECONDS_FIELD_NUMBER = 4;
    private static final Id9uvaegh4ai PARSER;
    public static final int SPEEDIN15S_FIELD_NUMBER = 1;
    public static final int SPEEDIN1H_FIELD_NUMBER = 3;
    public static final int SPEEDIN60S_FIELD_NUMBER = 2;
    private static final long serialVersionUID = 0;
    private byte memoizedIsInitialized;
    private int miningTotalSeconds_;
    private int speedIn15S_;
    private int speedIn1H_;
    private int speedIn60S_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements MiningLogProtoOrBuilder {
        private int bitField0_;
        private int miningTotalSeconds_;
        private int speedIn15S_;
        private int speedIn1H_;
        private int speedIn60S_;

        private Builder() {
        }

        private void buildPartial0(MiningLogProto miningLogProto) {
            int i = this.bitField0_;
            if ((i & 1) != 0) {
                miningLogProto.speedIn15S_ = this.speedIn15S_;
            }
            if ((i & 2) != 0) {
                miningLogProto.speedIn60S_ = this.speedIn60S_;
            }
            if ((i & 4) != 0) {
                miningLogProto.speedIn1H_ = this.speedIn1H_;
            }
            if ((i & 8) != 0) {
                miningLogProto.miningTotalSeconds_ = this.miningTotalSeconds_;
            }
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_MiningLogProto_descriptor;
        }

        public Builder clearMiningTotalSeconds() {
            this.bitField0_ &= -9;
            this.miningTotalSeconds_ = 0;
            onChanged();
            return this;
        }

        public Builder clearSpeedIn15S() {
            this.bitField0_ &= -2;
            this.speedIn15S_ = 0;
            onChanged();
            return this;
        }

        public Builder clearSpeedIn1H() {
            this.bitField0_ &= -5;
            this.speedIn1H_ = 0;
            onChanged();
            return this;
        }

        public Builder clearSpeedIn60S() {
            this.bitField0_ &= -3;
            this.speedIn60S_ = 0;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_MiningLogProto_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
        public int getMiningTotalSeconds() {
            return this.miningTotalSeconds_;
        }

        @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
        public int getSpeedIn15S() {
            return this.speedIn15S_;
        }

        @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
        public int getSpeedIn1H() {
            return this.speedIn1H_;
        }

        @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
        public int getSpeedIn60S() {
            return this.speedIn60S_;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_MiningLogProto_fieldAccessorTable.ieheiQu9sho5(MiningLogProto.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder setMiningTotalSeconds(int i) {
            this.miningTotalSeconds_ = i;
            this.bitField0_ |= 8;
            onChanged();
            return this;
        }

        public Builder setSpeedIn15S(int i) {
            this.speedIn15S_ = i;
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setSpeedIn1H(int i) {
            this.speedIn1H_ = i;
            this.bitField0_ |= 4;
            onChanged();
            return this;
        }

        public Builder setSpeedIn60S(int i) {
            this.speedIn60S_ = i;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MiningLogProto build() {
            MiningLogProto buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MiningLogProto buildPartial() {
            MiningLogProto miningLogProto = new MiningLogProto(this);
            if (this.bitField0_ != 0) {
                buildPartial0(miningLogProto);
            }
            onBuilt();
            return miningLogProto;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public MiningLogProto getDefaultInstanceForType() {
            return MiningLogProto.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m74clear() {
            super.m36clear();
            this.bitField0_ = 0;
            this.speedIn15S_ = 0;
            this.speedIn60S_ = 0;
            this.speedIn1H_ = 0;
            this.miningTotalSeconds_ = 0;
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 8) {
                                this.speedIn15S_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 16) {
                                this.speedIn60S_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 2;
                            } else if (io4laQuei7sa2 == 24) {
                                this.speedIn1H_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 4;
                            } else if (io4laQuei7sa2 == 32) {
                                this.miningTotalSeconds_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 8;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof MiningLogProto) {
                return mergeFrom((MiningLogProto) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(MiningLogProto miningLogProto) {
            if (miningLogProto == MiningLogProto.getDefaultInstance()) {
                return this;
            }
            if (miningLogProto.getSpeedIn15S() != 0) {
                setSpeedIn15S(miningLogProto.getSpeedIn15S());
            }
            if (miningLogProto.getSpeedIn60S() != 0) {
                setSpeedIn60S(miningLogProto.getSpeedIn60S());
            }
            if (miningLogProto.getSpeedIn1H() != 0) {
                setSpeedIn1H(miningLogProto.getSpeedIn1H());
            }
            if (miningLogProto.getMiningTotalSeconds() != 0) {
                setMiningTotalSeconds(miningLogProto.getMiningTotalSeconds());
            }
            m8mergeUnknownFields(miningLogProto.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, MiningLogProto.class.getName());
        DEFAULT_INSTANCE = new MiningLogProto();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.MiningLogProto.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public MiningLogProto parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = MiningLogProto.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private MiningLogProto() {
        this.speedIn15S_ = 0;
        this.speedIn60S_ = 0;
        this.speedIn1H_ = 0;
        this.miningTotalSeconds_ = 0;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static MiningLogProto getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_MiningLogProto_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static MiningLogProto parseDelimitedFrom(InputStream inputStream) {
        return (MiningLogProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static MiningLogProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (MiningLogProto) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MiningLogProto)) {
            return super.equals(obj);
        }
        MiningLogProto miningLogProto = (MiningLogProto) obj;
        return getSpeedIn15S() == miningLogProto.getSpeedIn15S() && getSpeedIn60S() == miningLogProto.getSpeedIn60S() && getSpeedIn1H() == miningLogProto.getSpeedIn1H() && getMiningTotalSeconds() == miningLogProto.getMiningTotalSeconds() && getUnknownFields().equals(miningLogProto.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
    public int getMiningTotalSeconds() {
        return this.miningTotalSeconds_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int i2 = this.speedIn15S_;
        int ohthie9thieG2 = i2 != 0 ? com.google.protobuf.ahthoK6usais.ohthie9thieG(1, i2) : 0;
        int i3 = this.speedIn60S_;
        if (i3 != 0) {
            ohthie9thieG2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(2, i3);
        }
        int i4 = this.speedIn1H_;
        if (i4 != 0) {
            ohthie9thieG2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(3, i4);
        }
        int i5 = this.miningTotalSeconds_;
        if (i5 != 0) {
            ohthie9thieG2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(4, i5);
        }
        int serializedSize = ohthie9thieG2 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
    public int getSpeedIn15S() {
        return this.speedIn15S_;
    }

    @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
    public int getSpeedIn1H() {
        return this.speedIn1H_;
    }

    @Override // org.uasecurity.mining.proto.user.MiningLogProtoOrBuilder
    public int getSpeedIn60S() {
        return this.speedIn60S_;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = ((((((((((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + getSpeedIn15S()) * 37) + 2) * 53) + getSpeedIn60S()) * 37) + 3) * 53) + getSpeedIn1H()) * 37) + 4) * 53) + getMiningTotalSeconds()) * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode;
        return hashCode;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_MiningLogProto_fieldAccessorTable.ieheiQu9sho5(MiningLogProto.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        int i = this.speedIn15S_;
        if (i != 0) {
            ahthok6usais.AexaNg2eecie(1, i);
        }
        int i2 = this.speedIn60S_;
        if (i2 != 0) {
            ahthok6usais.AexaNg2eecie(2, i2);
        }
        int i3 = this.speedIn1H_;
        if (i3 != 0) {
            ahthok6usais.AexaNg2eecie(3, i3);
        }
        int i4 = this.miningTotalSeconds_;
        if (i4 != 0) {
            ahthok6usais.AexaNg2eecie(4, i4);
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private MiningLogProto(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.speedIn15S_ = 0;
        this.speedIn60S_ = 0;
        this.speedIn1H_ = 0;
        this.miningTotalSeconds_ = 0;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(MiningLogProto miningLogProto) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(miningLogProto);
    }

    public static MiningLogProto parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MiningLogProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static MiningLogProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (MiningLogProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public MiningLogProto getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static MiningLogProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static MiningLogProto parseFrom(InputStream inputStream) {
        return (MiningLogProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static MiningLogProto parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MiningLogProto parseFrom(ByteBuffer byteBuffer) {
        return (MiningLogProto) PARSER.parseFrom(byteBuffer);
    }

    public static MiningLogProto parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static MiningLogProto parseFrom(byte[] bArr) {
        return (MiningLogProto) PARSER.parseFrom(bArr);
    }

    public static MiningLogProto parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (MiningLogProto) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
