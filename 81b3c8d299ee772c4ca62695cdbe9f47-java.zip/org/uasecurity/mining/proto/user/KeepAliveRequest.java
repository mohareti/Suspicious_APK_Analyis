package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Credential;
import org.uasecurity.mining.proto.common.CredentialOrBuilder;
import org.uasecurity.mining.proto.user.KeepAliveRecordProto;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class KeepAliveRequest extends IengaiSahh8H implements KeepAliveRequestOrBuilder {
    public static final int CREDENTIAL_FIELD_NUMBER = 1;
    private static final KeepAliveRequest DEFAULT_INSTANCE;
    public static final int KEEPALIVERECORDPROTO_FIELD_NUMBER = 2;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private Credential credential_;
    private KeepAliveRecordProto keepAliveRecordProto_;
    private byte memoizedIsInitialized;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements KeepAliveRequestOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a credentialBuilder_;
        private Credential credential_;
        private aeMuPhahFe7a keepAliveRecordProtoBuilder_;
        private KeepAliveRecordProto keepAliveRecordProto_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(KeepAliveRequest keepAliveRequest) {
            int i;
            int i2 = this.bitField0_;
            if ((i2 & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
                keepAliveRequest.credential_ = aemuphahfe7a == null ? this.credential_ : (Credential) aemuphahfe7a.thooCoci9zae();
                i = 1;
            } else {
                i = 0;
            }
            if ((i2 & 2) != 0) {
                aeMuPhahFe7a aemuphahfe7a2 = this.keepAliveRecordProtoBuilder_;
                keepAliveRequest.keepAliveRecordProto_ = aemuphahfe7a2 == null ? this.keepAliveRecordProto_ : (KeepAliveRecordProto) aemuphahfe7a2.thooCoci9zae();
                i |= 2;
            }
            KeepAliveRequest.access$676(keepAliveRequest, i);
        }

        private aeMuPhahFe7a getCredentialFieldBuilder() {
            if (this.credentialBuilder_ == null) {
                this.credentialBuilder_ = new aeMuPhahFe7a(getCredential(), getParentForChildren(), isClean());
                this.credential_ = null;
            }
            return this.credentialBuilder_;
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Keepalive.internal_static_KeepAliveRequest_descriptor;
        }

        private aeMuPhahFe7a getKeepAliveRecordProtoFieldBuilder() {
            if (this.keepAliveRecordProtoBuilder_ == null) {
                this.keepAliveRecordProtoBuilder_ = new aeMuPhahFe7a(getKeepAliveRecordProto(), getParentForChildren(), isClean());
                this.keepAliveRecordProto_ = null;
            }
            return this.keepAliveRecordProtoBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getCredentialFieldBuilder();
                getKeepAliveRecordProtoFieldBuilder();
            }
        }

        public Builder clearCredential() {
            this.bitField0_ &= -2;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            onChanged();
            return this;
        }

        public Builder clearKeepAliveRecordProto() {
            this.bitField0_ &= -3;
            this.keepAliveRecordProto_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.keepAliveRecordProtoBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public Credential getCredential() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (Credential) aemuphahfe7a.kuedujio7Aev();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        public Credential.Builder getCredentialBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (Credential.Builder) getCredentialFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public CredentialOrBuilder getCredentialOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (CredentialOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Keepalive.internal_static_KeepAliveRequest_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public KeepAliveRecordProto getKeepAliveRecordProto() {
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (KeepAliveRecordProto) aemuphahfe7a.kuedujio7Aev();
            }
            KeepAliveRecordProto keepAliveRecordProto = this.keepAliveRecordProto_;
            return keepAliveRecordProto == null ? KeepAliveRecordProto.getDefaultInstance() : keepAliveRecordProto;
        }

        public KeepAliveRecordProto.Builder getKeepAliveRecordProtoBuilder() {
            this.bitField0_ |= 2;
            onChanged();
            return (KeepAliveRecordProto.Builder) getKeepAliveRecordProtoFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public KeepAliveRecordProtoOrBuilder getKeepAliveRecordProtoOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (KeepAliveRecordProtoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            KeepAliveRecordProto keepAliveRecordProto = this.keepAliveRecordProto_;
            return keepAliveRecordProto == null ? KeepAliveRecordProto.getDefaultInstance() : keepAliveRecordProto;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public boolean hasCredential() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
        public boolean hasKeepAliveRecordProto() {
            return (this.bitField0_ & 2) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Keepalive.internal_static_KeepAliveRequest_fieldAccessorTable.ieheiQu9sho5(KeepAliveRequest.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeCredential(Credential credential) {
            Credential credential2;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(credential);
            } else if ((this.bitField0_ & 1) == 0 || (credential2 = this.credential_) == null || credential2 == Credential.getDefaultInstance()) {
                this.credential_ = credential;
            } else {
                getCredentialBuilder().mergeFrom(credential);
            }
            if (this.credential_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder mergeKeepAliveRecordProto(KeepAliveRecordProto keepAliveRecordProto) {
            KeepAliveRecordProto keepAliveRecordProto2;
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(keepAliveRecordProto);
            } else if ((this.bitField0_ & 2) == 0 || (keepAliveRecordProto2 = this.keepAliveRecordProto_) == null || keepAliveRecordProto2 == KeepAliveRecordProto.getDefaultInstance()) {
                this.keepAliveRecordProto_ = keepAliveRecordProto;
            } else {
                getKeepAliveRecordProtoBuilder().mergeFrom(keepAliveRecordProto);
            }
            if (this.keepAliveRecordProto_ != null) {
                this.bitField0_ |= 2;
                onChanged();
            }
            return this;
        }

        public Builder setCredential(Credential.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            Credential build = builder.build();
            if (aemuphahfe7a == null) {
                this.credential_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setKeepAliveRecordProto(KeepAliveRecordProto.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            KeepAliveRecordProto build = builder.build();
            if (aemuphahfe7a == null) {
                this.keepAliveRecordProto_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setCredential(Credential credential) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a == null) {
                credential.getClass();
                this.credential_ = credential;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(credential);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setKeepAliveRecordProto(KeepAliveRecordProto keepAliveRecordProto) {
            aeMuPhahFe7a aemuphahfe7a = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a == null) {
                keepAliveRecordProto.getClass();
                this.keepAliveRecordProto_ = keepAliveRecordProto;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(keepAliveRecordProto);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveRequest build() {
            KeepAliveRequest buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveRequest buildPartial() {
            KeepAliveRequest keepAliveRequest = new KeepAliveRequest(this);
            if (this.bitField0_ != 0) {
                buildPartial0(keepAliveRequest);
            }
            onBuilt();
            return keepAliveRequest;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public KeepAliveRequest getDefaultInstanceForType() {
            return KeepAliveRequest.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m62clear() {
            super.m59clear();
            this.bitField0_ = 0;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            this.keepAliveRecordProto_ = null;
            aeMuPhahFe7a aemuphahfe7a2 = this.keepAliveRecordProtoBuilder_;
            if (aemuphahfe7a2 != null) {
                aemuphahfe7a2.keiL1EiShomu();
                this.keepAliveRecordProtoBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getCredentialFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                ko7aifeiqu3s.ahz5eechei8U(getKeepAliveRecordProtoFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 2;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof KeepAliveRequest) {
                return mergeFrom((KeepAliveRequest) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(KeepAliveRequest keepAliveRequest) {
            if (keepAliveRequest == KeepAliveRequest.getDefaultInstance()) {
                return this;
            }
            if (keepAliveRequest.hasCredential()) {
                mergeCredential(keepAliveRequest.getCredential());
            }
            if (keepAliveRequest.hasKeepAliveRecordProto()) {
                mergeKeepAliveRecordProto(keepAliveRequest.getKeepAliveRecordProto());
            }
            m8mergeUnknownFields(keepAliveRequest.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, KeepAliveRequest.class.getName());
        DEFAULT_INSTANCE = new KeepAliveRequest();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.KeepAliveRequest.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public KeepAliveRequest parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = KeepAliveRequest.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private KeepAliveRequest() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$676(KeepAliveRequest keepAliveRequest, int i) {
        int i2 = i | keepAliveRequest.bitField0_;
        keepAliveRequest.bitField0_ = i2;
        return i2;
    }

    public static KeepAliveRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Keepalive.internal_static_KeepAliveRequest_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static KeepAliveRequest parseDelimitedFrom(InputStream inputStream) {
        return (KeepAliveRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static KeepAliveRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (KeepAliveRequest) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof KeepAliveRequest)) {
            return super.equals(obj);
        }
        KeepAliveRequest keepAliveRequest = (KeepAliveRequest) obj;
        if (hasCredential() != keepAliveRequest.hasCredential()) {
            return false;
        }
        if ((!hasCredential() || getCredential().equals(keepAliveRequest.getCredential())) && hasKeepAliveRecordProto() == keepAliveRequest.hasKeepAliveRecordProto()) {
            return (!hasKeepAliveRecordProto() || getKeepAliveRecordProto().equals(keepAliveRequest.getKeepAliveRecordProto())) && getUnknownFields().equals(keepAliveRequest.getUnknownFields());
        }
        return false;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public Credential getCredential() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public CredentialOrBuilder getCredentialOrBuilder() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public KeepAliveRecordProto getKeepAliveRecordProto() {
        KeepAliveRecordProto keepAliveRecordProto = this.keepAliveRecordProto_;
        return keepAliveRecordProto == null ? KeepAliveRecordProto.getDefaultInstance() : keepAliveRecordProto;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public KeepAliveRecordProtoOrBuilder getKeepAliveRecordProtoOrBuilder() {
        KeepAliveRecordProto keepAliveRecordProto = this.keepAliveRecordProto_;
        return keepAliveRecordProto == null ? KeepAliveRecordProto.getDefaultInstance() : keepAliveRecordProto;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = (this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getCredential()) : 0;
        if ((this.bitField0_ & 2) != 0) {
            Meu0ophaeng12 += com.google.protobuf.ahthoK6usais.Meu0ophaeng1(2, getKeepAliveRecordProto());
        }
        int serializedSize = Meu0ophaeng12 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public boolean hasCredential() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveRequestOrBuilder
    public boolean hasKeepAliveRecordProto() {
        return (this.bitField0_ & 2) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasCredential()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getCredential().hashCode();
        }
        if (hasKeepAliveRecordProto()) {
            hashCode = (((hashCode * 37) + 2) * 53) + getKeepAliveRecordProto().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Keepalive.internal_static_KeepAliveRequest_fieldAccessorTable.ieheiQu9sho5(KeepAliveRequest.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getCredential());
        }
        if ((this.bitField0_ & 2) != 0) {
            ahthok6usais.Do5Ierepupup(2, getKeepAliveRecordProto());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private KeepAliveRequest(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(KeepAliveRequest keepAliveRequest) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(keepAliveRequest);
    }

    public static KeepAliveRequest parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static KeepAliveRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (KeepAliveRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public KeepAliveRequest getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static KeepAliveRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static KeepAliveRequest parseFrom(InputStream inputStream) {
        return (KeepAliveRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static KeepAliveRequest parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveRequest parseFrom(ByteBuffer byteBuffer) {
        return (KeepAliveRequest) PARSER.parseFrom(byteBuffer);
    }

    public static KeepAliveRequest parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static KeepAliveRequest parseFrom(byte[] bArr) {
        return (KeepAliveRequest) PARSER.parseFrom(bArr);
    }

    public static KeepAliveRequest parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (KeepAliveRequest) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
