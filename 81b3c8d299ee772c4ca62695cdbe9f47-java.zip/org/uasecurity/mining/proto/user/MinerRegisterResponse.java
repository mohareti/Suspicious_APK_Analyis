package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Credential;
import org.uasecurity.mining.proto.common.CredentialOrBuilder;
import org.uasecurity.mining.proto.common.StatusInfo;
import org.uasecurity.mining.proto.common.StatusInfoOrBuilder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class MinerRegisterResponse extends IengaiSahh8H implements MinerRegisterResponseOrBuilder {
    public static final int CREDENTIAL_FIELD_NUMBER = 2;
    private static final MinerRegisterResponse DEFAULT_INSTANCE;
    private static final Id9uvaegh4ai PARSER;
    public static final int STATUS_FIELD_NUMBER = 1;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private Credential credential_;
    private byte memoizedIsInitialized;
    private StatusInfo status_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements MinerRegisterResponseOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a credentialBuilder_;
        private Credential credential_;
        private aeMuPhahFe7a statusBuilder_;
        private StatusInfo status_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(MinerRegisterResponse minerRegisterResponse) {
            int i;
            int i2 = this.bitField0_;
            if ((i2 & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
                minerRegisterResponse.status_ = aemuphahfe7a == null ? this.status_ : (StatusInfo) aemuphahfe7a.thooCoci9zae();
                i = 1;
            } else {
                i = 0;
            }
            if ((i2 & 2) != 0) {
                aeMuPhahFe7a aemuphahfe7a2 = this.credentialBuilder_;
                minerRegisterResponse.credential_ = aemuphahfe7a2 == null ? this.credential_ : (Credential) aemuphahfe7a2.thooCoci9zae();
                i |= 2;
            }
            MinerRegisterResponse.access$676(minerRegisterResponse, i);
        }

        private aeMuPhahFe7a getCredentialFieldBuilder() {
            if (this.credentialBuilder_ == null) {
                this.credentialBuilder_ = new aeMuPhahFe7a(getCredential(), getParentForChildren(), isClean());
                this.credential_ = null;
            }
            return this.credentialBuilder_;
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_MinerRegisterResponse_descriptor;
        }

        private aeMuPhahFe7a getStatusFieldBuilder() {
            if (this.statusBuilder_ == null) {
                this.statusBuilder_ = new aeMuPhahFe7a(getStatus(), getParentForChildren(), isClean());
                this.status_ = null;
            }
            return this.statusBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getStatusFieldBuilder();
                getCredentialFieldBuilder();
            }
        }

        public Builder clearCredential() {
            this.bitField0_ &= -3;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            onChanged();
            return this;
        }

        public Builder clearStatus() {
            this.bitField0_ &= -2;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public Credential getCredential() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (Credential) aemuphahfe7a.kuedujio7Aev();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        public Credential.Builder getCredentialBuilder() {
            this.bitField0_ |= 2;
            onChanged();
            return (Credential.Builder) getCredentialFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public CredentialOrBuilder getCredentialOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (CredentialOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_MinerRegisterResponse_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public StatusInfo getStatus() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfo) aemuphahfe7a.kuedujio7Aev();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        public StatusInfo.Builder getStatusBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (StatusInfo.Builder) getStatusFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public StatusInfoOrBuilder getStatusOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public boolean hasCredential() {
            return (this.bitField0_ & 2) != 0;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
        public boolean hasStatus() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_MinerRegisterResponse_fieldAccessorTable.ieheiQu9sho5(MinerRegisterResponse.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeCredential(Credential credential) {
            Credential credential2;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(credential);
            } else if ((this.bitField0_ & 2) == 0 || (credential2 = this.credential_) == null || credential2 == Credential.getDefaultInstance()) {
                this.credential_ = credential;
            } else {
                getCredentialBuilder().mergeFrom(credential);
            }
            if (this.credential_ != null) {
                this.bitField0_ |= 2;
                onChanged();
            }
            return this;
        }

        public Builder mergeStatus(StatusInfo statusInfo) {
            StatusInfo statusInfo2;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(statusInfo);
            } else if ((this.bitField0_ & 1) == 0 || (statusInfo2 = this.status_) == null || statusInfo2 == StatusInfo.getDefaultInstance()) {
                this.status_ = statusInfo;
            } else {
                getStatusBuilder().mergeFrom(statusInfo);
            }
            if (this.status_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setCredential(Credential.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            Credential build = builder.build();
            if (aemuphahfe7a == null) {
                this.credential_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setStatus(StatusInfo.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            StatusInfo build = builder.build();
            if (aemuphahfe7a == null) {
                this.status_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setCredential(Credential credential) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a == null) {
                credential.getClass();
                this.credential_ = credential;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(credential);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setStatus(StatusInfo statusInfo) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a == null) {
                statusInfo.getClass();
                this.status_ = statusInfo;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(statusInfo);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MinerRegisterResponse build() {
            MinerRegisterResponse buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MinerRegisterResponse buildPartial() {
            MinerRegisterResponse minerRegisterResponse = new MinerRegisterResponse(this);
            if (this.bitField0_ != 0) {
                buildPartial0(minerRegisterResponse);
            }
            onBuilt();
            return minerRegisterResponse;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public MinerRegisterResponse getDefaultInstanceForType() {
            return MinerRegisterResponse.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m71clear() {
            super.m59clear();
            this.bitField0_ = 0;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a2 = this.credentialBuilder_;
            if (aemuphahfe7a2 != null) {
                aemuphahfe7a2.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getStatusFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                ko7aifeiqu3s.ahz5eechei8U(getCredentialFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 2;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof MinerRegisterResponse) {
                return mergeFrom((MinerRegisterResponse) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(MinerRegisterResponse minerRegisterResponse) {
            if (minerRegisterResponse == MinerRegisterResponse.getDefaultInstance()) {
                return this;
            }
            if (minerRegisterResponse.hasStatus()) {
                mergeStatus(minerRegisterResponse.getStatus());
            }
            if (minerRegisterResponse.hasCredential()) {
                mergeCredential(minerRegisterResponse.getCredential());
            }
            m8mergeUnknownFields(minerRegisterResponse.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, MinerRegisterResponse.class.getName());
        DEFAULT_INSTANCE = new MinerRegisterResponse();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.MinerRegisterResponse.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public MinerRegisterResponse parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = MinerRegisterResponse.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private MinerRegisterResponse() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$676(MinerRegisterResponse minerRegisterResponse, int i) {
        int i2 = i | minerRegisterResponse.bitField0_;
        minerRegisterResponse.bitField0_ = i2;
        return i2;
    }

    public static MinerRegisterResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_MinerRegisterResponse_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static MinerRegisterResponse parseDelimitedFrom(InputStream inputStream) {
        return (MinerRegisterResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static MinerRegisterResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (MinerRegisterResponse) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MinerRegisterResponse)) {
            return super.equals(obj);
        }
        MinerRegisterResponse minerRegisterResponse = (MinerRegisterResponse) obj;
        if (hasStatus() != minerRegisterResponse.hasStatus()) {
            return false;
        }
        if ((!hasStatus() || getStatus().equals(minerRegisterResponse.getStatus())) && hasCredential() == minerRegisterResponse.hasCredential()) {
            return (!hasCredential() || getCredential().equals(minerRegisterResponse.getCredential())) && getUnknownFields().equals(minerRegisterResponse.getUnknownFields());
        }
        return false;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public Credential getCredential() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public CredentialOrBuilder getCredentialOrBuilder() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = (this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getStatus()) : 0;
        if ((this.bitField0_ & 2) != 0) {
            Meu0ophaeng12 += com.google.protobuf.ahthoK6usais.Meu0ophaeng1(2, getCredential());
        }
        int serializedSize = Meu0ophaeng12 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public StatusInfo getStatus() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public StatusInfoOrBuilder getStatusOrBuilder() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public boolean hasCredential() {
        return (this.bitField0_ & 2) != 0;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterResponseOrBuilder
    public boolean hasStatus() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasStatus()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getStatus().hashCode();
        }
        if (hasCredential()) {
            hashCode = (((hashCode * 37) + 2) * 53) + getCredential().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_MinerRegisterResponse_fieldAccessorTable.ieheiQu9sho5(MinerRegisterResponse.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getStatus());
        }
        if ((this.bitField0_ & 2) != 0) {
            ahthok6usais.Do5Ierepupup(2, getCredential());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private MinerRegisterResponse(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(MinerRegisterResponse minerRegisterResponse) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(minerRegisterResponse);
    }

    public static MinerRegisterResponse parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MinerRegisterResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static MinerRegisterResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (MinerRegisterResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public MinerRegisterResponse getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static MinerRegisterResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static MinerRegisterResponse parseFrom(InputStream inputStream) {
        return (MinerRegisterResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static MinerRegisterResponse parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MinerRegisterResponse parseFrom(ByteBuffer byteBuffer) {
        return (MinerRegisterResponse) PARSER.parseFrom(byteBuffer);
    }

    public static MinerRegisterResponse parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static MinerRegisterResponse parseFrom(byte[] bArr) {
        return (MinerRegisterResponse) PARSER.parseFrom(bArr);
    }

    public static MinerRegisterResponse parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (MinerRegisterResponse) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
