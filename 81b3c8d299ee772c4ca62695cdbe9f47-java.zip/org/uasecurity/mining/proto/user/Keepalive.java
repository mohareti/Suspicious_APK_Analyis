package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.laej2zeez5Ja;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Status;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Keepalive {
    private static AeJiPo4of6Sh.niah0Shohtha descriptor;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_KeepAliveRecordProto_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_KeepAliveRecordProto_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_KeepAliveRequest_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_KeepAliveRequest_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_KeepAliveResponse_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_KeepAliveResponse_fieldAccessorTable;

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, Keepalive.class.getName());
        descriptor = AeJiPo4of6Sh.niah0Shohtha.eyei9eigh3Ie(new String[]{"\n\u000fkeepalive.proto\u001a\fstatus.proto\"\u009f\u0001\n\u0014KeepAliveRecordProto\u0012\u0010\n\bisMining\u0018\u0001 \u0001(\b\u0012\u001a\n\u0012deviceBatteryLevel\u0018\u0002 \u0001(\u0005\u0012\u0019\n\u0011isOnMobileNetwork\u0018\u0003 \u0001(\b\u0012!\n\u0019isHighPriorityFCMReceived\u0018\u0004 \u0001(\b\u0012\u001b\n\u0013sessionAliveSeconds\u0018\u0005 \u0001(\u0005\"h\n\u0010KeepAliveRequest\u0012\u001f\n\ncredential\u0018\u0001 \u0001(\u000b2\u000b.Credential\u00123\n\u0014keepAliveRecordProto\u0018\u0002 \u0001(\u000b2\u0015.KeepAliveRecordProto\"0\n\u0011KeepAliveResponse\u0012\u001b\n\u0006status\u0018\u0001 \u0001(\u000b2\u000b.StatusInfo2H\n\u0010KeepAliveService\u00124\n\tKeepAlive\u0012\u0011.KeepAliveRequest\u001a\u0012.KeepAliveResponse\"\u0000B2\n org.uasecurity.mining.proto.userP\u0001ª\u0002\u000bMining.Userb\u0006proto3"}, new AeJiPo4of6Sh.niah0Shohtha[]{Status.getDescriptor()});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(0);
        internal_static_KeepAliveRecordProto_descriptor = thoococi9zae;
        internal_static_KeepAliveRecordProto_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae, new String[]{"IsMining", "DeviceBatteryLevel", "IsOnMobileNetwork", "IsHighPriorityFCMReceived", "SessionAliveSeconds"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae2 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(1);
        internal_static_KeepAliveRequest_descriptor = thoococi9zae2;
        internal_static_KeepAliveRequest_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae2, new String[]{"Credential", "KeepAliveRecordProto"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae3 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(2);
        internal_static_KeepAliveResponse_descriptor = thoococi9zae3;
        internal_static_KeepAliveResponse_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae3, new String[]{"Status"});
        descriptor.Ochoob6Ahvi2();
        Status.getDescriptor();
    }

    private Keepalive() {
    }

    public static AeJiPo4of6Sh.niah0Shohtha getDescriptor() {
        return descriptor;
    }

    public static void registerAllExtensions(laej2zeez5Ja laej2zeez5ja) {
        registerAllExtensions((esohshee3Pau) laej2zeez5ja);
    }

    public static void registerAllExtensions(esohshee3Pau esohshee3pau) {
    }
}
