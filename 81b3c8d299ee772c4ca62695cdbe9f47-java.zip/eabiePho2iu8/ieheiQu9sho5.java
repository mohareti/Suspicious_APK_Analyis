package eabiePho2iu8;

import android.R;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import java.util.concurrent.atomic.AtomicInteger;
import ruwiepo7ooVu.ieheiQu9sho5;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final AtomicInteger f5848ieseir3Choge = new AtomicInteger((int) SystemClock.elapsedRealtime());

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final ieheiQu9sho5.kuedujio7Aev f5849ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final int f5850keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final String f5851thooCoci9zae;

        public ieseir3Choge(ieheiQu9sho5.kuedujio7Aev kuedujio7aev, String str, int i) {
            this.f5849ieseir3Choge = kuedujio7aev;
            this.f5851thooCoci9zae = str;
            this.f5850keiL1EiShomu = i;
        }
    }

    public static String AeJiPo4of6Sh(io4laQuei7sa io4laquei7sa) {
        String oYe2ma2she1j2 = io4laquei7sa.oYe2ma2she1j("gcm.n.tag");
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            return oYe2ma2she1j2;
        }
        return "FCM-Notification:" + SystemClock.uptimeMillis();
    }

    public static Intent Aicohm8ieYoo(String str, io4laQuei7sa io4laquei7sa, PackageManager packageManager) {
        String oYe2ma2she1j2 = io4laquei7sa.oYe2ma2she1j("gcm.n.click_action");
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            Intent intent = new Intent(oYe2ma2she1j2);
            intent.setPackage(str);
            intent.setFlags(268435456);
            return intent;
        }
        Uri Aicohm8ieYoo2 = io4laquei7sa.Aicohm8ieYoo();
        if (Aicohm8ieYoo2 != null) {
            Intent intent2 = new Intent("android.intent.action.VIEW");
            intent2.setPackage(str);
            intent2.setData(Aicohm8ieYoo2);
            return intent2;
        }
        Intent launchIntentForPackage = packageManager.getLaunchIntentForPackage(str);
        if (launchIntentForPackage == null) {
            Log.w("FirebaseMessaging", "No activity found to launch app");
        }
        return launchIntentForPackage;
    }

    public static int Jah0aiP1ki6y() {
        return f5848ieseir3Choge.incrementAndGet();
    }

    public static int ahthoK6usais(int i) {
        return i | 67108864;
    }

    public static boolean eetheKaevie8(io4laQuei7sa io4laquei7sa) {
        return io4laquei7sa.ieseir3Choge("google.c.a.e");
    }

    public static ieseir3Choge ieheiQu9sho5(Context context, Context context2, io4laQuei7sa io4laquei7sa, String str, Bundle bundle) {
        String packageName = context2.getPackageName();
        Resources resources = context2.getResources();
        PackageManager packageManager = context2.getPackageManager();
        ieheiQu9sho5.kuedujio7Aev kuedujio7aev = new ieheiQu9sho5.kuedujio7Aev(context2, str);
        String ruwiepo7ooVu2 = io4laquei7sa.ruwiepo7ooVu(resources, packageName, "gcm.n.title");
        if (!TextUtils.isEmpty(ruwiepo7ooVu2)) {
            kuedujio7aev.ko7aiFeiqu3s(ruwiepo7ooVu2);
        }
        String ruwiepo7ooVu3 = io4laquei7sa.ruwiepo7ooVu(resources, packageName, "gcm.n.body");
        if (!TextUtils.isEmpty(ruwiepo7ooVu3)) {
            kuedujio7aev.ohv5Shie7AeZ(ruwiepo7ooVu3);
            kuedujio7aev.esohshee3Pau(new ieheiQu9sho5.keiL1EiShomu().niah0Shohtha(ruwiepo7ooVu3));
        }
        kuedujio7aev.laej2zeez5Ja(mi5Iecheimie(packageManager, resources, packageName, io4laquei7sa.oYe2ma2she1j("gcm.n.icon"), bundle));
        Uri ruwiepo7ooVu4 = ruwiepo7ooVu(packageName, io4laquei7sa, resources);
        if (ruwiepo7ooVu4 != null) {
            kuedujio7aev.rojaiZ9aeRee(ruwiepo7ooVu4);
        }
        kuedujio7aev.niah0Shohtha(ieseir3Choge(context, io4laquei7sa, packageName, packageManager));
        PendingIntent thooCoci9zae2 = thooCoci9zae(context, context2, io4laquei7sa);
        if (thooCoci9zae2 != null) {
            kuedujio7aev.ahthoK6usais(thooCoci9zae2);
        }
        Integer niah0Shohtha2 = niah0Shohtha(context2, io4laquei7sa.oYe2ma2she1j("gcm.n.color"), bundle);
        if (niah0Shohtha2 != null) {
            kuedujio7aev.Jah0aiP1ki6y(niah0Shohtha2.intValue());
        }
        kuedujio7aev.kuedujio7Aev(!io4laquei7sa.ieseir3Choge("gcm.n.sticky"));
        kuedujio7aev.oYe2ma2she1j(io4laquei7sa.ieseir3Choge("gcm.n.local_only"));
        String oYe2ma2she1j2 = io4laquei7sa.oYe2ma2she1j("gcm.n.ticker");
        if (oYe2ma2she1j2 != null) {
            kuedujio7aev.oph9lahCh6uo(oYe2ma2she1j2);
        }
        Integer mi5Iecheimie2 = io4laquei7sa.mi5Iecheimie();
        if (mi5Iecheimie2 != null) {
            kuedujio7aev.zoojiiKaht3i(mi5Iecheimie2.intValue());
        }
        Integer zoojiiKaht3i2 = io4laquei7sa.zoojiiKaht3i();
        if (zoojiiKaht3i2 != null) {
            kuedujio7aev.eyei9eigh3Ie(zoojiiKaht3i2.intValue());
        }
        Integer ahthoK6usais2 = io4laquei7sa.ahthoK6usais();
        if (ahthoK6usais2 != null) {
            kuedujio7aev.eetheKaevie8(ahthoK6usais2.intValue());
        }
        Long ko7aiFeiqu3s2 = io4laquei7sa.ko7aiFeiqu3s("gcm.n.event_time");
        if (ko7aiFeiqu3s2 != null) {
            kuedujio7aev.aac1eTaexee6(true);
            kuedujio7aev.Idohhaimaes0(ko7aiFeiqu3s2.longValue());
        }
        long[] eetheKaevie82 = io4laquei7sa.eetheKaevie8();
        if (eetheKaevie82 != null) {
            kuedujio7aev.ohthie9thieG(eetheKaevie82);
        }
        int[] kuedujio7Aev2 = io4laquei7sa.kuedujio7Aev();
        if (kuedujio7Aev2 != null) {
            kuedujio7aev.AeJiPo4of6Sh(kuedujio7Aev2[0], kuedujio7Aev2[1], kuedujio7Aev2[2]);
        }
        kuedujio7aev.ruNgecai1pae(ohv5Shie7AeZ(io4laquei7sa));
        return new ieseir3Choge(kuedujio7aev, AeJiPo4of6Sh(io4laquei7sa), 0);
    }

    public static PendingIntent ieseir3Choge(Context context, io4laQuei7sa io4laquei7sa, String str, PackageManager packageManager) {
        Intent Aicohm8ieYoo2 = Aicohm8ieYoo(str, io4laquei7sa, packageManager);
        if (Aicohm8ieYoo2 == null) {
            return null;
        }
        Aicohm8ieYoo2.addFlags(67108864);
        Aicohm8ieYoo2.putExtras(io4laquei7sa.eyei9eigh3Ie());
        if (eetheKaevie8(io4laquei7sa)) {
            Aicohm8ieYoo2.putExtra("gcm.n.analytics_data", io4laquei7sa.ohthie9thieG());
        }
        return PendingIntent.getActivity(context, Jah0aiP1ki6y(), Aicohm8ieYoo2, ahthoK6usais(1073741824));
    }

    public static PendingIntent keiL1EiShomu(Context context, Context context2, Intent intent) {
        return PendingIntent.getBroadcast(context, Jah0aiP1ki6y(), new Intent("com.google.android.c2dm.intent.RECEIVE").setPackage(context2.getPackageName()).putExtra("wrapped_intent", intent), ahthoK6usais(1073741824));
    }

    public static Bundle ko7aiFeiqu3s(PackageManager packageManager, String str) {
        try {
            ApplicationInfo applicationInfo = packageManager.getApplicationInfo(str, 128);
            if (applicationInfo != null) {
                Bundle bundle = applicationInfo.metaData;
                if (bundle != null) {
                    return bundle;
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            Log.w("FirebaseMessaging", "Couldn't get own application info: " + e);
        }
        return Bundle.EMPTY;
    }

    public static ieseir3Choge kuedujio7Aev(Context context, io4laQuei7sa io4laquei7sa) {
        Bundle ko7aiFeiqu3s2 = ko7aiFeiqu3s(context.getPackageManager(), context.getPackageName());
        return ieheiQu9sho5(context, context, io4laquei7sa, ruNgecai1pae(context, io4laquei7sa.ruNgecai1pae(), ko7aiFeiqu3s2), ko7aiFeiqu3s2);
    }

    public static int mi5Iecheimie(PackageManager packageManager, Resources resources, String str, String str2, Bundle bundle) {
        if (!TextUtils.isEmpty(str2)) {
            int identifier = resources.getIdentifier(str2, "drawable", str);
            if (identifier != 0 && oYe2ma2she1j(resources, identifier)) {
                return identifier;
            }
            int identifier2 = resources.getIdentifier(str2, "mipmap", str);
            if (identifier2 != 0 && oYe2ma2she1j(resources, identifier2)) {
                return identifier2;
            }
            Log.w("FirebaseMessaging", "Icon resource " + str2 + " not found. Notification will use default icon.");
        }
        int i = bundle.getInt("com.google.firebase.messaging.default_notification_icon", 0);
        if (i == 0 || !oYe2ma2she1j(resources, i)) {
            try {
                i = packageManager.getApplicationInfo(str, 0).icon;
            } catch (PackageManager.NameNotFoundException e) {
                Log.w("FirebaseMessaging", "Couldn't get own application info: " + e);
            }
        }
        if (i == 0 || !oYe2ma2she1j(resources, i)) {
            return R.drawable.sym_def_app_icon;
        }
        return i;
    }

    public static Integer niah0Shohtha(Context context, String str, Bundle bundle) {
        if (!TextUtils.isEmpty(str)) {
            try {
                return Integer.valueOf(Color.parseColor(str));
            } catch (IllegalArgumentException unused) {
                Log.w("FirebaseMessaging", "Color is invalid: " + str + ". Notification will use default color.");
            }
        }
        int i = bundle.getInt("com.google.firebase.messaging.default_notification_color", 0);
        if (i != 0) {
            try {
                return Integer.valueOf(AeJiPo4of6Sh.ieseir3Choge.keiL1EiShomu(context, i));
            } catch (Resources.NotFoundException unused2) {
                Log.w("FirebaseMessaging", "Cannot find the color resource referenced in AndroidManifest.");
                return null;
            }
        }
        return null;
    }

    public static boolean oYe2ma2she1j(Resources resources, int i) {
        if (Build.VERSION.SDK_INT != 26) {
            return true;
        }
        try {
            if (!keiL1EiShomu.ieseir3Choge(resources.getDrawable(i, null))) {
                return true;
            }
            Log.e("FirebaseMessaging", "Adaptive icons cannot be used in notifications. Ignoring icon id: " + i);
            return false;
        } catch (Resources.NotFoundException unused) {
            Log.e("FirebaseMessaging", "Couldn't find resource " + i + ", treating it as an invalid icon");
            return false;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6 */
    /* JADX WARN: Type inference failed for: r0v7 */
    public static int ohv5Shie7AeZ(io4laQuei7sa io4laquei7sa) {
        boolean ieseir3Choge2 = io4laquei7sa.ieseir3Choge("gcm.n.default_sound");
        ?? r0 = ieseir3Choge2;
        if (io4laquei7sa.ieseir3Choge("gcm.n.default_vibrate_timings")) {
            r0 = (ieseir3Choge2 ? 1 : 0) | 2;
        }
        if (io4laquei7sa.ieseir3Choge("gcm.n.default_light_settings")) {
            return r0 | 4;
        }
        return r0;
    }

    public static String ruNgecai1pae(Context context, String str, Bundle bundle) {
        String str2;
        NotificationChannel notificationChannel;
        String string;
        NotificationChannel notificationChannel2;
        NotificationChannel notificationChannel3;
        if (Build.VERSION.SDK_INT < 26) {
            return null;
        }
        try {
            if (context.getPackageManager().getApplicationInfo(context.getPackageName(), 0).targetSdkVersion < 26) {
                return null;
            }
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
            if (!TextUtils.isEmpty(str)) {
                notificationChannel3 = notificationManager.getNotificationChannel(str);
                if (notificationChannel3 != null) {
                    return str;
                }
                Log.w("FirebaseMessaging", "Notification Channel requested (" + str + ") has not been created by the app. Manifest configuration, or default, value will be used.");
            }
            String string2 = bundle.getString("com.google.firebase.messaging.default_notification_channel_id");
            if (!TextUtils.isEmpty(string2)) {
                notificationChannel2 = notificationManager.getNotificationChannel(string2);
                if (notificationChannel2 != null) {
                    return string2;
                }
                str2 = "Notification Channel set in AndroidManifest.xml has not been created by the app. Default value will be used.";
            } else {
                str2 = "Missing Default Notification Channel metadata in AndroidManifest. Default value will be used.";
            }
            Log.w("FirebaseMessaging", str2);
            notificationChannel = notificationManager.getNotificationChannel("fcm_fallback_notification_channel");
            if (notificationChannel == null) {
                int identifier = context.getResources().getIdentifier("fcm_fallback_notification_channel_label", "string", context.getPackageName());
                if (identifier == 0) {
                    Log.e("FirebaseMessaging", "String resource \"fcm_fallback_notification_channel_label\" is not found. Using default string channel name.");
                    string = "Misc";
                } else {
                    string = context.getString(identifier);
                }
                notificationManager.createNotificationChannel(Eikuh5Phaeth.niah0Shohtha.ieseir3Choge("fcm_fallback_notification_channel", string, 3));
            }
            return "fcm_fallback_notification_channel";
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public static Uri ruwiepo7ooVu(String str, io4laQuei7sa io4laquei7sa, Resources resources) {
        String AeJiPo4of6Sh2 = io4laquei7sa.AeJiPo4of6Sh();
        if (TextUtils.isEmpty(AeJiPo4of6Sh2)) {
            return null;
        }
        if (!"default".equals(AeJiPo4of6Sh2) && resources.getIdentifier(AeJiPo4of6Sh2, "raw", str) != 0) {
            return Uri.parse("android.resource://" + str + "/raw/" + AeJiPo4of6Sh2);
        }
        return RingtoneManager.getDefaultUri(2);
    }

    public static PendingIntent thooCoci9zae(Context context, Context context2, io4laQuei7sa io4laquei7sa) {
        if (!eetheKaevie8(io4laquei7sa)) {
            return null;
        }
        return keiL1EiShomu(context, context2, new Intent("com.google.firebase.messaging.NOTIFICATION_DISMISS").putExtras(io4laquei7sa.ohthie9thieG()));
    }
}
