package eabiePho2iu8;

import android.content.Context;
import android.content.SharedPreferences;
import java.lang.ref.WeakReference;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class doonge7ooYoe {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static WeakReference f5837ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final SharedPreferences f5838ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Executor f5839keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public soo9aeJ3kahb f5840thooCoci9zae;

    public doonge7ooYoe(SharedPreferences sharedPreferences, Executor executor) {
        this.f5839keiL1EiShomu = executor;
        this.f5838ieseir3Choge = sharedPreferences;
    }

    public static synchronized doonge7ooYoe thooCoci9zae(Context context, Executor executor) {
        doonge7ooYoe doonge7ooyoe;
        synchronized (doonge7ooYoe.class) {
            try {
                WeakReference weakReference = f5837ieheiQu9sho5;
                if (weakReference != null) {
                    doonge7ooyoe = (doonge7ooYoe) weakReference.get();
                } else {
                    doonge7ooyoe = null;
                }
                if (doonge7ooyoe == null) {
                    doonge7ooyoe = new doonge7ooYoe(context.getSharedPreferences("com.google.android.gms.appid", 0), executor);
                    doonge7ooyoe.ieheiQu9sho5();
                    f5837ieheiQu9sho5 = new WeakReference(doonge7ooyoe);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return doonge7ooyoe;
    }

    public final synchronized void ieheiQu9sho5() {
        this.f5840thooCoci9zae = soo9aeJ3kahb.ieheiQu9sho5(this.f5838ieseir3Choge, "topic_operation_queue", ",", this.f5839keiL1EiShomu);
    }

    public synchronized boolean ieseir3Choge(iev8ainaiLae iev8ainailae) {
        return this.f5840thooCoci9zae.thooCoci9zae(iev8ainailae.kuedujio7Aev());
    }

    public synchronized iev8ainaiLae keiL1EiShomu() {
        return iev8ainaiLae.ieseir3Choge(this.f5840thooCoci9zae.Aicohm8ieYoo());
    }

    public synchronized boolean kuedujio7Aev(iev8ainaiLae iev8ainailae) {
        return this.f5840thooCoci9zae.Jah0aiP1ki6y(iev8ainailae.kuedujio7Aev());
    }
}
