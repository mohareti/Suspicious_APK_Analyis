package eabiePho2iu8;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.Queue;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ohx8eem3Ahph {

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static ohx8eem3Ahph f5910kuedujio7Aev;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public String f5912ieseir3Choge = null;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public Boolean f5914thooCoci9zae = null;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public Boolean f5913keiL1EiShomu = null;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Queue f5911ieheiQu9sho5 = new ArrayDeque();

    public static synchronized ohx8eem3Ahph thooCoci9zae() {
        ohx8eem3Ahph ohx8eem3ahph;
        synchronized (ohx8eem3Ahph.class) {
            try {
                if (f5910kuedujio7Aev == null) {
                    f5910kuedujio7Aev = new ohx8eem3Ahph();
                }
                ohx8eem3ahph = f5910kuedujio7Aev;
            } catch (Throwable th) {
                throw th;
            }
        }
        return ohx8eem3ahph;
    }

    public final synchronized String Aicohm8ieYoo(Context context, Intent intent) {
        ServiceInfo serviceInfo;
        String str;
        String str2;
        try {
            String str3 = this.f5912ieseir3Choge;
            if (str3 != null) {
                return str3;
            }
            ResolveInfo resolveService = context.getPackageManager().resolveService(intent, 0);
            if (resolveService != null && (serviceInfo = resolveService.serviceInfo) != null) {
                if (context.getPackageName().equals(serviceInfo.packageName) && (str = serviceInfo.name) != null) {
                    if (str.startsWith(".")) {
                        str2 = context.getPackageName() + serviceInfo.name;
                    } else {
                        str2 = serviceInfo.name;
                    }
                    this.f5912ieseir3Choge = str2;
                    return this.f5912ieseir3Choge;
                }
                Log.e("FirebaseMessaging", "Error resolving target intent service, skipping classname enforcement. Resolved service was: " + serviceInfo.packageName + "/" + serviceInfo.name);
                return null;
            }
            Log.e("FirebaseMessaging", "Failed to resolve target intent service, skipping classname enforcement");
            return null;
        } catch (Throwable th) {
            throw th;
        }
    }

    public int Jah0aiP1ki6y(Context context, Intent intent) {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Starting service");
        }
        this.f5911ieheiQu9sho5.offer(intent);
        Intent intent2 = new Intent("com.google.firebase.MESSAGING_EVENT");
        intent2.setPackage(context.getPackageName());
        return ieseir3Choge(context, intent2);
    }

    public boolean ieheiQu9sho5(Context context) {
        boolean z;
        if (this.f5913keiL1EiShomu == null) {
            if (context.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0) {
                z = true;
            } else {
                z = false;
            }
            this.f5913keiL1EiShomu = Boolean.valueOf(z);
        }
        if (!this.f5914thooCoci9zae.booleanValue() && Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Missing Permission: android.permission.ACCESS_NETWORK_STATE this should normally be included by the manifest merger, but may needed to be manually added to your manifest");
        }
        return this.f5913keiL1EiShomu.booleanValue();
    }

    public final int ieseir3Choge(Context context, Intent intent) {
        ComponentName startService;
        String Aicohm8ieYoo2 = Aicohm8ieYoo(context, intent);
        if (Aicohm8ieYoo2 != null) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Restricting intent to a specific service: " + Aicohm8ieYoo2);
            }
            intent.setClassName(context.getPackageName(), Aicohm8ieYoo2);
        }
        try {
            if (kuedujio7Aev(context)) {
                startService = aed3pie3Chah.niah0Shohtha(context, intent);
            } else {
                startService = context.startService(intent);
                Log.d("FirebaseMessaging", "Missing wake lock permission, service start may be delayed");
            }
            if (startService == null) {
                Log.e("FirebaseMessaging", "Error while delivering the message: ServiceIntent not found.");
                return 404;
            }
            return -1;
        } catch (IllegalStateException e) {
            Log.e("FirebaseMessaging", "Failed to start service while in background: " + e);
            return 402;
        } catch (SecurityException e2) {
            Log.e("FirebaseMessaging", "Error while delivering the message to the serviceIntent", e2);
            return 401;
        }
    }

    public Intent keiL1EiShomu() {
        return (Intent) this.f5911ieheiQu9sho5.poll();
    }

    public boolean kuedujio7Aev(Context context) {
        boolean z;
        if (this.f5914thooCoci9zae == null) {
            if (context.checkCallingOrSelfPermission("android.permission.WAKE_LOCK") == 0) {
                z = true;
            } else {
                z = false;
            }
            this.f5914thooCoci9zae = Boolean.valueOf(z);
        }
        if (!this.f5914thooCoci9zae.booleanValue() && Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Missing Permission: android.permission.WAKE_LOCK this should normally be included by the manifest merger, but may needed to be manually added to your manifest");
        }
        return this.f5914thooCoci9zae.booleanValue();
    }
}
