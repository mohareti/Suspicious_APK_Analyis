package eabiePho2iu8;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class iecioL2LieVa {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final jeeGhae1Va1p.niah0Shohtha f5847ieseir3Choge = jeeGhae1Va1p.niah0Shohtha.ieseir3Choge().ieheiQu9sho5(ieseir3Choge.f5854ieseir3Choge).keiL1EiShomu();

    public static byte[] ieseir3Choge(Object obj) {
        return f5847ieseir3Choge.keiL1EiShomu(obj);
    }
}
