package eabiePho2iu8;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class thooCoci9zae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge extends FilterInputStream {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public long f5944ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public long f5945kuedujio7Aev;

        public ieseir3Choge(InputStream inputStream, long j) {
            super(inputStream);
            this.f5945kuedujio7Aev = -1L;
            this.f5944ieheiQu9sho5 = j;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int available() {
            return (int) Math.min(((FilterInputStream) this).in.available(), this.f5944ieheiQu9sho5);
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public synchronized void mark(int i) {
            ((FilterInputStream) this).in.mark(i);
            this.f5945kuedujio7Aev = this.f5944ieheiQu9sho5;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read() {
            if (this.f5944ieheiQu9sho5 == 0) {
                return -1;
            }
            int read = ((FilterInputStream) this).in.read();
            if (read != -1) {
                this.f5944ieheiQu9sho5--;
            }
            return read;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public synchronized void reset() {
            if (((FilterInputStream) this).in.markSupported()) {
                if (this.f5945kuedujio7Aev != -1) {
                    ((FilterInputStream) this).in.reset();
                    this.f5944ieheiQu9sho5 = this.f5945kuedujio7Aev;
                } else {
                    throw new IOException("Mark not set");
                }
            } else {
                throw new IOException("Mark not supported");
            }
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public long skip(long j) {
            long skip = ((FilterInputStream) this).in.skip(Math.min(j, this.f5944ieheiQu9sho5));
            this.f5944ieheiQu9sho5 -= skip;
            return skip;
        }

        @Override // java.io.FilterInputStream, java.io.InputStream
        public int read(byte[] bArr, int i, int i2) {
            long j = this.f5944ieheiQu9sho5;
            if (j == 0) {
                return -1;
            }
            int read = ((FilterInputStream) this).in.read(bArr, i, (int) Math.min(i2, j));
            if (read != -1) {
                this.f5944ieheiQu9sho5 -= read;
            }
            return read;
        }
    }

    public static byte[] ieheiQu9sho5(InputStream inputStream) {
        return kuedujio7Aev(inputStream, new ArrayDeque(20), 0);
    }

    public static byte[] ieseir3Choge(Queue queue, int i) {
        if (queue.isEmpty()) {
            return new byte[0];
        }
        byte[] bArr = (byte[]) queue.remove();
        if (bArr.length == i) {
            return bArr;
        }
        int length = i - bArr.length;
        byte[] copyOf = Arrays.copyOf(bArr, i);
        while (length > 0) {
            byte[] bArr2 = (byte[]) queue.remove();
            int min = Math.min(length, bArr2.length);
            System.arraycopy(bArr2, 0, copyOf, i - length, min);
            length -= min;
        }
        return copyOf;
    }

    public static int keiL1EiShomu(long j) {
        if (j > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        if (j < -2147483648L) {
            return Integer.MIN_VALUE;
        }
        return (int) j;
    }

    public static byte[] kuedujio7Aev(InputStream inputStream, Queue queue, int i) {
        int i2;
        int min = Math.min(8192, Math.max(128, Integer.highestOneBit(i) * 2));
        while (i < 2147483639) {
            int min2 = Math.min(min, 2147483639 - i);
            byte[] bArr = new byte[min2];
            queue.add(bArr);
            int i3 = 0;
            while (i3 < min2) {
                int read = inputStream.read(bArr, i3, min2 - i3);
                if (read == -1) {
                    return ieseir3Choge(queue, i);
                }
                i3 += read;
                i += read;
            }
            long j = min;
            if (min < 4096) {
                i2 = 4;
            } else {
                i2 = 2;
            }
            min = keiL1EiShomu(j * i2);
        }
        if (inputStream.read() == -1) {
            return ieseir3Choge(queue, 2147483639);
        }
        throw new OutOfMemoryError("input is too large to fit in a byte array");
    }

    public static InputStream thooCoci9zae(InputStream inputStream, long j) {
        return new ieseir3Choge(inputStream, j);
    }
}
