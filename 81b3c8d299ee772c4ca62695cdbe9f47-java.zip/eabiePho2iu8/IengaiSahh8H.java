package eabiePho2iu8;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.concurrent.ExecutionException;
import rieVei3pei5O.ko7aiFeiqu3s;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class IengaiSahh8H {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final sieChi1iehoo.niah0Shohtha f5799Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final oWouk4seiqua.thooCoci9zae f5800ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ohBoophood9o.kuedujio7Aev f5801ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Xe6mangaekai.keiL1EiShomu f5802keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final oWouk4seiqua.thooCoci9zae f5803kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final mi3Ozool1oa4 f5804thooCoci9zae;

    public IengaiSahh8H(ohBoophood9o.kuedujio7Aev kuedujio7aev, mi3Ozool1oa4 mi3ozool1oa4, Xe6mangaekai.keiL1EiShomu keil1eishomu, oWouk4seiqua.thooCoci9zae thoococi9zae, oWouk4seiqua.thooCoci9zae thoococi9zae2, sieChi1iehoo.niah0Shohtha niah0shohtha) {
        this.f5801ieseir3Choge = kuedujio7aev;
        this.f5804thooCoci9zae = mi3ozool1oa4;
        this.f5802keiL1EiShomu = keil1eishomu;
        this.f5800ieheiQu9sho5 = thoococi9zae;
        this.f5803kuedujio7Aev = thoococi9zae2;
        this.f5799Aicohm8ieYoo = niah0shohtha;
    }

    public static boolean niah0Shohtha(String str) {
        if (!"SERVICE_NOT_AVAILABLE".equals(str) && !"INTERNAL_SERVER_ERROR".equals(str) && !"InternalServerError".equals(str)) {
            return false;
        }
        return true;
    }

    public static String thooCoci9zae(byte[] bArr) {
        return Base64.encodeToString(bArr, 11);
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ Aicohm8ieYoo() {
        return keiL1EiShomu(ahthoK6usais(mi3Ozool1oa4.keiL1EiShomu(this.f5801ieseir3Choge), "*", new Bundle()));
    }

    public final String Jah0aiP1ki6y(Bundle bundle) {
        if (bundle != null) {
            String string = bundle.getString("registration_id");
            if (string != null) {
                return string;
            }
            String string2 = bundle.getString("unregistered");
            if (string2 != null) {
                return string2;
            }
            String string3 = bundle.getString("error");
            if (!"RST".equals(string3)) {
                if (string3 != null) {
                    throw new IOException(string3);
                }
                Log.w("FirebaseMessaging", "Unexpected response: " + bundle, new Throwable());
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
            throw new IOException("INSTANCE_ID_RESET");
        }
        throw new IOException("SERVICE_NOT_AVAILABLE");
    }

    public final vaeVoh2dei5I.ohv5Shie7AeZ ahthoK6usais(String str, String str2, Bundle bundle) {
        try {
            ko7aiFeiqu3s(str, str2, bundle);
            return this.f5802keiL1EiShomu.keiL1EiShomu(bundle);
        } catch (InterruptedException | ExecutionException e) {
            return vaeVoh2dei5I.ahthoK6usais.ieheiQu9sho5(e);
        }
    }

    public final String ieheiQu9sho5() {
        try {
            return thooCoci9zae(MessageDigest.getInstance("SHA-1").digest(this.f5801ieseir3Choge.ahthoK6usais().getBytes()));
        } catch (NoSuchAlgorithmException unused) {
            return "[HASH-ERROR]";
        }
    }

    public final vaeVoh2dei5I.ohv5Shie7AeZ keiL1EiShomu(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        return ohv5shie7aez.niah0Shohtha(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.ieseir3Choge() { // from class: eabiePho2iu8.kah6Uo2ooji4
            @Override // vaeVoh2dei5I.ieseir3Choge
            public final Object ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez2) {
                String ohv5Shie7AeZ2;
                ohv5Shie7AeZ2 = IengaiSahh8H.this.ohv5Shie7AeZ(ohv5shie7aez2);
                return ohv5Shie7AeZ2;
            }
        });
    }

    /* JADX WARN: Removed duplicated region for block: B:17:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x00c0 A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final void ko7aiFeiqu3s(String str, String str2, Bundle bundle) {
        rieVei3pei5O.ko7aiFeiqu3s ko7aifeiqu3s;
        ko7aiFeiqu3s.ieseir3Choge thooCoci9zae2;
        bundle.putString("scope", str2);
        bundle.putString("sender", str);
        bundle.putString("subtype", str);
        bundle.putString("gmp_app_id", this.f5801ieseir3Choge.mi5Iecheimie().keiL1EiShomu());
        bundle.putString("gmsv", Integer.toString(this.f5804thooCoci9zae.ieheiQu9sho5()));
        bundle.putString("osv", Integer.toString(Build.VERSION.SDK_INT));
        bundle.putString("app_ver", this.f5804thooCoci9zae.ieseir3Choge());
        bundle.putString("app_ver_name", this.f5804thooCoci9zae.thooCoci9zae());
        bundle.putString("firebase-app-name-hash", ieheiQu9sho5());
        try {
            String thooCoci9zae3 = ((sieChi1iehoo.mi5Iecheimie) vaeVoh2dei5I.ahthoK6usais.ieseir3Choge(this.f5799Aicohm8ieYoo.ieseir3Choge(false))).thooCoci9zae();
            if (!TextUtils.isEmpty(thooCoci9zae3)) {
                bundle.putString("Goog-Firebase-Installations-Auth", thooCoci9zae3);
            } else {
                Log.w("FirebaseMessaging", "FIS auth token is empty");
            }
        } catch (InterruptedException e) {
            e = e;
            Log.e("FirebaseMessaging", "Failed to get FIS auth token", e);
            bundle.putString("appid", (String) vaeVoh2dei5I.ahthoK6usais.ieseir3Choge(this.f5799Aicohm8ieYoo.getId()));
            bundle.putString("cliv", "fcm-24.1.0");
            ko7aifeiqu3s = (rieVei3pei5O.ko7aiFeiqu3s) this.f5803kuedujio7Aev.get();
            shieteechuY1.ohv5Shie7AeZ ohv5shie7aez = (shieteechuY1.ohv5Shie7AeZ) this.f5800ieheiQu9sho5.get();
            if (ko7aifeiqu3s != null) {
                return;
            } else {
                return;
            }
        } catch (ExecutionException e2) {
            e = e2;
            Log.e("FirebaseMessaging", "Failed to get FIS auth token", e);
            bundle.putString("appid", (String) vaeVoh2dei5I.ahthoK6usais.ieseir3Choge(this.f5799Aicohm8ieYoo.getId()));
            bundle.putString("cliv", "fcm-24.1.0");
            ko7aifeiqu3s = (rieVei3pei5O.ko7aiFeiqu3s) this.f5803kuedujio7Aev.get();
            shieteechuY1.ohv5Shie7AeZ ohv5shie7aez2 = (shieteechuY1.ohv5Shie7AeZ) this.f5800ieheiQu9sho5.get();
            if (ko7aifeiqu3s != null) {
            }
        }
        bundle.putString("appid", (String) vaeVoh2dei5I.ahthoK6usais.ieseir3Choge(this.f5799Aicohm8ieYoo.getId()));
        bundle.putString("cliv", "fcm-24.1.0");
        ko7aifeiqu3s = (rieVei3pei5O.ko7aiFeiqu3s) this.f5803kuedujio7Aev.get();
        shieteechuY1.ohv5Shie7AeZ ohv5shie7aez22 = (shieteechuY1.ohv5Shie7AeZ) this.f5800ieheiQu9sho5.get();
        if (ko7aifeiqu3s != null && ohv5shie7aez22 != null && (thooCoci9zae2 = ko7aifeiqu3s.thooCoci9zae("fire-iid")) != ko7aiFeiqu3s.ieseir3Choge.NONE) {
            bundle.putString("Firebase-Client-Log-Type", Integer.toString(thooCoci9zae2.Jah0aiP1ki6y()));
            bundle.putString("Firebase-Client", ohv5shie7aez22.ieseir3Choge());
        }
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ kuedujio7Aev() {
        return this.f5802keiL1EiShomu.ieseir3Choge();
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ mi5Iecheimie(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("gcm.topic", "/topics/" + str2);
        return keiL1EiShomu(ahthoK6usais(str, "/topics/" + str2, bundle));
    }

    public final /* synthetic */ String ohv5Shie7AeZ(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        return Jah0aiP1ki6y((Bundle) ohv5shie7aez.ahthoK6usais(IOException.class));
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ ruNgecai1pae(boolean z) {
        return this.f5802keiL1EiShomu.ieheiQu9sho5(z);
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ ruwiepo7ooVu(String str, String str2) {
        Bundle bundle = new Bundle();
        bundle.putString("gcm.topic", "/topics/" + str2);
        bundle.putString("delete", "1");
        return keiL1EiShomu(ahthoK6usais(str, "/topics/" + str2, bundle));
    }

    public IengaiSahh8H(ohBoophood9o.kuedujio7Aev kuedujio7aev, mi3Ozool1oa4 mi3ozool1oa4, oWouk4seiqua.thooCoci9zae thoococi9zae, oWouk4seiqua.thooCoci9zae thoococi9zae2, sieChi1iehoo.niah0Shohtha niah0shohtha) {
        this(kuedujio7aev, mi3ozool1oa4, new Xe6mangaekai.keiL1EiShomu(kuedujio7aev.ko7aiFeiqu3s()), thoococi9zae, thoococi9zae2, niah0shohtha);
    }
}
