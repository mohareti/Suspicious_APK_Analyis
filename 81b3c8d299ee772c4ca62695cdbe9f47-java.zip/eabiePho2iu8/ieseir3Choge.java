package eabiePho2iu8;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieseir3Choge implements aeTh5ATha5te.ieseir3Choge {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final aeTh5ATha5te.ieseir3Choge f5854ieseir3Choge = new ieseir3Choge();

    /* renamed from: eabiePho2iu8.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0076ieseir3Choge implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final C0076ieseir3Choge f5860ieseir3Choge = new C0076ieseir3Choge();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5870thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("projectNumber").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(1).ieseir3Choge()).ieseir3Choge();

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5861keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("messageId").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(2).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5859ieheiQu9sho5 = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("instanceId").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(3).ieseir3Choge()).ieseir3Choge();

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5863kuedujio7Aev = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("messageType").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(4).ieseir3Choge()).ieseir3Choge();

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5856Aicohm8ieYoo = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("sdkPlatform").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(5).ieseir3Choge()).ieseir3Choge();

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5857Jah0aiP1ki6y = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("packageName").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(6).ieseir3Choge()).ieseir3Choge();

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5865niah0Shohtha = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("collapseKey").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(7).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5867ohv5Shie7AeZ = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("priority").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(8).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5862ko7aiFeiqu3s = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("ttl").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(9).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5868ruNgecai1pae = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("topic").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(10).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5858ahthoK6usais = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("bulkId").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(11).ieseir3Choge()).ieseir3Choge();

        /* renamed from: mi5Iecheimie, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5864mi5Iecheimie = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("event").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(12).ieseir3Choge()).ieseir3Choge();

        /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5869ruwiepo7ooVu = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("analyticsLabel").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(13).ieseir3Choge()).ieseir3Choge();

        /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5855AeJiPo4of6Sh = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("campaignId").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(14).ieseir3Choge()).ieseir3Choge();

        /* renamed from: oYe2ma2she1j, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5866oYe2ma2she1j = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("composerLabel").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(15).ieseir3Choge()).ieseir3Choge();

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(Eis8oov7ohD0.ieseir3Choge ieseir3choge, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.ieheiQu9sho5(f5870thooCoci9zae, ieseir3choge.ahthoK6usais());
            aicohm8ieYoo.kuedujio7Aev(f5861keiL1EiShomu, ieseir3choge.niah0Shohtha());
            aicohm8ieYoo.kuedujio7Aev(f5859ieheiQu9sho5, ieseir3choge.Jah0aiP1ki6y());
            aicohm8ieYoo.kuedujio7Aev(f5863kuedujio7Aev, ieseir3choge.ohv5Shie7AeZ());
            aicohm8ieYoo.kuedujio7Aev(f5856Aicohm8ieYoo, ieseir3choge.mi5Iecheimie());
            aicohm8ieYoo.kuedujio7Aev(f5857Jah0aiP1ki6y, ieseir3choge.ko7aiFeiqu3s());
            aicohm8ieYoo.kuedujio7Aev(f5865niah0Shohtha, ieseir3choge.ieheiQu9sho5());
            aicohm8ieYoo.keiL1EiShomu(f5867ohv5Shie7AeZ, ieseir3choge.ruNgecai1pae());
            aicohm8ieYoo.keiL1EiShomu(f5862ko7aiFeiqu3s, ieseir3choge.AeJiPo4of6Sh());
            aicohm8ieYoo.kuedujio7Aev(f5868ruNgecai1pae, ieseir3choge.ruwiepo7ooVu());
            aicohm8ieYoo.ieheiQu9sho5(f5858ahthoK6usais, ieseir3choge.thooCoci9zae());
            aicohm8ieYoo.kuedujio7Aev(f5864mi5Iecheimie, ieseir3choge.Aicohm8ieYoo());
            aicohm8ieYoo.kuedujio7Aev(f5869ruwiepo7ooVu, ieseir3choge.ieseir3Choge());
            aicohm8ieYoo.ieheiQu9sho5(f5855AeJiPo4of6Sh, ieseir3choge.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f5866oYe2ma2she1j, ieseir3choge.kuedujio7Aev());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final keiL1EiShomu f5871ieseir3Choge = new keiL1EiShomu();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5872thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("messagingClientEventExtension");

        @Override // thai5ichoM2a.thooCoci9zae
        public /* bridge */ /* synthetic */ void ieseir3Choge(Object obj, Object obj2) {
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(obj);
            thooCoci9zae(null, (thai5ichoM2a.Aicohm8ieYoo) obj2);
        }

        public void thooCoci9zae(iecioL2LieVa ieciol2lieva, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            throw null;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final thooCoci9zae f5873ieseir3Choge = new thooCoci9zae();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f5874thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieseir3Choge("messagingClientEvent").thooCoci9zae(jeeGhae1Va1p.ieseir3Choge.thooCoci9zae().keiL1EiShomu(1).ieseir3Choge()).ieseir3Choge();

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(Eis8oov7ohD0.thooCoci9zae thoococi9zae, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.kuedujio7Aev(f5874thooCoci9zae, thoococi9zae.ieseir3Choge());
        }
    }

    @Override // aeTh5ATha5te.ieseir3Choge
    public void ieseir3Choge(aeTh5ATha5te.thooCoci9zae thoococi9zae) {
        thoococi9zae.ieseir3Choge(iecioL2LieVa.class, keiL1EiShomu.f5871ieseir3Choge);
        thoococi9zae.ieseir3Choge(Eis8oov7ohD0.thooCoci9zae.class, thooCoci9zae.f5873ieseir3Choge);
        thoococi9zae.ieseir3Choge(Eis8oov7ohD0.ieseir3Choge.class, C0076ieseir3Choge.f5860ieseir3Choge);
    }
}
