package eabiePho2iu8;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Ohah9Nai3tha {
    public static void Aicohm8ieYoo(Context context, boolean z) {
        SharedPreferences.Editor edit = thooCoci9zae(context).edit();
        edit.putBoolean("proxy_notification_initialized", z);
        edit.apply();
    }

    public static void Jah0aiP1ki6y(final Context context, IengaiSahh8H iengaiSahh8H, final boolean z) {
        if (Id9uvaegh4ai.ohv5Shie7AeZ.ohv5Shie7AeZ() && !ieheiQu9sho5(thooCoci9zae(context), z)) {
            iengaiSahh8H.ruNgecai1pae(z).Aicohm8ieYoo(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.Aicohm8ieYoo() { // from class: eabiePho2iu8.ieph3Uteimah
                @Override // vaeVoh2dei5I.Aicohm8ieYoo
                public final void ieheiQu9sho5(Object obj) {
                    Ohah9Nai3tha.niah0Shohtha(context, z);
                }
            });
        }
    }

    public static boolean ieheiQu9sho5(SharedPreferences sharedPreferences, boolean z) {
        if (!sharedPreferences.contains("proxy_retention") || sharedPreferences.getBoolean("proxy_retention", false) != z) {
            return false;
        }
        return true;
    }

    public static boolean keiL1EiShomu(Context context) {
        return thooCoci9zae(context).getBoolean("proxy_notification_initialized", false);
    }

    public static void niah0Shohtha(Context context, boolean z) {
        SharedPreferences.Editor edit = thooCoci9zae(context).edit();
        edit.putBoolean("proxy_retention", z);
        edit.apply();
    }

    public static SharedPreferences thooCoci9zae(Context context) {
        Context applicationContext = context.getApplicationContext();
        if (applicationContext != null) {
            context = applicationContext;
        }
        return context.getSharedPreferences("com.google.firebase.messaging", 0);
    }
}
