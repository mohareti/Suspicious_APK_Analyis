package eabiePho2iu8;

import android.app.Activity;
import android.app.Application;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.Queue;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class eetheKaevie8 implements Application.ActivityLifecycleCallbacks {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Queue f5841ieseir3Choge = new ArrayDeque(10);

    /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
    public final void thooCoci9zae(Intent intent) {
        Bundle bundle = null;
        try {
            Bundle extras = intent.getExtras();
            if (extras != null) {
                String niah0Shohtha2 = ahk3OhSh9Ree.niah0Shohtha(extras);
                if (!TextUtils.isEmpty(niah0Shohtha2)) {
                    if (this.f5841ieseir3Choge.contains(niah0Shohtha2)) {
                        return;
                    } else {
                        this.f5841ieseir3Choge.add(niah0Shohtha2);
                    }
                }
                bundle = extras.getBundle("gcm.n.analytics_data");
            }
        } catch (RuntimeException e) {
            Log.w("FirebaseMessaging", "Failed trying to get analytics data from Intent extras.", e);
        }
        if (ahk3OhSh9Ree.IengaiSahh8H(bundle)) {
            ahk3OhSh9Ree.ohthie9thieG(bundle);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
        final Intent intent = activity.getIntent();
        if (intent == null) {
            return;
        }
        if (Build.VERSION.SDK_INT <= 25) {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: eabiePho2iu8.oYe2ma2she1j
                @Override // java.lang.Runnable
                public final void run() {
                    eetheKaevie8.this.thooCoci9zae(intent);
                }
            });
        } else {
            thooCoci9zae(intent);
        }
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityDestroyed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityResumed(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStarted(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }
}
