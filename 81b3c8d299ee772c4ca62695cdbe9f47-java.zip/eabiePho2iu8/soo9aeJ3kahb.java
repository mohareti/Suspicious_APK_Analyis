package eabiePho2iu8;

import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.Executor;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class soo9aeJ3kahb {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final SharedPreferences f5940ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f5941keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final Executor f5942kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f5943thooCoci9zae;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final ArrayDeque f5939ieheiQu9sho5 = new ArrayDeque();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public boolean f5938Aicohm8ieYoo = false;

    public soo9aeJ3kahb(SharedPreferences sharedPreferences, String str, String str2, Executor executor) {
        this.f5940ieseir3Choge = sharedPreferences;
        this.f5943thooCoci9zae = str;
        this.f5941keiL1EiShomu = str2;
        this.f5942kuedujio7Aev = executor;
    }

    public static soo9aeJ3kahb ieheiQu9sho5(SharedPreferences sharedPreferences, String str, String str2, Executor executor) {
        soo9aeJ3kahb soo9aej3kahb = new soo9aeJ3kahb(sharedPreferences, str, str2, executor);
        soo9aej3kahb.kuedujio7Aev();
        return soo9aej3kahb;
    }

    public String Aicohm8ieYoo() {
        String str;
        synchronized (this.f5939ieheiQu9sho5) {
            str = (String) this.f5939ieheiQu9sho5.peek();
        }
        return str;
    }

    public boolean Jah0aiP1ki6y(Object obj) {
        boolean keiL1EiShomu2;
        synchronized (this.f5939ieheiQu9sho5) {
            keiL1EiShomu2 = keiL1EiShomu(this.f5939ieheiQu9sho5.remove(obj));
        }
        return keiL1EiShomu2;
    }

    public final boolean keiL1EiShomu(boolean z) {
        if (z && !this.f5938Aicohm8ieYoo) {
            ko7aiFeiqu3s();
        }
        return z;
    }

    public final void ko7aiFeiqu3s() {
        this.f5942kuedujio7Aev.execute(new Runnable() { // from class: eabiePho2iu8.GieBae8eiNge
            @Override // java.lang.Runnable
            public final void run() {
                soo9aeJ3kahb.this.ohv5Shie7AeZ();
            }
        });
    }

    public final void kuedujio7Aev() {
        synchronized (this.f5939ieheiQu9sho5) {
            try {
                this.f5939ieheiQu9sho5.clear();
                String string = this.f5940ieseir3Choge.getString(this.f5943thooCoci9zae, BuildConfig.FLAVOR);
                if (!TextUtils.isEmpty(string) && string.contains(this.f5941keiL1EiShomu)) {
                    String[] split = string.split(this.f5941keiL1EiShomu, -1);
                    if (split.length == 0) {
                        Log.e("FirebaseMessaging", "Corrupted queue. Please check the queue contents and item separator provided");
                    }
                    for (String str : split) {
                        if (!TextUtils.isEmpty(str)) {
                            this.f5939ieheiQu9sho5.add(str);
                        }
                    }
                }
            } finally {
            }
        }
    }

    public String niah0Shohtha() {
        StringBuilder sb = new StringBuilder();
        Iterator it = this.f5939ieheiQu9sho5.iterator();
        while (it.hasNext()) {
            sb.append((String) it.next());
            sb.append(this.f5941keiL1EiShomu);
        }
        return sb.toString();
    }

    public final void ohv5Shie7AeZ() {
        synchronized (this.f5939ieheiQu9sho5) {
            this.f5940ieseir3Choge.edit().putString(this.f5943thooCoci9zae, niah0Shohtha()).commit();
        }
    }

    public boolean thooCoci9zae(String str) {
        boolean keiL1EiShomu2;
        if (!TextUtils.isEmpty(str) && !str.contains(this.f5941keiL1EiShomu)) {
            synchronized (this.f5939ieheiQu9sho5) {
                keiL1EiShomu2 = keiL1EiShomu(this.f5939ieheiQu9sho5.add(str));
            }
            return keiL1EiShomu2;
        }
        return false;
    }
}
