package eabiePho2iu8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import java.io.IOException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Ohgahseiw0ni implements Runnable {

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public static Boolean f5816ko7aiFeiqu3s;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final Object f5817ohv5Shie7AeZ = new Object();

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public static Boolean f5818ruNgecai1pae;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final PowerManager.WakeLock f5819Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final Eipeibai2Aa0 f5820Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Context f5821ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final mi3Ozool1oa4 f5822kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final long f5823niah0Shohtha;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge extends BroadcastReceiver {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public Ohgahseiw0ni f5824ieseir3Choge;

        public ieseir3Choge(Ohgahseiw0ni ohgahseiw0ni) {
            this.f5824ieseir3Choge = ohgahseiw0ni;
        }

        public void ieseir3Choge() {
            if (Ohgahseiw0ni.thooCoci9zae()) {
                Log.d("FirebaseMessaging", "Connectivity change received registered");
            }
            Ohgahseiw0ni.this.f5821ieheiQu9sho5.registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }

        @Override // android.content.BroadcastReceiver
        public synchronized void onReceive(Context context, Intent intent) {
            try {
                Ohgahseiw0ni ohgahseiw0ni = this.f5824ieseir3Choge;
                if (ohgahseiw0ni == null) {
                    return;
                }
                if (!ohgahseiw0ni.ohv5Shie7AeZ()) {
                    return;
                }
                if (Ohgahseiw0ni.thooCoci9zae()) {
                    Log.d("FirebaseMessaging", "Connectivity changed. Starting background sync.");
                }
                this.f5824ieseir3Choge.f5820Jah0aiP1ki6y.mi5Iecheimie(this.f5824ieseir3Choge, 0L);
                context.unregisterReceiver(this);
                this.f5824ieseir3Choge = null;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public Ohgahseiw0ni(Eipeibai2Aa0 eipeibai2Aa0, Context context, mi3Ozool1oa4 mi3ozool1oa4, long j) {
        this.f5820Jah0aiP1ki6y = eipeibai2Aa0;
        this.f5821ieheiQu9sho5 = context;
        this.f5823niah0Shohtha = j;
        this.f5822kuedujio7Aev = mi3ozool1oa4;
        this.f5819Aicohm8ieYoo = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "wake:com.google.firebase.messaging");
    }

    public static boolean Aicohm8ieYoo(Context context) {
        boolean booleanValue;
        boolean booleanValue2;
        synchronized (f5817ohv5Shie7AeZ) {
            try {
                Boolean bool = f5818ruNgecai1pae;
                if (bool == null) {
                    booleanValue = Jah0aiP1ki6y(context, "android.permission.ACCESS_NETWORK_STATE", bool);
                } else {
                    booleanValue = bool.booleanValue();
                }
                Boolean valueOf = Boolean.valueOf(booleanValue);
                f5818ruNgecai1pae = valueOf;
                booleanValue2 = valueOf.booleanValue();
            } catch (Throwable th) {
                throw th;
            }
        }
        return booleanValue2;
    }

    public static boolean Jah0aiP1ki6y(Context context, String str, Boolean bool) {
        boolean z;
        if (bool != null) {
            return bool.booleanValue();
        }
        if (context.checkCallingOrSelfPermission(str) == 0) {
            z = true;
        } else {
            z = false;
        }
        if (!z && Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", kuedujio7Aev(str));
        }
        return z;
    }

    public static boolean ko7aiFeiqu3s() {
        if (!Log.isLoggable("FirebaseMessaging", 3) && (Build.VERSION.SDK_INT != 23 || !Log.isLoggable("FirebaseMessaging", 3))) {
            return false;
        }
        return true;
    }

    public static String kuedujio7Aev(String str) {
        return "Missing Permission: " + str + ". This permission should normally be included by the manifest merger, but may needed to be manually added to your manifest";
    }

    public static boolean niah0Shohtha(Context context) {
        boolean booleanValue;
        boolean booleanValue2;
        synchronized (f5817ohv5Shie7AeZ) {
            try {
                Boolean bool = f5816ko7aiFeiqu3s;
                if (bool == null) {
                    booleanValue = Jah0aiP1ki6y(context, "android.permission.WAKE_LOCK", bool);
                } else {
                    booleanValue = bool.booleanValue();
                }
                Boolean valueOf = Boolean.valueOf(booleanValue);
                f5816ko7aiFeiqu3s = valueOf;
                booleanValue2 = valueOf.booleanValue();
            } catch (Throwable th) {
                throw th;
            }
        }
        return booleanValue2;
    }

    public static /* synthetic */ boolean thooCoci9zae() {
        return ko7aiFeiqu3s();
    }

    public final synchronized boolean ohv5Shie7AeZ() {
        NetworkInfo networkInfo;
        boolean z;
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) this.f5821ieheiQu9sho5.getSystemService("connectivity");
            if (connectivityManager != null) {
                networkInfo = connectivityManager.getActiveNetworkInfo();
            } else {
                networkInfo = null;
            }
            if (networkInfo != null) {
                if (networkInfo.isConnected()) {
                    z = true;
                }
            }
            z = false;
        } catch (Throwable th) {
            throw th;
        }
        return z;
    }

    @Override // java.lang.Runnable
    public void run() {
        PowerManager.WakeLock wakeLock;
        if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
            this.f5819Aicohm8ieYoo.acquire(kuedujio7Aev.f5883ieseir3Choge);
        }
        try {
            try {
                try {
                    this.f5820Jah0aiP1ki6y.AeJiPo4of6Sh(true);
                } catch (Throwable th) {
                    if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
                        try {
                            this.f5819Aicohm8ieYoo.release();
                        } catch (RuntimeException unused) {
                            Log.i("FirebaseMessaging", "TopicsSyncTask's wakelock was already released due to timeout.");
                        }
                    }
                    throw th;
                }
            } catch (IOException e) {
                Log.e("FirebaseMessaging", "Failed to sync topics. Won't retry sync. " + e.getMessage());
                this.f5820Jah0aiP1ki6y.AeJiPo4of6Sh(false);
                if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
                    wakeLock = this.f5819Aicohm8ieYoo;
                } else {
                    return;
                }
            }
            if (!this.f5822kuedujio7Aev.Jah0aiP1ki6y()) {
                this.f5820Jah0aiP1ki6y.AeJiPo4of6Sh(false);
                if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
                    try {
                        this.f5819Aicohm8ieYoo.release();
                        return;
                    } catch (RuntimeException unused2) {
                        Log.i("FirebaseMessaging", "TopicsSyncTask's wakelock was already released due to timeout.");
                        return;
                    }
                }
                return;
            }
            if (Aicohm8ieYoo(this.f5821ieheiQu9sho5) && !ohv5Shie7AeZ()) {
                new ieseir3Choge(this).ieseir3Choge();
                if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
                    try {
                        this.f5819Aicohm8ieYoo.release();
                        return;
                    } catch (RuntimeException unused3) {
                        Log.i("FirebaseMessaging", "TopicsSyncTask's wakelock was already released due to timeout.");
                        return;
                    }
                }
                return;
            }
            if (this.f5820Jah0aiP1ki6y.aac1eTaexee6()) {
                this.f5820Jah0aiP1ki6y.AeJiPo4of6Sh(false);
            } else {
                this.f5820Jah0aiP1ki6y.laej2zeez5Ja(this.f5823niah0Shohtha);
            }
            if (niah0Shohtha(this.f5821ieheiQu9sho5)) {
                wakeLock = this.f5819Aicohm8ieYoo;
                wakeLock.release();
            }
        } catch (RuntimeException unused4) {
            Log.i("FirebaseMessaging", "TopicsSyncTask's wakelock was already released due to timeout.");
        }
    }
}
