package eabiePho2iu8;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class aed3pie3Chah {

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static ahSixio7zefo.ieseir3Choge f5832keiL1EiShomu;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final long f5831ieseir3Choge = TimeUnit.MINUTES.toMillis(1);

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final Object f5833thooCoci9zae = new Object();

    public static void Aicohm8ieYoo(Context context, ooJahquoo9ei oojahquoo9ei, final Intent intent) {
        synchronized (f5833thooCoci9zae) {
            try {
                thooCoci9zae(context);
                boolean ieheiQu9sho52 = ieheiQu9sho5(intent);
                Jah0aiP1ki6y(intent, true);
                if (!ieheiQu9sho52) {
                    f5832keiL1EiShomu.ieseir3Choge(f5831ieseir3Choge);
                }
                oojahquoo9ei.ieheiQu9sho5(intent).keiL1EiShomu(new vaeVoh2dei5I.ieheiQu9sho5() { // from class: eabiePho2iu8.baexaike8KuV
                    @Override // vaeVoh2dei5I.ieheiQu9sho5
                    public final void ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                        aed3pie3Chah.keiL1EiShomu(intent);
                    }
                });
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static void Jah0aiP1ki6y(Intent intent, boolean z) {
        intent.putExtra("com.google.firebase.iid.WakeLockHolder.wakefulintent", z);
    }

    public static boolean ieheiQu9sho5(Intent intent) {
        return intent.getBooleanExtra("com.google.firebase.iid.WakeLockHolder.wakefulintent", false);
    }

    public static void keiL1EiShomu(Intent intent) {
        synchronized (f5833thooCoci9zae) {
            try {
                if (f5832keiL1EiShomu != null && ieheiQu9sho5(intent)) {
                    Jah0aiP1ki6y(intent, false);
                    f5832keiL1EiShomu.keiL1EiShomu();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static ComponentName niah0Shohtha(Context context, Intent intent) {
        synchronized (f5833thooCoci9zae) {
            try {
                thooCoci9zae(context);
                boolean ieheiQu9sho52 = ieheiQu9sho5(intent);
                Jah0aiP1ki6y(intent, true);
                ComponentName startService = context.startService(intent);
                if (startService == null) {
                    return null;
                }
                if (!ieheiQu9sho52) {
                    f5832keiL1EiShomu.ieseir3Choge(f5831ieseir3Choge);
                }
                return startService;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public static void thooCoci9zae(Context context) {
        if (f5832keiL1EiShomu == null) {
            ahSixio7zefo.ieseir3Choge ieseir3choge = new ahSixio7zefo.ieseir3Choge(context, 1, "wake:com.google.firebase.iid.WakeLockHolder");
            f5832keiL1EiShomu = ieseir3choge;
            ieseir3choge.ieheiQu9sho5(true);
        }
    }
}
