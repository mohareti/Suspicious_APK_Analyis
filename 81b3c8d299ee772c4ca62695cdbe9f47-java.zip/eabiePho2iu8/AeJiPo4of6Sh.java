package eabiePho2iu8;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class AeJiPo4of6Sh {
    public static ExecutorService Aicohm8ieYoo() {
        return Executors.newSingleThreadExecutor(new Ahv6nai5fo5z.ieseir3Choge("Firebase-Messaging-Task"));
    }

    public static ScheduledExecutorService Jah0aiP1ki6y() {
        return new ScheduledThreadPoolExecutor(1, new Ahv6nai5fo5z.ieseir3Choge("Firebase-Messaging-Topics-Io"));
    }

    public static ExecutorService ieheiQu9sho5() {
        return ohgh8ooWieT2.thooCoci9zae.ieseir3Choge().ieseir3Choge(new Ahv6nai5fo5z.ieseir3Choge("Firebase-Messaging-Intent-Handle"), ohgh8ooWieT2.keiL1EiShomu.HIGH_SPEED);
    }

    public static Executor ieseir3Choge(String str) {
        return new ThreadPoolExecutor(0, 1, 30L, TimeUnit.SECONDS, new LinkedBlockingQueue(), new Ahv6nai5fo5z.ieseir3Choge(str));
    }

    public static ScheduledExecutorService keiL1EiShomu() {
        return new ScheduledThreadPoolExecutor(1, new Ahv6nai5fo5z.ieseir3Choge("Firebase-Messaging-Init"));
    }

    public static ExecutorService kuedujio7Aev() {
        return Executors.newSingleThreadExecutor(new Ahv6nai5fo5z.ieseir3Choge("Firebase-Messaging-Network-Io"));
    }

    public static Executor thooCoci9zae() {
        return ieseir3Choge("Firebase-Messaging-File-Io");
    }
}
