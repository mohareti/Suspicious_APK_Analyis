package eabiePho2iu8;

import Eis8oov7ohD0.ieseir3Choge;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;
import java.util.concurrent.ExecutionException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ahk3OhSh9Ree {
    public static String AeJiPo4of6Sh() {
        return ohBoophood9o.kuedujio7Aev.ruNgecai1pae().ko7aiFeiqu3s().getPackageName();
    }

    public static String Aicohm8ieYoo(Bundle bundle) {
        String string = bundle.getString("google.to");
        if (!TextUtils.isEmpty(string)) {
            return string;
        }
        try {
            return (String) vaeVoh2dei5I.ahthoK6usais.ieseir3Choge(sieChi1iehoo.Jah0aiP1ki6y.oYe2ma2she1j(ohBoophood9o.kuedujio7Aev.ruNgecai1pae()).getId());
        } catch (InterruptedException | ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    public static void Idohhaimaes0(ieseir3Choge.thooCoci9zae thoococi9zae, Intent intent, GieBae8eiNge.ohv5Shie7AeZ ohv5shie7aez) {
        if (ohv5shie7aez == null) {
            Log.e("FirebaseMessaging", "TransportFactory is null. Skip exporting message delivery metrics to Big Query");
            return;
        }
        Eis8oov7ohD0.ieseir3Choge thooCoci9zae2 = thooCoci9zae(thoococi9zae, intent);
        if (thooCoci9zae2 == null) {
            return;
        }
        try {
            ohv5shie7aez.ieseir3Choge("FCM_CLIENT_EVENT_LOGGING", Eis8oov7ohD0.thooCoci9zae.class, GieBae8eiNge.keiL1EiShomu.thooCoci9zae("proto"), new GieBae8eiNge.Jah0aiP1ki6y() { // from class: eabiePho2iu8.Uz0ahGh4yook
                @Override // GieBae8eiNge.Jah0aiP1ki6y
                public final Object ieseir3Choge(Object obj) {
                    return ((Eis8oov7ohD0.thooCoci9zae) obj).keiL1EiShomu();
                }
            }).ieseir3Choge(GieBae8eiNge.ieheiQu9sho5.kuedujio7Aev(Eis8oov7ohD0.thooCoci9zae.thooCoci9zae().thooCoci9zae(thooCoci9zae2).ieseir3Choge(), GieBae8eiNge.Aicohm8ieYoo.thooCoci9zae(Integer.valueOf(intent.getIntExtra("google.product_id", 111881503)))));
        } catch (RuntimeException e) {
            Log.w("FirebaseMessaging", "Failed to send big query analytics payload.", e);
        }
    }

    public static boolean IengaiSahh8H(Bundle bundle) {
        if (bundle == null) {
            return false;
        }
        return "1".equals(bundle.getString("google.c.a.e"));
    }

    public static String Jah0aiP1ki6y(Bundle bundle) {
        return bundle.getString("google.c.a.m_c");
    }

    public static void Ochoob6Ahvi2(String str, Bundle bundle) {
        try {
            ohBoophood9o.kuedujio7Aev.ruNgecai1pae();
            if (bundle == null) {
                bundle = new Bundle();
            }
            Bundle bundle2 = new Bundle();
            String ieheiQu9sho52 = ieheiQu9sho5(bundle);
            if (ieheiQu9sho52 != null) {
                bundle2.putString("_nmid", ieheiQu9sho52);
            }
            String kuedujio7Aev2 = kuedujio7Aev(bundle);
            if (kuedujio7Aev2 != null) {
                bundle2.putString("_nmn", kuedujio7Aev2);
            }
            String ohv5Shie7AeZ2 = ohv5Shie7AeZ(bundle);
            if (!TextUtils.isEmpty(ohv5Shie7AeZ2)) {
                bundle2.putString("label", ohv5Shie7AeZ2);
            }
            String Jah0aiP1ki6y2 = Jah0aiP1ki6y(bundle);
            if (!TextUtils.isEmpty(Jah0aiP1ki6y2)) {
                bundle2.putString("message_channel", Jah0aiP1ki6y2);
            }
            String zoojiiKaht3i2 = zoojiiKaht3i(bundle);
            if (zoojiiKaht3i2 != null) {
                bundle2.putString("_nt", zoojiiKaht3i2);
            }
            String ahthoK6usais2 = ahthoK6usais(bundle);
            if (ahthoK6usais2 != null) {
                try {
                    bundle2.putInt("_nmt", Integer.parseInt(ahthoK6usais2));
                } catch (NumberFormatException e) {
                    Log.w("FirebaseMessaging", "Error while parsing timestamp in GCM event", e);
                }
            }
            String laej2zeez5Ja2 = laej2zeez5Ja(bundle);
            if (laej2zeez5Ja2 != null) {
                try {
                    bundle2.putInt("_ndt", Integer.parseInt(laej2zeez5Ja2));
                } catch (NumberFormatException e2) {
                    Log.w("FirebaseMessaging", "Error while parsing use_device_time in GCM event", e2);
                }
            }
            String ruwiepo7ooVu2 = ruwiepo7ooVu(bundle);
            if ("_nr".equals(str) || "_nf".equals(str)) {
                bundle2.putString("_nmc", ruwiepo7ooVu2);
            }
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Logging to scion event=" + str + " scionPayload=" + bundle2);
            }
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(ohBoophood9o.kuedujio7Aev.ruNgecai1pae().ohv5Shie7AeZ(OhDeezoPii8H.ieseir3Choge.class));
            Log.w("FirebaseMessaging", "Unable to log event: analytics library is missing");
        } catch (IllegalStateException unused) {
            Log.e("FirebaseMessaging", "Default FirebaseApp has not been initialized. Skip logging event to GA.");
        }
    }

    public static boolean Phae5ooG6hah(Intent intent) {
        if (intent != null && !rojaiZ9aeRee(intent)) {
            return ieseir3Choge();
        }
        return false;
    }

    public static int aac1eTaexee6(Bundle bundle) {
        Object obj = bundle.get("google.ttl");
        if (obj instanceof Integer) {
            return ((Integer) obj).intValue();
        }
        if (obj instanceof String) {
            try {
                return Integer.parseInt((String) obj);
            } catch (NumberFormatException unused) {
                Log.w("FirebaseMessaging", "Invalid TTL: " + obj);
                return 0;
            }
        }
        return 0;
    }

    public static String ahthoK6usais(Bundle bundle) {
        return bundle.getString("google.c.a.ts");
    }

    public static void ahz5eechei8U(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        if ("1".equals(bundle.getString("google.c.a.tc"))) {
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(ohBoophood9o.kuedujio7Aev.ruNgecai1pae().ohv5Shie7AeZ(OhDeezoPii8H.ieseir3Choge.class));
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Received event with track-conversion=true. Setting user property and reengagement event");
            }
            Log.w("FirebaseMessaging", "Unable to set user property for conversion tracking:  analytics library is missing");
            return;
        }
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Received event with track-conversion=false. Do not set user property");
        }
    }

    public static long eetheKaevie8(Bundle bundle) {
        if (bundle.containsKey("google.c.sender.id")) {
            try {
                return Long.parseLong(bundle.getString("google.c.sender.id"));
            } catch (NumberFormatException e) {
                Log.w("FirebaseMessaging", "error parsing project number", e);
            }
        }
        ohBoophood9o.kuedujio7Aev ruNgecai1pae2 = ohBoophood9o.kuedujio7Aev.ruNgecai1pae();
        String ieheiQu9sho52 = ruNgecai1pae2.mi5Iecheimie().ieheiQu9sho5();
        if (ieheiQu9sho52 != null) {
            try {
                return Long.parseLong(ieheiQu9sho52);
            } catch (NumberFormatException e2) {
                Log.w("FirebaseMessaging", "error parsing sender ID", e2);
            }
        }
        String keiL1EiShomu2 = ruNgecai1pae2.mi5Iecheimie().keiL1EiShomu();
        try {
            if (!keiL1EiShomu2.startsWith("1:")) {
                return Long.parseLong(keiL1EiShomu2);
            }
            String[] split = keiL1EiShomu2.split(":");
            if (split.length < 2) {
                return 0L;
            }
            String str = split[1];
            if (str.isEmpty()) {
                return 0L;
            }
            return Long.parseLong(str);
        } catch (NumberFormatException e3) {
            Log.w("FirebaseMessaging", "error parsing app ID", e3);
            return 0L;
        }
    }

    public static void esohshee3Pau(Intent intent) {
        Ochoob6Ahvi2("_nd", intent.getExtras());
    }

    public static void eyei9eigh3Ie(Intent intent) {
        if (kah6Uo2ooji4(intent)) {
            Ochoob6Ahvi2("_nr", intent.getExtras());
        }
        if (Phae5ooG6hah(intent)) {
            Idohhaimaes0(ieseir3Choge.thooCoci9zae.MESSAGE_DELIVERED, intent, FirebaseMessaging.laej2zeez5Ja());
        }
    }

    public static String ieheiQu9sho5(Bundle bundle) {
        return bundle.getString("google.c.a.c_id");
    }

    public static boolean ieseir3Choge() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            ohBoophood9o.kuedujio7Aev.ruNgecai1pae();
            Context ko7aiFeiqu3s2 = ohBoophood9o.kuedujio7Aev.ruNgecai1pae().ko7aiFeiqu3s();
            SharedPreferences sharedPreferences = ko7aiFeiqu3s2.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("export_to_big_query")) {
                return sharedPreferences.getBoolean("export_to_big_query", false);
            }
            try {
                PackageManager packageManager = ko7aiFeiqu3s2.getPackageManager();
                if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(ko7aiFeiqu3s2.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("delivery_metrics_exported_to_big_query_enabled")) {
                    return applicationInfo.metaData.getBoolean("delivery_metrics_exported_to_big_query_enabled", false);
                }
            } catch (PackageManager.NameNotFoundException unused) {
            }
            return false;
        } catch (IllegalStateException unused2) {
            Log.i("FirebaseMessaging", "FirebaseApp has not being initialized. Device might be in direct boot mode. Skip exporting delivery metrics to Big Query");
            return false;
        }
    }

    public static boolean kah6Uo2ooji4(Intent intent) {
        if (intent != null && !rojaiZ9aeRee(intent)) {
            return IengaiSahh8H(intent.getExtras());
        }
        return false;
    }

    public static String keiL1EiShomu(Bundle bundle) {
        return bundle.getString("collapse_key");
    }

    public static int ko7aiFeiqu3s(String str) {
        if ("high".equals(str)) {
            return 1;
        }
        if ("normal".equals(str)) {
            return 2;
        }
        return 0;
    }

    public static String kuedujio7Aev(Bundle bundle) {
        return bundle.getString("google.c.a.c_l");
    }

    public static String laej2zeez5Ja(Bundle bundle) {
        if (bundle.containsKey("google.c.a.udt")) {
            return bundle.getString("google.c.a.udt");
        }
        return null;
    }

    public static ieseir3Choge.keiL1EiShomu mi5Iecheimie(Bundle bundle) {
        if (bundle != null && io4laQuei7sa.laej2zeez5Ja(bundle)) {
            return ieseir3Choge.keiL1EiShomu.DISPLAY_NOTIFICATION;
        }
        return ieseir3Choge.keiL1EiShomu.DATA_MESSAGE;
    }

    public static String niah0Shohtha(Bundle bundle) {
        String string = bundle.getString("google.message_id");
        if (string == null) {
            return bundle.getString("message_id");
        }
        return string;
    }

    public static int oYe2ma2she1j(Bundle bundle) {
        String string = bundle.getString("google.delivered_priority");
        if (string == null) {
            if ("1".equals(bundle.getString("google.priority_reduced"))) {
                return 2;
            }
            string = bundle.getString("google.priority");
        }
        return ko7aiFeiqu3s(string);
    }

    public static void ohthie9thieG(Bundle bundle) {
        ahz5eechei8U(bundle);
        Ochoob6Ahvi2("_no", bundle);
    }

    public static String ohv5Shie7AeZ(Bundle bundle) {
        return bundle.getString("google.c.a.m_l");
    }

    public static void oph9lahCh6uo(Intent intent) {
        Ochoob6Ahvi2("_nf", intent.getExtras());
    }

    public static boolean rojaiZ9aeRee(Intent intent) {
        return "com.google.firebase.messaging.RECEIVE_DIRECT_BOOT".equals(intent.getAction());
    }

    public static int ruNgecai1pae(Bundle bundle) {
        int oYe2ma2she1j2 = oYe2ma2she1j(bundle);
        if (oYe2ma2she1j2 == 2) {
            return 5;
        }
        if (oYe2ma2she1j2 == 1) {
            return 10;
        }
        return 0;
    }

    public static String ruwiepo7ooVu(Bundle bundle) {
        if (bundle != null && io4laQuei7sa.laej2zeez5Ja(bundle)) {
            return "display";
        }
        return "data";
    }

    public static Eis8oov7ohD0.ieseir3Choge thooCoci9zae(ieseir3Choge.thooCoci9zae thoococi9zae, Intent intent) {
        if (intent == null) {
            return null;
        }
        Bundle extras = intent.getExtras();
        if (extras == null) {
            extras = Bundle.EMPTY;
        }
        ieseir3Choge.C0015ieseir3Choge ko7aiFeiqu3s2 = Eis8oov7ohD0.ieseir3Choge.oYe2ma2she1j().ruwiepo7ooVu(aac1eTaexee6(extras)).kuedujio7Aev(thoococi9zae).Aicohm8ieYoo(Aicohm8ieYoo(extras)).ohv5Shie7AeZ(AeJiPo4of6Sh()).ahthoK6usais(ieseir3Choge.ieheiQu9sho5.ANDROID).niah0Shohtha(mi5Iecheimie(extras)).ko7aiFeiqu3s(ruNgecai1pae(extras));
        String niah0Shohtha2 = niah0Shohtha(extras);
        if (niah0Shohtha2 != null) {
            ko7aiFeiqu3s2.Jah0aiP1ki6y(niah0Shohtha2);
        }
        String zoojiiKaht3i2 = zoojiiKaht3i(extras);
        if (zoojiiKaht3i2 != null) {
            ko7aiFeiqu3s2.mi5Iecheimie(zoojiiKaht3i2);
        }
        String keiL1EiShomu2 = keiL1EiShomu(extras);
        if (keiL1EiShomu2 != null) {
            ko7aiFeiqu3s2.keiL1EiShomu(keiL1EiShomu2);
        }
        String ohv5Shie7AeZ2 = ohv5Shie7AeZ(extras);
        if (ohv5Shie7AeZ2 != null) {
            ko7aiFeiqu3s2.thooCoci9zae(ohv5Shie7AeZ2);
        }
        String kuedujio7Aev2 = kuedujio7Aev(extras);
        if (kuedujio7Aev2 != null) {
            ko7aiFeiqu3s2.ieheiQu9sho5(kuedujio7Aev2);
        }
        long eetheKaevie82 = eetheKaevie8(extras);
        if (eetheKaevie82 > 0) {
            ko7aiFeiqu3s2.ruNgecai1pae(eetheKaevie82);
        }
        return ko7aiFeiqu3s2.ieseir3Choge();
    }

    public static String zoojiiKaht3i(Bundle bundle) {
        String string = bundle.getString("from");
        if (string == null || !string.startsWith("/topics/")) {
            return null;
        }
        return string;
    }
}
