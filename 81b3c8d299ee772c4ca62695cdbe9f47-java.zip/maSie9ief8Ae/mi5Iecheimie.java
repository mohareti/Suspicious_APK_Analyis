package maSie9ief8Ae;

import java.util.List;
import maSie9ief8Ae.Jah0aiP1ki6y;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class mi5Iecheimie {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ieseir3Choge Aicohm8ieYoo(oYe2ma2she1j oye2ma2she1j);

        public abstract ieseir3Choge Jah0aiP1ki6y(long j);

        public abstract ieseir3Choge ieheiQu9sho5(Integer num);

        public abstract mi5Iecheimie ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(List list);

        public ieseir3Choge ko7aiFeiqu3s(String str) {
            return kuedujio7Aev(str);
        }

        public abstract ieseir3Choge kuedujio7Aev(String str);

        public abstract ieseir3Choge niah0Shohtha(long j);

        public ieseir3Choge ohv5Shie7AeZ(int i) {
            return ieheiQu9sho5(Integer.valueOf(i));
        }

        public abstract ieseir3Choge thooCoci9zae(ruNgecai1pae rungecai1pae);
    }

    public static ieseir3Choge ieseir3Choge() {
        return new Jah0aiP1ki6y.thooCoci9zae();
    }

    public abstract oYe2ma2she1j Aicohm8ieYoo();

    public abstract long Jah0aiP1ki6y();

    public abstract Integer ieheiQu9sho5();

    public abstract List keiL1EiShomu();

    public abstract String kuedujio7Aev();

    public abstract long niah0Shohtha();

    public abstract ruNgecai1pae thooCoci9zae();
}
