package maSie9ief8Ae;

import java.util.Arrays;
import maSie9ief8Ae.ahthoK6usais;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Aicohm8ieYoo extends ahthoK6usais {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final long f7120Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final AeJiPo4of6Sh f7121Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final byte[] f7122ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final long f7123ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final long f7124keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final String f7125kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Integer f7126thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends ahthoK6usais.ieseir3Choge {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public Long f7127Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public AeJiPo4of6Sh f7128Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public byte[] f7129ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public Long f7130ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public Long f7131keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public String f7132kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Integer f7133thooCoci9zae;

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge Aicohm8ieYoo(byte[] bArr) {
            this.f7129ieheiQu9sho5 = bArr;
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge Jah0aiP1ki6y(String str) {
            this.f7132kuedujio7Aev = str;
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge ieheiQu9sho5(long j) {
            this.f7131keiL1EiShomu = Long.valueOf(j);
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais ieseir3Choge() {
            Long l = this.f7130ieseir3Choge;
            String str = BuildConfig.FLAVOR;
            if (l == null) {
                str = BuildConfig.FLAVOR + " eventTimeMs";
            }
            if (this.f7131keiL1EiShomu == null) {
                str = str + " eventUptimeMs";
            }
            if (this.f7127Aicohm8ieYoo == null) {
                str = str + " timezoneOffsetSeconds";
            }
            if (str.isEmpty()) {
                return new Aicohm8ieYoo(this.f7130ieseir3Choge.longValue(), this.f7133thooCoci9zae, this.f7131keiL1EiShomu.longValue(), this.f7129ieheiQu9sho5, this.f7132kuedujio7Aev, this.f7127Aicohm8ieYoo.longValue(), this.f7128Jah0aiP1ki6y);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge keiL1EiShomu(long j) {
            this.f7130ieseir3Choge = Long.valueOf(j);
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge kuedujio7Aev(AeJiPo4of6Sh aeJiPo4of6Sh) {
            this.f7128Jah0aiP1ki6y = aeJiPo4of6Sh;
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge niah0Shohtha(long j) {
            this.f7127Aicohm8ieYoo = Long.valueOf(j);
            return this;
        }

        @Override // maSie9ief8Ae.ahthoK6usais.ieseir3Choge
        public ahthoK6usais.ieseir3Choge thooCoci9zae(Integer num) {
            this.f7133thooCoci9zae = num;
            return this;
        }
    }

    public Aicohm8ieYoo(long j, Integer num, long j2, byte[] bArr, String str, long j3, AeJiPo4of6Sh aeJiPo4of6Sh) {
        this.f7123ieseir3Choge = j;
        this.f7126thooCoci9zae = num;
        this.f7124keiL1EiShomu = j2;
        this.f7122ieheiQu9sho5 = bArr;
        this.f7125kuedujio7Aev = str;
        this.f7120Aicohm8ieYoo = j3;
        this.f7121Jah0aiP1ki6y = aeJiPo4of6Sh;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public byte[] Aicohm8ieYoo() {
        return this.f7122ieheiQu9sho5;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public String Jah0aiP1ki6y() {
        return this.f7125kuedujio7Aev;
    }

    public boolean equals(Object obj) {
        Integer num;
        byte[] Aicohm8ieYoo2;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ahthoK6usais)) {
            return false;
        }
        ahthoK6usais ahthok6usais = (ahthoK6usais) obj;
        if (this.f7123ieseir3Choge == ahthok6usais.keiL1EiShomu() && ((num = this.f7126thooCoci9zae) != null ? num.equals(ahthok6usais.thooCoci9zae()) : ahthok6usais.thooCoci9zae() == null) && this.f7124keiL1EiShomu == ahthok6usais.ieheiQu9sho5()) {
            byte[] bArr = this.f7122ieheiQu9sho5;
            if (ahthok6usais instanceof Aicohm8ieYoo) {
                Aicohm8ieYoo2 = ((Aicohm8ieYoo) ahthok6usais).f7122ieheiQu9sho5;
            } else {
                Aicohm8ieYoo2 = ahthok6usais.Aicohm8ieYoo();
            }
            if (Arrays.equals(bArr, Aicohm8ieYoo2) && ((str = this.f7125kuedujio7Aev) != null ? str.equals(ahthok6usais.Jah0aiP1ki6y()) : ahthok6usais.Jah0aiP1ki6y() == null) && this.f7120Aicohm8ieYoo == ahthok6usais.niah0Shohtha()) {
                AeJiPo4of6Sh aeJiPo4of6Sh = this.f7121Jah0aiP1ki6y;
                AeJiPo4of6Sh kuedujio7Aev2 = ahthok6usais.kuedujio7Aev();
                if (aeJiPo4of6Sh == null) {
                    if (kuedujio7Aev2 == null) {
                        return true;
                    }
                } else if (aeJiPo4of6Sh.equals(kuedujio7Aev2)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        int hashCode2;
        long j = this.f7123ieseir3Choge;
        int i = (((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f7126thooCoci9zae;
        int i2 = 0;
        if (num == null) {
            hashCode = 0;
        } else {
            hashCode = num.hashCode();
        }
        long j2 = this.f7124keiL1EiShomu;
        int hashCode3 = (((((i ^ hashCode) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f7122ieheiQu9sho5)) * 1000003;
        String str = this.f7125kuedujio7Aev;
        if (str == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = str.hashCode();
        }
        long j3 = this.f7120Aicohm8ieYoo;
        int i3 = (((hashCode3 ^ hashCode2) * 1000003) ^ ((int) ((j3 >>> 32) ^ j3))) * 1000003;
        AeJiPo4of6Sh aeJiPo4of6Sh = this.f7121Jah0aiP1ki6y;
        if (aeJiPo4of6Sh != null) {
            i2 = aeJiPo4of6Sh.hashCode();
        }
        return i3 ^ i2;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public long ieheiQu9sho5() {
        return this.f7124keiL1EiShomu;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public long keiL1EiShomu() {
        return this.f7123ieseir3Choge;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public AeJiPo4of6Sh kuedujio7Aev() {
        return this.f7121Jah0aiP1ki6y;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public long niah0Shohtha() {
        return this.f7120Aicohm8ieYoo;
    }

    @Override // maSie9ief8Ae.ahthoK6usais
    public Integer thooCoci9zae() {
        return this.f7126thooCoci9zae;
    }

    public String toString() {
        return "LogEvent{eventTimeMs=" + this.f7123ieseir3Choge + ", eventCode=" + this.f7126thooCoci9zae + ", eventUptimeMs=" + this.f7124keiL1EiShomu + ", sourceExtension=" + Arrays.toString(this.f7122ieheiQu9sho5) + ", sourceExtensionJsonProto3=" + this.f7125kuedujio7Aev + ", timezoneOffsetSeconds=" + this.f7120Aicohm8ieYoo + ", networkConnectionInfo=" + this.f7121Jah0aiP1ki6y + "}";
    }
}
