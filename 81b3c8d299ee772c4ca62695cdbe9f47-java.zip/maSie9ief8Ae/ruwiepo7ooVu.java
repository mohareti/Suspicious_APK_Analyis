package maSie9ief8Ae;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.IOException;
import java.io.Reader;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ruwiepo7ooVu {
    public static ruwiepo7ooVu ieseir3Choge(long j) {
        return new niah0Shohtha(j);
    }

    public static ruwiepo7ooVu thooCoci9zae(Reader reader) {
        JsonReader jsonReader = new JsonReader(reader);
        try {
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                if (jsonReader.nextName().equals("nextRequestWaitMillis")) {
                    if (jsonReader.peek() == JsonToken.STRING) {
                        return ieseir3Choge(Long.parseLong(jsonReader.nextString()));
                    }
                    return ieseir3Choge(jsonReader.nextLong());
                }
                jsonReader.skipValue();
            }
            throw new IOException("Response is missing nextRequestWaitMillis field.");
        } finally {
            jsonReader.close();
        }
    }

    public abstract long keiL1EiShomu();
}
