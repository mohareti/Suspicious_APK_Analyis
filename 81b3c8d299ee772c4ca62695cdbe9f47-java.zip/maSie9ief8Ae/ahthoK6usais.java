package maSie9ief8Ae;

import maSie9ief8Ae.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ahthoK6usais {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ieseir3Choge Aicohm8ieYoo(byte[] bArr);

        public abstract ieseir3Choge Jah0aiP1ki6y(String str);

        public abstract ieseir3Choge ieheiQu9sho5(long j);

        public abstract ahthoK6usais ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(long j);

        public abstract ieseir3Choge kuedujio7Aev(AeJiPo4of6Sh aeJiPo4of6Sh);

        public abstract ieseir3Choge niah0Shohtha(long j);

        public abstract ieseir3Choge thooCoci9zae(Integer num);
    }

    public static ieseir3Choge ieseir3Choge() {
        return new Aicohm8ieYoo.thooCoci9zae();
    }

    public static ieseir3Choge ko7aiFeiqu3s(byte[] bArr) {
        return ieseir3Choge().Aicohm8ieYoo(bArr);
    }

    public static ieseir3Choge ohv5Shie7AeZ(String str) {
        return ieseir3Choge().Jah0aiP1ki6y(str);
    }

    public abstract byte[] Aicohm8ieYoo();

    public abstract String Jah0aiP1ki6y();

    public abstract long ieheiQu9sho5();

    public abstract long keiL1EiShomu();

    public abstract AeJiPo4of6Sh kuedujio7Aev();

    public abstract long niah0Shohtha();

    public abstract Integer thooCoci9zae();
}
