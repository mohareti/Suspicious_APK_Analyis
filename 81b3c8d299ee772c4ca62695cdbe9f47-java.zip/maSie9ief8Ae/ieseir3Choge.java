package maSie9ief8Ae;

import maSie9ief8Ae.keiL1EiShomu;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieseir3Choge {

    /* renamed from: maSie9ief8Ae.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class AbstractC0098ieseir3Choge {
        public abstract AbstractC0098ieseir3Choge Aicohm8ieYoo(String str);

        public abstract AbstractC0098ieseir3Choge Jah0aiP1ki6y(String str);

        public abstract AbstractC0098ieseir3Choge ahthoK6usais(String str);

        public abstract AbstractC0098ieseir3Choge ieheiQu9sho5(String str);

        public abstract ieseir3Choge ieseir3Choge();

        public abstract AbstractC0098ieseir3Choge keiL1EiShomu(String str);

        public abstract AbstractC0098ieseir3Choge ko7aiFeiqu3s(String str);

        public abstract AbstractC0098ieseir3Choge kuedujio7Aev(String str);

        public abstract AbstractC0098ieseir3Choge mi5Iecheimie(Integer num);

        public abstract AbstractC0098ieseir3Choge niah0Shohtha(String str);

        public abstract AbstractC0098ieseir3Choge ohv5Shie7AeZ(String str);

        public abstract AbstractC0098ieseir3Choge ruNgecai1pae(String str);

        public abstract AbstractC0098ieseir3Choge thooCoci9zae(String str);
    }

    public static AbstractC0098ieseir3Choge ieseir3Choge() {
        return new keiL1EiShomu.thooCoci9zae();
    }

    public abstract String Aicohm8ieYoo();

    public abstract String Jah0aiP1ki6y();

    public abstract String ahthoK6usais();

    public abstract String ieheiQu9sho5();

    public abstract String keiL1EiShomu();

    public abstract String ko7aiFeiqu3s();

    public abstract String kuedujio7Aev();

    public abstract Integer mi5Iecheimie();

    public abstract String niah0Shohtha();

    public abstract String ohv5Shie7AeZ();

    public abstract String ruNgecai1pae();

    public abstract String thooCoci9zae();
}
