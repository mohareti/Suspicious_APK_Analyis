package maSie9ief8Ae;

import android.util.SparseArray;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public enum oYe2ma2she1j {
    DEFAULT(0),
    UNMETERED_ONLY(1),
    UNMETERED_OR_DAILY(2),
    FAST_IF_RADIO_AWAKE(3),
    NEVER(4),
    UNRECOGNIZED(-1);


    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public static final SparseArray f7185ruNgecai1pae;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final int f7186ieheiQu9sho5;

    static {
        oYe2ma2she1j oye2ma2she1j = DEFAULT;
        oYe2ma2she1j oye2ma2she1j2 = UNMETERED_ONLY;
        oYe2ma2she1j oye2ma2she1j3 = UNMETERED_OR_DAILY;
        oYe2ma2she1j oye2ma2she1j4 = FAST_IF_RADIO_AWAKE;
        oYe2ma2she1j oye2ma2she1j5 = NEVER;
        oYe2ma2she1j oye2ma2she1j6 = UNRECOGNIZED;
        SparseArray sparseArray = new SparseArray();
        f7185ruNgecai1pae = sparseArray;
        sparseArray.put(0, oye2ma2she1j);
        sparseArray.put(1, oye2ma2she1j2);
        sparseArray.put(2, oye2ma2she1j3);
        sparseArray.put(3, oye2ma2she1j4);
        sparseArray.put(4, oye2ma2she1j5);
        sparseArray.put(-1, oye2ma2she1j6);
    }

    oYe2ma2she1j(int i) {
        this.f7186ieheiQu9sho5 = i;
    }
}
