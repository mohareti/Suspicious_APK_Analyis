package maSie9ief8Ae;

import maSie9ief8Ae.kuedujio7Aev;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ruNgecai1pae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ruNgecai1pae ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(thooCoci9zae thoococi9zae);

        public abstract ieseir3Choge thooCoci9zae(maSie9ief8Ae.ieseir3Choge ieseir3choge);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        UNKNOWN(0),
        ANDROID_FIREBASE(23);


        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final int f7194ieheiQu9sho5;

        thooCoci9zae(int i) {
            this.f7194ieheiQu9sho5 = i;
        }
    }

    public static ieseir3Choge ieseir3Choge() {
        return new kuedujio7Aev.thooCoci9zae();
    }

    public abstract thooCoci9zae keiL1EiShomu();

    public abstract maSie9ief8Ae.ieseir3Choge thooCoci9zae();
}
