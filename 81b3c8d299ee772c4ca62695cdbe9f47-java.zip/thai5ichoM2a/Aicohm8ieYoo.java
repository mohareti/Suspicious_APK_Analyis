package thai5ichoM2a;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface Aicohm8ieYoo {
    Aicohm8ieYoo ieheiQu9sho5(ieheiQu9sho5 ieheiqu9sho5, long j);

    Aicohm8ieYoo keiL1EiShomu(ieheiQu9sho5 ieheiqu9sho5, int i);

    Aicohm8ieYoo kuedujio7Aev(ieheiQu9sho5 ieheiqu9sho5, Object obj);
}
