package thai5ichoM2a;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface niah0Shohtha {
    niah0Shohtha ieseir3Choge(String str);

    niah0Shohtha thooCoci9zae(boolean z);
}
