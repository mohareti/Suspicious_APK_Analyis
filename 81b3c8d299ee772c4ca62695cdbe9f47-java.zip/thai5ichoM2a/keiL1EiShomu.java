package thai5ichoM2a;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class keiL1EiShomu extends RuntimeException {
    public keiL1EiShomu(String str) {
        super(str);
    }

    public keiL1EiShomu(String str, Exception exc) {
        super(str, exc);
    }
}
