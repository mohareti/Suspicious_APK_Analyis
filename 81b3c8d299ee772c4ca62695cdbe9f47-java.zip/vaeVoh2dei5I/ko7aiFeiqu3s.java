package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ko7aiFeiqu3s {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Uz0ahGh4yook f8238ieseir3Choge = new Uz0ahGh4yook();

    public boolean ieheiQu9sho5(Exception exc) {
        return this.f8238ieseir3Choge.rojaiZ9aeRee(exc);
    }

    public ohv5Shie7AeZ ieseir3Choge() {
        return this.f8238ieseir3Choge;
    }

    public void keiL1EiShomu(Object obj) {
        this.f8238ieseir3Choge.aac1eTaexee6(obj);
    }

    public boolean kuedujio7Aev(Object obj) {
        return this.f8238ieseir3Choge.esohshee3Pau(obj);
    }

    public void thooCoci9zae(Exception exc) {
        this.f8238ieseir3Choge.zoojiiKaht3i(exc);
    }
}
