package vaeVoh2dei5I;

import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Meu0ophaeng1 implements Executor {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Handler f8210ieheiQu9sho5 = new ooThuoloosh4.ieseir3Choge(Looper.getMainLooper());

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        this.f8210ieheiQu9sho5.post(runnable);
    }
}
