package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class thooCoci9zae extends IllegalStateException {
    public thooCoci9zae(String str, Throwable th) {
        super(str, th);
    }

    public static IllegalStateException ieseir3Choge(ohv5Shie7AeZ ohv5shie7aez) {
        String str;
        if (!ohv5shie7aez.ruwiepo7ooVu()) {
            return new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
        }
        Exception ko7aiFeiqu3s2 = ohv5shie7aez.ko7aiFeiqu3s();
        if (ko7aiFeiqu3s2 != null) {
            str = "failure";
        } else if (ohv5shie7aez.AeJiPo4of6Sh()) {
            str = "result ".concat(String.valueOf(ohv5shie7aez.ruNgecai1pae()));
        } else if (ohv5shie7aez.mi5Iecheimie()) {
            str = "cancellation";
        } else {
            str = "unknown issue";
        }
        return new thooCoci9zae("Complete with: ".concat(str), ko7aiFeiqu3s2);
    }
}
