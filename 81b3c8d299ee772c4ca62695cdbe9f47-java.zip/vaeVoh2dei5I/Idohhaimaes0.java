package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Idohhaimaes0 implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ ohv5Shie7AeZ f8205ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ Ochoob6Ahvi2 f8206kuedujio7Aev;

    public Idohhaimaes0(Ochoob6Ahvi2 ochoob6Ahvi2, ohv5Shie7AeZ ohv5shie7aez) {
        this.f8206kuedujio7Aev = ochoob6Ahvi2;
        this.f8205ieheiQu9sho5 = ohv5shie7aez;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        Aicohm8ieYoo aicohm8ieYoo;
        Aicohm8ieYoo aicohm8ieYoo2;
        obj = this.f8206kuedujio7Aev.f8213thooCoci9zae;
        synchronized (obj) {
            try {
                Ochoob6Ahvi2 ochoob6Ahvi2 = this.f8206kuedujio7Aev;
                aicohm8ieYoo = ochoob6Ahvi2.f8212keiL1EiShomu;
                if (aicohm8ieYoo != null) {
                    aicohm8ieYoo2 = ochoob6Ahvi2.f8212keiL1EiShomu;
                    aicohm8ieYoo2.ieheiQu9sho5(this.f8205ieheiQu9sho5.ruNgecai1pae());
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
