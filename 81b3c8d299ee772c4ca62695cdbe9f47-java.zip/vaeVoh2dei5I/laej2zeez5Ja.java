package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class laej2zeez5Ja implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ rojaiZ9aeRee f8239ieheiQu9sho5;

    public laej2zeez5Ja(rojaiZ9aeRee rojaiz9aeree) {
        this.f8239ieheiQu9sho5 = rojaiz9aeree;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        keiL1EiShomu keil1eishomu;
        keiL1EiShomu keil1eishomu2;
        obj = this.f8239ieheiQu9sho5.f8249thooCoci9zae;
        synchronized (obj) {
            try {
                rojaiZ9aeRee rojaiz9aeree = this.f8239ieheiQu9sho5;
                keil1eishomu = rojaiz9aeree.f8248keiL1EiShomu;
                if (keil1eishomu != null) {
                    keil1eishomu2 = rojaiz9aeree.f8248keiL1EiShomu;
                    keil1eishomu2.ieseir3Choge();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
