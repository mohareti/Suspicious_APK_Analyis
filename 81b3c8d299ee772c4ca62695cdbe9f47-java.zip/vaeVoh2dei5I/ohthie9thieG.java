package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ohthie9thieG implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ ohv5Shie7AeZ f8242ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ eyei9eigh3Ie f8243kuedujio7Aev;

    public ohthie9thieG(eyei9eigh3Ie eyei9eigh3ie, ohv5Shie7AeZ ohv5shie7aez) {
        this.f8243kuedujio7Aev = eyei9eigh3ie;
        this.f8242ieheiQu9sho5 = ohv5shie7aez;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        kuedujio7Aev kuedujio7aev;
        kuedujio7Aev kuedujio7aev2;
        obj = this.f8243kuedujio7Aev.f8237thooCoci9zae;
        synchronized (obj) {
            try {
                eyei9eigh3Ie eyei9eigh3ie = this.f8243kuedujio7Aev;
                kuedujio7aev = eyei9eigh3ie.f8236keiL1EiShomu;
                if (kuedujio7aev != null) {
                    kuedujio7aev2 = eyei9eigh3ie.f8236keiL1EiShomu;
                    kuedujio7aev2.keiL1EiShomu((Exception) Aebu8yohvea8.ruwiepo7ooVu.ko7aiFeiqu3s(this.f8242ieheiQu9sho5.ko7aiFeiqu3s()));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
