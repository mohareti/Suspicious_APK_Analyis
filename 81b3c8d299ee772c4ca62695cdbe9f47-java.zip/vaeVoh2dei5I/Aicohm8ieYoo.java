package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface Aicohm8ieYoo {
    void ieheiQu9sho5(Object obj);
}
