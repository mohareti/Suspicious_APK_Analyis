package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class esohshee3Pau implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ ohv5Shie7AeZ f8233ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ oph9lahCh6uo f8234kuedujio7Aev;

    public esohshee3Pau(oph9lahCh6uo oph9lahch6uo, ohv5Shie7AeZ ohv5shie7aez) {
        this.f8234kuedujio7Aev = oph9lahch6uo;
        this.f8233ieheiQu9sho5 = ohv5shie7aez;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj;
        ieheiQu9sho5 ieheiqu9sho5;
        ieheiQu9sho5 ieheiqu9sho52;
        obj = this.f8234kuedujio7Aev.f8246thooCoci9zae;
        synchronized (obj) {
            try {
                oph9lahCh6uo oph9lahch6uo = this.f8234kuedujio7Aev;
                ieheiqu9sho5 = oph9lahch6uo.f8245keiL1EiShomu;
                if (ieheiqu9sho5 != null) {
                    ieheiqu9sho52 = oph9lahch6uo.f8245keiL1EiShomu;
                    ieheiqu9sho52.ieseir3Choge(this.f8233ieheiQu9sho5);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
