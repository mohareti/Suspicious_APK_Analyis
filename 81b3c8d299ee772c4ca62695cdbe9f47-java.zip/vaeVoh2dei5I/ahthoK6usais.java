package vaeVoh2dei5I;

import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ahthoK6usais {
    public static Object Aicohm8ieYoo(ohv5Shie7AeZ ohv5shie7aez) {
        if (ohv5shie7aez.AeJiPo4of6Sh()) {
            return ohv5shie7aez.ruNgecai1pae();
        }
        if (ohv5shie7aez.mi5Iecheimie()) {
            throw new CancellationException("Task is already canceled");
        }
        throw new ExecutionException(ohv5shie7aez.ko7aiFeiqu3s());
    }

    public static void Jah0aiP1ki6y(ohv5Shie7AeZ ohv5shie7aez, AeJiPo4of6Sh aeJiPo4of6Sh) {
        Executor executor = ruNgecai1pae.f8251thooCoci9zae;
        ohv5shie7aez.Aicohm8ieYoo(executor, aeJiPo4of6Sh);
        ohv5shie7aez.ieheiQu9sho5(executor, aeJiPo4of6Sh);
        ohv5shie7aez.ieseir3Choge(executor, aeJiPo4of6Sh);
    }

    public static ohv5Shie7AeZ ieheiQu9sho5(Exception exc) {
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        uz0ahGh4yook.zoojiiKaht3i(exc);
        return uz0ahGh4yook;
    }

    public static Object ieseir3Choge(ohv5Shie7AeZ ohv5shie7aez) {
        Aebu8yohvea8.ruwiepo7ooVu.niah0Shohtha();
        Aebu8yohvea8.ruwiepo7ooVu.Aicohm8ieYoo();
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(ohv5shie7aez, "Task must not be null");
        if (ohv5shie7aez.ruwiepo7ooVu()) {
            return Aicohm8ieYoo(ohv5shie7aez);
        }
        ruwiepo7ooVu ruwiepo7oovu = new ruwiepo7ooVu(null);
        Jah0aiP1ki6y(ohv5shie7aez, ruwiepo7oovu);
        ruwiepo7oovu.thooCoci9zae();
        return Aicohm8ieYoo(ohv5shie7aez);
    }

    public static ohv5Shie7AeZ keiL1EiShomu(Executor executor, Callable callable) {
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(executor, "Executor must not be null");
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(callable, "Callback must not be null");
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        executor.execute(new ahk3OhSh9Ree(uz0ahGh4yook, callable));
        return uz0ahGh4yook;
    }

    public static ohv5Shie7AeZ kuedujio7Aev(Object obj) {
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        uz0ahGh4yook.aac1eTaexee6(obj);
        return uz0ahGh4yook;
    }

    public static Object thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez, long j, TimeUnit timeUnit) {
        Aebu8yohvea8.ruwiepo7ooVu.niah0Shohtha();
        Aebu8yohvea8.ruwiepo7ooVu.Aicohm8ieYoo();
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(ohv5shie7aez, "Task must not be null");
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(timeUnit, "TimeUnit must not be null");
        if (ohv5shie7aez.ruwiepo7ooVu()) {
            return Aicohm8ieYoo(ohv5shie7aez);
        }
        ruwiepo7ooVu ruwiepo7oovu = new ruwiepo7ooVu(null);
        Jah0aiP1ki6y(ohv5shie7aez, ruwiepo7oovu);
        if (ruwiepo7oovu.kuedujio7Aev(j, timeUnit)) {
            return Aicohm8ieYoo(ohv5shie7aez);
        }
        throw new TimeoutException("Timed out waiting for Task");
    }
}
