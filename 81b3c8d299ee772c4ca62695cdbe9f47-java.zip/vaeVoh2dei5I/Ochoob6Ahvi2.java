package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Ochoob6Ahvi2 implements kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8211ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public Aicohm8ieYoo f8212keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Object f8213thooCoci9zae = new Object();

    public Ochoob6Ahvi2(Executor executor, Aicohm8ieYoo aicohm8ieYoo) {
        this.f8211ieseir3Choge = executor;
        this.f8212keiL1EiShomu = aicohm8ieYoo;
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        if (ohv5shie7aez.AeJiPo4of6Sh()) {
            synchronized (this.f8213thooCoci9zae) {
                try {
                    if (this.f8212keiL1EiShomu == null) {
                        return;
                    }
                    this.f8211ieseir3Choge.execute(new Idohhaimaes0(this, ohv5shie7aez));
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }
}
