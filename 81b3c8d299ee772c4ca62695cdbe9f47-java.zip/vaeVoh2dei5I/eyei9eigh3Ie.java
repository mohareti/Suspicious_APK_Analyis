package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eyei9eigh3Ie implements kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8235ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public kuedujio7Aev f8236keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Object f8237thooCoci9zae = new Object();

    public eyei9eigh3Ie(Executor executor, kuedujio7Aev kuedujio7aev) {
        this.f8235ieseir3Choge = executor;
        this.f8236keiL1EiShomu = kuedujio7aev;
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        if (!ohv5shie7aez.AeJiPo4of6Sh() && !ohv5shie7aez.mi5Iecheimie()) {
            synchronized (this.f8237thooCoci9zae) {
                try {
                    if (this.f8236keiL1EiShomu == null) {
                        return;
                    }
                    this.f8235ieseir3Choge.execute(new ohthie9thieG(this, ohv5shie7aez));
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }
}
