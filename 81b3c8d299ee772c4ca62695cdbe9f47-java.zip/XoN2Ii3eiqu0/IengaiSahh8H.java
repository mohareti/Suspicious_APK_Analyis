package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class IengaiSahh8H {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final lo8zieZoeseb f2287ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f2288ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final long f2289keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final lo8zieZoeseb f2290kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final thooCoci9zae f2291thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public lo8zieZoeseb f2292ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public String f2293ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public Long f2294keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public lo8zieZoeseb f2295kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public thooCoci9zae f2296thooCoci9zae;

        public ieseir3Choge ieheiQu9sho5(lo8zieZoeseb lo8ziezoeseb) {
            this.f2295kuedujio7Aev = lo8ziezoeseb;
            return this;
        }

        public IengaiSahh8H ieseir3Choge() {
            boolean z;
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(this.f2293ieseir3Choge, "description");
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(this.f2296thooCoci9zae, "severity");
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(this.f2294keiL1EiShomu, "timestampNanos");
            if (this.f2292ieheiQu9sho5 != null && this.f2295kuedujio7Aev != null) {
                z = false;
            } else {
                z = true;
            }
            Vaig0nohza7i.ko7aiFeiqu3s.rojaiZ9aeRee(z, "at least one of channelRef and subchannelRef must be null");
            return new IengaiSahh8H(this.f2293ieseir3Choge, this.f2296thooCoci9zae, this.f2294keiL1EiShomu.longValue(), this.f2292ieheiQu9sho5, this.f2295kuedujio7Aev);
        }

        public ieseir3Choge keiL1EiShomu(thooCoci9zae thoococi9zae) {
            this.f2296thooCoci9zae = thoococi9zae;
            return this;
        }

        public ieseir3Choge kuedujio7Aev(long j) {
            this.f2294keiL1EiShomu = Long.valueOf(j);
            return this;
        }

        public ieseir3Choge thooCoci9zae(String str) {
            this.f2293ieseir3Choge = str;
            return this;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        CT_UNKNOWN,
        CT_INFO,
        CT_WARNING,
        CT_ERROR
    }

    public IengaiSahh8H(String str, thooCoci9zae thoococi9zae, long j, lo8zieZoeseb lo8ziezoeseb, lo8zieZoeseb lo8ziezoeseb2) {
        this.f2288ieseir3Choge = str;
        this.f2291thooCoci9zae = (thooCoci9zae) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(thoococi9zae, "severity");
        this.f2289keiL1EiShomu = j;
        this.f2287ieheiQu9sho5 = lo8ziezoeseb;
        this.f2290kuedujio7Aev = lo8ziezoeseb2;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof IengaiSahh8H)) {
            return false;
        }
        IengaiSahh8H iengaiSahh8H = (IengaiSahh8H) obj;
        if (!Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2288ieseir3Choge, iengaiSahh8H.f2288ieseir3Choge) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2291thooCoci9zae, iengaiSahh8H.f2291thooCoci9zae) || this.f2289keiL1EiShomu != iengaiSahh8H.f2289keiL1EiShomu || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2287ieheiQu9sho5, iengaiSahh8H.f2287ieheiQu9sho5) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2290kuedujio7Aev, iengaiSahh8H.f2290kuedujio7Aev)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2288ieseir3Choge, this.f2291thooCoci9zae, Long.valueOf(this.f2289keiL1EiShomu), this.f2287ieheiQu9sho5, this.f2290kuedujio7Aev);
    }

    public String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("description", this.f2288ieseir3Choge).ieheiQu9sho5("severity", this.f2291thooCoci9zae).keiL1EiShomu("timestampNanos", this.f2289keiL1EiShomu).ieheiQu9sho5("channelRef", this.f2287ieheiQu9sho5).ieheiQu9sho5("subchannelRef", this.f2290kuedujio7Aev).toString();
    }
}
