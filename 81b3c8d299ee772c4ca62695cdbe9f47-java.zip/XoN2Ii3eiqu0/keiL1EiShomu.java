package XoN2Ii3eiqu0;

import Vaig0nohza7i.Aicohm8ieYoo;
import XoN2Ii3eiqu0.ruNgecai1pae;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class keiL1EiShomu {

    /* renamed from: ahthoK6usais, reason: collision with root package name */
    public static final keiL1EiShomu f2475ahthoK6usais;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final Object[][] f2476Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final List f2477Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final XoN2Ii3eiqu0.thooCoci9zae f2478ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final rojaiZ9aeRee f2479ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f2480keiL1EiShomu;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public final Integer f2481ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final String f2482kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final Boolean f2483niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public final Integer f2484ohv5Shie7AeZ;

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public final Integer f2485ruNgecai1pae;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Executor f2486thooCoci9zae;

    /* renamed from: XoN2Ii3eiqu0.keiL1EiShomu$keiL1EiShomu, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0031keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f2487ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Object f2488thooCoci9zae;

        public C0031keiL1EiShomu(String str, Object obj) {
            this.f2487ieseir3Choge = str;
            this.f2488thooCoci9zae = obj;
        }

        public static C0031keiL1EiShomu thooCoci9zae(String str) {
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "debugString");
            return new C0031keiL1EiShomu(str, null);
        }

        public String toString() {
            return this.f2487ieseir3Choge;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public Object[][] f2489Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public List f2490Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public XoN2Ii3eiqu0.thooCoci9zae f2491ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public rojaiZ9aeRee f2492ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public String f2493keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public Integer f2494ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public String f2495kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public Boolean f2496niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public Integer f2497ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public Integer f2498ruNgecai1pae;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Executor f2499thooCoci9zae;

        public final keiL1EiShomu thooCoci9zae() {
            return new keiL1EiShomu(this);
        }
    }

    static {
        thooCoci9zae thoococi9zae = new thooCoci9zae();
        thoococi9zae.f2489Aicohm8ieYoo = (Object[][]) Array.newInstance((Class<?>) Object.class, 0, 2);
        thoococi9zae.f2490Jah0aiP1ki6y = Collections.emptyList();
        f2475ahthoK6usais = thoococi9zae.thooCoci9zae();
    }

    public keiL1EiShomu(thooCoci9zae thoococi9zae) {
        this.f2479ieseir3Choge = thoococi9zae.f2492ieseir3Choge;
        this.f2486thooCoci9zae = thoococi9zae.f2499thooCoci9zae;
        this.f2480keiL1EiShomu = thoococi9zae.f2493keiL1EiShomu;
        this.f2478ieheiQu9sho5 = thoococi9zae.f2491ieheiQu9sho5;
        this.f2482kuedujio7Aev = thoococi9zae.f2495kuedujio7Aev;
        this.f2476Aicohm8ieYoo = thoococi9zae.f2489Aicohm8ieYoo;
        this.f2477Jah0aiP1ki6y = thoococi9zae.f2490Jah0aiP1ki6y;
        this.f2483niah0Shohtha = thoococi9zae.f2496niah0Shohtha;
        this.f2484ohv5Shie7AeZ = thoococi9zae.f2497ohv5Shie7AeZ;
        this.f2481ko7aiFeiqu3s = thoococi9zae.f2494ko7aiFeiqu3s;
        this.f2485ruNgecai1pae = thoococi9zae.f2498ruNgecai1pae;
    }

    public static thooCoci9zae ahthoK6usais(keiL1EiShomu keil1eishomu) {
        thooCoci9zae thoococi9zae = new thooCoci9zae();
        thoococi9zae.f2492ieseir3Choge = keil1eishomu.f2479ieseir3Choge;
        thoococi9zae.f2499thooCoci9zae = keil1eishomu.f2486thooCoci9zae;
        thoococi9zae.f2493keiL1EiShomu = keil1eishomu.f2480keiL1EiShomu;
        thoococi9zae.f2491ieheiQu9sho5 = keil1eishomu.f2478ieheiQu9sho5;
        thoococi9zae.f2495kuedujio7Aev = keil1eishomu.f2482kuedujio7Aev;
        thoococi9zae.f2489Aicohm8ieYoo = keil1eishomu.f2476Aicohm8ieYoo;
        thoococi9zae.f2490Jah0aiP1ki6y = keil1eishomu.f2477Jah0aiP1ki6y;
        thoococi9zae.f2496niah0Shohtha = keil1eishomu.f2483niah0Shohtha;
        thoococi9zae.f2497ohv5Shie7AeZ = keil1eishomu.f2484ohv5Shie7AeZ;
        thoococi9zae.f2494ko7aiFeiqu3s = keil1eishomu.f2481ko7aiFeiqu3s;
        thoococi9zae.f2498ruNgecai1pae = keil1eishomu.f2485ruNgecai1pae;
        return thoococi9zae;
    }

    public keiL1EiShomu AeJiPo4of6Sh(String str) {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2495kuedujio7Aev = str;
        return ahthoK6usais2.thooCoci9zae();
    }

    public Integer Aicohm8ieYoo() {
        return this.f2484ohv5Shie7AeZ;
    }

    public Integer Jah0aiP1ki6y() {
        return this.f2481ko7aiFeiqu3s;
    }

    public keiL1EiShomu aac1eTaexee6(int i) {
        boolean z;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        Vaig0nohza7i.ko7aiFeiqu3s.niah0Shohtha(z, "invalid maxsize %s", i);
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2497ohv5Shie7AeZ = Integer.valueOf(i);
        return ahthoK6usais2.thooCoci9zae();
    }

    public keiL1EiShomu eetheKaevie8(long j, TimeUnit timeUnit) {
        return oYe2ma2she1j(rojaiZ9aeRee.ieseir3Choge(j, timeUnit));
    }

    public keiL1EiShomu esohshee3Pau(C0031keiL1EiShomu c0031keiL1EiShomu, Object obj) {
        int i;
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0031keiL1EiShomu, "key");
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "value");
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        int i2 = 0;
        while (true) {
            Object[][] objArr = this.f2476Aicohm8ieYoo;
            if (i2 < objArr.length) {
                if (c0031keiL1EiShomu.equals(objArr[i2][0])) {
                    break;
                }
                i2++;
            } else {
                i2 = -1;
                break;
            }
        }
        int length = this.f2476Aicohm8ieYoo.length;
        if (i2 == -1) {
            i = 1;
        } else {
            i = 0;
        }
        Object[][] objArr2 = (Object[][]) Array.newInstance((Class<?>) Object.class, length + i, 2);
        ahthoK6usais2.f2489Aicohm8ieYoo = objArr2;
        Object[][] objArr3 = this.f2476Aicohm8ieYoo;
        System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
        if (i2 == -1) {
            Object[][] objArr4 = ahthoK6usais2.f2489Aicohm8ieYoo;
            int length2 = this.f2476Aicohm8ieYoo.length;
            Object[] objArr5 = new Object[2];
            objArr5[0] = c0031keiL1EiShomu;
            objArr5[1] = obj;
            objArr4[length2] = objArr5;
        } else {
            Object[][] objArr6 = ahthoK6usais2.f2489Aicohm8ieYoo;
            Object[] objArr7 = new Object[2];
            objArr7[0] = c0031keiL1EiShomu;
            objArr7[1] = obj;
            objArr6[i2] = objArr7;
        }
        return ahthoK6usais2.thooCoci9zae();
    }

    public keiL1EiShomu eyei9eigh3Ie() {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2496niah0Shohtha = Boolean.FALSE;
        return ahthoK6usais2.thooCoci9zae();
    }

    public rojaiZ9aeRee ieheiQu9sho5() {
        return this.f2479ieseir3Choge;
    }

    public String ieseir3Choge() {
        return this.f2480keiL1EiShomu;
    }

    public XoN2Ii3eiqu0.thooCoci9zae keiL1EiShomu() {
        return this.f2478ieheiQu9sho5;
    }

    public List ko7aiFeiqu3s() {
        return this.f2477Jah0aiP1ki6y;
    }

    public Executor kuedujio7Aev() {
        return this.f2486thooCoci9zae;
    }

    public keiL1EiShomu laej2zeez5Ja(int i) {
        boolean z;
        if (i >= 0) {
            z = true;
        } else {
            z = false;
        }
        Vaig0nohza7i.ko7aiFeiqu3s.niah0Shohtha(z, "invalid maxsize %s", i);
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2494ko7aiFeiqu3s = Integer.valueOf(i);
        return ahthoK6usais2.thooCoci9zae();
    }

    public keiL1EiShomu mi5Iecheimie(String str) {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2493keiL1EiShomu = str;
        return ahthoK6usais2.thooCoci9zae();
    }

    public Integer niah0Shohtha() {
        return this.f2485ruNgecai1pae;
    }

    public keiL1EiShomu oYe2ma2she1j(rojaiZ9aeRee rojaiz9aeree) {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2492ieseir3Choge = rojaiz9aeree;
        return ahthoK6usais2.thooCoci9zae();
    }

    public keiL1EiShomu ohthie9thieG() {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2496niah0Shohtha = Boolean.TRUE;
        return ahthoK6usais2.thooCoci9zae();
    }

    public Object ohv5Shie7AeZ(C0031keiL1EiShomu c0031keiL1EiShomu) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0031keiL1EiShomu, "key");
        int i = 0;
        while (true) {
            Object[][] objArr = this.f2476Aicohm8ieYoo;
            if (i >= objArr.length) {
                return c0031keiL1EiShomu.f2488thooCoci9zae;
            }
            if (c0031keiL1EiShomu.equals(objArr[i][0])) {
                return this.f2476Aicohm8ieYoo[i][1];
            }
            i++;
        }
    }

    public keiL1EiShomu oph9lahCh6uo(ruNgecai1pae.ieseir3Choge ieseir3choge) {
        ArrayList arrayList = new ArrayList(this.f2477Jah0aiP1ki6y.size() + 1);
        arrayList.addAll(this.f2477Jah0aiP1ki6y);
        arrayList.add(ieseir3choge);
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2490Jah0aiP1ki6y = Collections.unmodifiableList(arrayList);
        return ahthoK6usais2.thooCoci9zae();
    }

    public keiL1EiShomu rojaiZ9aeRee(int i) {
        boolean z;
        if (i > 0) {
            z = true;
        } else {
            z = false;
        }
        Vaig0nohza7i.ko7aiFeiqu3s.niah0Shohtha(z, "numBytes must be positive: %s", i);
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2498ruNgecai1pae = Integer.valueOf(i);
        return ahthoK6usais2.thooCoci9zae();
    }

    public boolean ruNgecai1pae() {
        return Boolean.TRUE.equals(this.f2483niah0Shohtha);
    }

    public keiL1EiShomu ruwiepo7ooVu(XoN2Ii3eiqu0.thooCoci9zae thoococi9zae) {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2491ieheiQu9sho5 = thoococi9zae;
        return ahthoK6usais2.thooCoci9zae();
    }

    public String thooCoci9zae() {
        return this.f2482kuedujio7Aev;
    }

    public String toString() {
        Class<?> cls;
        Aicohm8ieYoo.thooCoci9zae ieheiQu9sho52 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("deadline", this.f2479ieseir3Choge).ieheiQu9sho5("authority", this.f2480keiL1EiShomu).ieheiQu9sho5("callCredentials", this.f2478ieheiQu9sho5);
        Executor executor = this.f2486thooCoci9zae;
        if (executor != null) {
            cls = executor.getClass();
        } else {
            cls = null;
        }
        return ieheiQu9sho52.ieheiQu9sho5("executor", cls).ieheiQu9sho5("compressorName", this.f2482kuedujio7Aev).ieheiQu9sho5("customOptions", Arrays.deepToString(this.f2476Aicohm8ieYoo)).kuedujio7Aev("waitForReady", ruNgecai1pae()).ieheiQu9sho5("maxInboundMessageSize", this.f2484ohv5Shie7AeZ).ieheiQu9sho5("maxOutboundMessageSize", this.f2481ko7aiFeiqu3s).ieheiQu9sho5("onReadyThreshold", this.f2485ruNgecai1pae).ieheiQu9sho5("streamTracerFactories", this.f2477Jah0aiP1ki6y).toString();
    }

    public keiL1EiShomu zoojiiKaht3i(Executor executor) {
        thooCoci9zae ahthoK6usais2 = ahthoK6usais(this);
        ahthoK6usais2.f2499thooCoci9zae = executor;
        return ahthoK6usais2.thooCoci9zae();
    }
}
