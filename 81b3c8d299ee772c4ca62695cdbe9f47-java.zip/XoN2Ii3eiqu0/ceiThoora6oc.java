package XoN2Ii3eiqu0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ceiThoora6oc {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements Comparator {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final /* synthetic */ thooCoci9zae f2404ieheiQu9sho5;

        public ieseir3Choge(thooCoci9zae thoococi9zae) {
            this.f2404ieheiQu9sho5 = thoococi9zae;
        }

        @Override // java.util.Comparator
        public int compare(Object obj, Object obj2) {
            int ieseir3Choge2 = this.f2404ieheiQu9sho5.ieseir3Choge(obj) - this.f2404ieheiQu9sho5.ieseir3Choge(obj2);
            if (ieseir3Choge2 != 0) {
                return ieseir3Choge2;
            }
            return obj.getClass().getName().compareTo(obj2.getClass().getName());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface thooCoci9zae {
        int ieseir3Choge(Object obj);

        boolean thooCoci9zae(Object obj);
    }

    public static boolean ieheiQu9sho5(ClassLoader classLoader) {
        try {
            Class.forName("android.app.Application", false, classLoader);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public static Object ieseir3Choge(Class cls, Class cls2) {
        try {
            return cls2.asSubclass(cls).getConstructor(null).newInstance(null);
        } catch (ClassCastException unused) {
            return null;
        } catch (Throwable th) {
            throw new ServiceConfigurationError(String.format("Provider %s could not be instantiated %s", cls2.getName(), th), th);
        }
    }

    public static Iterable keiL1EiShomu(Class cls, ClassLoader classLoader) {
        ServiceLoader load = ServiceLoader.load(cls, classLoader);
        if (!load.iterator().hasNext()) {
            return ServiceLoader.load(cls);
        }
        return load;
    }

    public static List kuedujio7Aev(Class cls, Iterable iterable, ClassLoader classLoader, thooCoci9zae thoococi9zae) {
        Iterable keiL1EiShomu2;
        if (ieheiQu9sho5(classLoader)) {
            keiL1EiShomu2 = thooCoci9zae(cls, iterable);
        } else {
            keiL1EiShomu2 = keiL1EiShomu(cls, classLoader);
        }
        ArrayList arrayList = new ArrayList();
        for (Object obj : keiL1EiShomu2) {
            if (thoococi9zae.thooCoci9zae(obj)) {
                arrayList.add(obj);
            }
        }
        Collections.sort(arrayList, Collections.reverseOrder(new ieseir3Choge(thoococi9zae)));
        return Collections.unmodifiableList(arrayList);
    }

    public static Iterable thooCoci9zae(Class cls, Iterable iterable) {
        ArrayList arrayList = new ArrayList();
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            Object ieseir3Choge2 = ieseir3Choge(cls, (Class) it.next());
            if (ieseir3Choge2 != null) {
                arrayList.add(ieseir3Choge2);
            }
        }
        return arrayList;
    }
}
