package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Uz0ahGh4yook {
    public static byte[] ieseir3Choge(oph9lahCh6uo oph9lahch6uo) {
        return oph9lahch6uo.ieheiQu9sho5();
    }
}
