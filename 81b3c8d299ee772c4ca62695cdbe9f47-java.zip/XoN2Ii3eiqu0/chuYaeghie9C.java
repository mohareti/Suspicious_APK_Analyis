package XoN2Ii3eiqu0;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class chuYaeghie9C {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f2405ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Object f2406keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Collection f2407thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public String f2408ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public Object f2409keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public List f2410thooCoci9zae;

        public thooCoci9zae(String str) {
            this.f2410thooCoci9zae = new ArrayList();
            niah0Shohtha(str);
        }

        public thooCoci9zae Aicohm8ieYoo(GieBae8eiNge gieBae8eiNge) {
            this.f2410thooCoci9zae.add((GieBae8eiNge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(gieBae8eiNge, "method"));
            return this;
        }

        public chuYaeghie9C Jah0aiP1ki6y() {
            return new chuYaeghie9C(this);
        }

        public final thooCoci9zae kuedujio7Aev(Collection collection) {
            this.f2410thooCoci9zae.addAll(collection);
            return this;
        }

        public thooCoci9zae niah0Shohtha(String str) {
            this.f2408ieseir3Choge = (String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "name");
            return this;
        }

        public thooCoci9zae ohv5Shie7AeZ(Object obj) {
            this.f2409keiL1EiShomu = obj;
            return this;
        }
    }

    public chuYaeghie9C(thooCoci9zae thoococi9zae) {
        String str = thoococi9zae.f2408ieseir3Choge;
        this.f2405ieseir3Choge = str;
        ieheiQu9sho5(str, thoococi9zae.f2410thooCoci9zae);
        this.f2407thooCoci9zae = Collections.unmodifiableList(new ArrayList(thoococi9zae.f2410thooCoci9zae));
        this.f2406keiL1EiShomu = thoococi9zae.f2409keiL1EiShomu;
    }

    public static void ieheiQu9sho5(String str, Collection collection) {
        HashSet hashSet = new HashSet(collection.size());
        Iterator it = collection.iterator();
        while (it.hasNext()) {
            GieBae8eiNge gieBae8eiNge = (GieBae8eiNge) it.next();
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(gieBae8eiNge, "method");
            String ieheiQu9sho52 = gieBae8eiNge.ieheiQu9sho5();
            Vaig0nohza7i.ko7aiFeiqu3s.ruNgecai1pae(str.equals(ieheiQu9sho52), "service names %s != %s", ieheiQu9sho52, str);
            Vaig0nohza7i.ko7aiFeiqu3s.ko7aiFeiqu3s(hashSet.add(gieBae8eiNge.keiL1EiShomu()), "duplicate name %s", gieBae8eiNge.keiL1EiShomu());
        }
    }

    public static thooCoci9zae keiL1EiShomu(String str) {
        return new thooCoci9zae(str);
    }

    public Collection ieseir3Choge() {
        return this.f2407thooCoci9zae;
    }

    public String thooCoci9zae() {
        return this.f2405ieseir3Choge;
    }

    public String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("name", this.f2405ieseir3Choge).ieheiQu9sho5("schemaDescriptor", this.f2406keiL1EiShomu).ieheiQu9sho5("methods", this.f2407thooCoci9zae).ruNgecai1pae().toString();
    }

    public chuYaeghie9C(String str, Collection collection) {
        this(keiL1EiShomu(str).kuedujio7Aev((Collection) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(collection, "methods")));
    }
}
