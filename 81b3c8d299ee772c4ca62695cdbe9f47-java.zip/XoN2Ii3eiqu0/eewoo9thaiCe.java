package XoN2Ii3eiqu0;

import Aevahngah0ah.sheizaFeith4;
import XoN2Ii3eiqu0.ceiThoora6oc;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eewoo9thaiCe {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static eewoo9thaiCe f2417ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final Logger f2418keiL1EiShomu = Logger.getLogger(eewoo9thaiCe.class.getName());

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final Iterable f2419kuedujio7Aev = keiL1EiShomu();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final LinkedHashSet f2420ieseir3Choge = new LinkedHashSet();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final LinkedHashMap f2421thooCoci9zae = new LinkedHashMap();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge implements ceiThoora6oc.thooCoci9zae {
        @Override // XoN2Ii3eiqu0.ceiThoora6oc.thooCoci9zae
        /* renamed from: ieheiQu9sho5, reason: merged with bridge method [inline-methods] */
        public boolean thooCoci9zae(Ohah9Nai3tha ohah9Nai3tha) {
            return ohah9Nai3tha.ieheiQu9sho5();
        }

        @Override // XoN2Ii3eiqu0.ceiThoora6oc.thooCoci9zae
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public int ieseir3Choge(Ohah9Nai3tha ohah9Nai3tha) {
            return ohah9Nai3tha.keiL1EiShomu();
        }
    }

    public static List keiL1EiShomu() {
        ArrayList arrayList = new ArrayList();
        try {
            boolean z = sheizaFeith4.f1260thooCoci9zae;
            arrayList.add(sheizaFeith4.class);
        } catch (ClassNotFoundException e) {
            f2418keiL1EiShomu.log(Level.WARNING, "Unable to find pick-first LoadBalancer", (Throwable) e);
        }
        try {
            int i = uc6Iec4eomim.ahthoK6usais.f8087thooCoci9zae;
            arrayList.add(uc6Iec4eomim.ahthoK6usais.class);
        } catch (ClassNotFoundException e2) {
            f2418keiL1EiShomu.log(Level.FINE, "Unable to find round-robin LoadBalancer", (Throwable) e2);
        }
        return Collections.unmodifiableList(arrayList);
    }

    public static synchronized eewoo9thaiCe thooCoci9zae() {
        eewoo9thaiCe eewoo9thaice;
        synchronized (eewoo9thaiCe.class) {
            try {
                if (f2417ieheiQu9sho5 == null) {
                    List<Ohah9Nai3tha> kuedujio7Aev2 = ceiThoora6oc.kuedujio7Aev(Ohah9Nai3tha.class, f2419kuedujio7Aev, Ohah9Nai3tha.class.getClassLoader(), new ieseir3Choge());
                    f2417ieheiQu9sho5 = new eewoo9thaiCe();
                    for (Ohah9Nai3tha ohah9Nai3tha : kuedujio7Aev2) {
                        f2418keiL1EiShomu.fine("Service loader found " + ohah9Nai3tha);
                        f2417ieheiQu9sho5.ieseir3Choge(ohah9Nai3tha);
                    }
                    f2417ieheiQu9sho5.kuedujio7Aev();
                }
                eewoo9thaice = f2417ieheiQu9sho5;
            } catch (Throwable th) {
                throw th;
            }
        }
        return eewoo9thaice;
    }

    public synchronized Ohah9Nai3tha ieheiQu9sho5(String str) {
        return (Ohah9Nai3tha) this.f2421thooCoci9zae.get(Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "policy"));
    }

    public final synchronized void ieseir3Choge(Ohah9Nai3tha ohah9Nai3tha) {
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(ohah9Nai3tha.ieheiQu9sho5(), "isAvailable() returned false");
        this.f2420ieseir3Choge.add(ohah9Nai3tha);
    }

    public final synchronized void kuedujio7Aev() {
        try {
            this.f2421thooCoci9zae.clear();
            Iterator it = this.f2420ieseir3Choge.iterator();
            while (it.hasNext()) {
                Ohah9Nai3tha ohah9Nai3tha = (Ohah9Nai3tha) it.next();
                String thooCoci9zae2 = ohah9Nai3tha.thooCoci9zae();
                Ohah9Nai3tha ohah9Nai3tha2 = (Ohah9Nai3tha) this.f2421thooCoci9zae.get(thooCoci9zae2);
                if (ohah9Nai3tha2 != null && ohah9Nai3tha2.keiL1EiShomu() >= ohah9Nai3tha.keiL1EiShomu()) {
                }
                this.f2421thooCoci9zae.put(thooCoci9zae2, ohah9Nai3tha);
            }
        } catch (Throwable th) {
            throw th;
        }
    }
}
