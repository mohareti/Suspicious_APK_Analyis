package XoN2Ii3eiqu0;

import java.util.Iterator;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Meu0ophaeng1 {
    public static void ieseir3Choge(Xix0Vei5vo3j xix0Vei5vo3j) {
        Iterator it = oYe2ma2she1j.thooCoci9zae().ieseir3Choge().iterator();
        if (!it.hasNext()) {
            return;
        }
        Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(it.next());
        throw null;
    }

    public static boolean thooCoci9zae() {
        return oYe2ma2she1j.thooCoci9zae().keiL1EiShomu();
    }
}
