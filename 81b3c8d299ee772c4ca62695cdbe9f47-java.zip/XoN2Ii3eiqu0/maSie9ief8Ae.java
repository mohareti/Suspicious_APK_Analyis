package XoN2Ii3eiqu0;

import java.util.HashSet;
import java.util.Set;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class maSie9ief8Ae {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static maSie9ief8Ae f2502ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Object f2503ieseir3Choge = new Object();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Set f2505thooCoci9zae = new HashSet();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public soo9aeJ3kahb[] f2504keiL1EiShomu = new soo9aeJ3kahb[5];

    public static synchronized maSie9ief8Ae ieseir3Choge() {
        maSie9ief8Ae masie9ief8ae;
        synchronized (maSie9ief8Ae.class) {
            try {
                if (f2502ieheiQu9sho5 == null) {
                    f2502ieheiQu9sho5 = new maSie9ief8Ae();
                }
                masie9ief8ae = f2502ieheiQu9sho5;
            } catch (Throwable th) {
                throw th;
            }
        }
        return masie9ief8ae;
    }
}
