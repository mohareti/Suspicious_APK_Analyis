package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Wee2wi3pheim {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final GieBae8eiNge f2343ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final chie7aequa3C f2344thooCoci9zae;

    public Wee2wi3pheim(GieBae8eiNge gieBae8eiNge, chie7aequa3C chie7aequa3c) {
        this.f2343ieseir3Choge = gieBae8eiNge;
        this.f2344thooCoci9zae = chie7aequa3c;
    }

    public static Wee2wi3pheim ieseir3Choge(GieBae8eiNge gieBae8eiNge, chie7aequa3C chie7aequa3c) {
        return new Wee2wi3pheim(gieBae8eiNge, chie7aequa3c);
    }

    public GieBae8eiNge thooCoci9zae() {
        return this.f2343ieseir3Choge;
    }
}
