package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ieseir3Choge;
import XoN2Ii3eiqu0.ruNgecai1pae;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieph3Uteimah {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public int f2434ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2433thooCoci9zae = ieseir3Choge.keiL1EiShomu.ieseir3Choge("internal:health-checking-config");

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final thooCoci9zae.C0029thooCoci9zae f2431keiL1EiShomu = thooCoci9zae.C0029thooCoci9zae.thooCoci9zae("internal:health-check-consumer-listener");

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final thooCoci9zae.C0029thooCoci9zae f2430ieheiQu9sho5 = thooCoci9zae.C0029thooCoci9zae.keiL1EiShomu("internal:disable-subchannel-reconnect", Boolean.FALSE);

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2432kuedujio7Aev = ieseir3Choge.keiL1EiShomu.ieseir3Choge("internal:has-health-check-producer-listener");

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2428Aicohm8ieYoo = ieseir3Choge.keiL1EiShomu.ieseir3Choge("io.grpc.IS_PETIOLE_POLICY");

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final ruNgecai1pae f2429Jah0aiP1ki6y = new ieseir3Choge();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface Aicohm8ieYoo {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Jah0aiP1ki6y {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public static final Jah0aiP1ki6y f2435Aicohm8ieYoo = new Jah0aiP1ki6y(null, null, Xe6mangaekai.f2358kuedujio7Aev, false);

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final boolean f2436ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final ko7aiFeiqu3s f2437ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Xe6mangaekai f2438keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final String f2439kuedujio7Aev = null;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final ruNgecai1pae.ieseir3Choge f2440thooCoci9zae;

        public Jah0aiP1ki6y(ko7aiFeiqu3s ko7aifeiqu3s, ruNgecai1pae.ieseir3Choge ieseir3choge, Xe6mangaekai xe6mangaekai, boolean z) {
            this.f2437ieseir3Choge = ko7aifeiqu3s;
            this.f2440thooCoci9zae = ieseir3choge;
            this.f2438keiL1EiShomu = (Xe6mangaekai) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(xe6mangaekai, "status");
            this.f2436ieheiQu9sho5 = z;
        }

        public static Jah0aiP1ki6y Aicohm8ieYoo(Xe6mangaekai xe6mangaekai) {
            Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!xe6mangaekai.oYe2ma2she1j(), "drop status shouldn't be OK");
            return new Jah0aiP1ki6y(null, null, xe6mangaekai, true);
        }

        public static Jah0aiP1ki6y Jah0aiP1ki6y(Xe6mangaekai xe6mangaekai) {
            Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!xe6mangaekai.oYe2ma2she1j(), "error status shouldn't be OK");
            return new Jah0aiP1ki6y(null, null, xe6mangaekai, false);
        }

        public static Jah0aiP1ki6y ko7aiFeiqu3s(ko7aiFeiqu3s ko7aifeiqu3s, ruNgecai1pae.ieseir3Choge ieseir3choge) {
            return new Jah0aiP1ki6y((ko7aiFeiqu3s) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ko7aifeiqu3s, "subchannel"), ieseir3choge, Xe6mangaekai.f2358kuedujio7Aev, false);
        }

        public static Jah0aiP1ki6y niah0Shohtha() {
            return f2435Aicohm8ieYoo;
        }

        public static Jah0aiP1ki6y ohv5Shie7AeZ(ko7aiFeiqu3s ko7aifeiqu3s) {
            return ko7aiFeiqu3s(ko7aifeiqu3s, null);
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof Jah0aiP1ki6y)) {
                return false;
            }
            Jah0aiP1ki6y jah0aiP1ki6y = (Jah0aiP1ki6y) obj;
            if (!Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2437ieseir3Choge, jah0aiP1ki6y.f2437ieseir3Choge) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2438keiL1EiShomu, jah0aiP1ki6y.f2438keiL1EiShomu) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2440thooCoci9zae, jah0aiP1ki6y.f2440thooCoci9zae) || this.f2436ieheiQu9sho5 != jah0aiP1ki6y.f2436ieheiQu9sho5) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2437ieseir3Choge, this.f2438keiL1EiShomu, this.f2440thooCoci9zae, Boolean.valueOf(this.f2436ieheiQu9sho5));
        }

        public ko7aiFeiqu3s ieheiQu9sho5() {
            return this.f2437ieseir3Choge;
        }

        public String ieseir3Choge() {
            return this.f2439kuedujio7Aev;
        }

        public ruNgecai1pae.ieseir3Choge keiL1EiShomu() {
            return this.f2440thooCoci9zae;
        }

        public boolean kuedujio7Aev() {
            return this.f2436ieheiQu9sho5;
        }

        public Xe6mangaekai thooCoci9zae() {
            return this.f2438keiL1EiShomu;
        }

        public String toString() {
            return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("subchannel", this.f2437ieseir3Choge).ieheiQu9sho5("streamTracerFactory", this.f2440thooCoci9zae).ieheiQu9sho5("status", this.f2438keiL1EiShomu).kuedujio7Aev("drop", this.f2436ieheiQu9sho5).ieheiQu9sho5("authority-override", this.f2439kuedujio7Aev).toString();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ahthoK6usais {
        void ieseir3Choge(zoojiiKaht3i zoojiikaht3i);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieheiQu9sho5 extends ruNgecai1pae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Jah0aiP1ki6y f2441ieseir3Choge;

        public ieheiQu9sho5(Jah0aiP1ki6y jah0aiP1ki6y) {
            this.f2441ieseir3Choge = (Jah0aiP1ki6y) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(jah0aiP1ki6y, "result");
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof ieheiQu9sho5)) {
                return false;
            }
            return this.f2441ieseir3Choge.equals(((ieheiQu9sho5) obj).f2441ieseir3Choge);
        }

        public int hashCode() {
            return this.f2441ieseir3Choge.hashCode();
        }

        @Override // XoN2Ii3eiqu0.ieph3Uteimah.ruNgecai1pae
        public Jah0aiP1ki6y ieseir3Choge(niah0Shohtha niah0shohtha) {
            return this.f2441ieseir3Choge;
        }

        public String toString() {
            return "FixedResultPicker(" + this.f2441ieseir3Choge + ")";
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge extends ruNgecai1pae {
        @Override // XoN2Ii3eiqu0.ieph3Uteimah.ruNgecai1pae
        public Jah0aiP1ki6y ieseir3Choge(niah0Shohtha niah0shohtha) {
            return Jah0aiP1ki6y.niah0Shohtha();
        }

        public String toString() {
            return "EMPTY_PICKER";
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class keiL1EiShomu {
        public abstract ieph3Uteimah ieseir3Choge(kuedujio7Aev kuedujio7aev);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ko7aiFeiqu3s {
        public abstract void Aicohm8ieYoo();

        public abstract void Jah0aiP1ki6y();

        public abstract XoN2Ii3eiqu0.Aicohm8ieYoo ieheiQu9sho5();

        /* JADX WARN: Code restructure failed: missing block: B:4:0x000c, code lost:
        
            if (r0.size() == 1) goto L8;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public final eyei9eigh3Ie ieseir3Choge() {
            boolean z;
            List thooCoci9zae2 = thooCoci9zae();
            if (thooCoci9zae2 != null) {
                z = true;
            }
            z = false;
            Vaig0nohza7i.ko7aiFeiqu3s.oph9lahCh6uo(z, "%s does not have exactly one group", thooCoci9zae2);
            return (eyei9eigh3Ie) thooCoci9zae2.get(0);
        }

        public abstract XoN2Ii3eiqu0.ieseir3Choge keiL1EiShomu();

        public abstract Object kuedujio7Aev();

        public abstract void niah0Shohtha(ahthoK6usais ahthok6usais);

        public abstract void ohv5Shie7AeZ(List list);

        public abstract List thooCoci9zae();
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class kuedujio7Aev {
        public abstract void Aicohm8ieYoo(eetheKaevie8 eethekaevie8, ruNgecai1pae rungecai1pae);

        public abstract Niethookee4d ieheiQu9sho5();

        public abstract ko7aiFeiqu3s ieseir3Choge(thooCoci9zae thoococi9zae);

        public abstract ScheduledExecutorService keiL1EiShomu();

        public abstract void kuedujio7Aev();

        public abstract XoN2Ii3eiqu0.Aicohm8ieYoo thooCoci9zae();
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class niah0Shohtha {
        public abstract XoN2Ii3eiqu0.keiL1EiShomu ieseir3Choge();

        public abstract GieBae8eiNge keiL1EiShomu();

        public abstract ohx8eem3Ahph thooCoci9zae();
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ohv5Shie7AeZ {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final List f2442ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Object f2443keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final XoN2Ii3eiqu0.ieseir3Choge f2444thooCoci9zae;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class ieseir3Choge {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public List f2445ieseir3Choge;

            /* renamed from: keiL1EiShomu, reason: collision with root package name */
            public Object f2446keiL1EiShomu;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public XoN2Ii3eiqu0.ieseir3Choge f2447thooCoci9zae = XoN2Ii3eiqu0.ieseir3Choge.f2456keiL1EiShomu;

            public ieseir3Choge ieheiQu9sho5(Object obj) {
                this.f2446keiL1EiShomu = obj;
                return this;
            }

            public ohv5Shie7AeZ ieseir3Choge() {
                return new ohv5Shie7AeZ(this.f2445ieseir3Choge, this.f2447thooCoci9zae, this.f2446keiL1EiShomu, null);
            }

            public ieseir3Choge keiL1EiShomu(XoN2Ii3eiqu0.ieseir3Choge ieseir3choge) {
                this.f2447thooCoci9zae = ieseir3choge;
                return this;
            }

            public ieseir3Choge thooCoci9zae(List list) {
                this.f2445ieseir3Choge = list;
                return this;
            }
        }

        public ohv5Shie7AeZ(List list, XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, Object obj) {
            this.f2442ieseir3Choge = Collections.unmodifiableList(new ArrayList((Collection) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(list, "addresses")));
            this.f2444thooCoci9zae = (XoN2Ii3eiqu0.ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "attributes");
            this.f2443keiL1EiShomu = obj;
        }

        public static ieseir3Choge ieheiQu9sho5() {
            return new ieseir3Choge();
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof ohv5Shie7AeZ)) {
                return false;
            }
            ohv5Shie7AeZ ohv5shie7aez = (ohv5Shie7AeZ) obj;
            if (!Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2442ieseir3Choge, ohv5shie7aez.f2442ieseir3Choge) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2444thooCoci9zae, ohv5shie7aez.f2444thooCoci9zae) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2443keiL1EiShomu, ohv5shie7aez.f2443keiL1EiShomu)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2442ieseir3Choge, this.f2444thooCoci9zae, this.f2443keiL1EiShomu);
        }

        public List ieseir3Choge() {
            return this.f2442ieseir3Choge;
        }

        public Object keiL1EiShomu() {
            return this.f2443keiL1EiShomu;
        }

        public ieseir3Choge kuedujio7Aev() {
            return ieheiQu9sho5().thooCoci9zae(this.f2442ieseir3Choge).keiL1EiShomu(this.f2444thooCoci9zae).ieheiQu9sho5(this.f2443keiL1EiShomu);
        }

        public XoN2Ii3eiqu0.ieseir3Choge thooCoci9zae() {
            return this.f2444thooCoci9zae;
        }

        public String toString() {
            return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("addresses", this.f2442ieseir3Choge).ieheiQu9sho5("attributes", this.f2444thooCoci9zae).ieheiQu9sho5("loadBalancingPolicyConfig", this.f2443keiL1EiShomu).toString();
        }

        public /* synthetic */ ohv5Shie7AeZ(List list, XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, Object obj, ieseir3Choge ieseir3choge2) {
            this(list, ieseir3choge, obj);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ruNgecai1pae {
        public abstract Jah0aiP1ki6y ieseir3Choge(niah0Shohtha niah0shohtha);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final List f2448ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Object[][] f2449keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final XoN2Ii3eiqu0.ieseir3Choge f2450thooCoci9zae;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class ieseir3Choge {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public List f2451ieseir3Choge;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public XoN2Ii3eiqu0.ieseir3Choge f2453thooCoci9zae = XoN2Ii3eiqu0.ieseir3Choge.f2456keiL1EiShomu;

            /* renamed from: keiL1EiShomu, reason: collision with root package name */
            public Object[][] f2452keiL1EiShomu = (Object[][]) Array.newInstance((Class<?>) Object.class, 0, 2);

            public ieseir3Choge Aicohm8ieYoo(XoN2Ii3eiqu0.ieseir3Choge ieseir3choge) {
                this.f2453thooCoci9zae = (XoN2Ii3eiqu0.ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "attrs");
                return this;
            }

            public final ieseir3Choge ieheiQu9sho5(Object[][] objArr) {
                Object[][] objArr2 = (Object[][]) Array.newInstance((Class<?>) Object.class, objArr.length, 2);
                this.f2452keiL1EiShomu = objArr2;
                System.arraycopy(objArr, 0, objArr2, 0, objArr.length);
                return this;
            }

            public thooCoci9zae keiL1EiShomu() {
                return new thooCoci9zae(this.f2451ieseir3Choge, this.f2453thooCoci9zae, this.f2452keiL1EiShomu, null);
            }

            public ieseir3Choge kuedujio7Aev(List list) {
                Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!list.isEmpty(), "addrs is empty");
                this.f2451ieseir3Choge = Collections.unmodifiableList(new ArrayList(list));
                return this;
            }

            public ieseir3Choge thooCoci9zae(C0029thooCoci9zae c0029thooCoci9zae, Object obj) {
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0029thooCoci9zae, "key");
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "value");
                int i = 0;
                while (true) {
                    Object[][] objArr = this.f2452keiL1EiShomu;
                    if (i < objArr.length) {
                        if (c0029thooCoci9zae.equals(objArr[i][0])) {
                            break;
                        }
                        i++;
                    } else {
                        i = -1;
                        break;
                    }
                }
                if (i == -1) {
                    Object[][] objArr2 = (Object[][]) Array.newInstance((Class<?>) Object.class, this.f2452keiL1EiShomu.length + 1, 2);
                    Object[][] objArr3 = this.f2452keiL1EiShomu;
                    System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
                    this.f2452keiL1EiShomu = objArr2;
                    i = objArr2.length - 1;
                }
                Object[][] objArr4 = this.f2452keiL1EiShomu;
                Object[] objArr5 = new Object[2];
                objArr5[0] = c0029thooCoci9zae;
                objArr5[1] = obj;
                objArr4[i] = objArr5;
                return this;
            }
        }

        /* renamed from: XoN2Ii3eiqu0.ieph3Uteimah$thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class C0029thooCoci9zae {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public final String f2454ieseir3Choge;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public final Object f2455thooCoci9zae;

            public C0029thooCoci9zae(String str, Object obj) {
                this.f2454ieseir3Choge = str;
                this.f2455thooCoci9zae = obj;
            }

            public static C0029thooCoci9zae keiL1EiShomu(String str, Object obj) {
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "debugString");
                return new C0029thooCoci9zae(str, obj);
            }

            public static C0029thooCoci9zae thooCoci9zae(String str) {
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "debugString");
                return new C0029thooCoci9zae(str, null);
            }

            public String toString() {
                return this.f2454ieseir3Choge;
            }
        }

        public thooCoci9zae(List list, XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, Object[][] objArr) {
            this.f2448ieseir3Choge = (List) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(list, "addresses are not set");
            this.f2450thooCoci9zae = (XoN2Ii3eiqu0.ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "attrs");
            this.f2449keiL1EiShomu = (Object[][]) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(objArr, "customOptions");
        }

        public static ieseir3Choge ieheiQu9sho5() {
            return new ieseir3Choge();
        }

        public List ieseir3Choge() {
            return this.f2448ieseir3Choge;
        }

        public Object keiL1EiShomu(C0029thooCoci9zae c0029thooCoci9zae) {
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0029thooCoci9zae, "key");
            int i = 0;
            while (true) {
                Object[][] objArr = this.f2449keiL1EiShomu;
                if (i >= objArr.length) {
                    return c0029thooCoci9zae.f2455thooCoci9zae;
                }
                if (c0029thooCoci9zae.equals(objArr[i][0])) {
                    return this.f2449keiL1EiShomu[i][1];
                }
                i++;
            }
        }

        public ieseir3Choge kuedujio7Aev() {
            return ieheiQu9sho5().kuedujio7Aev(this.f2448ieseir3Choge).Aicohm8ieYoo(this.f2450thooCoci9zae).ieheiQu9sho5(this.f2449keiL1EiShomu);
        }

        public XoN2Ii3eiqu0.ieseir3Choge thooCoci9zae() {
            return this.f2450thooCoci9zae;
        }

        public String toString() {
            return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("addrs", this.f2448ieseir3Choge).ieheiQu9sho5("attrs", this.f2450thooCoci9zae).ieheiQu9sho5("customOptions", Arrays.deepToString(this.f2449keiL1EiShomu)).toString();
        }

        public /* synthetic */ thooCoci9zae(List list, XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, Object[][] objArr, ieseir3Choge ieseir3choge2) {
            this(list, ieseir3choge, objArr);
        }
    }

    public abstract void Aicohm8ieYoo();

    public void ieheiQu9sho5(ohv5Shie7AeZ ohv5shie7aez) {
        int i = this.f2434ieseir3Choge;
        this.f2434ieseir3Choge = i + 1;
        if (i == 0) {
            ieseir3Choge(ohv5shie7aez);
        }
        this.f2434ieseir3Choge = 0;
    }

    public Xe6mangaekai ieseir3Choge(ohv5Shie7AeZ ohv5shie7aez) {
        if (ohv5shie7aez.ieseir3Choge().isEmpty() && !thooCoci9zae()) {
            Xe6mangaekai zoojiiKaht3i2 = Xe6mangaekai.f2359laej2zeez5Ja.zoojiiKaht3i("NameResolver returned no usable address. addrs=" + ohv5shie7aez.ieseir3Choge() + ", attrs=" + ohv5shie7aez.thooCoci9zae());
            keiL1EiShomu(zoojiiKaht3i2);
            return zoojiiKaht3i2;
        }
        int i = this.f2434ieseir3Choge;
        this.f2434ieseir3Choge = i + 1;
        if (i == 0) {
            ieheiQu9sho5(ohv5shie7aez);
        }
        this.f2434ieseir3Choge = 0;
        return Xe6mangaekai.f2358kuedujio7Aev;
    }

    public abstract void keiL1EiShomu(Xe6mangaekai xe6mangaekai);

    public boolean thooCoci9zae() {
        return false;
    }

    public void kuedujio7Aev() {
    }
}
