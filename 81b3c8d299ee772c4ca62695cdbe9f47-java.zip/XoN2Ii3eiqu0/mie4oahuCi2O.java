package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.aac1eTaexee6;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class mie4oahuCi2O extends aac1eTaexee6.keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final Logger f2517ieseir3Choge = Logger.getLogger(mie4oahuCi2O.class.getName());

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ThreadLocal f2518thooCoci9zae = new ThreadLocal();

    @Override // XoN2Ii3eiqu0.aac1eTaexee6.keiL1EiShomu
    public aac1eTaexee6 ieseir3Choge() {
        aac1eTaexee6 aac1etaexee6 = (aac1eTaexee6) f2518thooCoci9zae.get();
        if (aac1etaexee6 == null) {
            return aac1eTaexee6.f2394keiL1EiShomu;
        }
        return aac1etaexee6;
    }

    @Override // XoN2Ii3eiqu0.aac1eTaexee6.keiL1EiShomu
    public aac1eTaexee6 keiL1EiShomu(aac1eTaexee6 aac1etaexee6) {
        aac1eTaexee6 ieseir3Choge2 = ieseir3Choge();
        f2518thooCoci9zae.set(aac1etaexee6);
        return ieseir3Choge2;
    }

    @Override // XoN2Ii3eiqu0.aac1eTaexee6.keiL1EiShomu
    public void thooCoci9zae(aac1eTaexee6 aac1etaexee6, aac1eTaexee6 aac1etaexee62) {
        ThreadLocal threadLocal;
        if (ieseir3Choge() != aac1etaexee6) {
            f2517ieseir3Choge.log(Level.SEVERE, "Context was not attached when detaching", new Throwable().fillInStackTrace());
        }
        if (aac1etaexee62 != aac1eTaexee6.f2394keiL1EiShomu) {
            threadLocal = f2518thooCoci9zae;
        } else {
            threadLocal = f2518thooCoci9zae;
            aac1etaexee62 = null;
        }
        threadLocal.set(aac1etaexee62);
    }
}
