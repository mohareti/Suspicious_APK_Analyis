package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.Jah0aiP1ki6y;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ko7aiFeiqu3s {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final Jah0aiP1ki6y f2500ieseir3Choge = new ieseir3Choge();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae extends ieheiQu9sho5 {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final ieheiQu9sho5 f2501ieseir3Choge;

        public thooCoci9zae(ieheiQu9sho5 ieheiqu9sho5, niah0Shohtha niah0shohtha) {
            this.f2501ieseir3Choge = ieheiqu9sho5;
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(niah0shohtha, "interceptor"));
        }

        @Override // XoN2Ii3eiqu0.ieheiQu9sho5
        public String ieseir3Choge() {
            return this.f2501ieseir3Choge.ieseir3Choge();
        }

        @Override // XoN2Ii3eiqu0.ieheiQu9sho5
        public Jah0aiP1ki6y thooCoci9zae(GieBae8eiNge gieBae8eiNge, keiL1EiShomu keil1eishomu) {
            throw null;
        }

        public /* synthetic */ thooCoci9zae(ieheiQu9sho5 ieheiqu9sho5, niah0Shohtha niah0shohtha, ohv5Shie7AeZ ohv5shie7aez) {
            this(ieheiqu9sho5, niah0shohtha);
        }
    }

    public static ieheiQu9sho5 ieseir3Choge(ieheiQu9sho5 ieheiqu9sho5, List list) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieheiqu9sho5, "channel");
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(it.next());
            ohv5Shie7AeZ ohv5shie7aez = null;
            ieheiqu9sho5 = new thooCoci9zae(ieheiqu9sho5, ohv5shie7aez, ohv5shie7aez);
        }
        return ieheiqu9sho5;
    }

    public static ieheiQu9sho5 thooCoci9zae(ieheiQu9sho5 ieheiqu9sho5, niah0Shohtha... niah0shohthaArr) {
        return ieseir3Choge(ieheiqu9sho5, Arrays.asList(niah0shohthaArr));
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge extends Jah0aiP1ki6y {
        @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
        public void thooCoci9zae() {
        }

        @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
        public void ieheiQu9sho5(Object obj) {
        }

        @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
        public void keiL1EiShomu(int i) {
        }

        @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
        public void ieseir3Choge(String str, Throwable th) {
        }

        @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
        public void kuedujio7Aev(Jah0aiP1ki6y.ieseir3Choge ieseir3choge, ohx8eem3Ahph ohx8eem3ahph) {
        }
    }
}
