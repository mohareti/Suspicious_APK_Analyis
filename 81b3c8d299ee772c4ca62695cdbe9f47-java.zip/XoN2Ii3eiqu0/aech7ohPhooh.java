package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class aech7ohPhooh extends Exception {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Xe6mangaekai f2398ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final ohx8eem3Ahph f2399kuedujio7Aev;

    public aech7ohPhooh(Xe6mangaekai xe6mangaekai) {
        this(xe6mangaekai, null);
    }

    public final Xe6mangaekai ieseir3Choge() {
        return this.f2398ieheiQu9sho5;
    }

    public final ohx8eem3Ahph thooCoci9zae() {
        return this.f2399kuedujio7Aev;
    }

    public aech7ohPhooh(Xe6mangaekai xe6mangaekai, ohx8eem3Ahph ohx8eem3ahph) {
        super(Xe6mangaekai.niah0Shohtha(xe6mangaekai), xe6mangaekai.mi5Iecheimie());
        this.f2398ieheiQu9sho5 = xe6mangaekai;
        this.f2399kuedujio7Aev = ohx8eem3ahph;
    }
}
