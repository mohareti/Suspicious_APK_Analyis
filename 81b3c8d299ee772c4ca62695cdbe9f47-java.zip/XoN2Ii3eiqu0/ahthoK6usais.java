package XoN2Ii3eiqu0;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface ahthoK6usais extends ruwiepo7ooVu, esohshee3Pau {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge implements ahthoK6usais {
        @Override // XoN2Ii3eiqu0.ruwiepo7ooVu, XoN2Ii3eiqu0.esohshee3Pau
        public String ieseir3Choge() {
            return "gzip";
        }

        @Override // XoN2Ii3eiqu0.ruwiepo7ooVu
        public OutputStream keiL1EiShomu(OutputStream outputStream) {
            return new GZIPOutputStream(outputStream);
        }

        @Override // XoN2Ii3eiqu0.esohshee3Pau
        public InputStream thooCoci9zae(InputStream inputStream) {
            return new GZIPInputStream(inputStream);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae implements ahthoK6usais {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final ahthoK6usais f2400ieseir3Choge = new thooCoci9zae();

        @Override // XoN2Ii3eiqu0.ruwiepo7ooVu, XoN2Ii3eiqu0.esohshee3Pau
        public String ieseir3Choge() {
            return "identity";
        }

        @Override // XoN2Ii3eiqu0.ruwiepo7ooVu
        public OutputStream keiL1EiShomu(OutputStream outputStream) {
            return outputStream;
        }

        @Override // XoN2Ii3eiqu0.esohshee3Pau
        public InputStream thooCoci9zae(InputStream inputStream) {
            return inputStream;
        }
    }
}
