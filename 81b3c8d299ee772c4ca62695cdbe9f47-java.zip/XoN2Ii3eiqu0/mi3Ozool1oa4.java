package XoN2Ii3eiqu0;

import java.util.concurrent.atomic.AtomicLong;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class mi3Ozool1oa4 {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final AtomicLong f2506ieheiQu9sho5 = new AtomicLong();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f2507ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final long f2508keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f2509thooCoci9zae;

    public mi3Ozool1oa4(String str, String str2, long j) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "typeName");
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!str.isEmpty(), "empty type");
        this.f2507ieseir3Choge = str;
        this.f2509thooCoci9zae = str2;
        this.f2508keiL1EiShomu = j;
    }

    public static mi3Ozool1oa4 ieseir3Choge(Class cls, String str) {
        return thooCoci9zae(keiL1EiShomu(cls), str);
    }

    public static String keiL1EiShomu(Class cls) {
        String simpleName = ((Class) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(cls, "type")).getSimpleName();
        if (!simpleName.isEmpty()) {
            return simpleName;
        }
        return cls.getName().substring(cls.getPackage().getName().length() + 1);
    }

    public static long kuedujio7Aev() {
        return f2506ieheiQu9sho5.incrementAndGet();
    }

    public static mi3Ozool1oa4 thooCoci9zae(String str, String str2) {
        return new mi3Ozool1oa4(str, str2, kuedujio7Aev());
    }

    public String Aicohm8ieYoo() {
        return this.f2507ieseir3Choge + "<" + this.f2508keiL1EiShomu + ">";
    }

    public long ieheiQu9sho5() {
        return this.f2508keiL1EiShomu;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Aicohm8ieYoo());
        if (this.f2509thooCoci9zae != null) {
            sb.append(": (");
            sb.append(this.f2509thooCoci9zae);
            sb.append(')');
        }
        return sb.toString();
    }
}
