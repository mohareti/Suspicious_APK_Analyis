package XoN2Ii3eiqu0;

import java.lang.Thread;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Niethookee4d implements Executor {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Thread.UncaughtExceptionHandler f2309ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final Queue f2310kuedujio7Aev = new ConcurrentLinkedQueue();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final AtomicReference f2308Aicohm8ieYoo = new AtomicReference();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieheiQu9sho5 {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final keiL1EiShomu f2311ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final ScheduledFuture f2312thooCoci9zae;

        public ieheiQu9sho5(keiL1EiShomu keil1eishomu, ScheduledFuture scheduledFuture) {
            this.f2311ieseir3Choge = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(keil1eishomu, "runnable");
            this.f2312thooCoci9zae = (ScheduledFuture) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(scheduledFuture, "future");
        }

        public void ieseir3Choge() {
            this.f2311ieseir3Choge.f2318kuedujio7Aev = true;
            this.f2312thooCoci9zae.cancel(false);
        }

        public boolean thooCoci9zae() {
            keiL1EiShomu keil1eishomu = this.f2311ieseir3Choge;
            if (!keil1eishomu.f2316Aicohm8ieYoo && !keil1eishomu.f2318kuedujio7Aev) {
                return true;
            }
            return false;
        }

        public /* synthetic */ ieheiQu9sho5(keiL1EiShomu keil1eishomu, ScheduledFuture scheduledFuture, ieseir3Choge ieseir3choge) {
            this(keil1eishomu, scheduledFuture);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements Runnable {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final /* synthetic */ keiL1EiShomu f2314ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final /* synthetic */ Runnable f2315kuedujio7Aev;

        public ieseir3Choge(keiL1EiShomu keil1eishomu, Runnable runnable) {
            this.f2314ieheiQu9sho5 = keil1eishomu;
            this.f2315kuedujio7Aev = runnable;
        }

        @Override // java.lang.Runnable
        public void run() {
            Niethookee4d.this.execute(this.f2314ieheiQu9sho5);
        }

        public String toString() {
            return this.f2315kuedujio7Aev.toString() + "(scheduled in SynchronizationContext)";
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu implements Runnable {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public boolean f2316Aicohm8ieYoo;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final Runnable f2317ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public boolean f2318kuedujio7Aev;

        public keiL1EiShomu(Runnable runnable) {
            this.f2317ieheiQu9sho5 = (Runnable) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(runnable, "task");
        }

        @Override // java.lang.Runnable
        public void run() {
            if (!this.f2318kuedujio7Aev) {
                this.f2316Aicohm8ieYoo = true;
                this.f2317ieheiQu9sho5.run();
            }
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class thooCoci9zae implements Runnable {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public final /* synthetic */ long f2319Aicohm8ieYoo;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final /* synthetic */ keiL1EiShomu f2321ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final /* synthetic */ Runnable f2322kuedujio7Aev;

        public thooCoci9zae(keiL1EiShomu keil1eishomu, Runnable runnable, long j) {
            this.f2321ieheiQu9sho5 = keil1eishomu;
            this.f2322kuedujio7Aev = runnable;
            this.f2319Aicohm8ieYoo = j;
        }

        @Override // java.lang.Runnable
        public void run() {
            Niethookee4d.this.execute(this.f2321ieheiQu9sho5);
        }

        public String toString() {
            return this.f2322kuedujio7Aev.toString() + "(scheduled in SynchronizationContext with delay of " + this.f2319Aicohm8ieYoo + ")";
        }
    }

    public Niethookee4d(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f2309ieheiQu9sho5 = (Thread.UncaughtExceptionHandler) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(uncaughtExceptionHandler, "uncaughtExceptionHandler");
    }

    @Override // java.util.concurrent.Executor
    public final void execute(Runnable runnable) {
        thooCoci9zae(runnable);
        ieseir3Choge();
    }

    public final ieheiQu9sho5 ieheiQu9sho5(Runnable runnable, long j, long j2, TimeUnit timeUnit, ScheduledExecutorService scheduledExecutorService) {
        keiL1EiShomu keil1eishomu = new keiL1EiShomu(runnable);
        return new ieheiQu9sho5(keil1eishomu, scheduledExecutorService.scheduleWithFixedDelay(new thooCoci9zae(keil1eishomu, runnable, j2), j, j2, timeUnit), null);
    }

    public final void ieseir3Choge() {
        while (eik1oetahvuF.ohx8eem3Ahph.ieseir3Choge(this.f2308Aicohm8ieYoo, null, Thread.currentThread())) {
            while (true) {
                try {
                    Runnable runnable = (Runnable) this.f2310kuedujio7Aev.poll();
                    if (runnable == null) {
                        break;
                    }
                    try {
                        runnable.run();
                    } catch (Throwable th) {
                        this.f2309ieheiQu9sho5.uncaughtException(Thread.currentThread(), th);
                    }
                } catch (Throwable th2) {
                    this.f2308Aicohm8ieYoo.set(null);
                    throw th2;
                }
            }
            this.f2308Aicohm8ieYoo.set(null);
            if (this.f2310kuedujio7Aev.isEmpty()) {
                return;
            }
        }
    }

    public final ieheiQu9sho5 keiL1EiShomu(Runnable runnable, long j, TimeUnit timeUnit, ScheduledExecutorService scheduledExecutorService) {
        keiL1EiShomu keil1eishomu = new keiL1EiShomu(runnable);
        return new ieheiQu9sho5(keil1eishomu, scheduledExecutorService.schedule(new ieseir3Choge(keil1eishomu, runnable), j, timeUnit), null);
    }

    public void kuedujio7Aev() {
        boolean z;
        if (Thread.currentThread() == this.f2308Aicohm8ieYoo.get()) {
            z = true;
        } else {
            z = false;
        }
        Vaig0nohza7i.ko7aiFeiqu3s.rojaiZ9aeRee(z, "Not called from the SynchronizationContext");
    }

    public final void thooCoci9zae(Runnable runnable) {
        this.f2310kuedujio7Aev.add((Runnable) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(runnable, "runnable is null"));
    }
}
