package XoN2Ii3eiqu0;

import Vaig0nohza7i.Aicohm8ieYoo;
import java.net.InetSocketAddress;
import java.net.SocketAddress;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Phae5ooG6hah extends aed3pie3Chah {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final String f2335Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final String f2336Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final SocketAddress f2337ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final InetSocketAddress f2338kuedujio7Aev;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public String f2339ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public SocketAddress f2340ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public String f2341keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public InetSocketAddress f2342thooCoci9zae;

        public thooCoci9zae() {
        }

        public thooCoci9zae ieheiQu9sho5(InetSocketAddress inetSocketAddress) {
            this.f2342thooCoci9zae = (InetSocketAddress) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(inetSocketAddress, "targetAddress");
            return this;
        }

        public Phae5ooG6hah ieseir3Choge() {
            return new Phae5ooG6hah(this.f2340ieseir3Choge, this.f2342thooCoci9zae, this.f2341keiL1EiShomu, this.f2339ieheiQu9sho5);
        }

        public thooCoci9zae keiL1EiShomu(SocketAddress socketAddress) {
            this.f2340ieseir3Choge = (SocketAddress) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(socketAddress, "proxyAddress");
            return this;
        }

        public thooCoci9zae kuedujio7Aev(String str) {
            this.f2341keiL1EiShomu = str;
            return this;
        }

        public thooCoci9zae thooCoci9zae(String str) {
            this.f2339ieheiQu9sho5 = str;
            return this;
        }
    }

    public Phae5ooG6hah(SocketAddress socketAddress, InetSocketAddress inetSocketAddress, String str, String str2) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(socketAddress, "proxyAddress");
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(inetSocketAddress, "targetAddress");
        if (socketAddress instanceof InetSocketAddress) {
            Vaig0nohza7i.ko7aiFeiqu3s.oph9lahCh6uo(!((InetSocketAddress) socketAddress).isUnresolved(), "The proxy address %s is not resolved", socketAddress);
        }
        this.f2337ieheiQu9sho5 = socketAddress;
        this.f2338kuedujio7Aev = inetSocketAddress;
        this.f2335Aicohm8ieYoo = str;
        this.f2336Jah0aiP1ki6y = str2;
    }

    public static thooCoci9zae kuedujio7Aev() {
        return new thooCoci9zae();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Phae5ooG6hah)) {
            return false;
        }
        Phae5ooG6hah phae5ooG6hah = (Phae5ooG6hah) obj;
        if (!Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2337ieheiQu9sho5, phae5ooG6hah.f2337ieheiQu9sho5) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2338kuedujio7Aev, phae5ooG6hah.f2338kuedujio7Aev) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2335Aicohm8ieYoo, phae5ooG6hah.f2335Aicohm8ieYoo) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2336Jah0aiP1ki6y, phae5ooG6hah.f2336Jah0aiP1ki6y)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2337ieheiQu9sho5, this.f2338kuedujio7Aev, this.f2335Aicohm8ieYoo, this.f2336Jah0aiP1ki6y);
    }

    public String ieheiQu9sho5() {
        return this.f2335Aicohm8ieYoo;
    }

    public String ieseir3Choge() {
        return this.f2336Jah0aiP1ki6y;
    }

    public InetSocketAddress keiL1EiShomu() {
        return this.f2338kuedujio7Aev;
    }

    public SocketAddress thooCoci9zae() {
        return this.f2337ieheiQu9sho5;
    }

    public String toString() {
        boolean z;
        Aicohm8ieYoo.thooCoci9zae ieheiQu9sho52 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("proxyAddr", this.f2337ieheiQu9sho5).ieheiQu9sho5("targetAddr", this.f2338kuedujio7Aev).ieheiQu9sho5("username", this.f2335Aicohm8ieYoo);
        if (this.f2336Jah0aiP1ki6y != null) {
            z = true;
        } else {
            z = false;
        }
        return ieheiQu9sho52.kuedujio7Aev("hasPassword", z).toString();
    }
}
