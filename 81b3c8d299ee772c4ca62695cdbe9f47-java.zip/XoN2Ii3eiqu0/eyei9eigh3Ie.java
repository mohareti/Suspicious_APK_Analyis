package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ieseir3Choge;
import java.net.SocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eyei9eigh3Ie {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2424ieheiQu9sho5 = ieseir3Choge.keiL1EiShomu.ieseir3Choge("io.grpc.EquivalentAddressGroup.ATTR_AUTHORITY_OVERRIDE");

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final List f2425ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final int f2426keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ieseir3Choge f2427thooCoci9zae;

    public eyei9eigh3Ie(SocketAddress socketAddress) {
        this(socketAddress, ieseir3Choge.f2456keiL1EiShomu);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof eyei9eigh3Ie)) {
            return false;
        }
        eyei9eigh3Ie eyei9eigh3ie = (eyei9eigh3Ie) obj;
        if (this.f2425ieseir3Choge.size() != eyei9eigh3ie.f2425ieseir3Choge.size()) {
            return false;
        }
        for (int i = 0; i < this.f2425ieseir3Choge.size(); i++) {
            if (!((SocketAddress) this.f2425ieseir3Choge.get(i)).equals(eyei9eigh3ie.f2425ieseir3Choge.get(i))) {
                return false;
            }
        }
        if (this.f2427thooCoci9zae.equals(eyei9eigh3ie.f2427thooCoci9zae)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return this.f2426keiL1EiShomu;
    }

    public List ieseir3Choge() {
        return this.f2425ieseir3Choge;
    }

    public ieseir3Choge thooCoci9zae() {
        return this.f2427thooCoci9zae;
    }

    public String toString() {
        return "[" + this.f2425ieseir3Choge + "/" + this.f2427thooCoci9zae + "]";
    }

    public eyei9eigh3Ie(SocketAddress socketAddress, ieseir3Choge ieseir3choge) {
        this(Collections.singletonList(socketAddress), ieseir3choge);
    }

    public eyei9eigh3Ie(List list, ieseir3Choge ieseir3choge) {
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!list.isEmpty(), "addrs is empty");
        List unmodifiableList = Collections.unmodifiableList(new ArrayList(list));
        this.f2425ieseir3Choge = unmodifiableList;
        this.f2427thooCoci9zae = (ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "attrs");
        this.f2426keiL1EiShomu = unmodifiableList.hashCode();
    }
}
