package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ceiThoora6oc;
import XoN2Ii3eiqu0.pho6iiPh5IaG;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Ohgahseiw0ni {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static Ohgahseiw0ni f2328Aicohm8ieYoo;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final Logger f2329kuedujio7Aev = Logger.getLogger(Ohgahseiw0ni.class.getName());

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final pho6iiPh5IaG.keiL1EiShomu f2331ieseir3Choge = new thooCoci9zae();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public String f2333thooCoci9zae = "unknown";

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final LinkedHashSet f2332keiL1EiShomu = new LinkedHashSet();

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public aeMuPhahFe7a.ahthoK6usais f2330ieheiQu9sho5 = aeMuPhahFe7a.ahthoK6usais.ohv5Shie7AeZ();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu implements ceiThoora6oc.thooCoci9zae {
        public keiL1EiShomu() {
        }

        @Override // XoN2Ii3eiqu0.ceiThoora6oc.thooCoci9zae
        /* renamed from: ieheiQu9sho5, reason: merged with bridge method [inline-methods] */
        public boolean thooCoci9zae(Eipeibai2Aa0 eipeibai2Aa0) {
            return eipeibai2Aa0.kuedujio7Aev();
        }

        @Override // XoN2Ii3eiqu0.ceiThoora6oc.thooCoci9zae
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public int ieseir3Choge(Eipeibai2Aa0 eipeibai2Aa0) {
            return eipeibai2Aa0.Aicohm8ieYoo();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public final class thooCoci9zae extends pho6iiPh5IaG.keiL1EiShomu {
        public thooCoci9zae() {
        }
    }

    public static List ieheiQu9sho5() {
        ArrayList arrayList = new ArrayList();
        try {
            boolean z = Aevahngah0ah.ahk3OhSh9Ree.f652ieseir3Choge;
            arrayList.add(Aevahngah0ah.ahk3OhSh9Ree.class);
        } catch (ClassNotFoundException e) {
            f2329kuedujio7Aev.log(Level.FINE, "Unable to find DNS NameResolver", (Throwable) e);
        }
        return Collections.unmodifiableList(arrayList);
    }

    public static synchronized Ohgahseiw0ni thooCoci9zae() {
        Ohgahseiw0ni ohgahseiw0ni;
        synchronized (Ohgahseiw0ni.class) {
            try {
                if (f2328Aicohm8ieYoo == null) {
                    List<Eipeibai2Aa0> kuedujio7Aev2 = ceiThoora6oc.kuedujio7Aev(Eipeibai2Aa0.class, ieheiQu9sho5(), Eipeibai2Aa0.class.getClassLoader(), new keiL1EiShomu());
                    if (kuedujio7Aev2.isEmpty()) {
                        f2329kuedujio7Aev.warning("No NameResolverProviders found via ServiceLoader, including for DNS. This is probably due to a broken build. If using ProGuard, check your configuration");
                    }
                    f2328Aicohm8ieYoo = new Ohgahseiw0ni();
                    for (Eipeibai2Aa0 eipeibai2Aa0 : kuedujio7Aev2) {
                        f2329kuedujio7Aev.fine("Service loader found " + eipeibai2Aa0);
                        f2328Aicohm8ieYoo.ieseir3Choge(eipeibai2Aa0);
                    }
                    f2328Aicohm8ieYoo.Jah0aiP1ki6y();
                }
                ohgahseiw0ni = f2328Aicohm8ieYoo;
            } catch (Throwable th) {
                throw th;
            }
        }
        return ohgahseiw0ni;
    }

    public synchronized Map Aicohm8ieYoo() {
        return this.f2330ieheiQu9sho5;
    }

    /* JADX WARN: Removed duplicated region for block: B:13:0x003e A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0010 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public final synchronized void Jah0aiP1ki6y() {
        try {
            HashMap hashMap = new HashMap();
            String str = "unknown";
            Iterator it = this.f2332keiL1EiShomu.iterator();
            int i = Integer.MIN_VALUE;
            while (it.hasNext()) {
                Eipeibai2Aa0 eipeibai2Aa0 = (Eipeibai2Aa0) it.next();
                String ieheiQu9sho52 = eipeibai2Aa0.ieheiQu9sho5();
                Eipeibai2Aa0 eipeibai2Aa02 = (Eipeibai2Aa0) hashMap.get(ieheiQu9sho52);
                if (eipeibai2Aa02 != null) {
                    if (eipeibai2Aa02.Aicohm8ieYoo() < eipeibai2Aa0.Aicohm8ieYoo()) {
                    }
                    if (i >= eipeibai2Aa0.Aicohm8ieYoo()) {
                        i = eipeibai2Aa0.Aicohm8ieYoo();
                        str = eipeibai2Aa0.ieheiQu9sho5();
                    }
                }
                hashMap.put(ieheiQu9sho52, eipeibai2Aa0);
                if (i >= eipeibai2Aa0.Aicohm8ieYoo()) {
                }
            }
            this.f2330ieheiQu9sho5 = aeMuPhahFe7a.ahthoK6usais.thooCoci9zae(hashMap);
            this.f2333thooCoci9zae = str;
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized void ieseir3Choge(Eipeibai2Aa0 eipeibai2Aa0) {
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(eipeibai2Aa0.kuedujio7Aev(), "isAvailable() returned false");
        this.f2332keiL1EiShomu.add(eipeibai2Aa0);
    }

    public synchronized String keiL1EiShomu() {
        return this.f2333thooCoci9zae;
    }

    public Eipeibai2Aa0 kuedujio7Aev(String str) {
        if (str == null) {
            return null;
        }
        return (Eipeibai2Aa0) Aicohm8ieYoo().get(str.toLowerCase(Locale.US));
    }
}
