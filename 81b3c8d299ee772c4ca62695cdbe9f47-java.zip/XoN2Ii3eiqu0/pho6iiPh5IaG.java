package XoN2Ii3eiqu0;

import Vaig0nohza7i.Aicohm8ieYoo;
import java.net.URI;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.ScheduledExecutorService;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class pho6iiPh5IaG {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class Aicohm8ieYoo {
        public abstract thooCoci9zae ieseir3Choge(Map map);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieheiQu9sho5 {
        public abstract Xe6mangaekai ieseir3Choge(kuedujio7Aev kuedujio7aev);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public final XoN2Ii3eiqu0.Aicohm8ieYoo f2544Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public final Executor f2545Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final Aicohm8ieYoo f2546ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final int f2547ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Niethookee4d f2548keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public final IdentityHashMap f2549ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final ScheduledExecutorService f2550kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public final String f2551niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public final iev8ainaiLae f2552ohv5Shie7AeZ;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final woizoTie7shi f2553thooCoci9zae;

        /* renamed from: XoN2Ii3eiqu0.pho6iiPh5IaG$ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class C0032ieseir3Choge {

            /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
            public XoN2Ii3eiqu0.Aicohm8ieYoo f2554Aicohm8ieYoo;

            /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
            public Executor f2555Jah0aiP1ki6y;

            /* renamed from: ieheiQu9sho5, reason: collision with root package name */
            public Aicohm8ieYoo f2556ieheiQu9sho5;

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public Integer f2557ieseir3Choge;

            /* renamed from: keiL1EiShomu, reason: collision with root package name */
            public Niethookee4d f2558keiL1EiShomu;

            /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
            public IdentityHashMap f2559ko7aiFeiqu3s;

            /* renamed from: kuedujio7Aev, reason: collision with root package name */
            public ScheduledExecutorService f2560kuedujio7Aev;

            /* renamed from: niah0Shohtha, reason: collision with root package name */
            public String f2561niah0Shohtha;

            /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
            public iev8ainaiLae f2562ohv5Shie7AeZ;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public woizoTie7shi f2563thooCoci9zae;

            public C0032ieseir3Choge AeJiPo4of6Sh(iev8ainaiLae iev8ainailae) {
                this.f2562ohv5Shie7AeZ = iev8ainailae;
                return this;
            }

            public C0032ieseir3Choge aac1eTaexee6(ScheduledExecutorService scheduledExecutorService) {
                this.f2560kuedujio7Aev = (ScheduledExecutorService) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(scheduledExecutorService);
                return this;
            }

            public C0032ieseir3Choge ahthoK6usais(thooCoci9zae thoococi9zae, Object obj) {
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(thoococi9zae, "key");
                Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "value");
                if (this.f2559ko7aiFeiqu3s == null) {
                    this.f2559ko7aiFeiqu3s = new IdentityHashMap();
                }
                this.f2559ko7aiFeiqu3s.put(thoococi9zae, obj);
                return this;
            }

            public C0032ieseir3Choge eetheKaevie8(String str) {
                this.f2561niah0Shohtha = str;
                return this;
            }

            public C0032ieseir3Choge laej2zeez5Ja(Aicohm8ieYoo aicohm8ieYoo) {
                this.f2556ieheiQu9sho5 = (Aicohm8ieYoo) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(aicohm8ieYoo);
                return this;
            }

            public C0032ieseir3Choge mi5Iecheimie(XoN2Ii3eiqu0.Aicohm8ieYoo aicohm8ieYoo) {
                this.f2554Aicohm8ieYoo = (XoN2Ii3eiqu0.Aicohm8ieYoo) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(aicohm8ieYoo);
                return this;
            }

            public C0032ieseir3Choge oYe2ma2she1j(Executor executor) {
                this.f2555Jah0aiP1ki6y = executor;
                return this;
            }

            public C0032ieseir3Choge rojaiZ9aeRee(Niethookee4d niethookee4d) {
                this.f2558keiL1EiShomu = (Niethookee4d) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(niethookee4d);
                return this;
            }

            public ieseir3Choge ruNgecai1pae() {
                return new ieseir3Choge(this, null);
            }

            public C0032ieseir3Choge ruwiepo7ooVu(int i) {
                this.f2557ieseir3Choge = Integer.valueOf(i);
                return this;
            }

            public C0032ieseir3Choge zoojiiKaht3i(woizoTie7shi woizotie7shi) {
                this.f2563thooCoci9zae = (woizoTie7shi) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(woizotie7shi);
                return this;
            }
        }

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class thooCoci9zae {
        }

        public ieseir3Choge(C0032ieseir3Choge c0032ieseir3Choge) {
            this.f2547ieseir3Choge = ((Integer) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0032ieseir3Choge.f2557ieseir3Choge, "defaultPort not set")).intValue();
            this.f2553thooCoci9zae = (woizoTie7shi) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0032ieseir3Choge.f2563thooCoci9zae, "proxyDetector not set");
            this.f2548keiL1EiShomu = (Niethookee4d) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0032ieseir3Choge.f2558keiL1EiShomu, "syncContext not set");
            this.f2546ieheiQu9sho5 = (Aicohm8ieYoo) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(c0032ieseir3Choge.f2556ieheiQu9sho5, "serviceConfigParser not set");
            this.f2550kuedujio7Aev = c0032ieseir3Choge.f2560kuedujio7Aev;
            this.f2544Aicohm8ieYoo = c0032ieseir3Choge.f2554Aicohm8ieYoo;
            this.f2545Jah0aiP1ki6y = c0032ieseir3Choge.f2555Jah0aiP1ki6y;
            this.f2551niah0Shohtha = c0032ieseir3Choge.f2561niah0Shohtha;
            this.f2552ohv5Shie7AeZ = c0032ieseir3Choge.f2562ohv5Shie7AeZ;
            this.f2549ko7aiFeiqu3s = pho6iiPh5IaG.thooCoci9zae(c0032ieseir3Choge.f2559ko7aiFeiqu3s);
        }

        public static C0032ieseir3Choge Jah0aiP1ki6y() {
            return new C0032ieseir3Choge();
        }

        public Niethookee4d Aicohm8ieYoo() {
            return this.f2548keiL1EiShomu;
        }

        public ScheduledExecutorService ieheiQu9sho5() {
            ScheduledExecutorService scheduledExecutorService = this.f2550kuedujio7Aev;
            if (scheduledExecutorService != null) {
                return scheduledExecutorService;
            }
            throw new IllegalStateException("ScheduledExecutorService not set in Builder");
        }

        public int ieseir3Choge() {
            return this.f2547ieseir3Choge;
        }

        public woizoTie7shi keiL1EiShomu() {
            return this.f2553thooCoci9zae;
        }

        public Aicohm8ieYoo kuedujio7Aev() {
            return this.f2546ieheiQu9sho5;
        }

        public Executor thooCoci9zae() {
            return this.f2545Jah0aiP1ki6y;
        }

        public String toString() {
            return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).thooCoci9zae("defaultPort", this.f2547ieseir3Choge).ieheiQu9sho5("proxyDetector", this.f2553thooCoci9zae).ieheiQu9sho5("syncContext", this.f2548keiL1EiShomu).ieheiQu9sho5("serviceConfigParser", this.f2546ieheiQu9sho5).ieheiQu9sho5("customArgs", this.f2549ko7aiFeiqu3s).ieheiQu9sho5("scheduledExecutorService", this.f2550kuedujio7Aev).ieheiQu9sho5("channelLogger", this.f2544Aicohm8ieYoo).ieheiQu9sho5("executor", this.f2545Jah0aiP1ki6y).ieheiQu9sho5("overrideAuthority", this.f2551niah0Shohtha).ieheiQu9sho5("metricRecorder", this.f2552ohv5Shie7AeZ).toString();
        }

        public /* synthetic */ ieseir3Choge(C0032ieseir3Choge c0032ieseir3Choge, doonge7ooYoe doonge7ooyoe) {
            this(c0032ieseir3Choge);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class keiL1EiShomu {
        public abstract String ieseir3Choge();

        public abstract pho6iiPh5IaG thooCoci9zae(URI uri, ieseir3Choge ieseir3choge);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Laez5aeCooSh f2564ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final thooCoci9zae f2565keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final XoN2Ii3eiqu0.ieseir3Choge f2566thooCoci9zae;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class ieseir3Choge {

            /* renamed from: keiL1EiShomu, reason: collision with root package name */
            public thooCoci9zae f2568keiL1EiShomu;

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public Laez5aeCooSh f2567ieseir3Choge = Laez5aeCooSh.thooCoci9zae(Collections.emptyList());

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public XoN2Ii3eiqu0.ieseir3Choge f2569thooCoci9zae = XoN2Ii3eiqu0.ieseir3Choge.f2456keiL1EiShomu;

            public ieseir3Choge ieheiQu9sho5(thooCoci9zae thoococi9zae) {
                this.f2568keiL1EiShomu = thoococi9zae;
                return this;
            }

            public kuedujio7Aev ieseir3Choge() {
                return new kuedujio7Aev(this.f2567ieseir3Choge, this.f2569thooCoci9zae, this.f2568keiL1EiShomu);
            }

            public ieseir3Choge keiL1EiShomu(XoN2Ii3eiqu0.ieseir3Choge ieseir3choge) {
                this.f2569thooCoci9zae = ieseir3choge;
                return this;
            }

            public ieseir3Choge thooCoci9zae(Laez5aeCooSh laez5aeCooSh) {
                this.f2567ieseir3Choge = (Laez5aeCooSh) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(laez5aeCooSh, "StatusOr addresses cannot be null.");
                return this;
            }
        }

        public kuedujio7Aev(Laez5aeCooSh laez5aeCooSh, XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, thooCoci9zae thoococi9zae) {
            this.f2564ieseir3Choge = laez5aeCooSh;
            this.f2566thooCoci9zae = (XoN2Ii3eiqu0.ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "attributes");
            this.f2565keiL1EiShomu = thoococi9zae;
        }

        public static ieseir3Choge ieheiQu9sho5() {
            return new ieseir3Choge();
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof kuedujio7Aev)) {
                return false;
            }
            kuedujio7Aev kuedujio7aev = (kuedujio7Aev) obj;
            if (!Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2564ieseir3Choge, kuedujio7aev.f2564ieseir3Choge) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2566thooCoci9zae, kuedujio7aev.f2566thooCoci9zae) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2565keiL1EiShomu, kuedujio7aev.f2565keiL1EiShomu)) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2564ieseir3Choge, this.f2566thooCoci9zae, this.f2565keiL1EiShomu);
        }

        public Laez5aeCooSh ieseir3Choge() {
            return this.f2564ieseir3Choge;
        }

        public thooCoci9zae keiL1EiShomu() {
            return this.f2565keiL1EiShomu;
        }

        public XoN2Ii3eiqu0.ieseir3Choge thooCoci9zae() {
            return this.f2566thooCoci9zae;
        }

        public String toString() {
            Aicohm8ieYoo.thooCoci9zae thooCoci9zae2 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this);
            thooCoci9zae2.ieheiQu9sho5("addressesOrError", this.f2564ieseir3Choge.toString());
            thooCoci9zae2.ieheiQu9sho5("attributes", this.f2566thooCoci9zae);
            thooCoci9zae2.ieheiQu9sho5("serviceConfigOrError", this.f2565keiL1EiShomu);
            return thooCoci9zae2.toString();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Xe6mangaekai f2570ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Object f2571thooCoci9zae;

        public thooCoci9zae(Xe6mangaekai xe6mangaekai) {
            this.f2571thooCoci9zae = null;
            this.f2570ieseir3Choge = (Xe6mangaekai) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(xe6mangaekai, "status");
            Vaig0nohza7i.ko7aiFeiqu3s.ko7aiFeiqu3s(!xe6mangaekai.oYe2ma2she1j(), "cannot use OK status: %s", xe6mangaekai);
        }

        public static thooCoci9zae ieseir3Choge(Object obj) {
            return new thooCoci9zae(obj);
        }

        public static thooCoci9zae thooCoci9zae(Xe6mangaekai xe6mangaekai) {
            return new thooCoci9zae(xe6mangaekai);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || thooCoci9zae.class != obj.getClass()) {
                return false;
            }
            thooCoci9zae thoococi9zae = (thooCoci9zae) obj;
            if (Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2570ieseir3Choge, thoococi9zae.f2570ieseir3Choge) && Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2571thooCoci9zae, thoococi9zae.f2571thooCoci9zae)) {
                return true;
            }
            return false;
        }

        public int hashCode() {
            return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2570ieseir3Choge, this.f2571thooCoci9zae);
        }

        public Xe6mangaekai ieheiQu9sho5() {
            return this.f2570ieseir3Choge;
        }

        public Object keiL1EiShomu() {
            return this.f2571thooCoci9zae;
        }

        public String toString() {
            Aicohm8ieYoo.thooCoci9zae thooCoci9zae2;
            String str;
            Object obj;
            if (this.f2571thooCoci9zae != null) {
                thooCoci9zae2 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this);
                str = "config";
                obj = this.f2571thooCoci9zae;
            } else {
                thooCoci9zae2 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this);
                str = "error";
                obj = this.f2570ieseir3Choge;
            }
            return thooCoci9zae2.ieheiQu9sho5(str, obj).toString();
        }

        public thooCoci9zae(Object obj) {
            this.f2571thooCoci9zae = Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "config");
            this.f2570ieseir3Choge = null;
        }
    }

    public static IdentityHashMap thooCoci9zae(IdentityHashMap identityHashMap) {
        if (identityHashMap != null) {
            return new IdentityHashMap(identityHashMap);
        }
        return null;
    }

    public abstract void Aicohm8ieYoo(ieheiQu9sho5 ieheiqu9sho5);

    public abstract void ieheiQu9sho5();

    public abstract String keiL1EiShomu();

    public abstract void kuedujio7Aev();
}
