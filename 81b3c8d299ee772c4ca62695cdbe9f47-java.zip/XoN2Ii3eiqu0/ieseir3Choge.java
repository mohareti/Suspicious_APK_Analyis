package XoN2Ii3eiqu0;

import java.util.IdentityHashMap;
import java.util.Map;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieseir3Choge {

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final ieseir3Choge f2456keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final IdentityHashMap f2457thooCoci9zae;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final IdentityHashMap f2458ieseir3Choge;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f2459ieseir3Choge;

        public keiL1EiShomu(String str) {
            this.f2459ieseir3Choge = str;
        }

        public static keiL1EiShomu ieseir3Choge(String str) {
            return new keiL1EiShomu(str);
        }

        public String toString() {
            return this.f2459ieseir3Choge;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public ieseir3Choge f2460ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public IdentityHashMap f2461thooCoci9zae;

        public thooCoci9zae(ieseir3Choge ieseir3choge) {
            this.f2460ieseir3Choge = ieseir3choge;
        }

        public thooCoci9zae ieheiQu9sho5(keiL1EiShomu keil1eishomu, Object obj) {
            thooCoci9zae(1).put(keil1eishomu, obj);
            return this;
        }

        public ieseir3Choge ieseir3Choge() {
            if (this.f2461thooCoci9zae != null) {
                for (Map.Entry entry : this.f2460ieseir3Choge.f2458ieseir3Choge.entrySet()) {
                    if (!this.f2461thooCoci9zae.containsKey(entry.getKey())) {
                        this.f2461thooCoci9zae.put((keiL1EiShomu) entry.getKey(), entry.getValue());
                    }
                }
                this.f2460ieseir3Choge = new ieseir3Choge(this.f2461thooCoci9zae);
                this.f2461thooCoci9zae = null;
            }
            return this.f2460ieseir3Choge;
        }

        public thooCoci9zae keiL1EiShomu(keiL1EiShomu keil1eishomu) {
            if (this.f2460ieseir3Choge.f2458ieseir3Choge.containsKey(keil1eishomu)) {
                IdentityHashMap identityHashMap = new IdentityHashMap(this.f2460ieseir3Choge.f2458ieseir3Choge);
                identityHashMap.remove(keil1eishomu);
                this.f2460ieseir3Choge = new ieseir3Choge(identityHashMap);
            }
            IdentityHashMap identityHashMap2 = this.f2461thooCoci9zae;
            if (identityHashMap2 != null) {
                identityHashMap2.remove(keil1eishomu);
            }
            return this;
        }

        public final IdentityHashMap thooCoci9zae(int i) {
            if (this.f2461thooCoci9zae == null) {
                this.f2461thooCoci9zae = new IdentityHashMap(i);
            }
            return this.f2461thooCoci9zae;
        }
    }

    static {
        IdentityHashMap identityHashMap = new IdentityHashMap();
        f2457thooCoci9zae = identityHashMap;
        f2456keiL1EiShomu = new ieseir3Choge(identityHashMap);
    }

    public ieseir3Choge(IdentityHashMap identityHashMap) {
        this.f2458ieseir3Choge = identityHashMap;
    }

    public static thooCoci9zae keiL1EiShomu() {
        return new thooCoci9zae();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || ieseir3Choge.class != obj.getClass()) {
            return false;
        }
        ieseir3Choge ieseir3choge = (ieseir3Choge) obj;
        if (this.f2458ieseir3Choge.size() != ieseir3choge.f2458ieseir3Choge.size()) {
            return false;
        }
        for (Map.Entry entry : this.f2458ieseir3Choge.entrySet()) {
            if (!ieseir3choge.f2458ieseir3Choge.containsKey(entry.getKey()) || !Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(entry.getValue(), ieseir3choge.f2458ieseir3Choge.get(entry.getKey()))) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 0;
        for (Map.Entry entry : this.f2458ieseir3Choge.entrySet()) {
            i += Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(entry.getKey(), entry.getValue());
        }
        return i;
    }

    public thooCoci9zae ieheiQu9sho5() {
        return new thooCoci9zae();
    }

    public Object thooCoci9zae(keiL1EiShomu keil1eishomu) {
        return this.f2458ieseir3Choge.get(keil1eishomu);
    }

    public String toString() {
        return this.f2458ieseir3Choge.toString();
    }
}
