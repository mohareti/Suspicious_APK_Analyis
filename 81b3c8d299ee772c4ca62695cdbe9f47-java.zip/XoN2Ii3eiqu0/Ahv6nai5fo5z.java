package XoN2Ii3eiqu0;

import java.time.Duration;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Ahv6nai5fo5z {
    public static long ieseir3Choge(Duration duration) {
        boolean isNegative;
        long nanos;
        try {
            nanos = duration.toNanos();
            return nanos;
        } catch (ArithmeticException unused) {
            isNegative = duration.isNegative();
            if (isNegative) {
                return Long.MIN_VALUE;
            }
            return Long.MAX_VALUE;
        }
    }
}
