package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Aebu8yohvea8 {
    public void Jah0aiP1ki6y(long j) {
    }

    public void ieheiQu9sho5(long j) {
    }

    public void ieseir3Choge(int i) {
    }

    public void keiL1EiShomu(long j) {
    }

    public void kuedujio7Aev(int i) {
    }

    public void niah0Shohtha(long j) {
    }

    public void ohv5Shie7AeZ(Xe6mangaekai xe6mangaekai) {
    }

    public void Aicohm8ieYoo(int i, long j, long j2) {
    }

    public void thooCoci9zae(int i, long j, long j2) {
    }
}
