package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ieph3Uteimah;
import XoN2Ii3eiqu0.pho6iiPh5IaG;
import java.util.Map;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Ohah9Nai3tha extends ieph3Uteimah.keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final pho6iiPh5IaG.thooCoci9zae f2327ieseir3Choge = pho6iiPh5IaG.thooCoci9zae.ieseir3Choge(new ieseir3Choge());

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {
        public String toString() {
            return "service config is unused";
        }
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    public abstract boolean ieheiQu9sho5();

    public abstract int keiL1EiShomu();

    public abstract pho6iiPh5IaG.thooCoci9zae kuedujio7Aev(Map map);

    public abstract String thooCoci9zae();

    public final String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("policy", thooCoci9zae()).thooCoci9zae("priority", keiL1EiShomu()).kuedujio7Aev("available", ieheiQu9sho5()).toString();
    }
}
