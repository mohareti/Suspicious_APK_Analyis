package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.keiL1EiShomu;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ruNgecai1pae extends Aebu8yohvea8 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final keiL1EiShomu.C0031keiL1EiShomu f2584ieseir3Choge = keiL1EiShomu.C0031keiL1EiShomu.thooCoci9zae("io.grpc.ClientStreamTracer.NAME_RESOLUTION_DELAYED");

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ruNgecai1pae ieseir3Choge(thooCoci9zae thoococi9zae, ohx8eem3Ahph ohx8eem3ahph);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final keiL1EiShomu f2585ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final boolean f2586keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final int f2587thooCoci9zae;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class ieseir3Choge {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public keiL1EiShomu f2588ieseir3Choge = keiL1EiShomu.f2475ahthoK6usais;

            /* renamed from: keiL1EiShomu, reason: collision with root package name */
            public boolean f2589keiL1EiShomu;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public int f2590thooCoci9zae;

            public ieseir3Choge ieheiQu9sho5(int i) {
                this.f2590thooCoci9zae = i;
                return this;
            }

            public thooCoci9zae ieseir3Choge() {
                return new thooCoci9zae(this.f2588ieseir3Choge, this.f2590thooCoci9zae, this.f2589keiL1EiShomu);
            }

            public ieseir3Choge keiL1EiShomu(boolean z) {
                this.f2589keiL1EiShomu = z;
                return this;
            }

            public ieseir3Choge thooCoci9zae(keiL1EiShomu keil1eishomu) {
                this.f2588ieseir3Choge = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(keil1eishomu, "callOptions cannot be null");
                return this;
            }
        }

        public thooCoci9zae(keiL1EiShomu keil1eishomu, int i, boolean z) {
            this.f2585ieseir3Choge = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(keil1eishomu, "callOptions");
            this.f2587thooCoci9zae = i;
            this.f2586keiL1EiShomu = z;
        }

        public static ieseir3Choge ieseir3Choge() {
            return new ieseir3Choge();
        }

        public String toString() {
            return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("callOptions", this.f2585ieseir3Choge).thooCoci9zae("previousAttempts", this.f2587thooCoci9zae).kuedujio7Aev("isTransparentRetry", this.f2586keiL1EiShomu).toString();
        }
    }

    public void ahthoK6usais(ohx8eem3Ahph ohx8eem3ahph) {
        ruNgecai1pae();
    }

    public void ko7aiFeiqu3s() {
    }

    public void ruNgecai1pae() {
    }

    public void ruwiepo7ooVu() {
    }

    public void mi5Iecheimie(ohx8eem3Ahph ohx8eem3ahph) {
    }

    public void AeJiPo4of6Sh(XoN2Ii3eiqu0.ieseir3Choge ieseir3choge, ohx8eem3Ahph ohx8eem3ahph) {
    }
}
