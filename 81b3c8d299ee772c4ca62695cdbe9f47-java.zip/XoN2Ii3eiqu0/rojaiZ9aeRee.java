package XoN2Ii3eiqu0;

import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class rojaiZ9aeRee implements Comparable {

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final thooCoci9zae f2577Jah0aiP1ki6y = new thooCoci9zae();

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public static final long f2578ko7aiFeiqu3s;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public static final long f2579niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final long f2580ohv5Shie7AeZ;

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public volatile boolean f2581Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final keiL1EiShomu f2582ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final long f2583kuedujio7Aev;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class keiL1EiShomu {
        public abstract long ieseir3Choge();
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae extends keiL1EiShomu {
        public thooCoci9zae() {
        }

        @Override // XoN2Ii3eiqu0.rojaiZ9aeRee.keiL1EiShomu
        public long ieseir3Choge() {
            return System.nanoTime();
        }
    }

    static {
        long nanos = TimeUnit.DAYS.toNanos(36500L);
        f2579niah0Shohtha = nanos;
        f2580ohv5Shie7AeZ = -nanos;
        f2578ko7aiFeiqu3s = TimeUnit.SECONDS.toNanos(1L);
    }

    public rojaiZ9aeRee(keiL1EiShomu keil1eishomu, long j, long j2, boolean z) {
        this.f2582ieheiQu9sho5 = keil1eishomu;
        long min = Math.min(f2579niah0Shohtha, Math.max(f2580ohv5Shie7AeZ, j2));
        this.f2583kuedujio7Aev = j + min;
        this.f2581Aicohm8ieYoo = z && min <= 0;
    }

    public static rojaiZ9aeRee Jah0aiP1ki6y(long j, TimeUnit timeUnit, keiL1EiShomu keil1eishomu) {
        niah0Shohtha(timeUnit, "units");
        return new rojaiZ9aeRee(keil1eishomu, timeUnit.toNanos(j), true);
    }

    public static rojaiZ9aeRee ieseir3Choge(long j, TimeUnit timeUnit) {
        return Jah0aiP1ki6y(j, timeUnit, f2577Jah0aiP1ki6y);
    }

    public static Object niah0Shohtha(Object obj, Object obj2) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException(String.valueOf(obj2));
    }

    public static keiL1EiShomu ruNgecai1pae() {
        return f2577Jah0aiP1ki6y;
    }

    public long AeJiPo4of6Sh(TimeUnit timeUnit) {
        long ieseir3Choge2 = this.f2582ieheiQu9sho5.ieseir3Choge();
        if (!this.f2581Aicohm8ieYoo && this.f2583kuedujio7Aev - ieseir3Choge2 <= 0) {
            this.f2581Aicohm8ieYoo = true;
        }
        return timeUnit.convert(this.f2583kuedujio7Aev - ieseir3Choge2, TimeUnit.NANOSECONDS);
    }

    public boolean ahthoK6usais(rojaiZ9aeRee rojaiz9aeree) {
        ohv5Shie7AeZ(rojaiz9aeree);
        if (this.f2583kuedujio7Aev - rojaiz9aeree.f2583kuedujio7Aev < 0) {
            return true;
        }
        return false;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof rojaiZ9aeRee)) {
            return false;
        }
        rojaiZ9aeRee rojaiz9aeree = (rojaiZ9aeRee) obj;
        keiL1EiShomu keil1eishomu = this.f2582ieheiQu9sho5;
        if (keil1eishomu != null ? keil1eishomu != rojaiz9aeree.f2582ieheiQu9sho5 : rojaiz9aeree.f2582ieheiQu9sho5 != null) {
            return false;
        }
        if (this.f2583kuedujio7Aev == rojaiz9aeree.f2583kuedujio7Aev) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return Arrays.asList(this.f2582ieheiQu9sho5, Long.valueOf(this.f2583kuedujio7Aev)).hashCode();
    }

    @Override // java.lang.Comparable
    /* renamed from: ko7aiFeiqu3s, reason: merged with bridge method [inline-methods] */
    public int compareTo(rojaiZ9aeRee rojaiz9aeree) {
        ohv5Shie7AeZ(rojaiz9aeree);
        long j = this.f2583kuedujio7Aev - rojaiz9aeree.f2583kuedujio7Aev;
        if (j < 0) {
            return -1;
        }
        if (j > 0) {
            return 1;
        }
        return 0;
    }

    public boolean mi5Iecheimie() {
        if (!this.f2581Aicohm8ieYoo) {
            if (this.f2583kuedujio7Aev - this.f2582ieheiQu9sho5.ieseir3Choge() <= 0) {
                this.f2581Aicohm8ieYoo = true;
            } else {
                return false;
            }
        }
        return true;
    }

    public final void ohv5Shie7AeZ(rojaiZ9aeRee rojaiz9aeree) {
        if (this.f2582ieheiQu9sho5 == rojaiz9aeree.f2582ieheiQu9sho5) {
            return;
        }
        throw new AssertionError("Tickers (" + this.f2582ieheiQu9sho5 + " and " + rojaiz9aeree.f2582ieheiQu9sho5 + ") don't match. Custom Ticker should only be used in tests!");
    }

    public rojaiZ9aeRee ruwiepo7ooVu(rojaiZ9aeRee rojaiz9aeree) {
        ohv5Shie7AeZ(rojaiz9aeree);
        if (ahthoK6usais(rojaiz9aeree)) {
            return this;
        }
        return rojaiz9aeree;
    }

    public String toString() {
        long AeJiPo4of6Sh2 = AeJiPo4of6Sh(TimeUnit.NANOSECONDS);
        long abs = Math.abs(AeJiPo4of6Sh2);
        long j = f2578ko7aiFeiqu3s;
        long j2 = abs / j;
        long abs2 = Math.abs(AeJiPo4of6Sh2) % j;
        StringBuilder sb = new StringBuilder();
        if (AeJiPo4of6Sh2 < 0) {
            sb.append('-');
        }
        sb.append(j2);
        if (abs2 > 0) {
            sb.append(String.format(Locale.US, ".%09d", Long.valueOf(abs2)));
        }
        sb.append("s from now");
        if (this.f2582ieheiQu9sho5 != f2577Jah0aiP1ki6y) {
            sb.append(" (ticker=" + this.f2582ieheiQu9sho5 + ")");
        }
        return sb.toString();
    }

    public rojaiZ9aeRee(keiL1EiShomu keil1eishomu, long j, boolean z) {
        this(keil1eishomu, keil1eishomu.ieseir3Choge(), j, z);
    }
}
