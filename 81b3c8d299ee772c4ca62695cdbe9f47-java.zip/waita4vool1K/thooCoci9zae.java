package waita4vool1K;

import org.conscrypt.BuildConfig;
import waita4vool1K.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class thooCoci9zae extends Aicohm8ieYoo {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f8282ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Aicohm8ieYoo.thooCoci9zae f8283keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final long f8284thooCoci9zae;

    /* renamed from: waita4vool1K.thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0117thooCoci9zae extends Aicohm8ieYoo.ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public String f8285ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public Aicohm8ieYoo.thooCoci9zae f8286keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Long f8287thooCoci9zae;

        @Override // waita4vool1K.Aicohm8ieYoo.ieseir3Choge
        public Aicohm8ieYoo.ieseir3Choge ieheiQu9sho5(long j) {
            this.f8287thooCoci9zae = Long.valueOf(j);
            return this;
        }

        @Override // waita4vool1K.Aicohm8ieYoo.ieseir3Choge
        public Aicohm8ieYoo ieseir3Choge() {
            Long l = this.f8287thooCoci9zae;
            String str = BuildConfig.FLAVOR;
            if (l == null) {
                str = BuildConfig.FLAVOR + " tokenExpirationTimestamp";
            }
            if (str.isEmpty()) {
                return new thooCoci9zae(this.f8285ieseir3Choge, this.f8287thooCoci9zae.longValue(), this.f8286keiL1EiShomu);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // waita4vool1K.Aicohm8ieYoo.ieseir3Choge
        public Aicohm8ieYoo.ieseir3Choge keiL1EiShomu(String str) {
            this.f8285ieseir3Choge = str;
            return this;
        }

        @Override // waita4vool1K.Aicohm8ieYoo.ieseir3Choge
        public Aicohm8ieYoo.ieseir3Choge thooCoci9zae(Aicohm8ieYoo.thooCoci9zae thoococi9zae) {
            this.f8286keiL1EiShomu = thoococi9zae;
            return this;
        }
    }

    public thooCoci9zae(String str, long j, Aicohm8ieYoo.thooCoci9zae thoococi9zae) {
        this.f8282ieseir3Choge = str;
        this.f8284thooCoci9zae = j;
        this.f8283keiL1EiShomu = thoococi9zae;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Aicohm8ieYoo)) {
            return false;
        }
        Aicohm8ieYoo aicohm8ieYoo = (Aicohm8ieYoo) obj;
        String str = this.f8282ieseir3Choge;
        if (str != null ? str.equals(aicohm8ieYoo.keiL1EiShomu()) : aicohm8ieYoo.keiL1EiShomu() == null) {
            if (this.f8284thooCoci9zae == aicohm8ieYoo.ieheiQu9sho5()) {
                Aicohm8ieYoo.thooCoci9zae thoococi9zae = this.f8283keiL1EiShomu;
                Aicohm8ieYoo.thooCoci9zae thooCoci9zae2 = aicohm8ieYoo.thooCoci9zae();
                if (thoococi9zae == null) {
                    if (thooCoci9zae2 == null) {
                        return true;
                    }
                } else if (thoococi9zae.equals(thooCoci9zae2)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        String str = this.f8282ieseir3Choge;
        int i = 0;
        if (str == null) {
            hashCode = 0;
        } else {
            hashCode = str.hashCode();
        }
        long j = this.f8284thooCoci9zae;
        int i2 = (((hashCode ^ 1000003) * 1000003) ^ ((int) (j ^ (j >>> 32)))) * 1000003;
        Aicohm8ieYoo.thooCoci9zae thoococi9zae = this.f8283keiL1EiShomu;
        if (thoococi9zae != null) {
            i = thoococi9zae.hashCode();
        }
        return i2 ^ i;
    }

    @Override // waita4vool1K.Aicohm8ieYoo
    public long ieheiQu9sho5() {
        return this.f8284thooCoci9zae;
    }

    @Override // waita4vool1K.Aicohm8ieYoo
    public String keiL1EiShomu() {
        return this.f8282ieseir3Choge;
    }

    @Override // waita4vool1K.Aicohm8ieYoo
    public Aicohm8ieYoo.thooCoci9zae thooCoci9zae() {
        return this.f8283keiL1EiShomu;
    }

    public String toString() {
        return "TokenResult{token=" + this.f8282ieseir3Choge + ", tokenExpirationTimestamp=" + this.f8284thooCoci9zae + ", responseCode=" + this.f8283keiL1EiShomu + "}";
    }
}
