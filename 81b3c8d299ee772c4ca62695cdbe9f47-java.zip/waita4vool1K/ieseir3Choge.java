package waita4vool1K;

import waita4vool1K.ieheiQu9sho5;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieseir3Choge extends ieheiQu9sho5 {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Aicohm8ieYoo f8262ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f8263ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f8264keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final ieheiQu9sho5.thooCoci9zae f8265kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f8266thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends ieheiQu9sho5.ieseir3Choge {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public Aicohm8ieYoo f8267ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public String f8268ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public String f8269keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public ieheiQu9sho5.thooCoci9zae f8270kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public String f8271thooCoci9zae;

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5.ieseir3Choge Aicohm8ieYoo(String str) {
            this.f8268ieseir3Choge = str;
            return this;
        }

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5.ieseir3Choge ieheiQu9sho5(String str) {
            this.f8269keiL1EiShomu = str;
            return this;
        }

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5 ieseir3Choge() {
            return new ieseir3Choge(this.f8268ieseir3Choge, this.f8271thooCoci9zae, this.f8269keiL1EiShomu, this.f8267ieheiQu9sho5, this.f8270kuedujio7Aev);
        }

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5.ieseir3Choge keiL1EiShomu(String str) {
            this.f8271thooCoci9zae = str;
            return this;
        }

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5.ieseir3Choge kuedujio7Aev(ieheiQu9sho5.thooCoci9zae thoococi9zae) {
            this.f8270kuedujio7Aev = thoococi9zae;
            return this;
        }

        @Override // waita4vool1K.ieheiQu9sho5.ieseir3Choge
        public ieheiQu9sho5.ieseir3Choge thooCoci9zae(Aicohm8ieYoo aicohm8ieYoo) {
            this.f8267ieheiQu9sho5 = aicohm8ieYoo;
            return this;
        }
    }

    public ieseir3Choge(String str, String str2, String str3, Aicohm8ieYoo aicohm8ieYoo, ieheiQu9sho5.thooCoci9zae thoococi9zae) {
        this.f8263ieseir3Choge = str;
        this.f8266thooCoci9zae = str2;
        this.f8264keiL1EiShomu = str3;
        this.f8262ieheiQu9sho5 = aicohm8ieYoo;
        this.f8265kuedujio7Aev = thoococi9zae;
    }

    @Override // waita4vool1K.ieheiQu9sho5
    public String Aicohm8ieYoo() {
        return this.f8263ieseir3Choge;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ieheiQu9sho5)) {
            return false;
        }
        ieheiQu9sho5 ieheiqu9sho5 = (ieheiQu9sho5) obj;
        String str = this.f8263ieseir3Choge;
        if (str != null ? str.equals(ieheiqu9sho5.Aicohm8ieYoo()) : ieheiqu9sho5.Aicohm8ieYoo() == null) {
            String str2 = this.f8266thooCoci9zae;
            if (str2 != null ? str2.equals(ieheiqu9sho5.keiL1EiShomu()) : ieheiqu9sho5.keiL1EiShomu() == null) {
                String str3 = this.f8264keiL1EiShomu;
                if (str3 != null ? str3.equals(ieheiqu9sho5.ieheiQu9sho5()) : ieheiqu9sho5.ieheiQu9sho5() == null) {
                    Aicohm8ieYoo aicohm8ieYoo = this.f8262ieheiQu9sho5;
                    if (aicohm8ieYoo != null ? aicohm8ieYoo.equals(ieheiqu9sho5.thooCoci9zae()) : ieheiqu9sho5.thooCoci9zae() == null) {
                        ieheiQu9sho5.thooCoci9zae thoococi9zae = this.f8265kuedujio7Aev;
                        ieheiQu9sho5.thooCoci9zae kuedujio7Aev2 = ieheiqu9sho5.kuedujio7Aev();
                        if (thoococi9zae == null) {
                            if (kuedujio7Aev2 == null) {
                                return true;
                            }
                        } else if (thoococi9zae.equals(kuedujio7Aev2)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        int hashCode2;
        int hashCode3;
        int hashCode4;
        String str = this.f8263ieseir3Choge;
        int i = 0;
        if (str == null) {
            hashCode = 0;
        } else {
            hashCode = str.hashCode();
        }
        int i2 = (hashCode ^ 1000003) * 1000003;
        String str2 = this.f8266thooCoci9zae;
        if (str2 == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = str2.hashCode();
        }
        int i3 = (i2 ^ hashCode2) * 1000003;
        String str3 = this.f8264keiL1EiShomu;
        if (str3 == null) {
            hashCode3 = 0;
        } else {
            hashCode3 = str3.hashCode();
        }
        int i4 = (i3 ^ hashCode3) * 1000003;
        Aicohm8ieYoo aicohm8ieYoo = this.f8262ieheiQu9sho5;
        if (aicohm8ieYoo == null) {
            hashCode4 = 0;
        } else {
            hashCode4 = aicohm8ieYoo.hashCode();
        }
        int i5 = (i4 ^ hashCode4) * 1000003;
        ieheiQu9sho5.thooCoci9zae thoococi9zae = this.f8265kuedujio7Aev;
        if (thoococi9zae != null) {
            i = thoococi9zae.hashCode();
        }
        return i5 ^ i;
    }

    @Override // waita4vool1K.ieheiQu9sho5
    public String ieheiQu9sho5() {
        return this.f8264keiL1EiShomu;
    }

    @Override // waita4vool1K.ieheiQu9sho5
    public String keiL1EiShomu() {
        return this.f8266thooCoci9zae;
    }

    @Override // waita4vool1K.ieheiQu9sho5
    public ieheiQu9sho5.thooCoci9zae kuedujio7Aev() {
        return this.f8265kuedujio7Aev;
    }

    @Override // waita4vool1K.ieheiQu9sho5
    public Aicohm8ieYoo thooCoci9zae() {
        return this.f8262ieheiQu9sho5;
    }

    public String toString() {
        return "InstallationResponse{uri=" + this.f8263ieseir3Choge + ", fid=" + this.f8266thooCoci9zae + ", refreshToken=" + this.f8264keiL1EiShomu + ", authToken=" + this.f8262ieheiQu9sho5 + ", responseCode=" + this.f8265kuedujio7Aev + "}";
    }
}
