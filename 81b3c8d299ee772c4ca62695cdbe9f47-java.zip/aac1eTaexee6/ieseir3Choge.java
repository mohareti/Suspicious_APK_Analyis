package aac1eTaexee6;

import android.view.Menu;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface ieseir3Choge extends Menu {
}
