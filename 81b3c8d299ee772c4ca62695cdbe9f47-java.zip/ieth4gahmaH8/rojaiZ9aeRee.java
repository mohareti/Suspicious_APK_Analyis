package ieth4gahmaH8;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface rojaiZ9aeRee {
}
