package ciyeeP1yuath;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import maR1iecoofoh.keiL1EiShomu;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ieseir3Choge {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public boolean f4150ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f4151ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final keiL1EiShomu f4152keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final SharedPreferences f4153thooCoci9zae;

    public ieseir3Choge(Context context, String str, keiL1EiShomu keil1eishomu) {
        Context ieseir3Choge2 = ieseir3Choge(context);
        this.f4151ieseir3Choge = ieseir3Choge2;
        this.f4153thooCoci9zae = ieseir3Choge2.getSharedPreferences("com.google.firebase.common.prefs:" + str, 0);
        this.f4152keiL1EiShomu = keil1eishomu;
        this.f4150ieheiQu9sho5 = keiL1EiShomu();
    }

    public static Context ieseir3Choge(Context context) {
        if (Build.VERSION.SDK_INT < 24) {
            return context;
        }
        return AeJiPo4of6Sh.ieseir3Choge.thooCoci9zae(context);
    }

    public final boolean ieheiQu9sho5() {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            PackageManager packageManager = this.f4151ieseir3Choge.getPackageManager();
            if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(this.f4151ieseir3Choge.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("firebase_data_collection_default_enabled")) {
                return applicationInfo.metaData.getBoolean("firebase_data_collection_default_enabled");
            }
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return true;
        }
    }

    public final boolean keiL1EiShomu() {
        if (this.f4153thooCoci9zae.contains("firebase_data_collection_default_enabled")) {
            return this.f4153thooCoci9zae.getBoolean("firebase_data_collection_default_enabled", true);
        }
        return ieheiQu9sho5();
    }

    public synchronized boolean thooCoci9zae() {
        return this.f4150ieheiQu9sho5;
    }
}
