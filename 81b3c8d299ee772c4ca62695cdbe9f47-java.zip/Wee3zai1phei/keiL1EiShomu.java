package Wee3zai1phei;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class keiL1EiShomu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f2179ieseir3Choge;

    public keiL1EiShomu(Context context) {
        this.f2179ieseir3Choge = context;
    }

    public PackageInfo ieheiQu9sho5(String str, int i) {
        return this.f2179ieseir3Choge.getPackageManager().getPackageInfo(str, i);
    }

    public int ieseir3Choge(String str, String str2) {
        return this.f2179ieseir3Choge.getPackageManager().checkPermission(str, str2);
    }

    public CharSequence keiL1EiShomu(String str) {
        Context context = this.f2179ieseir3Choge;
        return context.getPackageManager().getApplicationLabel(context.getPackageManager().getApplicationInfo(str, 0));
    }

    public ApplicationInfo thooCoci9zae(String str, int i) {
        return this.f2179ieseir3Choge.getPackageManager().getApplicationInfo(str, i);
    }
}
