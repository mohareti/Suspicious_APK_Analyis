package Wee3zai1phei;

import Id9uvaegh4ai.ohv5Shie7AeZ;
import android.content.Context;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class thooCoci9zae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static Context f2180ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static Boolean f2181thooCoci9zae;

    public static synchronized boolean ieseir3Choge(Context context) {
        Boolean bool;
        boolean isInstantApp;
        Boolean bool2;
        synchronized (thooCoci9zae.class) {
            Context applicationContext = context.getApplicationContext();
            Context context2 = f2180ieseir3Choge;
            if (context2 != null && (bool2 = f2181thooCoci9zae) != null && context2 == applicationContext) {
                return bool2.booleanValue();
            }
            f2181thooCoci9zae = null;
            if (ohv5Shie7AeZ.Jah0aiP1ki6y()) {
                isInstantApp = applicationContext.getPackageManager().isInstantApp();
                bool = Boolean.valueOf(isInstantApp);
            } else {
                try {
                    context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                    f2181thooCoci9zae = Boolean.TRUE;
                } catch (ClassNotFoundException unused) {
                    bool = Boolean.FALSE;
                }
                f2180ieseir3Choge = applicationContext;
                return f2181thooCoci9zae.booleanValue();
            }
            f2181thooCoci9zae = bool;
            f2180ieseir3Choge = applicationContext;
            return f2181thooCoci9zae.booleanValue();
        }
    }
}
