package aiboob5Ielei;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public interface ieseir3Choge {

    /* renamed from: aiboob5Ielei.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface InterfaceC0044ieseir3Choge {
    }

    void ieseir3Choge(InterfaceC0044ieseir3Choge interfaceC0044ieseir3Choge);
}
