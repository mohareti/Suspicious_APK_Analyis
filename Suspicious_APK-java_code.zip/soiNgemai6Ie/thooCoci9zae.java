package soiNgemai6Ie;

import android.os.Trace;
import android.util.Log;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class thooCoci9zae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static long f8018ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static Method f8019thooCoci9zae;

    public static boolean ieheiQu9sho5() {
        boolean isEnabled;
        try {
            if (f8019thooCoci9zae == null) {
                isEnabled = Trace.isEnabled();
                return isEnabled;
            }
        } catch (NoClassDefFoundError | NoSuchMethodError unused) {
        }
        return kuedujio7Aev();
    }

    public static void ieseir3Choge(String str) {
        keiL1EiShomu.ieseir3Choge(str);
    }

    public static void keiL1EiShomu(String str, Exception exc) {
        if (exc instanceof InvocationTargetException) {
            Throwable cause = exc.getCause();
            if (cause instanceof RuntimeException) {
                throw ((RuntimeException) cause);
            }
            throw new RuntimeException(cause);
        }
        Log.v("Trace", "Unable to call " + str + " via reflection", exc);
    }

    public static boolean kuedujio7Aev() {
        try {
            if (f8019thooCoci9zae == null) {
                f8018ieseir3Choge = Trace.class.getField("TRACE_TAG_APP").getLong(null);
                f8019thooCoci9zae = Trace.class.getMethod("isTagEnabled", Long.TYPE);
            }
            return ((Boolean) f8019thooCoci9zae.invoke(null, Long.valueOf(f8018ieseir3Choge))).booleanValue();
        } catch (Exception e) {
            keiL1EiShomu("isTagEnabled", e);
            return false;
        }
    }

    public static void thooCoci9zae() {
        keiL1EiShomu.thooCoci9zae();
    }
}
