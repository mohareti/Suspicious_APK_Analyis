package maSie9ief8Ae;

import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ko7aiFeiqu3s {
    public static ko7aiFeiqu3s ieseir3Choge(List list) {
        return new ieheiQu9sho5(list);
    }

    public static thai5ichoM2a.ieseir3Choge thooCoci9zae() {
        return new aiL2see7giec.ieheiQu9sho5().ko7aiFeiqu3s(thooCoci9zae.f7195ieseir3Choge).ruNgecai1pae(true).ohv5Shie7AeZ();
    }

    public abstract List keiL1EiShomu();
}
