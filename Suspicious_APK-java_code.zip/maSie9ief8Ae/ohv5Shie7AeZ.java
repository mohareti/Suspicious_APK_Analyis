package maSie9ief8Ae;

import maSie9ief8Ae.AeJiPo4of6Sh;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ohv5Shie7AeZ extends AeJiPo4of6Sh {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final AeJiPo4of6Sh.keiL1EiShomu f7187ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final AeJiPo4of6Sh.thooCoci9zae f7188thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends AeJiPo4of6Sh.ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public AeJiPo4of6Sh.keiL1EiShomu f7189ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public AeJiPo4of6Sh.thooCoci9zae f7190thooCoci9zae;

        @Override // maSie9ief8Ae.AeJiPo4of6Sh.ieseir3Choge
        public AeJiPo4of6Sh ieseir3Choge() {
            return new ohv5Shie7AeZ(this.f7189ieseir3Choge, this.f7190thooCoci9zae);
        }

        @Override // maSie9ief8Ae.AeJiPo4of6Sh.ieseir3Choge
        public AeJiPo4of6Sh.ieseir3Choge keiL1EiShomu(AeJiPo4of6Sh.keiL1EiShomu keil1eishomu) {
            this.f7189ieseir3Choge = keil1eishomu;
            return this;
        }

        @Override // maSie9ief8Ae.AeJiPo4of6Sh.ieseir3Choge
        public AeJiPo4of6Sh.ieseir3Choge thooCoci9zae(AeJiPo4of6Sh.thooCoci9zae thoococi9zae) {
            this.f7190thooCoci9zae = thoococi9zae;
            return this;
        }
    }

    public ohv5Shie7AeZ(AeJiPo4of6Sh.keiL1EiShomu keil1eishomu, AeJiPo4of6Sh.thooCoci9zae thoococi9zae) {
        this.f7187ieseir3Choge = keil1eishomu;
        this.f7188thooCoci9zae = thoococi9zae;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof AeJiPo4of6Sh)) {
            return false;
        }
        AeJiPo4of6Sh aeJiPo4of6Sh = (AeJiPo4of6Sh) obj;
        AeJiPo4of6Sh.keiL1EiShomu keil1eishomu = this.f7187ieseir3Choge;
        if (keil1eishomu != null ? keil1eishomu.equals(aeJiPo4of6Sh.keiL1EiShomu()) : aeJiPo4of6Sh.keiL1EiShomu() == null) {
            AeJiPo4of6Sh.thooCoci9zae thoococi9zae = this.f7188thooCoci9zae;
            AeJiPo4of6Sh.thooCoci9zae thooCoci9zae2 = aeJiPo4of6Sh.thooCoci9zae();
            if (thoococi9zae == null) {
                if (thooCoci9zae2 == null) {
                    return true;
                }
            } else if (thoococi9zae.equals(thooCoci9zae2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        AeJiPo4of6Sh.keiL1EiShomu keil1eishomu = this.f7187ieseir3Choge;
        int i = 0;
        if (keil1eishomu == null) {
            hashCode = 0;
        } else {
            hashCode = keil1eishomu.hashCode();
        }
        int i2 = (hashCode ^ 1000003) * 1000003;
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae = this.f7188thooCoci9zae;
        if (thoococi9zae != null) {
            i = thoococi9zae.hashCode();
        }
        return i2 ^ i;
    }

    @Override // maSie9ief8Ae.AeJiPo4of6Sh
    public AeJiPo4of6Sh.keiL1EiShomu keiL1EiShomu() {
        return this.f7187ieseir3Choge;
    }

    @Override // maSie9ief8Ae.AeJiPo4of6Sh
    public AeJiPo4of6Sh.thooCoci9zae thooCoci9zae() {
        return this.f7188thooCoci9zae;
    }

    public String toString() {
        return "NetworkConnectionInfo{networkType=" + this.f7187ieseir3Choge + ", mobileSubtype=" + this.f7188thooCoci9zae + "}";
    }
}
