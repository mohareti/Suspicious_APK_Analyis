package maSie9ief8Ae;

import java.util.List;
import maSie9ief8Ae.mi5Iecheimie;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Jah0aiP1ki6y extends mi5Iecheimie {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final List f7134Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final oYe2ma2she1j f7135Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Integer f7136ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final long f7137ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final ruNgecai1pae f7138keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final String f7139kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final long f7140thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends mi5Iecheimie.ieseir3Choge {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public List f7141Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public oYe2ma2she1j f7142Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public Integer f7143ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public Long f7144ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public ruNgecai1pae f7145keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public String f7146kuedujio7Aev;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Long f7147thooCoci9zae;

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge Aicohm8ieYoo(oYe2ma2she1j oye2ma2she1j) {
            this.f7142Jah0aiP1ki6y = oye2ma2she1j;
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge Jah0aiP1ki6y(long j) {
            this.f7144ieseir3Choge = Long.valueOf(j);
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge ieheiQu9sho5(Integer num) {
            this.f7143ieheiQu9sho5 = num;
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie ieseir3Choge() {
            Long l = this.f7144ieseir3Choge;
            String str = BuildConfig.FLAVOR;
            if (l == null) {
                str = BuildConfig.FLAVOR + " requestTimeMs";
            }
            if (this.f7147thooCoci9zae == null) {
                str = str + " requestUptimeMs";
            }
            if (str.isEmpty()) {
                return new Jah0aiP1ki6y(this.f7144ieseir3Choge.longValue(), this.f7147thooCoci9zae.longValue(), this.f7145keiL1EiShomu, this.f7143ieheiQu9sho5, this.f7146kuedujio7Aev, this.f7141Aicohm8ieYoo, this.f7142Jah0aiP1ki6y);
            }
            throw new IllegalStateException("Missing required properties:" + str);
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge keiL1EiShomu(List list) {
            this.f7141Aicohm8ieYoo = list;
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge kuedujio7Aev(String str) {
            this.f7146kuedujio7Aev = str;
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge niah0Shohtha(long j) {
            this.f7147thooCoci9zae = Long.valueOf(j);
            return this;
        }

        @Override // maSie9ief8Ae.mi5Iecheimie.ieseir3Choge
        public mi5Iecheimie.ieseir3Choge thooCoci9zae(ruNgecai1pae rungecai1pae) {
            this.f7145keiL1EiShomu = rungecai1pae;
            return this;
        }
    }

    public Jah0aiP1ki6y(long j, long j2, ruNgecai1pae rungecai1pae, Integer num, String str, List list, oYe2ma2she1j oye2ma2she1j) {
        this.f7137ieseir3Choge = j;
        this.f7140thooCoci9zae = j2;
        this.f7138keiL1EiShomu = rungecai1pae;
        this.f7136ieheiQu9sho5 = num;
        this.f7139kuedujio7Aev = str;
        this.f7134Aicohm8ieYoo = list;
        this.f7135Jah0aiP1ki6y = oye2ma2she1j;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public oYe2ma2she1j Aicohm8ieYoo() {
        return this.f7135Jah0aiP1ki6y;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public long Jah0aiP1ki6y() {
        return this.f7137ieseir3Choge;
    }

    public boolean equals(Object obj) {
        ruNgecai1pae rungecai1pae;
        Integer num;
        String str;
        List list;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof mi5Iecheimie)) {
            return false;
        }
        mi5Iecheimie mi5iecheimie = (mi5Iecheimie) obj;
        if (this.f7137ieseir3Choge == mi5iecheimie.Jah0aiP1ki6y() && this.f7140thooCoci9zae == mi5iecheimie.niah0Shohtha() && ((rungecai1pae = this.f7138keiL1EiShomu) != null ? rungecai1pae.equals(mi5iecheimie.thooCoci9zae()) : mi5iecheimie.thooCoci9zae() == null) && ((num = this.f7136ieheiQu9sho5) != null ? num.equals(mi5iecheimie.ieheiQu9sho5()) : mi5iecheimie.ieheiQu9sho5() == null) && ((str = this.f7139kuedujio7Aev) != null ? str.equals(mi5iecheimie.kuedujio7Aev()) : mi5iecheimie.kuedujio7Aev() == null) && ((list = this.f7134Aicohm8ieYoo) != null ? list.equals(mi5iecheimie.keiL1EiShomu()) : mi5iecheimie.keiL1EiShomu() == null)) {
            oYe2ma2she1j oye2ma2she1j = this.f7135Jah0aiP1ki6y;
            oYe2ma2she1j Aicohm8ieYoo2 = mi5iecheimie.Aicohm8ieYoo();
            if (oye2ma2she1j == null) {
                if (Aicohm8ieYoo2 == null) {
                    return true;
                }
            } else if (oye2ma2she1j.equals(Aicohm8ieYoo2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        int hashCode2;
        int hashCode3;
        int hashCode4;
        long j = this.f7137ieseir3Choge;
        long j2 = this.f7140thooCoci9zae;
        int i = (((((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j2 >>> 32) ^ j2))) * 1000003;
        ruNgecai1pae rungecai1pae = this.f7138keiL1EiShomu;
        int i2 = 0;
        if (rungecai1pae == null) {
            hashCode = 0;
        } else {
            hashCode = rungecai1pae.hashCode();
        }
        int i3 = (i ^ hashCode) * 1000003;
        Integer num = this.f7136ieheiQu9sho5;
        if (num == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = num.hashCode();
        }
        int i4 = (i3 ^ hashCode2) * 1000003;
        String str = this.f7139kuedujio7Aev;
        if (str == null) {
            hashCode3 = 0;
        } else {
            hashCode3 = str.hashCode();
        }
        int i5 = (i4 ^ hashCode3) * 1000003;
        List list = this.f7134Aicohm8ieYoo;
        if (list == null) {
            hashCode4 = 0;
        } else {
            hashCode4 = list.hashCode();
        }
        int i6 = (i5 ^ hashCode4) * 1000003;
        oYe2ma2she1j oye2ma2she1j = this.f7135Jah0aiP1ki6y;
        if (oye2ma2she1j != null) {
            i2 = oye2ma2she1j.hashCode();
        }
        return i6 ^ i2;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public Integer ieheiQu9sho5() {
        return this.f7136ieheiQu9sho5;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public List keiL1EiShomu() {
        return this.f7134Aicohm8ieYoo;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public String kuedujio7Aev() {
        return this.f7139kuedujio7Aev;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public long niah0Shohtha() {
        return this.f7140thooCoci9zae;
    }

    @Override // maSie9ief8Ae.mi5Iecheimie
    public ruNgecai1pae thooCoci9zae() {
        return this.f7138keiL1EiShomu;
    }

    public String toString() {
        return "LogRequest{requestTimeMs=" + this.f7137ieseir3Choge + ", requestUptimeMs=" + this.f7140thooCoci9zae + ", clientInfo=" + this.f7138keiL1EiShomu + ", logSource=" + this.f7136ieheiQu9sho5 + ", logSourceName=" + this.f7139kuedujio7Aev + ", logEvents=" + this.f7134Aicohm8ieYoo + ", qosTier=" + this.f7135Jah0aiP1ki6y + "}";
    }
}
