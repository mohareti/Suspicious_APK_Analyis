package maSie9ief8Ae;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class thooCoci9zae implements aeTh5ATha5te.ieseir3Choge {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final aeTh5ATha5te.ieseir3Choge f7195ieseir3Choge = new thooCoci9zae();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Aicohm8ieYoo implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final Aicohm8ieYoo f7196ieseir3Choge = new Aicohm8ieYoo();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7198thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("networkType");

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7197keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("mobileSubtype");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(AeJiPo4of6Sh aeJiPo4of6Sh, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.kuedujio7Aev(f7198thooCoci9zae, aeJiPo4of6Sh.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f7197keiL1EiShomu, aeJiPo4of6Sh.thooCoci9zae());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieheiQu9sho5 implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final ieheiQu9sho5 f7202ieseir3Choge = new ieheiQu9sho5();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7206thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("eventTimeMs");

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7203keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("eventCode");

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7201ieheiQu9sho5 = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("eventUptimeMs");

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7204kuedujio7Aev = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("sourceExtension");

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7199Aicohm8ieYoo = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("sourceExtensionJsonProto3");

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7200Jah0aiP1ki6y = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("timezoneOffsetSeconds");

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7205niah0Shohtha = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("networkConnectionInfo");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(ahthoK6usais ahthok6usais, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.ieheiQu9sho5(f7206thooCoci9zae, ahthok6usais.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f7203keiL1EiShomu, ahthok6usais.thooCoci9zae());
            aicohm8ieYoo.ieheiQu9sho5(f7201ieheiQu9sho5, ahthok6usais.ieheiQu9sho5());
            aicohm8ieYoo.kuedujio7Aev(f7204kuedujio7Aev, ahthok6usais.Aicohm8ieYoo());
            aicohm8ieYoo.kuedujio7Aev(f7199Aicohm8ieYoo, ahthok6usais.Jah0aiP1ki6y());
            aicohm8ieYoo.ieheiQu9sho5(f7200Jah0aiP1ki6y, ahthok6usais.niah0Shohtha());
            aicohm8ieYoo.kuedujio7Aev(f7205niah0Shohtha, ahthok6usais.kuedujio7Aev());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final ieseir3Choge f7211ieseir3Choge = new ieseir3Choge();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7219thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("sdkVersion");

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7212keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("model");

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7210ieheiQu9sho5 = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("hardware");

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7214kuedujio7Aev = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("device");

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7207Aicohm8ieYoo = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("product");

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7208Jah0aiP1ki6y = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("osBuild");

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7216niah0Shohtha = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("manufacturer");

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7217ohv5Shie7AeZ = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("fingerprint");

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7213ko7aiFeiqu3s = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("locale");

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7218ruNgecai1pae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("country");

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7209ahthoK6usais = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("mccMnc");

        /* renamed from: mi5Iecheimie, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7215mi5Iecheimie = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("applicationBuild");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(maSie9ief8Ae.ieseir3Choge ieseir3choge, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.kuedujio7Aev(f7219thooCoci9zae, ieseir3choge.mi5Iecheimie());
            aicohm8ieYoo.kuedujio7Aev(f7212keiL1EiShomu, ieseir3choge.ko7aiFeiqu3s());
            aicohm8ieYoo.kuedujio7Aev(f7210ieheiQu9sho5, ieseir3choge.Aicohm8ieYoo());
            aicohm8ieYoo.kuedujio7Aev(f7214kuedujio7Aev, ieseir3choge.ieheiQu9sho5());
            aicohm8ieYoo.kuedujio7Aev(f7207Aicohm8ieYoo, ieseir3choge.ahthoK6usais());
            aicohm8ieYoo.kuedujio7Aev(f7208Jah0aiP1ki6y, ieseir3choge.ruNgecai1pae());
            aicohm8ieYoo.kuedujio7Aev(f7216niah0Shohtha, ieseir3choge.niah0Shohtha());
            aicohm8ieYoo.kuedujio7Aev(f7217ohv5Shie7AeZ, ieseir3choge.kuedujio7Aev());
            aicohm8ieYoo.kuedujio7Aev(f7213ko7aiFeiqu3s, ieseir3choge.Jah0aiP1ki6y());
            aicohm8ieYoo.kuedujio7Aev(f7218ruNgecai1pae, ieseir3choge.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f7209ahthoK6usais, ieseir3choge.ohv5Shie7AeZ());
            aicohm8ieYoo.kuedujio7Aev(f7215mi5Iecheimie, ieseir3choge.thooCoci9zae());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final keiL1EiShomu f7220ieseir3Choge = new keiL1EiShomu();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7222thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("clientType");

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7221keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("androidClientInfo");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(ruNgecai1pae rungecai1pae, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.kuedujio7Aev(f7222thooCoci9zae, rungecai1pae.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f7221keiL1EiShomu, rungecai1pae.thooCoci9zae());
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class kuedujio7Aev implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final kuedujio7Aev f7226ieseir3Choge = new kuedujio7Aev();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7230thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("requestTimeMs");

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7227keiL1EiShomu = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("requestUptimeMs");

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7225ieheiQu9sho5 = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("clientInfo");

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7228kuedujio7Aev = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("logSource");

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7223Aicohm8ieYoo = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("logSourceName");

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7224Jah0aiP1ki6y = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("logEvent");

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7229niah0Shohtha = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("qosTier");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(mi5Iecheimie mi5iecheimie, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.ieheiQu9sho5(f7230thooCoci9zae, mi5iecheimie.Jah0aiP1ki6y());
            aicohm8ieYoo.ieheiQu9sho5(f7227keiL1EiShomu, mi5iecheimie.niah0Shohtha());
            aicohm8ieYoo.kuedujio7Aev(f7225ieheiQu9sho5, mi5iecheimie.thooCoci9zae());
            aicohm8ieYoo.kuedujio7Aev(f7228kuedujio7Aev, mi5iecheimie.ieheiQu9sho5());
            aicohm8ieYoo.kuedujio7Aev(f7223Aicohm8ieYoo, mi5iecheimie.kuedujio7Aev());
            aicohm8ieYoo.kuedujio7Aev(f7224Jah0aiP1ki6y, mi5iecheimie.keiL1EiShomu());
            aicohm8ieYoo.kuedujio7Aev(f7229niah0Shohtha, mi5iecheimie.Aicohm8ieYoo());
        }
    }

    /* renamed from: maSie9ief8Ae.thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class C0099thooCoci9zae implements thai5ichoM2a.kuedujio7Aev {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final C0099thooCoci9zae f7231ieseir3Choge = new C0099thooCoci9zae();

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public static final thai5ichoM2a.ieheiQu9sho5 f7232thooCoci9zae = thai5ichoM2a.ieheiQu9sho5.ieheiQu9sho5("logRequest");

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(ko7aiFeiqu3s ko7aifeiqu3s, thai5ichoM2a.Aicohm8ieYoo aicohm8ieYoo) {
            aicohm8ieYoo.kuedujio7Aev(f7232thooCoci9zae, ko7aifeiqu3s.keiL1EiShomu());
        }
    }

    @Override // aeTh5ATha5te.ieseir3Choge
    public void ieseir3Choge(aeTh5ATha5te.thooCoci9zae thoococi9zae) {
        C0099thooCoci9zae c0099thooCoci9zae = C0099thooCoci9zae.f7231ieseir3Choge;
        thoococi9zae.ieseir3Choge(ko7aiFeiqu3s.class, c0099thooCoci9zae);
        thoococi9zae.ieseir3Choge(maSie9ief8Ae.ieheiQu9sho5.class, c0099thooCoci9zae);
        kuedujio7Aev kuedujio7aev = kuedujio7Aev.f7226ieseir3Choge;
        thoococi9zae.ieseir3Choge(mi5Iecheimie.class, kuedujio7aev);
        thoococi9zae.ieseir3Choge(Jah0aiP1ki6y.class, kuedujio7aev);
        keiL1EiShomu keil1eishomu = keiL1EiShomu.f7220ieseir3Choge;
        thoococi9zae.ieseir3Choge(ruNgecai1pae.class, keil1eishomu);
        thoococi9zae.ieseir3Choge(maSie9ief8Ae.kuedujio7Aev.class, keil1eishomu);
        ieseir3Choge ieseir3choge = ieseir3Choge.f7211ieseir3Choge;
        thoococi9zae.ieseir3Choge(maSie9ief8Ae.ieseir3Choge.class, ieseir3choge);
        thoococi9zae.ieseir3Choge(maSie9ief8Ae.keiL1EiShomu.class, ieseir3choge);
        ieheiQu9sho5 ieheiqu9sho5 = ieheiQu9sho5.f7202ieseir3Choge;
        thoococi9zae.ieseir3Choge(ahthoK6usais.class, ieheiqu9sho5);
        thoococi9zae.ieseir3Choge(maSie9ief8Ae.Aicohm8ieYoo.class, ieheiqu9sho5);
        Aicohm8ieYoo aicohm8ieYoo = Aicohm8ieYoo.f7196ieseir3Choge;
        thoococi9zae.ieseir3Choge(AeJiPo4of6Sh.class, aicohm8ieYoo);
        thoococi9zae.ieseir3Choge(ohv5Shie7AeZ.class, aicohm8ieYoo);
    }
}
