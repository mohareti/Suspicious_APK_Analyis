package maSie9ief8Ae;

import android.util.SparseArray;
import maSie9ief8Ae.ohv5Shie7AeZ;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class AeJiPo4of6Sh {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract AeJiPo4of6Sh ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(keiL1EiShomu keil1eishomu);

        public abstract ieseir3Choge thooCoci9zae(thooCoci9zae thoococi9zae);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum keiL1EiShomu {
        MOBILE(0),
        WIFI(1),
        MOBILE_MMS(2),
        MOBILE_SUPL(3),
        MOBILE_DUN(4),
        MOBILE_HIPRI(5),
        WIMAX(6),
        BLUETOOTH(7),
        DUMMY(8),
        ETHERNET(9),
        MOBILE_FOTA(10),
        MOBILE_IMS(11),
        MOBILE_CBS(12),
        WIFI_P2P(13),
        MOBILE_IA(14),
        MOBILE_EMERGENCY(15),
        PROXY(16),
        VPN(17),
        NONE(-1);


        /* renamed from: ohthie9thieG, reason: collision with root package name */
        public static final SparseArray f7088ohthie9thieG;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final int f7095ieheiQu9sho5;

        static {
            keiL1EiShomu keil1eishomu = MOBILE;
            keiL1EiShomu keil1eishomu2 = WIFI;
            keiL1EiShomu keil1eishomu3 = MOBILE_MMS;
            keiL1EiShomu keil1eishomu4 = MOBILE_SUPL;
            keiL1EiShomu keil1eishomu5 = MOBILE_DUN;
            keiL1EiShomu keil1eishomu6 = MOBILE_HIPRI;
            keiL1EiShomu keil1eishomu7 = WIMAX;
            keiL1EiShomu keil1eishomu8 = BLUETOOTH;
            keiL1EiShomu keil1eishomu9 = DUMMY;
            keiL1EiShomu keil1eishomu10 = ETHERNET;
            keiL1EiShomu keil1eishomu11 = MOBILE_FOTA;
            keiL1EiShomu keil1eishomu12 = MOBILE_IMS;
            keiL1EiShomu keil1eishomu13 = MOBILE_CBS;
            keiL1EiShomu keil1eishomu14 = WIFI_P2P;
            keiL1EiShomu keil1eishomu15 = MOBILE_IA;
            keiL1EiShomu keil1eishomu16 = MOBILE_EMERGENCY;
            keiL1EiShomu keil1eishomu17 = PROXY;
            keiL1EiShomu keil1eishomu18 = VPN;
            keiL1EiShomu keil1eishomu19 = NONE;
            SparseArray sparseArray = new SparseArray();
            f7088ohthie9thieG = sparseArray;
            sparseArray.put(0, keil1eishomu);
            sparseArray.put(1, keil1eishomu2);
            sparseArray.put(2, keil1eishomu3);
            sparseArray.put(3, keil1eishomu4);
            sparseArray.put(4, keil1eishomu5);
            sparseArray.put(5, keil1eishomu6);
            sparseArray.put(6, keil1eishomu7);
            sparseArray.put(7, keil1eishomu8);
            sparseArray.put(8, keil1eishomu9);
            sparseArray.put(9, keil1eishomu10);
            sparseArray.put(10, keil1eishomu11);
            sparseArray.put(11, keil1eishomu12);
            sparseArray.put(12, keil1eishomu13);
            sparseArray.put(13, keil1eishomu14);
            sparseArray.put(14, keil1eishomu15);
            sparseArray.put(15, keil1eishomu16);
            sparseArray.put(16, keil1eishomu17);
            sparseArray.put(17, keil1eishomu18);
            sparseArray.put(-1, keil1eishomu19);
        }

        keiL1EiShomu(int i) {
            this.f7095ieheiQu9sho5 = i;
        }

        public static keiL1EiShomu ieseir3Choge(int i) {
            return (keiL1EiShomu) f7088ohthie9thieG.get(i);
        }

        public int Jah0aiP1ki6y() {
            return this.f7095ieheiQu9sho5;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        UNKNOWN_MOBILE_SUBTYPE(0),
        GPRS(1),
        EDGE(2),
        UMTS(3),
        CDMA(4),
        EVDO_0(5),
        EVDO_A(6),
        RTT(7),
        HSDPA(8),
        HSUPA(9),
        HSPA(10),
        IDEN(11),
        EVDO_B(12),
        LTE(13),
        EHRPD(14),
        HSPAP(15),
        GSM(16),
        TD_SCDMA(17),
        IWLAN(18),
        LTE_CA(19),
        COMBINED(100);


        /* renamed from: Idohhaimaes0, reason: collision with root package name */
        public static final SparseArray f7098Idohhaimaes0;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final int f7119ieheiQu9sho5;

        static {
            thooCoci9zae thoococi9zae = UNKNOWN_MOBILE_SUBTYPE;
            thooCoci9zae thoococi9zae2 = GPRS;
            thooCoci9zae thoococi9zae3 = EDGE;
            thooCoci9zae thoococi9zae4 = UMTS;
            thooCoci9zae thoococi9zae5 = CDMA;
            thooCoci9zae thoococi9zae6 = EVDO_0;
            thooCoci9zae thoococi9zae7 = EVDO_A;
            thooCoci9zae thoococi9zae8 = RTT;
            thooCoci9zae thoococi9zae9 = HSDPA;
            thooCoci9zae thoococi9zae10 = HSUPA;
            thooCoci9zae thoococi9zae11 = HSPA;
            thooCoci9zae thoococi9zae12 = IDEN;
            thooCoci9zae thoococi9zae13 = EVDO_B;
            thooCoci9zae thoococi9zae14 = LTE;
            thooCoci9zae thoococi9zae15 = EHRPD;
            thooCoci9zae thoococi9zae16 = HSPAP;
            thooCoci9zae thoococi9zae17 = GSM;
            thooCoci9zae thoococi9zae18 = TD_SCDMA;
            thooCoci9zae thoococi9zae19 = IWLAN;
            thooCoci9zae thoococi9zae20 = LTE_CA;
            SparseArray sparseArray = new SparseArray();
            f7098Idohhaimaes0 = sparseArray;
            sparseArray.put(0, thoococi9zae);
            sparseArray.put(1, thoococi9zae2);
            sparseArray.put(2, thoococi9zae3);
            sparseArray.put(3, thoococi9zae4);
            sparseArray.put(4, thoococi9zae5);
            sparseArray.put(5, thoococi9zae6);
            sparseArray.put(6, thoococi9zae7);
            sparseArray.put(7, thoococi9zae8);
            sparseArray.put(8, thoococi9zae9);
            sparseArray.put(9, thoococi9zae10);
            sparseArray.put(10, thoococi9zae11);
            sparseArray.put(11, thoococi9zae12);
            sparseArray.put(12, thoococi9zae13);
            sparseArray.put(13, thoococi9zae14);
            sparseArray.put(14, thoococi9zae15);
            sparseArray.put(15, thoococi9zae16);
            sparseArray.put(16, thoococi9zae17);
            sparseArray.put(17, thoococi9zae18);
            sparseArray.put(18, thoococi9zae19);
            sparseArray.put(19, thoococi9zae20);
        }

        thooCoci9zae(int i) {
            this.f7119ieheiQu9sho5 = i;
        }

        public static thooCoci9zae ieseir3Choge(int i) {
            return (thooCoci9zae) f7098Idohhaimaes0.get(i);
        }

        public int Jah0aiP1ki6y() {
            return this.f7119ieheiQu9sho5;
        }
    }

    public static ieseir3Choge ieseir3Choge() {
        return new ohv5Shie7AeZ.thooCoci9zae();
    }

    public abstract keiL1EiShomu keiL1EiShomu();

    public abstract thooCoci9zae thooCoci9zae();
}
