package maSie9ief8Ae;

import maSie9ief8Ae.ruNgecai1pae;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class kuedujio7Aev extends ruNgecai1pae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ruNgecai1pae.thooCoci9zae f7173ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final maSie9ief8Ae.ieseir3Choge f7174thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends ruNgecai1pae.ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public ruNgecai1pae.thooCoci9zae f7175ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public maSie9ief8Ae.ieseir3Choge f7176thooCoci9zae;

        @Override // maSie9ief8Ae.ruNgecai1pae.ieseir3Choge
        public ruNgecai1pae ieseir3Choge() {
            return new kuedujio7Aev(this.f7175ieseir3Choge, this.f7176thooCoci9zae);
        }

        @Override // maSie9ief8Ae.ruNgecai1pae.ieseir3Choge
        public ruNgecai1pae.ieseir3Choge keiL1EiShomu(ruNgecai1pae.thooCoci9zae thoococi9zae) {
            this.f7175ieseir3Choge = thoococi9zae;
            return this;
        }

        @Override // maSie9ief8Ae.ruNgecai1pae.ieseir3Choge
        public ruNgecai1pae.ieseir3Choge thooCoci9zae(maSie9ief8Ae.ieseir3Choge ieseir3choge) {
            this.f7176thooCoci9zae = ieseir3choge;
            return this;
        }
    }

    public kuedujio7Aev(ruNgecai1pae.thooCoci9zae thoococi9zae, maSie9ief8Ae.ieseir3Choge ieseir3choge) {
        this.f7173ieseir3Choge = thoococi9zae;
        this.f7174thooCoci9zae = ieseir3choge;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ruNgecai1pae)) {
            return false;
        }
        ruNgecai1pae rungecai1pae = (ruNgecai1pae) obj;
        ruNgecai1pae.thooCoci9zae thoococi9zae = this.f7173ieseir3Choge;
        if (thoococi9zae != null ? thoococi9zae.equals(rungecai1pae.keiL1EiShomu()) : rungecai1pae.keiL1EiShomu() == null) {
            maSie9ief8Ae.ieseir3Choge ieseir3choge = this.f7174thooCoci9zae;
            maSie9ief8Ae.ieseir3Choge thooCoci9zae2 = rungecai1pae.thooCoci9zae();
            if (ieseir3choge == null) {
                if (thooCoci9zae2 == null) {
                    return true;
                }
            } else if (ieseir3choge.equals(thooCoci9zae2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        ruNgecai1pae.thooCoci9zae thoococi9zae = this.f7173ieseir3Choge;
        int i = 0;
        if (thoococi9zae == null) {
            hashCode = 0;
        } else {
            hashCode = thoococi9zae.hashCode();
        }
        int i2 = (hashCode ^ 1000003) * 1000003;
        maSie9ief8Ae.ieseir3Choge ieseir3choge = this.f7174thooCoci9zae;
        if (ieseir3choge != null) {
            i = ieseir3choge.hashCode();
        }
        return i2 ^ i;
    }

    @Override // maSie9ief8Ae.ruNgecai1pae
    public ruNgecai1pae.thooCoci9zae keiL1EiShomu() {
        return this.f7173ieseir3Choge;
    }

    @Override // maSie9ief8Ae.ruNgecai1pae
    public maSie9ief8Ae.ieseir3Choge thooCoci9zae() {
        return this.f7174thooCoci9zae;
    }

    public String toString() {
        return "ClientInfo{clientType=" + this.f7173ieseir3Choge + ", androidClientInfo=" + this.f7174thooCoci9zae + "}";
    }
}
