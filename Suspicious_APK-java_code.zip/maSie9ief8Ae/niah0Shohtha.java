package maSie9ief8Ae;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class niah0Shohtha extends ruwiepo7ooVu {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final long f7177ieseir3Choge;

    public niah0Shohtha(long j) {
        this.f7177ieseir3Choge = j;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if ((obj instanceof ruwiepo7ooVu) && this.f7177ieseir3Choge == ((ruwiepo7ooVu) obj).keiL1EiShomu()) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        long j = this.f7177ieseir3Choge;
        return ((int) (j ^ (j >>> 32))) ^ 1000003;
    }

    @Override // maSie9ief8Ae.ruwiepo7ooVu
    public long keiL1EiShomu() {
        return this.f7177ieseir3Choge;
    }

    public String toString() {
        return "LogResponse{nextRequestWaitMillis=" + this.f7177ieseir3Choge + "}";
    }
}
