package maSie9ief8Ae;

import maSie9ief8Ae.ieseir3Choge;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class keiL1EiShomu extends maSie9ief8Ae.ieseir3Choge {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final String f7149Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final String f7150Jah0aiP1ki6y;

    /* renamed from: ahthoK6usais, reason: collision with root package name */
    public final String f7151ahthoK6usais;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final String f7152ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Integer f7153ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f7154keiL1EiShomu;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public final String f7155ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final String f7156kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final String f7157niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public final String f7158ohv5Shie7AeZ;

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public final String f7159ruNgecai1pae;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f7160thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae extends ieseir3Choge.AbstractC0098ieseir3Choge {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public String f7161Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public String f7162Jah0aiP1ki6y;

        /* renamed from: ahthoK6usais, reason: collision with root package name */
        public String f7163ahthoK6usais;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public String f7164ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public Integer f7165ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public String f7166keiL1EiShomu;

        /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
        public String f7167ko7aiFeiqu3s;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public String f7168kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public String f7169niah0Shohtha;

        /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
        public String f7170ohv5Shie7AeZ;

        /* renamed from: ruNgecai1pae, reason: collision with root package name */
        public String f7171ruNgecai1pae;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public String f7172thooCoci9zae;

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge Aicohm8ieYoo(String str) {
            this.f7166keiL1EiShomu = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge Jah0aiP1ki6y(String str) {
            this.f7170ohv5Shie7AeZ = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge ahthoK6usais(String str) {
            this.f7168kuedujio7Aev = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge ieheiQu9sho5(String str) {
            this.f7164ieheiQu9sho5 = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public maSie9ief8Ae.ieseir3Choge ieseir3Choge() {
            return new keiL1EiShomu(this.f7165ieseir3Choge, this.f7172thooCoci9zae, this.f7166keiL1EiShomu, this.f7164ieheiQu9sho5, this.f7168kuedujio7Aev, this.f7161Aicohm8ieYoo, this.f7162Jah0aiP1ki6y, this.f7169niah0Shohtha, this.f7170ohv5Shie7AeZ, this.f7167ko7aiFeiqu3s, this.f7171ruNgecai1pae, this.f7163ahthoK6usais);
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge keiL1EiShomu(String str) {
            this.f7167ko7aiFeiqu3s = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge ko7aiFeiqu3s(String str) {
            this.f7172thooCoci9zae = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge kuedujio7Aev(String str) {
            this.f7169niah0Shohtha = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge mi5Iecheimie(Integer num) {
            this.f7165ieseir3Choge = num;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge niah0Shohtha(String str) {
            this.f7162Jah0aiP1ki6y = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge ohv5Shie7AeZ(String str) {
            this.f7171ruNgecai1pae = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge ruNgecai1pae(String str) {
            this.f7161Aicohm8ieYoo = str;
            return this;
        }

        @Override // maSie9ief8Ae.ieseir3Choge.AbstractC0098ieseir3Choge
        public ieseir3Choge.AbstractC0098ieseir3Choge thooCoci9zae(String str) {
            this.f7163ahthoK6usais = str;
            return this;
        }
    }

    public keiL1EiShomu(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11) {
        this.f7153ieseir3Choge = num;
        this.f7160thooCoci9zae = str;
        this.f7154keiL1EiShomu = str2;
        this.f7152ieheiQu9sho5 = str3;
        this.f7156kuedujio7Aev = str4;
        this.f7149Aicohm8ieYoo = str5;
        this.f7150Jah0aiP1ki6y = str6;
        this.f7157niah0Shohtha = str7;
        this.f7158ohv5Shie7AeZ = str8;
        this.f7155ko7aiFeiqu3s = str9;
        this.f7159ruNgecai1pae = str10;
        this.f7151ahthoK6usais = str11;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String Aicohm8ieYoo() {
        return this.f7154keiL1EiShomu;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String Jah0aiP1ki6y() {
        return this.f7158ohv5Shie7AeZ;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String ahthoK6usais() {
        return this.f7156kuedujio7Aev;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof maSie9ief8Ae.ieseir3Choge)) {
            return false;
        }
        maSie9ief8Ae.ieseir3Choge ieseir3choge = (maSie9ief8Ae.ieseir3Choge) obj;
        Integer num = this.f7153ieseir3Choge;
        if (num != null ? num.equals(ieseir3choge.mi5Iecheimie()) : ieseir3choge.mi5Iecheimie() == null) {
            String str = this.f7160thooCoci9zae;
            if (str != null ? str.equals(ieseir3choge.ko7aiFeiqu3s()) : ieseir3choge.ko7aiFeiqu3s() == null) {
                String str2 = this.f7154keiL1EiShomu;
                if (str2 != null ? str2.equals(ieseir3choge.Aicohm8ieYoo()) : ieseir3choge.Aicohm8ieYoo() == null) {
                    String str3 = this.f7152ieheiQu9sho5;
                    if (str3 != null ? str3.equals(ieseir3choge.ieheiQu9sho5()) : ieseir3choge.ieheiQu9sho5() == null) {
                        String str4 = this.f7156kuedujio7Aev;
                        if (str4 != null ? str4.equals(ieseir3choge.ahthoK6usais()) : ieseir3choge.ahthoK6usais() == null) {
                            String str5 = this.f7149Aicohm8ieYoo;
                            if (str5 != null ? str5.equals(ieseir3choge.ruNgecai1pae()) : ieseir3choge.ruNgecai1pae() == null) {
                                String str6 = this.f7150Jah0aiP1ki6y;
                                if (str6 != null ? str6.equals(ieseir3choge.niah0Shohtha()) : ieseir3choge.niah0Shohtha() == null) {
                                    String str7 = this.f7157niah0Shohtha;
                                    if (str7 != null ? str7.equals(ieseir3choge.kuedujio7Aev()) : ieseir3choge.kuedujio7Aev() == null) {
                                        String str8 = this.f7158ohv5Shie7AeZ;
                                        if (str8 != null ? str8.equals(ieseir3choge.Jah0aiP1ki6y()) : ieseir3choge.Jah0aiP1ki6y() == null) {
                                            String str9 = this.f7155ko7aiFeiqu3s;
                                            if (str9 != null ? str9.equals(ieseir3choge.keiL1EiShomu()) : ieseir3choge.keiL1EiShomu() == null) {
                                                String str10 = this.f7159ruNgecai1pae;
                                                if (str10 != null ? str10.equals(ieseir3choge.ohv5Shie7AeZ()) : ieseir3choge.ohv5Shie7AeZ() == null) {
                                                    String str11 = this.f7151ahthoK6usais;
                                                    String thooCoci9zae2 = ieseir3choge.thooCoci9zae();
                                                    if (str11 == null) {
                                                        if (thooCoci9zae2 == null) {
                                                            return true;
                                                        }
                                                    } else if (str11.equals(thooCoci9zae2)) {
                                                        return true;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        int hashCode2;
        int hashCode3;
        int hashCode4;
        int hashCode5;
        int hashCode6;
        int hashCode7;
        int hashCode8;
        int hashCode9;
        int hashCode10;
        int hashCode11;
        Integer num = this.f7153ieseir3Choge;
        int i = 0;
        if (num == null) {
            hashCode = 0;
        } else {
            hashCode = num.hashCode();
        }
        int i2 = (hashCode ^ 1000003) * 1000003;
        String str = this.f7160thooCoci9zae;
        if (str == null) {
            hashCode2 = 0;
        } else {
            hashCode2 = str.hashCode();
        }
        int i3 = (i2 ^ hashCode2) * 1000003;
        String str2 = this.f7154keiL1EiShomu;
        if (str2 == null) {
            hashCode3 = 0;
        } else {
            hashCode3 = str2.hashCode();
        }
        int i4 = (i3 ^ hashCode3) * 1000003;
        String str3 = this.f7152ieheiQu9sho5;
        if (str3 == null) {
            hashCode4 = 0;
        } else {
            hashCode4 = str3.hashCode();
        }
        int i5 = (i4 ^ hashCode4) * 1000003;
        String str4 = this.f7156kuedujio7Aev;
        if (str4 == null) {
            hashCode5 = 0;
        } else {
            hashCode5 = str4.hashCode();
        }
        int i6 = (i5 ^ hashCode5) * 1000003;
        String str5 = this.f7149Aicohm8ieYoo;
        if (str5 == null) {
            hashCode6 = 0;
        } else {
            hashCode6 = str5.hashCode();
        }
        int i7 = (i6 ^ hashCode6) * 1000003;
        String str6 = this.f7150Jah0aiP1ki6y;
        if (str6 == null) {
            hashCode7 = 0;
        } else {
            hashCode7 = str6.hashCode();
        }
        int i8 = (i7 ^ hashCode7) * 1000003;
        String str7 = this.f7157niah0Shohtha;
        if (str7 == null) {
            hashCode8 = 0;
        } else {
            hashCode8 = str7.hashCode();
        }
        int i9 = (i8 ^ hashCode8) * 1000003;
        String str8 = this.f7158ohv5Shie7AeZ;
        if (str8 == null) {
            hashCode9 = 0;
        } else {
            hashCode9 = str8.hashCode();
        }
        int i10 = (i9 ^ hashCode9) * 1000003;
        String str9 = this.f7155ko7aiFeiqu3s;
        if (str9 == null) {
            hashCode10 = 0;
        } else {
            hashCode10 = str9.hashCode();
        }
        int i11 = (i10 ^ hashCode10) * 1000003;
        String str10 = this.f7159ruNgecai1pae;
        if (str10 == null) {
            hashCode11 = 0;
        } else {
            hashCode11 = str10.hashCode();
        }
        int i12 = (i11 ^ hashCode11) * 1000003;
        String str11 = this.f7151ahthoK6usais;
        if (str11 != null) {
            i = str11.hashCode();
        }
        return i12 ^ i;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String ieheiQu9sho5() {
        return this.f7152ieheiQu9sho5;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String keiL1EiShomu() {
        return this.f7155ko7aiFeiqu3s;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String ko7aiFeiqu3s() {
        return this.f7160thooCoci9zae;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String kuedujio7Aev() {
        return this.f7157niah0Shohtha;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public Integer mi5Iecheimie() {
        return this.f7153ieseir3Choge;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String niah0Shohtha() {
        return this.f7150Jah0aiP1ki6y;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String ohv5Shie7AeZ() {
        return this.f7159ruNgecai1pae;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String ruNgecai1pae() {
        return this.f7149Aicohm8ieYoo;
    }

    @Override // maSie9ief8Ae.ieseir3Choge
    public String thooCoci9zae() {
        return this.f7151ahthoK6usais;
    }

    public String toString() {
        return "AndroidClientInfo{sdkVersion=" + this.f7153ieseir3Choge + ", model=" + this.f7160thooCoci9zae + ", hardware=" + this.f7154keiL1EiShomu + ", device=" + this.f7152ieheiQu9sho5 + ", product=" + this.f7156kuedujio7Aev + ", osBuild=" + this.f7149Aicohm8ieYoo + ", manufacturer=" + this.f7150Jah0aiP1ki6y + ", fingerprint=" + this.f7157niah0Shohtha + ", locale=" + this.f7158ohv5Shie7AeZ + ", country=" + this.f7155ko7aiFeiqu3s + ", mccMnc=" + this.f7159ruNgecai1pae + ", applicationBuild=" + this.f7151ahthoK6usais + "}";
    }
}
