package maSie9ief8Ae;

import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieheiQu9sho5 extends ko7aiFeiqu3s {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final List f7148ieseir3Choge;

    public ieheiQu9sho5(List list) {
        if (list != null) {
            this.f7148ieseir3Choge = list;
            return;
        }
        throw new NullPointerException("Null logRequests");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof ko7aiFeiqu3s) {
            return this.f7148ieseir3Choge.equals(((ko7aiFeiqu3s) obj).keiL1EiShomu());
        }
        return false;
    }

    public int hashCode() {
        return this.f7148ieseir3Choge.hashCode() ^ 1000003;
    }

    @Override // maSie9ief8Ae.ko7aiFeiqu3s
    public List keiL1EiShomu() {
        return this.f7148ieseir3Choge;
    }

    public String toString() {
        return "BatchedLogRequest{logRequests=" + this.f7148ieseir3Choge + "}";
    }
}
