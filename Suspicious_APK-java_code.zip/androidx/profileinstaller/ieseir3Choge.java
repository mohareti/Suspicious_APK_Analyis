package androidx.profileinstaller;

import android.content.Context;
import android.os.Build;
import androidx.profileinstaller.ProfileInstallReceiver;
import java.io.File;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieseir3Choge {

    /* renamed from: androidx.profileinstaller.ieseir3Choge$ieseir3Choge, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class C0058ieseir3Choge {
        public static File ieseir3Choge(Context context) {
            return context.getCodeCacheDir();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {
        public static File ieseir3Choge(Context context) {
            Context createDeviceProtectedStorageContext;
            createDeviceProtectedStorageContext = context.createDeviceProtectedStorageContext();
            return createDeviceProtectedStorageContext.getCodeCacheDir();
        }
    }

    public static boolean ieseir3Choge(File file) {
        if (!file.isDirectory()) {
            file.delete();
            return true;
        }
        File[] listFiles = file.listFiles();
        if (listFiles == null) {
            return false;
        }
        boolean z = true;
        for (File file2 : listFiles) {
            z = ieseir3Choge(file2) && z;
        }
        return z;
    }

    public static void thooCoci9zae(Context context, ProfileInstallReceiver.ieseir3Choge ieseir3choge) {
        ieseir3choge.thooCoci9zae(ieseir3Choge(Build.VERSION.SDK_INT >= 24 ? thooCoci9zae.ieseir3Choge(context) : C0058ieseir3Choge.ieseir3Choge(context)) ? 14 : 15, null);
    }
}
