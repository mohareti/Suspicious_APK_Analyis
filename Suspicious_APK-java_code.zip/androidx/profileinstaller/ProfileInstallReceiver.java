package androidx.profileinstaller;

import HaeYeFaep1if.Aicohm8ieYoo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import androidx.profileinstaller.keiL1EiShomu;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ProfileInstallReceiver extends BroadcastReceiver {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements keiL1EiShomu.InterfaceC0059keiL1EiShomu {
        public ieseir3Choge() {
        }

        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void ieseir3Choge(int i, Object obj) {
            keiL1EiShomu.f3879thooCoci9zae.ieseir3Choge(i, obj);
        }

        @Override // androidx.profileinstaller.keiL1EiShomu.InterfaceC0059keiL1EiShomu
        public void thooCoci9zae(int i, Object obj) {
            keiL1EiShomu.f3879thooCoci9zae.thooCoci9zae(i, obj);
            ProfileInstallReceiver.this.setResultCode(i);
        }
    }

    public static void ieseir3Choge(keiL1EiShomu.InterfaceC0059keiL1EiShomu interfaceC0059keiL1EiShomu) {
        int i;
        if (Build.VERSION.SDK_INT >= 24) {
            Process.sendSignal(Process.myPid(), 10);
            i = 12;
        } else {
            i = 13;
        }
        interfaceC0059keiL1EiShomu.thooCoci9zae(i, null);
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Bundle extras;
        if (intent == null) {
            return;
        }
        String action = intent.getAction();
        if ("androidx.profileinstaller.action.INSTALL_PROFILE".equals(action)) {
            keiL1EiShomu.ruNgecai1pae(context, new Aicohm8ieYoo(), new ieseir3Choge(), true);
            return;
        }
        if ("androidx.profileinstaller.action.SKIP_FILE".equals(action)) {
            Bundle extras2 = intent.getExtras();
            if (extras2 != null) {
                String string = extras2.getString("EXTRA_SKIP_FILE_OPERATION");
                if ("WRITE_SKIP_FILE".equals(string)) {
                    keiL1EiShomu.ahthoK6usais(context, new Aicohm8ieYoo(), new ieseir3Choge());
                    return;
                } else {
                    if ("DELETE_SKIP_FILE".equals(string)) {
                        keiL1EiShomu.keiL1EiShomu(context, new Aicohm8ieYoo(), new ieseir3Choge());
                        return;
                    }
                    return;
                }
            }
            return;
        }
        if ("androidx.profileinstaller.action.SAVE_PROFILE".equals(action)) {
            ieseir3Choge(new ieseir3Choge());
            return;
        }
        if (!"androidx.profileinstaller.action.BENCHMARK_OPERATION".equals(action) || (extras = intent.getExtras()) == null) {
            return;
        }
        String string2 = extras.getString("EXTRA_BENCHMARK_OPERATION");
        ieseir3Choge ieseir3choge = new ieseir3Choge();
        if ("DROP_SHADER_CACHE".equals(string2)) {
            androidx.profileinstaller.ieseir3Choge.thooCoci9zae(context, ieseir3choge);
        } else {
            ieseir3choge.thooCoci9zae(16, null);
        }
    }
}
