package androidx.profileinstaller;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Objects;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ahthoK6usais.keiL1EiShomu f3868ieseir3Choge = ahthoK6usais.keiL1EiShomu.oph9lahCh6uo();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final Object f3870thooCoci9zae = new Object();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static keiL1EiShomu f3869keiL1EiShomu = null;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static PackageInfo ieseir3Choge(PackageManager packageManager, Context context) {
            return packageManager.getPackageInfo(context.getPackageName(), PackageManager.PackageInfoFlags.of(0L));
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final int f3871ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final boolean f3872keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final boolean f3873thooCoci9zae;

        public keiL1EiShomu(int i, boolean z, boolean z2) {
            this.f3871ieseir3Choge = i;
            this.f3872keiL1EiShomu = z2;
            this.f3873thooCoci9zae = z;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final long f3874ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final int f3875ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final long f3876keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final int f3877thooCoci9zae;

        public thooCoci9zae(int i, int i2, long j, long j2) {
            this.f3875ieseir3Choge = i;
            this.f3877thooCoci9zae = i2;
            this.f3876keiL1EiShomu = j;
            this.f3874ieheiQu9sho5 = j2;
        }

        public static thooCoci9zae ieseir3Choge(File file) {
            DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
            try {
                thooCoci9zae thoococi9zae = new thooCoci9zae(dataInputStream.readInt(), dataInputStream.readInt(), dataInputStream.readLong(), dataInputStream.readLong());
                dataInputStream.close();
                return thoococi9zae;
            } catch (Throwable th) {
                try {
                    dataInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || !(obj instanceof thooCoci9zae)) {
                return false;
            }
            thooCoci9zae thoococi9zae = (thooCoci9zae) obj;
            return this.f3877thooCoci9zae == thoococi9zae.f3877thooCoci9zae && this.f3876keiL1EiShomu == thoococi9zae.f3876keiL1EiShomu && this.f3875ieseir3Choge == thoococi9zae.f3875ieseir3Choge && this.f3874ieheiQu9sho5 == thoococi9zae.f3874ieheiQu9sho5;
        }

        public int hashCode() {
            return Objects.hash(Integer.valueOf(this.f3877thooCoci9zae), Long.valueOf(this.f3876keiL1EiShomu), Integer.valueOf(this.f3875ieseir3Choge), Long.valueOf(this.f3874ieheiQu9sho5));
        }

        public void thooCoci9zae(File file) {
            file.delete();
            DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
            try {
                dataOutputStream.writeInt(this.f3875ieseir3Choge);
                dataOutputStream.writeInt(this.f3877thooCoci9zae);
                dataOutputStream.writeLong(this.f3876keiL1EiShomu);
                dataOutputStream.writeLong(this.f3874ieheiQu9sho5);
                dataOutputStream.close();
            } catch (Throwable th) {
                try {
                    dataOutputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
                throw th;
            }
        }
    }

    public static long ieseir3Choge(Context context) {
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        return (Build.VERSION.SDK_INT >= 33 ? ieseir3Choge.ieseir3Choge(packageManager, context) : packageManager.getPackageInfo(context.getPackageName(), 0)).lastUpdateTime;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(20:14|(1:79)(1:18)|19|(1:78)(1:23)|24|25|26|(2:63|64)(1:28)|29|(8:36|(1:40)|(1:47)|48|(2:55|56)|52|53|54)|(1:62)|(1:40)|(3:42|45|47)|48|(1:50)|55|56|52|53|54) */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x00cf, code lost:
    
        r3 = 196608;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00a0, code lost:
    
        r3 = 1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public static keiL1EiShomu keiL1EiShomu(Context context, boolean z) {
        thooCoci9zae ieseir3Choge2;
        thooCoci9zae thoococi9zae;
        int i;
        keiL1EiShomu keil1eishomu;
        if (!z && (keil1eishomu = f3869keiL1EiShomu) != null) {
            return keil1eishomu;
        }
        synchronized (f3870thooCoci9zae) {
            if (!z) {
                try {
                    keiL1EiShomu keil1eishomu2 = f3869keiL1EiShomu;
                    if (keil1eishomu2 != null) {
                        return keil1eishomu2;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
            int i2 = Build.VERSION.SDK_INT;
            int i3 = 0;
            if (i2 >= 28 && i2 != 30) {
                File file = new File(new File("/data/misc/profiles/ref/", context.getPackageName()), "primary.prof");
                long length = file.length();
                boolean z2 = file.exists() && length > 0;
                File file2 = new File(new File("/data/misc/profiles/cur/0/", context.getPackageName()), "primary.prof");
                long length2 = file2.length();
                boolean z3 = file2.exists() && length2 > 0;
                try {
                    long ieseir3Choge3 = ieseir3Choge(context);
                    File file3 = new File(context.getFilesDir(), "profileInstalled");
                    if (file3.exists()) {
                        try {
                            ieseir3Choge2 = thooCoci9zae.ieseir3Choge(file3);
                        } catch (IOException unused) {
                            return thooCoci9zae(131072, z2, z3);
                        }
                    } else {
                        ieseir3Choge2 = null;
                    }
                    if (ieseir3Choge2 != null && ieseir3Choge2.f3876keiL1EiShomu == ieseir3Choge3 && (i = ieseir3Choge2.f3877thooCoci9zae) != 2) {
                        i3 = i;
                        if (z && z3 && i3 != 1) {
                            i3 = 2;
                        }
                        if (ieseir3Choge2 != null && ieseir3Choge2.f3877thooCoci9zae == 2 && i3 == 1 && length < ieseir3Choge2.f3874ieheiQu9sho5) {
                            i3 = 3;
                        }
                        thoococi9zae = new thooCoci9zae(1, i3, ieseir3Choge3, length2);
                        if (ieseir3Choge2 != null || !ieseir3Choge2.equals(thoococi9zae)) {
                            thoococi9zae.thooCoci9zae(file3);
                        }
                        return thooCoci9zae(i3, z2, z3);
                    }
                    if (z3) {
                        i3 = 2;
                    }
                    if (z) {
                        i3 = 2;
                    }
                    if (ieseir3Choge2 != null) {
                        i3 = 3;
                    }
                    thoococi9zae = new thooCoci9zae(1, i3, ieseir3Choge3, length2);
                    if (ieseir3Choge2 != null) {
                    }
                    thoococi9zae.thooCoci9zae(file3);
                    return thooCoci9zae(i3, z2, z3);
                } catch (PackageManager.NameNotFoundException unused2) {
                    return thooCoci9zae(65536, z2, z3);
                }
            }
            return thooCoci9zae(262144, false, false);
        }
    }

    public static keiL1EiShomu thooCoci9zae(int i, boolean z, boolean z2) {
        keiL1EiShomu keil1eishomu = new keiL1EiShomu(i, z, z2);
        f3869keiL1EiShomu = keil1eishomu;
        f3868ieseir3Choge.aac1eTaexee6(keil1eishomu);
        return f3869keiL1EiShomu;
    }
}
