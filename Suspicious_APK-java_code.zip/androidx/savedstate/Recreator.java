package androidx.savedstate;

import android.os.Bundle;
import androidx.lifecycle.Jah0aiP1ki6y;
import androidx.lifecycle.ahthoK6usais;
import androidx.lifecycle.ko7aiFeiqu3s;
import androidx.savedstate.ieseir3Choge;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import oote1Ahvo8Ai.ieheiQu9sho5;
import thiet5ees7Wu.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Recreator implements ko7aiFeiqu3s {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ieseir3Choge f3891thooCoci9zae = new ieseir3Choge(null);

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ieheiQu9sho5 f3892ieseir3Choge;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {
        public ieseir3Choge() {
        }

        public /* synthetic */ ieseir3Choge(thiet5ees7Wu.ieheiQu9sho5 ieheiqu9sho5) {
            this();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae implements ieseir3Choge.keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Set f3893ieseir3Choge;

        public thooCoci9zae(androidx.savedstate.ieseir3Choge ieseir3choge) {
            Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "registry");
            this.f3893ieseir3Choge = new LinkedHashSet();
            ieseir3choge.niah0Shohtha("androidx.savedstate.Restarter", this);
        }

        @Override // androidx.savedstate.ieseir3Choge.keiL1EiShomu
        public Bundle ieseir3Choge() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList<>(this.f3893ieseir3Choge));
            return bundle;
        }

        public final void thooCoci9zae(String str) {
            Aicohm8ieYoo.kuedujio7Aev(str, "className");
            this.f3893ieseir3Choge.add(str);
        }
    }

    public Recreator(ieheiQu9sho5 ieheiqu9sho5) {
        Aicohm8ieYoo.kuedujio7Aev(ieheiqu9sho5, "owner");
        this.f3892ieseir3Choge = ieheiqu9sho5;
    }

    public final void keiL1EiShomu(String str) {
        try {
            Class<? extends U> asSubclass = Class.forName(str, false, Recreator.class.getClassLoader()).asSubclass(ieseir3Choge.InterfaceC0060ieseir3Choge.class);
            Aicohm8ieYoo.ieheiQu9sho5(asSubclass, "{\n                Class.…class.java)\n            }");
            try {
                Constructor declaredConstructor = asSubclass.getDeclaredConstructor(null);
                declaredConstructor.setAccessible(true);
                try {
                    Object newInstance = declaredConstructor.newInstance(null);
                    Aicohm8ieYoo.ieheiQu9sho5(newInstance, "{\n                constr…wInstance()\n            }");
                    ((ieseir3Choge.InterfaceC0060ieseir3Choge) newInstance).ieseir3Choge(this.f3892ieseir3Choge);
                } catch (Exception e) {
                    throw new RuntimeException("Failed to instantiate " + str, e);
                }
            } catch (NoSuchMethodException e2) {
                throw new IllegalStateException("Class " + asSubclass.getSimpleName() + " must have default constructor in order to be automatically recreated", e2);
            }
        } catch (ClassNotFoundException e3) {
            throw new RuntimeException("Class " + str + " wasn't found", e3);
        }
    }

    @Override // androidx.lifecycle.ko7aiFeiqu3s
    public void kuedujio7Aev(ahthoK6usais ahthok6usais, Jah0aiP1ki6y.ieseir3Choge ieseir3choge) {
        Aicohm8ieYoo.kuedujio7Aev(ahthok6usais, "source");
        Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "event");
        if (ieseir3choge != Jah0aiP1ki6y.ieseir3Choge.ON_CREATE) {
            throw new AssertionError("Next event must be ON_CREATE");
        }
        ahthok6usais.Jah0aiP1ki6y().keiL1EiShomu(this);
        Bundle thooCoci9zae2 = this.f3892ieseir3Choge.thooCoci9zae().thooCoci9zae("androidx.savedstate.Restarter");
        if (thooCoci9zae2 == null) {
            return;
        }
        ArrayList<String> stringArrayList = thooCoci9zae2.getStringArrayList("classes_to_restore");
        if (stringArrayList == null) {
            throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
        }
        Iterator<String> it = stringArrayList.iterator();
        while (it.hasNext()) {
            keiL1EiShomu(it.next());
        }
    }
}
