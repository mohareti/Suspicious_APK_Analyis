package androidx.emoji2.text;

import android.text.PrecomputedText;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract /* synthetic */ class rojaiZ9aeRee {
    public static /* bridge */ /* synthetic */ boolean ieseir3Choge(Object obj) {
        return obj instanceof PrecomputedText;
    }
}
