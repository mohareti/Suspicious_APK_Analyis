package androidx.emoji2.text;

import android.os.Build;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class laej2zeez5Ja implements Spannable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public boolean f3381ieheiQu9sho5 = false;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public Spannable f3382kuedujio7Aev;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {
        public static IntStream ieseir3Choge(CharSequence charSequence) {
            IntStream chars;
            chars = charSequence.chars();
            return chars;
        }

        public static IntStream thooCoci9zae(CharSequence charSequence) {
            IntStream codePoints;
            codePoints = charSequence.codePoints();
            return codePoints;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu extends thooCoci9zae {
        @Override // androidx.emoji2.text.laej2zeez5Ja.thooCoci9zae
        public boolean ieseir3Choge(CharSequence charSequence) {
            return rojaiZ9aeRee.ieseir3Choge(charSequence);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {
        public boolean ieseir3Choge(CharSequence charSequence) {
            return false;
        }
    }

    public laej2zeez5Ja(Spannable spannable) {
        this.f3382kuedujio7Aev = spannable;
    }

    public static thooCoci9zae keiL1EiShomu() {
        return Build.VERSION.SDK_INT < 28 ? new thooCoci9zae() : new keiL1EiShomu();
    }

    @Override // java.lang.CharSequence
    public char charAt(int i) {
        return this.f3382kuedujio7Aev.charAt(i);
    }

    @Override // java.lang.CharSequence
    public IntStream chars() {
        return ieseir3Choge.ieseir3Choge(this.f3382kuedujio7Aev);
    }

    @Override // java.lang.CharSequence
    public IntStream codePoints() {
        return ieseir3Choge.thooCoci9zae(this.f3382kuedujio7Aev);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f3382kuedujio7Aev.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f3382kuedujio7Aev.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f3382kuedujio7Aev.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public Object[] getSpans(int i, int i2, Class cls) {
        return this.f3382kuedujio7Aev.getSpans(i, i2, cls);
    }

    public final void ieseir3Choge() {
        Spannable spannable = this.f3382kuedujio7Aev;
        if (!this.f3381ieheiQu9sho5 && keiL1EiShomu().ieseir3Choge(spannable)) {
            this.f3382kuedujio7Aev = new SpannableString(spannable);
        }
        this.f3381ieheiQu9sho5 = true;
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f3382kuedujio7Aev.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i, int i2, Class cls) {
        return this.f3382kuedujio7Aev.nextSpanTransition(i, i2, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        ieseir3Choge();
        this.f3382kuedujio7Aev.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i, int i2, int i3) {
        ieseir3Choge();
        this.f3382kuedujio7Aev.setSpan(obj, i, i2, i3);
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i, int i2) {
        return this.f3382kuedujio7Aev.subSequence(i, i2);
    }

    public Spannable thooCoci9zae() {
        return this.f3382kuedujio7Aev;
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f3382kuedujio7Aev.toString();
    }

    public laej2zeez5Ja(CharSequence charSequence) {
        this.f3382kuedujio7Aev = new SpannableString(charSequence);
    }
}
