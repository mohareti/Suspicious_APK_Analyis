package androidx.emoji2.text;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class oYe2ma2she1j {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final ThreadLocal f3386ieheiQu9sho5 = new ThreadLocal();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final int f3387ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public volatile int f3388keiL1EiShomu = 0;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ruwiepo7ooVu f3389thooCoci9zae;

    public oYe2ma2she1j(ruwiepo7ooVu ruwiepo7oovu, int i) {
        this.f3389thooCoci9zae = ruwiepo7oovu;
        this.f3387ieseir3Choge = i;
    }

    public int Aicohm8ieYoo() {
        return Jah0aiP1ki6y().ahthoK6usais();
    }

    public final Nieyie8tecah.ieseir3Choge Jah0aiP1ki6y() {
        ThreadLocal threadLocal = f3386ieheiQu9sho5;
        Nieyie8tecah.ieseir3Choge ieseir3choge = (Nieyie8tecah.ieseir3Choge) threadLocal.get();
        if (ieseir3choge == null) {
            ieseir3choge = new Nieyie8tecah.ieseir3Choge();
            threadLocal.set(ieseir3choge);
        }
        this.f3389thooCoci9zae.ieheiQu9sho5().ko7aiFeiqu3s(ieseir3choge, this.f3387ieseir3Choge);
        return ieseir3choge;
    }

    public void ahthoK6usais(boolean z) {
        int ieheiQu9sho52 = ieheiQu9sho5();
        if (z) {
            this.f3388keiL1EiShomu = ieheiQu9sho52 | 4;
        } else {
            this.f3388keiL1EiShomu = ieheiQu9sho52;
        }
    }

    public int ieheiQu9sho5() {
        return this.f3388keiL1EiShomu & 3;
    }

    public void ieseir3Choge(Canvas canvas, float f, float f2, Paint paint) {
        Typeface Jah0aiP1ki6y2 = this.f3389thooCoci9zae.Jah0aiP1ki6y();
        Typeface typeface = paint.getTypeface();
        paint.setTypeface(Jah0aiP1ki6y2);
        canvas.drawText(this.f3389thooCoci9zae.keiL1EiShomu(), this.f3387ieseir3Choge * 2, 2, f, f2, paint);
        paint.setTypeface(typeface);
    }

    public int keiL1EiShomu() {
        return Jah0aiP1ki6y().ohv5Shie7AeZ();
    }

    public boolean ko7aiFeiqu3s() {
        return Jah0aiP1ki6y().ko7aiFeiqu3s();
    }

    public int kuedujio7Aev() {
        return Jah0aiP1ki6y().ruNgecai1pae();
    }

    public void mi5Iecheimie(boolean z) {
        int i = this.f3388keiL1EiShomu & 4;
        this.f3388keiL1EiShomu = z ? i | 2 : i | 1;
    }

    public short niah0Shohtha() {
        return Jah0aiP1ki6y().mi5Iecheimie();
    }

    public int ohv5Shie7AeZ() {
        return Jah0aiP1ki6y().ruwiepo7ooVu();
    }

    public boolean ruNgecai1pae() {
        return (this.f3388keiL1EiShomu & 4) > 0;
    }

    public int thooCoci9zae(int i) {
        return Jah0aiP1ki6y().niah0Shohtha(i);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(", id:");
        sb.append(Integer.toHexString(Aicohm8ieYoo()));
        sb.append(", codepoints:");
        int keiL1EiShomu2 = keiL1EiShomu();
        for (int i = 0; i < keiL1EiShomu2; i++) {
            sb.append(Integer.toHexString(thooCoci9zae(i)));
            sb.append(" ");
        }
        return sb.toString();
    }
}
