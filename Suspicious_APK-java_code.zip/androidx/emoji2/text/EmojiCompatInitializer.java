package androidx.emoji2.text;

import android.content.Context;
import androidx.emoji2.text.Aicohm8ieYoo;
import androidx.emoji2.text.EmojiCompatInitializer;
import androidx.lifecycle.ProcessLifecycleInitializer;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ThreadPoolExecutor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class EmojiCompatInitializer implements lo8zieZoeseb.thooCoci9zae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge extends Aicohm8ieYoo.keiL1EiShomu {
        public ieseir3Choge(Context context) {
            super(new thooCoci9zae(context));
            thooCoci9zae(1);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu implements Runnable {
        @Override // java.lang.Runnable
        public void run() {
            try {
                rojaiZ9aeRee.ahthoK6usais.ieseir3Choge("EmojiCompat.EmojiCompatInitializer.run");
                if (Aicohm8ieYoo.ohv5Shie7AeZ()) {
                    Aicohm8ieYoo.keiL1EiShomu().ahthoK6usais();
                }
            } finally {
                rojaiZ9aeRee.ahthoK6usais.thooCoci9zae();
            }
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae implements Aicohm8ieYoo.niah0Shohtha {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Context f3362ieseir3Choge;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public class ieseir3Choge extends Aicohm8ieYoo.ohv5Shie7AeZ {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public final /* synthetic */ Aicohm8ieYoo.ohv5Shie7AeZ f3363ieseir3Choge;

            /* renamed from: thooCoci9zae, reason: collision with root package name */
            public final /* synthetic */ ThreadPoolExecutor f3365thooCoci9zae;

            public ieseir3Choge(Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez, ThreadPoolExecutor threadPoolExecutor) {
                this.f3363ieseir3Choge = ohv5shie7aez;
                this.f3365thooCoci9zae = threadPoolExecutor;
            }

            @Override // androidx.emoji2.text.Aicohm8ieYoo.ohv5Shie7AeZ
            public void ieseir3Choge(Throwable th) {
                try {
                    this.f3363ieseir3Choge.ieseir3Choge(th);
                } finally {
                    this.f3365thooCoci9zae.shutdown();
                }
            }

            @Override // androidx.emoji2.text.Aicohm8ieYoo.ohv5Shie7AeZ
            public void thooCoci9zae(ruwiepo7ooVu ruwiepo7oovu) {
                try {
                    this.f3363ieseir3Choge.thooCoci9zae(ruwiepo7oovu);
                } finally {
                    this.f3365thooCoci9zae.shutdown();
                }
            }
        }

        public thooCoci9zae(Context context) {
            this.f3362ieseir3Choge = context.getApplicationContext();
        }

        @Override // androidx.emoji2.text.Aicohm8ieYoo.niah0Shohtha
        public void ieseir3Choge(final Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez) {
            final ThreadPoolExecutor thooCoci9zae2 = androidx.emoji2.text.keiL1EiShomu.thooCoci9zae("EmojiCompatInitializer");
            thooCoci9zae2.execute(new Runnable() { // from class: androidx.emoji2.text.Jah0aiP1ki6y
                @Override // java.lang.Runnable
                public final void run() {
                    EmojiCompatInitializer.thooCoci9zae.this.ieheiQu9sho5(ohv5shie7aez, thooCoci9zae2);
                }
            });
        }

        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public void ieheiQu9sho5(Aicohm8ieYoo.ohv5Shie7AeZ ohv5shie7aez, ThreadPoolExecutor threadPoolExecutor) {
            try {
                ruNgecai1pae ieseir3Choge2 = ieheiQu9sho5.ieseir3Choge(this.f3362ieseir3Choge);
                if (ieseir3Choge2 == null) {
                    throw new RuntimeException("EmojiCompat font provider not available on this device.");
                }
                ieseir3Choge2.keiL1EiShomu(threadPoolExecutor);
                ieseir3Choge2.ieseir3Choge().ieseir3Choge(new ieseir3Choge(ohv5shie7aez, threadPoolExecutor));
            } catch (Throwable th) {
                ohv5shie7aez.ieseir3Choge(th);
                threadPoolExecutor.shutdown();
            }
        }
    }

    public void ieheiQu9sho5(Context context) {
        final androidx.lifecycle.Jah0aiP1ki6y Jah0aiP1ki6y2 = ((androidx.lifecycle.ahthoK6usais) lo8zieZoeseb.ieseir3Choge.kuedujio7Aev(context).Aicohm8ieYoo(ProcessLifecycleInitializer.class)).Jah0aiP1ki6y();
        Jah0aiP1ki6y2.ieseir3Choge(new androidx.lifecycle.keiL1EiShomu() { // from class: androidx.emoji2.text.EmojiCompatInitializer.1
            @Override // androidx.lifecycle.keiL1EiShomu
            public /* synthetic */ void Aicohm8ieYoo(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                androidx.lifecycle.thooCoci9zae.keiL1EiShomu(this, ahthok6usais);
            }

            @Override // androidx.lifecycle.keiL1EiShomu
            public /* synthetic */ void Jah0aiP1ki6y(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                androidx.lifecycle.thooCoci9zae.kuedujio7Aev(this, ahthok6usais);
            }

            @Override // androidx.lifecycle.keiL1EiShomu
            public /* synthetic */ void ieheiQu9sho5(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                androidx.lifecycle.thooCoci9zae.ieseir3Choge(this, ahthok6usais);
            }

            @Override // androidx.lifecycle.keiL1EiShomu
            public void ieseir3Choge(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                EmojiCompatInitializer.this.kuedujio7Aev();
                Jah0aiP1ki6y2.keiL1EiShomu(this);
            }

            @Override // androidx.lifecycle.keiL1EiShomu
            public /* synthetic */ void niah0Shohtha(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                androidx.lifecycle.thooCoci9zae.ieheiQu9sho5(this, ahthok6usais);
            }

            @Override // androidx.lifecycle.keiL1EiShomu
            public /* synthetic */ void thooCoci9zae(androidx.lifecycle.ahthoK6usais ahthok6usais) {
                androidx.lifecycle.thooCoci9zae.thooCoci9zae(this, ahthok6usais);
            }
        });
    }

    @Override // lo8zieZoeseb.thooCoci9zae
    public List ieseir3Choge() {
        return Collections.singletonList(ProcessLifecycleInitializer.class);
    }

    @Override // lo8zieZoeseb.thooCoci9zae
    /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
    public Boolean thooCoci9zae(Context context) {
        Aicohm8ieYoo.niah0Shohtha(new ieseir3Choge(context));
        ieheiQu9sho5(context);
        return Boolean.TRUE;
    }

    public void kuedujio7Aev() {
        androidx.emoji2.text.keiL1EiShomu.ieheiQu9sho5().postDelayed(new keiL1EiShomu(), 500L);
    }
}
