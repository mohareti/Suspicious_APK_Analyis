package androidx.emoji2.text;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class mi5Iecheimie {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge implements keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final ByteBuffer f3383ieseir3Choge;

        public ieseir3Choge(ByteBuffer byteBuffer) {
            this.f3383ieseir3Choge = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // androidx.emoji2.text.mi5Iecheimie.keiL1EiShomu
        public int ieheiQu9sho5() {
            return this.f3383ieseir3Choge.getInt();
        }

        @Override // androidx.emoji2.text.mi5Iecheimie.keiL1EiShomu
        public long ieseir3Choge() {
            return mi5Iecheimie.keiL1EiShomu(this.f3383ieseir3Choge.getInt());
        }

        @Override // androidx.emoji2.text.mi5Iecheimie.keiL1EiShomu
        public int keiL1EiShomu() {
            return mi5Iecheimie.ieheiQu9sho5(this.f3383ieseir3Choge.getShort());
        }

        @Override // androidx.emoji2.text.mi5Iecheimie.keiL1EiShomu
        public long kuedujio7Aev() {
            return this.f3383ieseir3Choge.position();
        }

        @Override // androidx.emoji2.text.mi5Iecheimie.keiL1EiShomu
        public void thooCoci9zae(int i) {
            ByteBuffer byteBuffer = this.f3383ieseir3Choge;
            byteBuffer.position(byteBuffer.position() + i);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface keiL1EiShomu {
        int ieheiQu9sho5();

        long ieseir3Choge();

        int keiL1EiShomu();

        long kuedujio7Aev();

        void thooCoci9zae(int i);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final long f3384ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final long f3385thooCoci9zae;

        public thooCoci9zae(long j, long j2) {
            this.f3384ieseir3Choge = j;
            this.f3385thooCoci9zae = j2;
        }

        public long ieseir3Choge() {
            return this.f3384ieseir3Choge;
        }
    }

    public static int ieheiQu9sho5(short s) {
        return s & 65535;
    }

    public static thooCoci9zae ieseir3Choge(keiL1EiShomu keil1eishomu) {
        long j;
        keil1eishomu.thooCoci9zae(4);
        int keiL1EiShomu2 = keil1eishomu.keiL1EiShomu();
        if (keiL1EiShomu2 > 100) {
            throw new IOException("Cannot read metadata.");
        }
        keil1eishomu.thooCoci9zae(6);
        int i = 0;
        while (true) {
            if (i >= keiL1EiShomu2) {
                j = -1;
                break;
            }
            int ieheiQu9sho52 = keil1eishomu.ieheiQu9sho5();
            keil1eishomu.thooCoci9zae(4);
            j = keil1eishomu.ieseir3Choge();
            keil1eishomu.thooCoci9zae(4);
            if (1835365473 == ieheiQu9sho52) {
                break;
            }
            i++;
        }
        if (j != -1) {
            keil1eishomu.thooCoci9zae((int) (j - keil1eishomu.kuedujio7Aev()));
            keil1eishomu.thooCoci9zae(12);
            long ieseir3Choge2 = keil1eishomu.ieseir3Choge();
            for (int i2 = 0; i2 < ieseir3Choge2; i2++) {
                int ieheiQu9sho53 = keil1eishomu.ieheiQu9sho5();
                long ieseir3Choge3 = keil1eishomu.ieseir3Choge();
                long ieseir3Choge4 = keil1eishomu.ieseir3Choge();
                if (1164798569 == ieheiQu9sho53 || 1701669481 == ieheiQu9sho53) {
                    return new thooCoci9zae(ieseir3Choge3 + j, ieseir3Choge4);
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    public static long keiL1EiShomu(int i) {
        return i & 4294967295L;
    }

    public static Nieyie8tecah.thooCoci9zae thooCoci9zae(ByteBuffer byteBuffer) {
        ByteBuffer duplicate = byteBuffer.duplicate();
        duplicate.position((int) ieseir3Choge(new ieseir3Choge(duplicate)).ieseir3Choge());
        return Nieyie8tecah.thooCoci9zae.niah0Shohtha(duplicate);
    }
}
