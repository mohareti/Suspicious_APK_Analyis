package androidx.emoji2.text;

import android.text.TextPaint;
import androidx.emoji2.text.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class kuedujio7Aev implements Aicohm8ieYoo.kuedujio7Aev {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ThreadLocal f3379thooCoci9zae = new ThreadLocal();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final TextPaint f3380ieseir3Choge;

    public kuedujio7Aev() {
        TextPaint textPaint = new TextPaint();
        this.f3380ieseir3Choge = textPaint;
        textPaint.setTextSize(10.0f);
    }

    public static StringBuilder thooCoci9zae() {
        ThreadLocal threadLocal = f3379thooCoci9zae;
        if (threadLocal.get() == null) {
            threadLocal.set(new StringBuilder());
        }
        return (StringBuilder) threadLocal.get();
    }

    @Override // androidx.emoji2.text.Aicohm8ieYoo.kuedujio7Aev
    public boolean ieseir3Choge(CharSequence charSequence, int i, int i2, int i3) {
        StringBuilder thooCoci9zae2 = thooCoci9zae();
        thooCoci9zae2.setLength(0);
        while (i < i2) {
            thooCoci9zae2.append(charSequence.charAt(i));
            i++;
        }
        return eetheKaevie8.Jah0aiP1ki6y.ieseir3Choge(this.f3380ieseir3Choge, thooCoci9zae2.toString());
    }
}
