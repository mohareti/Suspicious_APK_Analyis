package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import java.nio.ByteBuffer;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ruwiepo7ooVu {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Typeface f3417ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Nieyie8tecah.thooCoci9zae f3418ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final ieseir3Choge f3419keiL1EiShomu = new ieseir3Choge(1024);

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final char[] f3420thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final SparseArray f3421ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public oYe2ma2she1j f3422thooCoci9zae;

        public ieseir3Choge() {
            this(1);
        }

        public ieseir3Choge ieseir3Choge(int i) {
            SparseArray sparseArray = this.f3421ieseir3Choge;
            if (sparseArray == null) {
                return null;
            }
            return (ieseir3Choge) sparseArray.get(i);
        }

        public void keiL1EiShomu(oYe2ma2she1j oye2ma2she1j, int i, int i2) {
            ieseir3Choge ieseir3Choge2 = ieseir3Choge(oye2ma2she1j.thooCoci9zae(i));
            if (ieseir3Choge2 == null) {
                ieseir3Choge2 = new ieseir3Choge();
                this.f3421ieseir3Choge.put(oye2ma2she1j.thooCoci9zae(i), ieseir3Choge2);
            }
            if (i2 > i) {
                ieseir3Choge2.keiL1EiShomu(oye2ma2she1j, i + 1, i2);
            } else {
                ieseir3Choge2.f3422thooCoci9zae = oye2ma2she1j;
            }
        }

        public final oYe2ma2she1j thooCoci9zae() {
            return this.f3422thooCoci9zae;
        }

        public ieseir3Choge(int i) {
            this.f3421ieseir3Choge = new SparseArray(i);
        }
    }

    public ruwiepo7ooVu(Typeface typeface, Nieyie8tecah.thooCoci9zae thoococi9zae) {
        this.f3417ieheiQu9sho5 = typeface;
        this.f3418ieseir3Choge = thoococi9zae;
        this.f3420thooCoci9zae = new char[thoococi9zae.ruNgecai1pae() * 2];
        ieseir3Choge(thoococi9zae);
    }

    public static ruwiepo7ooVu thooCoci9zae(Typeface typeface, ByteBuffer byteBuffer) {
        try {
            rojaiZ9aeRee.ahthoK6usais.ieseir3Choge("EmojiCompat.MetadataRepo.create");
            return new ruwiepo7ooVu(typeface, mi5Iecheimie.thooCoci9zae(byteBuffer));
        } finally {
            rojaiZ9aeRee.ahthoK6usais.thooCoci9zae();
        }
    }

    public ieseir3Choge Aicohm8ieYoo() {
        return this.f3419keiL1EiShomu;
    }

    public Typeface Jah0aiP1ki6y() {
        return this.f3417ieheiQu9sho5;
    }

    public Nieyie8tecah.thooCoci9zae ieheiQu9sho5() {
        return this.f3418ieseir3Choge;
    }

    public final void ieseir3Choge(Nieyie8tecah.thooCoci9zae thoococi9zae) {
        int ruNgecai1pae2 = thoococi9zae.ruNgecai1pae();
        for (int i = 0; i < ruNgecai1pae2; i++) {
            oYe2ma2she1j oye2ma2she1j = new oYe2ma2she1j(this, i);
            Character.toChars(oye2ma2she1j.Aicohm8ieYoo(), this.f3420thooCoci9zae, i * 2);
            niah0Shohtha(oye2ma2she1j);
        }
    }

    public char[] keiL1EiShomu() {
        return this.f3420thooCoci9zae;
    }

    public int kuedujio7Aev() {
        return this.f3418ieseir3Choge.ahthoK6usais();
    }

    public void niah0Shohtha(oYe2ma2she1j oye2ma2she1j) {
        ohthie9thieG.ieheiQu9sho5.kuedujio7Aev(oye2ma2she1j, "emoji metadata cannot be null");
        ohthie9thieG.ieheiQu9sho5.ieseir3Choge(oye2ma2she1j.keiL1EiShomu() > 0, "invalid metadata codepoint length");
        this.f3419keiL1EiShomu.keiL1EiShomu(oye2ma2she1j, 0, oye2ma2she1j.keiL1EiShomu() - 1);
    }
}
