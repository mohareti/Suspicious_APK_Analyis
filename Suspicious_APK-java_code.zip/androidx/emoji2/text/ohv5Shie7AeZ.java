package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import androidx.emoji2.text.Aicohm8ieYoo;
import androidx.emoji2.text.ruwiepo7ooVu;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ohv5Shie7AeZ {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final boolean f3390ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Aicohm8ieYoo.ko7aiFeiqu3s f3391ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public Aicohm8ieYoo.kuedujio7Aev f3392keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final int[] f3393kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ruwiepo7ooVu f3394thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieheiQu9sho5 implements keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f3395ieseir3Choge;

        public ieheiQu9sho5(String str) {
            this.f3395ieseir3Choge = str;
        }

        @Override // androidx.emoji2.text.ohv5Shie7AeZ.keiL1EiShomu
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public ieheiQu9sho5 ieseir3Choge() {
            return this;
        }

        @Override // androidx.emoji2.text.ohv5Shie7AeZ.keiL1EiShomu
        public boolean thooCoci9zae(CharSequence charSequence, int i, int i2, oYe2ma2she1j oye2ma2she1j) {
            if (!TextUtils.equals(charSequence.subSequence(i, i2), this.f3395ieseir3Choge)) {
                return true;
            }
            oye2ma2she1j.ahthoK6usais(true);
            return false;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {
        public static int ieseir3Choge(CharSequence charSequence, int i, int i2) {
            int length = charSequence.length();
            if (i < 0 || length < i || i2 < 0) {
                return -1;
            }
            while (true) {
                boolean z = false;
                while (i2 != 0) {
                    i--;
                    if (i < 0) {
                        return z ? -1 : 0;
                    }
                    char charAt = charSequence.charAt(i);
                    if (z) {
                        if (!Character.isHighSurrogate(charAt)) {
                            return -1;
                        }
                        i2--;
                    } else if (!Character.isSurrogate(charAt)) {
                        i2--;
                    } else {
                        if (Character.isHighSurrogate(charAt)) {
                            return -1;
                        }
                        z = true;
                    }
                }
                return i;
            }
        }

        public static int thooCoci9zae(CharSequence charSequence, int i, int i2) {
            int length = charSequence.length();
            if (i < 0 || length < i || i2 < 0) {
                return -1;
            }
            while (true) {
                boolean z = false;
                while (i2 != 0) {
                    if (i >= length) {
                        if (z) {
                            return -1;
                        }
                        return length;
                    }
                    char charAt = charSequence.charAt(i);
                    if (z) {
                        if (!Character.isLowSurrogate(charAt)) {
                            return -1;
                        }
                        i2--;
                        i++;
                    } else if (!Character.isSurrogate(charAt)) {
                        i2--;
                        i++;
                    } else {
                        if (Character.isLowSurrogate(charAt)) {
                            return -1;
                        }
                        i++;
                        z = true;
                    }
                }
                return i;
            }
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface keiL1EiShomu {
        Object ieseir3Choge();

        boolean thooCoci9zae(CharSequence charSequence, int i, int i2, oYe2ma2she1j oye2ma2she1j);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class kuedujio7Aev {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public int f3396Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public final boolean f3397Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public ruwiepo7ooVu.ieseir3Choge f3398ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public int f3399ieseir3Choge = 1;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public ruwiepo7ooVu.ieseir3Choge f3400keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public int f3401kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public final int[] f3402niah0Shohtha;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final ruwiepo7ooVu.ieseir3Choge f3403thooCoci9zae;

        public kuedujio7Aev(ruwiepo7ooVu.ieseir3Choge ieseir3choge, boolean z, int[] iArr) {
            this.f3403thooCoci9zae = ieseir3choge;
            this.f3400keiL1EiShomu = ieseir3choge;
            this.f3397Jah0aiP1ki6y = z;
            this.f3402niah0Shohtha = iArr;
        }

        public static boolean Aicohm8ieYoo(int i) {
            return i == 65038;
        }

        public static boolean ieheiQu9sho5(int i) {
            return i == 65039;
        }

        public final int Jah0aiP1ki6y() {
            this.f3399ieseir3Choge = 1;
            this.f3400keiL1EiShomu = this.f3403thooCoci9zae;
            this.f3396Aicohm8ieYoo = 0;
            return 1;
        }

        public int ieseir3Choge(int i) {
            ruwiepo7ooVu.ieseir3Choge ieseir3Choge2 = this.f3400keiL1EiShomu.ieseir3Choge(i);
            int i2 = 2;
            if (this.f3399ieseir3Choge != 2) {
                if (ieseir3Choge2 != null) {
                    this.f3399ieseir3Choge = 2;
                    this.f3400keiL1EiShomu = ieseir3Choge2;
                    this.f3396Aicohm8ieYoo = 1;
                }
                i2 = Jah0aiP1ki6y();
            } else if (ieseir3Choge2 != null) {
                this.f3400keiL1EiShomu = ieseir3Choge2;
                this.f3396Aicohm8ieYoo++;
            } else {
                if (!Aicohm8ieYoo(i)) {
                    if (!ieheiQu9sho5(i)) {
                        if (this.f3400keiL1EiShomu.thooCoci9zae() != null) {
                            i2 = 3;
                            if (this.f3396Aicohm8ieYoo != 1 || niah0Shohtha()) {
                                this.f3398ieheiQu9sho5 = this.f3400keiL1EiShomu;
                                Jah0aiP1ki6y();
                            }
                        }
                    }
                }
                i2 = Jah0aiP1ki6y();
            }
            this.f3401kuedujio7Aev = i;
            return i2;
        }

        public oYe2ma2she1j keiL1EiShomu() {
            return this.f3398ieheiQu9sho5.thooCoci9zae();
        }

        public boolean kuedujio7Aev() {
            return this.f3399ieseir3Choge == 2 && this.f3400keiL1EiShomu.thooCoci9zae() != null && (this.f3396Aicohm8ieYoo > 1 || niah0Shohtha());
        }

        public final boolean niah0Shohtha() {
            if (this.f3400keiL1EiShomu.thooCoci9zae().ko7aiFeiqu3s() || ieheiQu9sho5(this.f3401kuedujio7Aev)) {
                return true;
            }
            if (this.f3397Jah0aiP1ki6y) {
                if (this.f3402niah0Shohtha == null) {
                    return true;
                }
                if (Arrays.binarySearch(this.f3402niah0Shohtha, this.f3400keiL1EiShomu.thooCoci9zae().thooCoci9zae(0)) < 0) {
                    return true;
                }
            }
            return false;
        }

        public oYe2ma2she1j thooCoci9zae() {
            return this.f3400keiL1EiShomu.thooCoci9zae();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class thooCoci9zae implements keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public laej2zeez5Ja f3404ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Aicohm8ieYoo.ko7aiFeiqu3s f3405thooCoci9zae;

        public thooCoci9zae(laej2zeez5Ja laej2zeez5ja, Aicohm8ieYoo.ko7aiFeiqu3s ko7aifeiqu3s) {
            this.f3404ieseir3Choge = laej2zeez5ja;
            this.f3405thooCoci9zae = ko7aifeiqu3s;
        }

        @Override // androidx.emoji2.text.ohv5Shie7AeZ.keiL1EiShomu
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public laej2zeez5Ja ieseir3Choge() {
            return this.f3404ieseir3Choge;
        }

        @Override // androidx.emoji2.text.ohv5Shie7AeZ.keiL1EiShomu
        public boolean thooCoci9zae(CharSequence charSequence, int i, int i2, oYe2ma2she1j oye2ma2she1j) {
            if (oye2ma2she1j.ruNgecai1pae()) {
                return true;
            }
            if (this.f3404ieseir3Choge == null) {
                this.f3404ieseir3Choge = new laej2zeez5Ja(charSequence instanceof Spannable ? (Spannable) charSequence : new SpannableString(charSequence));
            }
            this.f3404ieseir3Choge.setSpan(this.f3405thooCoci9zae.ieseir3Choge(oye2ma2she1j), i, i2, 33);
            return true;
        }
    }

    public ohv5Shie7AeZ(ruwiepo7ooVu ruwiepo7oovu, Aicohm8ieYoo.ko7aiFeiqu3s ko7aifeiqu3s, Aicohm8ieYoo.kuedujio7Aev kuedujio7aev, boolean z, int[] iArr, Set set) {
        this.f3391ieseir3Choge = ko7aifeiqu3s;
        this.f3394thooCoci9zae = ruwiepo7oovu;
        this.f3392keiL1EiShomu = kuedujio7aev;
        this.f3390ieheiQu9sho5 = z;
        this.f3393kuedujio7Aev = iArr;
        Jah0aiP1ki6y(set);
    }

    public static boolean Aicohm8ieYoo(KeyEvent keyEvent) {
        return !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState());
    }

    public static boolean ieseir3Choge(Editable editable, KeyEvent keyEvent, boolean z) {
        ko7aiFeiqu3s[] ko7aifeiqu3sArr;
        if (Aicohm8ieYoo(keyEvent)) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (!kuedujio7Aev(selectionStart, selectionEnd) && (ko7aifeiqu3sArr = (ko7aiFeiqu3s[]) editable.getSpans(selectionStart, selectionEnd, ko7aiFeiqu3s.class)) != null && ko7aifeiqu3sArr.length > 0) {
            for (ko7aiFeiqu3s ko7aifeiqu3s : ko7aifeiqu3sArr) {
                int spanStart = editable.getSpanStart(ko7aifeiqu3s);
                int spanEnd = editable.getSpanEnd(ko7aifeiqu3s);
                if ((z && spanStart == selectionStart) || ((!z && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean keiL1EiShomu(Editable editable, int i, KeyEvent keyEvent) {
        if (!(i != 67 ? i != 112 ? false : ieseir3Choge(editable, keyEvent, true) : ieseir3Choge(editable, keyEvent, false))) {
            return false;
        }
        MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
        return true;
    }

    public static boolean kuedujio7Aev(int i, int i2) {
        return i == -1 || i2 == -1 || i != i2;
    }

    public static boolean thooCoci9zae(InputConnection inputConnection, Editable editable, int i, int i2, boolean z) {
        int max;
        int min;
        if (editable != null && inputConnection != null && i >= 0 && i2 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (kuedujio7Aev(selectionStart, selectionEnd)) {
                return false;
            }
            if (z) {
                max = ieseir3Choge.ieseir3Choge(editable, selectionStart, Math.max(i, 0));
                min = ieseir3Choge.thooCoci9zae(editable, selectionEnd, Math.max(i2, 0));
                if (max == -1 || min == -1) {
                    return false;
                }
            } else {
                max = Math.max(selectionStart - i, 0);
                min = Math.min(selectionEnd + i2, editable.length());
            }
            ko7aiFeiqu3s[] ko7aifeiqu3sArr = (ko7aiFeiqu3s[]) editable.getSpans(max, min, ko7aiFeiqu3s.class);
            if (ko7aifeiqu3sArr != null && ko7aifeiqu3sArr.length > 0) {
                for (ko7aiFeiqu3s ko7aifeiqu3s : ko7aifeiqu3sArr) {
                    int spanStart = editable.getSpanStart(ko7aifeiqu3s);
                    int spanEnd = editable.getSpanEnd(ko7aifeiqu3s);
                    max = Math.min(spanStart, max);
                    min = Math.max(spanEnd, min);
                }
                int max2 = Math.max(max, 0);
                int min2 = Math.min(min, editable.length());
                inputConnection.beginBatchEdit();
                editable.delete(max2, min2);
                inputConnection.endBatchEdit();
                return true;
            }
        }
        return false;
    }

    public final void Jah0aiP1ki6y(Set set) {
        if (set.isEmpty()) {
            return;
        }
        Iterator it = set.iterator();
        while (it.hasNext()) {
            int[] iArr = (int[]) it.next();
            String str = new String(iArr, 0, iArr.length);
            ohv5Shie7AeZ(str, 0, str.length(), 1, true, new ieheiQu9sho5(str));
        }
    }

    public final boolean ieheiQu9sho5(CharSequence charSequence, int i, int i2, oYe2ma2she1j oye2ma2she1j) {
        if (oye2ma2she1j.ieheiQu9sho5() == 0) {
            oye2ma2she1j.mi5Iecheimie(this.f3392keiL1EiShomu.ieseir3Choge(charSequence, i, i2, oye2ma2she1j.niah0Shohtha()));
        }
        return oye2ma2she1j.ieheiQu9sho5() == 2;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0049 A[Catch: all -> 0x002a, TryCatch #0 {all -> 0x002a, blocks: (B:51:0x000e, B:54:0x0013, B:56:0x0017, B:58:0x0024, B:9:0x003a, B:11:0x0042, B:13:0x0045, B:15:0x0049, B:17:0x0055, B:19:0x0058, B:24:0x0066, B:30:0x0074, B:31:0x0080, B:33:0x0094, B:6:0x002f), top: B:50:0x000e }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0094 A[Catch: all -> 0x002a, TRY_LEAVE, TryCatch #0 {all -> 0x002a, blocks: (B:51:0x000e, B:54:0x0013, B:56:0x0017, B:58:0x0024, B:9:0x003a, B:11:0x0042, B:13:0x0045, B:15:0x0049, B:17:0x0055, B:19:0x0058, B:24:0x0066, B:30:0x0074, B:31:0x0080, B:33:0x0094, B:6:0x002f), top: B:50:0x000e }] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00a0  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public CharSequence niah0Shohtha(CharSequence charSequence, int i, int i2, int i3, boolean z) {
        laej2zeez5Ja laej2zeez5ja;
        int i4;
        laej2zeez5Ja laej2zeez5ja2;
        ko7aiFeiqu3s[] ko7aifeiqu3sArr;
        boolean z2 = charSequence instanceof AeJiPo4of6Sh;
        if (z2) {
            ((AeJiPo4of6Sh) charSequence).ieseir3Choge();
        }
        if (!z2) {
            try {
                if (!(charSequence instanceof Spannable)) {
                    laej2zeez5ja = (!(charSequence instanceof Spanned) || ((Spanned) charSequence).nextSpanTransition(i + (-1), i2 + 1, ko7aiFeiqu3s.class) > i2) ? null : new laej2zeez5Ja(charSequence);
                    if (laej2zeez5ja != null && (ko7aifeiqu3sArr = (ko7aiFeiqu3s[]) laej2zeez5ja.getSpans(i, i2, ko7aiFeiqu3s.class)) != null && ko7aifeiqu3sArr.length > 0) {
                        for (ko7aiFeiqu3s ko7aifeiqu3s : ko7aifeiqu3sArr) {
                            int spanStart = laej2zeez5ja.getSpanStart(ko7aifeiqu3s);
                            int spanEnd = laej2zeez5ja.getSpanEnd(ko7aifeiqu3s);
                            if (spanStart != i2) {
                                laej2zeez5ja.removeSpan(ko7aifeiqu3s);
                            }
                            i = Math.min(spanStart, i);
                            i2 = Math.max(spanEnd, i2);
                        }
                    }
                    i4 = i2;
                    if (i != i4 && i < charSequence.length()) {
                        if (i3 != Integer.MAX_VALUE && laej2zeez5ja != null) {
                            i3 -= ((ko7aiFeiqu3s[]) laej2zeez5ja.getSpans(0, laej2zeez5ja.length(), ko7aiFeiqu3s.class)).length;
                        }
                        laej2zeez5ja2 = (laej2zeez5Ja) ohv5Shie7AeZ(charSequence, i, i4, i3, z, new thooCoci9zae(laej2zeez5ja, this.f3391ieseir3Choge));
                        if (laej2zeez5ja2 != null) {
                            if (z2) {
                                ((AeJiPo4of6Sh) charSequence).ieheiQu9sho5();
                            }
                            return charSequence;
                        }
                        Spannable thooCoci9zae2 = laej2zeez5ja2.thooCoci9zae();
                        if (z2) {
                            ((AeJiPo4of6Sh) charSequence).ieheiQu9sho5();
                        }
                        return thooCoci9zae2;
                    }
                    return charSequence;
                }
            } finally {
                if (z2) {
                    ((AeJiPo4of6Sh) charSequence).ieheiQu9sho5();
                }
            }
        }
        laej2zeez5ja = new laej2zeez5Ja((Spannable) charSequence);
        if (laej2zeez5ja != null) {
            while (r6 < r5) {
            }
        }
        i4 = i2;
        if (i != i4) {
            if (i3 != Integer.MAX_VALUE) {
                i3 -= ((ko7aiFeiqu3s[]) laej2zeez5ja.getSpans(0, laej2zeez5ja.length(), ko7aiFeiqu3s.class)).length;
            }
            laej2zeez5ja2 = (laej2zeez5Ja) ohv5Shie7AeZ(charSequence, i, i4, i3, z, new thooCoci9zae(laej2zeez5ja, this.f3391ieseir3Choge));
            if (laej2zeez5ja2 != null) {
            }
        }
        return charSequence;
    }

    public final Object ohv5Shie7AeZ(CharSequence charSequence, int i, int i2, int i3, boolean z, keiL1EiShomu keil1eishomu) {
        int i4;
        kuedujio7Aev kuedujio7aev = new kuedujio7Aev(this.f3394thooCoci9zae.Aicohm8ieYoo(), this.f3390ieheiQu9sho5, this.f3393kuedujio7Aev);
        int i5 = 0;
        boolean z2 = true;
        int codePointAt = Character.codePointAt(charSequence, i);
        loop0: while (true) {
            i4 = i;
            while (i < i2 && i5 < i3 && z2) {
                int ieseir3Choge2 = kuedujio7aev.ieseir3Choge(codePointAt);
                if (ieseir3Choge2 == 1) {
                    i4 += Character.charCount(Character.codePointAt(charSequence, i4));
                    if (i4 < i2) {
                        codePointAt = Character.codePointAt(charSequence, i4);
                    }
                    i = i4;
                } else if (ieseir3Choge2 == 2) {
                    i += Character.charCount(codePointAt);
                    if (i < i2) {
                        codePointAt = Character.codePointAt(charSequence, i);
                    }
                } else if (ieseir3Choge2 == 3) {
                    if (z || !ieheiQu9sho5(charSequence, i4, i, kuedujio7aev.keiL1EiShomu())) {
                        z2 = keil1eishomu.thooCoci9zae(charSequence, i4, i, kuedujio7aev.keiL1EiShomu());
                        i5++;
                    }
                }
            }
        }
        if (kuedujio7aev.kuedujio7Aev() && i5 < i3 && z2 && (z || !ieheiQu9sho5(charSequence, i4, i, kuedujio7aev.thooCoci9zae()))) {
            keil1eishomu.thooCoci9zae(charSequence, i4, i, kuedujio7aev.thooCoci9zae());
        }
        return keil1eishomu.ieseir3Choge();
    }
}
