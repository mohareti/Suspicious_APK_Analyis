package Mudeexooxai0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class kuedujio7Aev extends ieheiQu9sho5 {
    public static int ieseir3Choge(int i, int i2) {
        if (i < i2) {
            return i2;
        }
        return i;
    }

    public static ieseir3Choge keiL1EiShomu(int i, int i2) {
        return ieseir3Choge.f1678Jah0aiP1ki6y.ieseir3Choge(i, i2, -1);
    }

    public static int thooCoci9zae(int i, int i2) {
        if (i > i2) {
            return i2;
        }
        return i;
    }
}
