package vaeVoh2dei5I;

import java.util.concurrent.Callable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ahk3OhSh9Ree implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ Uz0ahGh4yook f8226ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ Callable f8227kuedujio7Aev;

    public ahk3OhSh9Ree(Uz0ahGh4yook uz0ahGh4yook, Callable callable) {
        this.f8226ieheiQu9sho5 = uz0ahGh4yook;
        this.f8227kuedujio7Aev = callable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            this.f8226ieheiQu9sho5.aac1eTaexee6(this.f8227kuedujio7Aev.call());
        } catch (Exception e) {
            this.f8226ieheiQu9sho5.zoojiiKaht3i(e);
        } catch (Throwable th) {
            this.f8226ieheiQu9sho5.zoojiiKaht3i(new RuntimeException(th));
        }
    }
}
