package vaeVoh2dei5I;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ruwiepo7ooVu implements AeJiPo4of6Sh {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final CountDownLatch f8252ieseir3Choge = new CountDownLatch(1);

    public /* synthetic */ ruwiepo7ooVu(mi5Iecheimie mi5iecheimie) {
    }

    @Override // vaeVoh2dei5I.Aicohm8ieYoo
    public final void ieheiQu9sho5(Object obj) {
        this.f8252ieseir3Choge.countDown();
    }

    @Override // vaeVoh2dei5I.keiL1EiShomu
    public final void ieseir3Choge() {
        this.f8252ieseir3Choge.countDown();
    }

    @Override // vaeVoh2dei5I.kuedujio7Aev
    public final void keiL1EiShomu(Exception exc) {
        this.f8252ieseir3Choge.countDown();
    }

    public final boolean kuedujio7Aev(long j, TimeUnit timeUnit) {
        return this.f8252ieseir3Choge.await(j, timeUnit);
    }

    public final void thooCoci9zae() {
        this.f8252ieseir3Choge.await();
    }
}
