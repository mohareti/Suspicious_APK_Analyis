package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class oYe2ma2she1j implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ ohv5Shie7AeZ f8240ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ eetheKaevie8 f8241kuedujio7Aev;

    public oYe2ma2she1j(eetheKaevie8 eethekaevie8, ohv5Shie7AeZ ohv5shie7aez) {
        this.f8241kuedujio7Aev = eethekaevie8;
        this.f8240ieheiQu9sho5 = ohv5shie7aez;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Uz0ahGh4yook uz0ahGh4yook;
        Uz0ahGh4yook uz0ahGh4yook2;
        Uz0ahGh4yook uz0ahGh4yook3;
        ieseir3Choge ieseir3choge;
        Uz0ahGh4yook uz0ahGh4yook4;
        Uz0ahGh4yook uz0ahGh4yook5;
        if (this.f8240ieheiQu9sho5.mi5Iecheimie()) {
            uz0ahGh4yook5 = this.f8241kuedujio7Aev.f8231keiL1EiShomu;
            uz0ahGh4yook5.laej2zeez5Ja();
            return;
        }
        try {
            ieseir3choge = this.f8241kuedujio7Aev.f8232thooCoci9zae;
            Object ieseir3Choge2 = ieseir3choge.ieseir3Choge(this.f8240ieheiQu9sho5);
            uz0ahGh4yook4 = this.f8241kuedujio7Aev.f8231keiL1EiShomu;
            uz0ahGh4yook4.aac1eTaexee6(ieseir3Choge2);
        } catch (Jah0aiP1ki6y e) {
            if (e.getCause() instanceof Exception) {
                uz0ahGh4yook3 = this.f8241kuedujio7Aev.f8231keiL1EiShomu;
                uz0ahGh4yook3.zoojiiKaht3i((Exception) e.getCause());
            } else {
                uz0ahGh4yook2 = this.f8241kuedujio7Aev.f8231keiL1EiShomu;
                uz0ahGh4yook2.zoojiiKaht3i(e);
            }
        } catch (Exception e2) {
            uz0ahGh4yook = this.f8241kuedujio7Aev.f8231keiL1EiShomu;
            uz0ahGh4yook.zoojiiKaht3i(e2);
        }
    }
}
