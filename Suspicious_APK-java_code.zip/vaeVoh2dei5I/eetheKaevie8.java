package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eetheKaevie8 implements kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8230ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Uz0ahGh4yook f8231keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ieseir3Choge f8232thooCoci9zae;

    public eetheKaevie8(Executor executor, ieseir3Choge ieseir3choge, Uz0ahGh4yook uz0ahGh4yook) {
        this.f8230ieseir3Choge = executor;
        this.f8232thooCoci9zae = ieseir3choge;
        this.f8231keiL1EiShomu = uz0ahGh4yook;
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        this.f8230ieseir3Choge.execute(new oYe2ma2she1j(this, ohv5shie7aez));
    }
}
