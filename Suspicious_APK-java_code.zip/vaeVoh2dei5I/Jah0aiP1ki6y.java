package vaeVoh2dei5I;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Jah0aiP1ki6y extends RuntimeException {
    public Jah0aiP1ki6y(Throwable th) {
        super(th);
    }
}
