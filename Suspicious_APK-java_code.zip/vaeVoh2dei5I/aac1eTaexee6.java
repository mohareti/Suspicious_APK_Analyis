package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class aac1eTaexee6 implements Aicohm8ieYoo, kuedujio7Aev, keiL1EiShomu, kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8223ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Uz0ahGh4yook f8224keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ieseir3Choge f8225thooCoci9zae;

    public aac1eTaexee6(Executor executor, ieseir3Choge ieseir3choge, Uz0ahGh4yook uz0ahGh4yook) {
        this.f8223ieseir3Choge = executor;
        this.f8225thooCoci9zae = ieseir3choge;
        this.f8224keiL1EiShomu = uz0ahGh4yook;
    }

    @Override // vaeVoh2dei5I.Aicohm8ieYoo
    public final void ieheiQu9sho5(Object obj) {
        this.f8224keiL1EiShomu.aac1eTaexee6(obj);
    }

    @Override // vaeVoh2dei5I.keiL1EiShomu
    public final void ieseir3Choge() {
        this.f8224keiL1EiShomu.laej2zeez5Ja();
    }

    @Override // vaeVoh2dei5I.kuedujio7Aev
    public final void keiL1EiShomu(Exception exc) {
        this.f8224keiL1EiShomu.zoojiiKaht3i(exc);
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        this.f8223ieseir3Choge.execute(new zoojiiKaht3i(this, ohv5shie7aez));
    }
}
