package vaeVoh2dei5I;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ahz5eechei8U implements Runnable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final /* synthetic */ ohv5Shie7AeZ f8228ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final /* synthetic */ Phae5ooG6hah f8229kuedujio7Aev;

    public ahz5eechei8U(Phae5ooG6hah phae5ooG6hah, ohv5Shie7AeZ ohv5shie7aez) {
        this.f8229kuedujio7Aev = phae5ooG6hah;
        this.f8228ieheiQu9sho5 = ohv5shie7aez;
    }

    @Override // java.lang.Runnable
    public final void run() {
        niah0Shohtha niah0shohtha;
        try {
            niah0shohtha = this.f8229kuedujio7Aev.f8216thooCoci9zae;
            ohv5Shie7AeZ ieseir3Choge2 = niah0shohtha.ieseir3Choge(this.f8228ieheiQu9sho5.ruNgecai1pae());
            if (ieseir3Choge2 == null) {
                this.f8229kuedujio7Aev.keiL1EiShomu(new NullPointerException("Continuation returned null"));
                return;
            }
            Phae5ooG6hah phae5ooG6hah = this.f8229kuedujio7Aev;
            Executor executor = ruNgecai1pae.f8251thooCoci9zae;
            ieseir3Choge2.Aicohm8ieYoo(executor, phae5ooG6hah);
            ieseir3Choge2.ieheiQu9sho5(executor, this.f8229kuedujio7Aev);
            ieseir3Choge2.ieseir3Choge(executor, this.f8229kuedujio7Aev);
        } catch (CancellationException unused) {
            this.f8229kuedujio7Aev.ieseir3Choge();
        } catch (Jah0aiP1ki6y e) {
            if (e.getCause() instanceof Exception) {
                this.f8229kuedujio7Aev.keiL1EiShomu((Exception) e.getCause());
            } else {
                this.f8229kuedujio7Aev.keiL1EiShomu(e);
            }
        } catch (Exception e2) {
            this.f8229kuedujio7Aev.keiL1EiShomu(e2);
        }
    }
}
