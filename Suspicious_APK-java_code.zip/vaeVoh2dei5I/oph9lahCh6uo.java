package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class oph9lahCh6uo implements kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8244ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public ieheiQu9sho5 f8245keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Object f8246thooCoci9zae = new Object();

    public oph9lahCh6uo(Executor executor, ieheiQu9sho5 ieheiqu9sho5) {
        this.f8244ieseir3Choge = executor;
        this.f8245keiL1EiShomu = ieheiqu9sho5;
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        synchronized (this.f8246thooCoci9zae) {
            try {
                if (this.f8245keiL1EiShomu == null) {
                    return;
                }
                this.f8244ieseir3Choge.execute(new esohshee3Pau(this, ohv5shie7aez));
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
