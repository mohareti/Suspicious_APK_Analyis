package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Phae5ooG6hah implements Aicohm8ieYoo, kuedujio7Aev, keiL1EiShomu, kah6Uo2ooji4 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Executor f8214ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Uz0ahGh4yook f8215keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final niah0Shohtha f8216thooCoci9zae;

    public Phae5ooG6hah(Executor executor, niah0Shohtha niah0shohtha, Uz0ahGh4yook uz0ahGh4yook) {
        this.f8214ieseir3Choge = executor;
        this.f8216thooCoci9zae = niah0shohtha;
        this.f8215keiL1EiShomu = uz0ahGh4yook;
    }

    @Override // vaeVoh2dei5I.Aicohm8ieYoo
    public final void ieheiQu9sho5(Object obj) {
        this.f8215keiL1EiShomu.aac1eTaexee6(obj);
    }

    @Override // vaeVoh2dei5I.keiL1EiShomu
    public final void ieseir3Choge() {
        this.f8215keiL1EiShomu.laej2zeez5Ja();
    }

    @Override // vaeVoh2dei5I.kuedujio7Aev
    public final void keiL1EiShomu(Exception exc) {
        this.f8215keiL1EiShomu.zoojiiKaht3i(exc);
    }

    @Override // vaeVoh2dei5I.kah6Uo2ooji4
    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        this.f8214ieseir3Choge.execute(new ahz5eechei8U(this, ohv5shie7aez));
    }
}
