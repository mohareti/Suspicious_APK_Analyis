package vaeVoh2dei5I;

import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Uz0ahGh4yook extends ohv5Shie7AeZ {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public Exception f8217Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public volatile boolean f8218ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public boolean f8220keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public Object f8221kuedujio7Aev;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Object f8219ieseir3Choge = new Object();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final IengaiSahh8H f8222thooCoci9zae = new IengaiSahh8H();

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final boolean AeJiPo4of6Sh() {
        boolean z;
        synchronized (this.f8219ieseir3Choge) {
            try {
                z = false;
                if (this.f8220keiL1EiShomu && !this.f8218ieheiQu9sho5 && this.f8217Aicohm8ieYoo == null) {
                    z = true;
                }
            } finally {
            }
        }
        return z;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ Aicohm8ieYoo(Executor executor, Aicohm8ieYoo aicohm8ieYoo) {
        this.f8222thooCoci9zae.ieseir3Choge(new Ochoob6Ahvi2(executor, aicohm8ieYoo));
        Idohhaimaes0();
        return this;
    }

    public final void Idohhaimaes0() {
        synchronized (this.f8219ieseir3Choge) {
            try {
                if (!this.f8220keiL1EiShomu) {
                    return;
                }
                this.f8222thooCoci9zae.thooCoci9zae(this);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ Jah0aiP1ki6y(Aicohm8ieYoo aicohm8ieYoo) {
        Aicohm8ieYoo(ruNgecai1pae.f8250ieseir3Choge, aicohm8ieYoo);
        return this;
    }

    public final void aac1eTaexee6(Object obj) {
        synchronized (this.f8219ieseir3Choge) {
            eyei9eigh3Ie();
            this.f8220keiL1EiShomu = true;
            this.f8221kuedujio7Aev = obj;
        }
        this.f8222thooCoci9zae.thooCoci9zae(this);
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final Object ahthoK6usais(Class cls) {
        Object obj;
        synchronized (this.f8219ieseir3Choge) {
            try {
                oph9lahCh6uo();
                ohthie9thieG();
                if (!cls.isInstance(this.f8217Aicohm8ieYoo)) {
                    Exception exc = this.f8217Aicohm8ieYoo;
                    if (exc == null) {
                        obj = this.f8221kuedujio7Aev;
                    } else {
                        throw new Jah0aiP1ki6y(exc);
                    }
                } else {
                    throw ((Throwable) cls.cast(this.f8217Aicohm8ieYoo));
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return obj;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ eetheKaevie8(niah0Shohtha niah0shohtha) {
        Executor executor = ruNgecai1pae.f8250ieseir3Choge;
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        this.f8222thooCoci9zae.ieseir3Choge(new Phae5ooG6hah(executor, niah0shohtha, uz0ahGh4yook));
        Idohhaimaes0();
        return uz0ahGh4yook;
    }

    public final boolean esohshee3Pau(Object obj) {
        synchronized (this.f8219ieseir3Choge) {
            try {
                if (this.f8220keiL1EiShomu) {
                    return false;
                }
                this.f8220keiL1EiShomu = true;
                this.f8221kuedujio7Aev = obj;
                this.f8222thooCoci9zae.thooCoci9zae(this);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void eyei9eigh3Ie() {
        if (!this.f8220keiL1EiShomu) {
        } else {
            throw thooCoci9zae.ieseir3Choge(this);
        }
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ ieheiQu9sho5(Executor executor, kuedujio7Aev kuedujio7aev) {
        this.f8222thooCoci9zae.ieseir3Choge(new eyei9eigh3Ie(executor, kuedujio7aev));
        Idohhaimaes0();
        return this;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ ieseir3Choge(Executor executor, keiL1EiShomu keil1eishomu) {
        this.f8222thooCoci9zae.ieseir3Choge(new rojaiZ9aeRee(executor, keil1eishomu));
        Idohhaimaes0();
        return this;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ keiL1EiShomu(ieheiQu9sho5 ieheiqu9sho5) {
        this.f8222thooCoci9zae.ieseir3Choge(new oph9lahCh6uo(ruNgecai1pae.f8250ieseir3Choge, ieheiqu9sho5));
        Idohhaimaes0();
        return this;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final Exception ko7aiFeiqu3s() {
        Exception exc;
        synchronized (this.f8219ieseir3Choge) {
            exc = this.f8217Aicohm8ieYoo;
        }
        return exc;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ kuedujio7Aev(kuedujio7Aev kuedujio7aev) {
        ieheiQu9sho5(ruNgecai1pae.f8250ieseir3Choge, kuedujio7aev);
        return this;
    }

    public final boolean laej2zeez5Ja() {
        synchronized (this.f8219ieseir3Choge) {
            try {
                if (this.f8220keiL1EiShomu) {
                    return false;
                }
                this.f8220keiL1EiShomu = true;
                this.f8218ieheiQu9sho5 = true;
                this.f8222thooCoci9zae.thooCoci9zae(this);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final boolean mi5Iecheimie() {
        return this.f8218ieheiQu9sho5;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ niah0Shohtha(Executor executor, ieseir3Choge ieseir3choge) {
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        this.f8222thooCoci9zae.ieseir3Choge(new eetheKaevie8(executor, ieseir3choge, uz0ahGh4yook));
        Idohhaimaes0();
        return uz0ahGh4yook;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ oYe2ma2she1j(Executor executor, niah0Shohtha niah0shohtha) {
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        this.f8222thooCoci9zae.ieseir3Choge(new Phae5ooG6hah(executor, niah0shohtha, uz0ahGh4yook));
        Idohhaimaes0();
        return uz0ahGh4yook;
    }

    public final void ohthie9thieG() {
        if (!this.f8218ieheiQu9sho5) {
        } else {
            throw new CancellationException("Task is already canceled.");
        }
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ ohv5Shie7AeZ(Executor executor, ieseir3Choge ieseir3choge) {
        Uz0ahGh4yook uz0ahGh4yook = new Uz0ahGh4yook();
        this.f8222thooCoci9zae.ieseir3Choge(new aac1eTaexee6(executor, ieseir3choge, uz0ahGh4yook));
        Idohhaimaes0();
        return uz0ahGh4yook;
    }

    public final void oph9lahCh6uo() {
        Aebu8yohvea8.ruwiepo7ooVu.mi5Iecheimie(this.f8220keiL1EiShomu, "Task is not yet complete");
    }

    public final boolean rojaiZ9aeRee(Exception exc) {
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(exc, "Exception must not be null");
        synchronized (this.f8219ieseir3Choge) {
            try {
                if (this.f8220keiL1EiShomu) {
                    return false;
                }
                this.f8220keiL1EiShomu = true;
                this.f8217Aicohm8ieYoo = exc;
                this.f8222thooCoci9zae.thooCoci9zae(this);
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final Object ruNgecai1pae() {
        Object obj;
        synchronized (this.f8219ieseir3Choge) {
            try {
                oph9lahCh6uo();
                ohthie9thieG();
                Exception exc = this.f8217Aicohm8ieYoo;
                if (exc == null) {
                    obj = this.f8221kuedujio7Aev;
                } else {
                    throw new Jah0aiP1ki6y(exc);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
        return obj;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final boolean ruwiepo7ooVu() {
        boolean z;
        synchronized (this.f8219ieseir3Choge) {
            z = this.f8220keiL1EiShomu;
        }
        return z;
    }

    @Override // vaeVoh2dei5I.ohv5Shie7AeZ
    public final ohv5Shie7AeZ thooCoci9zae(Executor executor, ieheiQu9sho5 ieheiqu9sho5) {
        this.f8222thooCoci9zae.ieseir3Choge(new oph9lahCh6uo(executor, ieheiqu9sho5));
        Idohhaimaes0();
        return this;
    }

    public final void zoojiiKaht3i(Exception exc) {
        Aebu8yohvea8.ruwiepo7ooVu.ruNgecai1pae(exc, "Exception must not be null");
        synchronized (this.f8219ieseir3Choge) {
            eyei9eigh3Ie();
            this.f8220keiL1EiShomu = true;
            this.f8217Aicohm8ieYoo = exc;
        }
        this.f8222thooCoci9zae.thooCoci9zae(this);
    }
}
