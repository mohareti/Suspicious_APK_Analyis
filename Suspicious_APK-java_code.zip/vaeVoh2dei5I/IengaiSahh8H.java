package vaeVoh2dei5I;

import java.util.ArrayDeque;
import java.util.Queue;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class IengaiSahh8H {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Object f8207ieseir3Choge = new Object();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public boolean f8208keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public Queue f8209thooCoci9zae;

    public final void ieseir3Choge(kah6Uo2ooji4 kah6uo2ooji4) {
        synchronized (this.f8207ieseir3Choge) {
            try {
                if (this.f8209thooCoci9zae == null) {
                    this.f8209thooCoci9zae = new ArrayDeque();
                }
                this.f8209thooCoci9zae.add(kah6uo2ooji4);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void thooCoci9zae(ohv5Shie7AeZ ohv5shie7aez) {
        kah6Uo2ooji4 kah6uo2ooji4;
        synchronized (this.f8207ieseir3Choge) {
            if (this.f8209thooCoci9zae != null && !this.f8208keiL1EiShomu) {
                this.f8208keiL1EiShomu = true;
                while (true) {
                    synchronized (this.f8207ieseir3Choge) {
                        try {
                            kah6uo2ooji4 = (kah6Uo2ooji4) this.f8209thooCoci9zae.poll();
                            if (kah6uo2ooji4 == null) {
                                this.f8208keiL1EiShomu = false;
                                return;
                            }
                        } finally {
                        }
                    }
                    kah6uo2ooji4.thooCoci9zae(ohv5shie7aez);
                }
            }
        }
    }
}
