package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ruNgecai1pae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final Executor f8250ieseir3Choge = new Meu0ophaeng1();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final Executor f8251thooCoci9zae = new Nieyie8tecah();
}
