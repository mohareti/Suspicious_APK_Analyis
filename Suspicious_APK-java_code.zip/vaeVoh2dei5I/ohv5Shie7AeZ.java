package vaeVoh2dei5I;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ohv5Shie7AeZ {
    public abstract boolean AeJiPo4of6Sh();

    public abstract ohv5Shie7AeZ Aicohm8ieYoo(Executor executor, Aicohm8ieYoo aicohm8ieYoo);

    public abstract ohv5Shie7AeZ Jah0aiP1ki6y(Aicohm8ieYoo aicohm8ieYoo);

    public abstract Object ahthoK6usais(Class cls);

    public abstract ohv5Shie7AeZ eetheKaevie8(niah0Shohtha niah0shohtha);

    public abstract ohv5Shie7AeZ ieheiQu9sho5(Executor executor, kuedujio7Aev kuedujio7aev);

    public abstract ohv5Shie7AeZ ieseir3Choge(Executor executor, keiL1EiShomu keil1eishomu);

    public abstract ohv5Shie7AeZ keiL1EiShomu(ieheiQu9sho5 ieheiqu9sho5);

    public abstract Exception ko7aiFeiqu3s();

    public abstract ohv5Shie7AeZ kuedujio7Aev(kuedujio7Aev kuedujio7aev);

    public abstract boolean mi5Iecheimie();

    public abstract ohv5Shie7AeZ niah0Shohtha(Executor executor, ieseir3Choge ieseir3choge);

    public abstract ohv5Shie7AeZ oYe2ma2she1j(Executor executor, niah0Shohtha niah0shohtha);

    public abstract ohv5Shie7AeZ ohv5Shie7AeZ(Executor executor, ieseir3Choge ieseir3choge);

    public abstract Object ruNgecai1pae();

    public abstract boolean ruwiepo7ooVu();

    public abstract ohv5Shie7AeZ thooCoci9zae(Executor executor, ieheiQu9sho5 ieheiqu9sho5);
}
