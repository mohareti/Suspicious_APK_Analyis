package org.conscrypt;

import javax.net.ssl.SNIHostName;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract /* synthetic */ class ohv5Shie7AeZ {
    public static /* bridge */ /* synthetic */ SNIHostName ieseir3Choge(Object obj) {
        return (SNIHostName) obj;
    }
}
