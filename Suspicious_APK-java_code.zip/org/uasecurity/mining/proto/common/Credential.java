package org.uasecurity.mining.proto.common;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.ahk3OhSh9Ree;
import com.google.protobuf.ahthoK6usais;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ko7aiFeiqu3s;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.ohv5Shie7AeZ;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Credential extends IengaiSahh8H implements CredentialOrBuilder {
    public static final int ACCESSTOKEN_FIELD_NUMBER = 2;
    private static final Credential DEFAULT_INSTANCE;
    public static final int ID_FIELD_NUMBER = 1;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private ohv5Shie7AeZ accessToken_;
    private long id_;
    private byte memoizedIsInitialized;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements CredentialOrBuilder {
        private ohv5Shie7AeZ accessToken_;
        private int bitField0_;
        private long id_;

        private Builder() {
            this.accessToken_ = ohv5Shie7AeZ.f4876kuedujio7Aev;
        }

        private void buildPartial0(Credential credential) {
            int i = this.bitField0_;
            if ((i & 1) != 0) {
                credential.id_ = this.id_;
            }
            if ((i & 2) != 0) {
                credential.accessToken_ = this.accessToken_;
            }
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Status.internal_static_Credential_descriptor;
        }

        public Builder clearAccessToken() {
            this.bitField0_ &= -3;
            this.accessToken_ = Credential.getDefaultInstance().getAccessToken();
            onChanged();
            return this;
        }

        public Builder clearId() {
            this.bitField0_ &= -2;
            this.id_ = 0L;
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.common.CredentialOrBuilder
        public ohv5Shie7AeZ getAccessToken() {
            return this.accessToken_;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Status.internal_static_Credential_descriptor;
        }

        @Override // org.uasecurity.mining.proto.common.CredentialOrBuilder
        public long getId() {
            return this.id_;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Status.internal_static_Credential_fieldAccessorTable.ieheiQu9sho5(Credential.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder setAccessToken(ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            this.accessToken_ = ohv5shie7aez;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setId(long j) {
            this.id_ = j;
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            this.accessToken_ = ohv5Shie7AeZ.f4876kuedujio7Aev;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Credential build() {
            Credential buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Credential buildPartial() {
            Credential credential = new Credential(this);
            if (this.bitField0_ != 0) {
                buildPartial0(credential);
            }
            onBuilt();
            return credential;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public Credential getDefaultInstanceForType() {
            return Credential.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m33clear() {
            super.m71clear();
            this.bitField0_ = 0;
            this.id_ = 0L;
            this.accessToken_ = ohv5Shie7AeZ.f4876kuedujio7Aev;
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 8) {
                                this.id_ = ko7aifeiqu3s.Idohhaimaes0();
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                this.accessToken_ = ko7aifeiqu3s.zoojiiKaht3i();
                                this.bitField0_ |= 2;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof Credential) {
                return mergeFrom((Credential) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(Credential credential) {
            if (credential == Credential.getDefaultInstance()) {
                return this;
            }
            if (credential.getId() != 0) {
                setId(credential.getId());
            }
            if (credential.getAccessToken() != ohv5Shie7AeZ.f4876kuedujio7Aev) {
                setAccessToken(credential.getAccessToken());
            }
            m8mergeUnknownFields(credential.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, Credential.class.getName());
        DEFAULT_INSTANCE = new Credential();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.common.Credential.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public Credential parsePartialFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = Credential.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private Credential() {
        this.id_ = 0L;
        ohv5Shie7AeZ ohv5shie7aez = ohv5Shie7AeZ.f4876kuedujio7Aev;
        this.memoizedIsInitialized = (byte) -1;
        this.accessToken_ = ohv5shie7aez;
    }

    public static Credential getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Status.internal_static_Credential_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static Credential parseDelimitedFrom(InputStream inputStream) {
        return (Credential) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static Credential parseFrom(ohv5Shie7AeZ ohv5shie7aez) {
        return (Credential) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Credential)) {
            return super.equals(obj);
        }
        Credential credential = (Credential) obj;
        return getId() == credential.getId() && getAccessToken().equals(credential.getAccessToken()) && getUnknownFields().equals(credential.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.common.CredentialOrBuilder
    public ohv5Shie7AeZ getAccessToken() {
        return this.accessToken_;
    }

    @Override // org.uasecurity.mining.proto.common.CredentialOrBuilder
    public long getId() {
        return this.id_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        long j = this.id_;
        int Idohhaimaes02 = j != 0 ? ahthoK6usais.Idohhaimaes0(1, j) : 0;
        if (!this.accessToken_.isEmpty()) {
            Idohhaimaes02 += ahthoK6usais.niah0Shohtha(2, this.accessToken_);
        }
        int serializedSize = Idohhaimaes02 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = ((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + ahk3OhSh9Ree.niah0Shohtha(getId())) * 37) + 2) * 53) + getAccessToken().hashCode()) * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode;
        return hashCode;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Status.internal_static_Credential_fieldAccessorTable.ieheiQu9sho5(Credential.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(ahthoK6usais ahthok6usais) {
        long j = this.id_;
        if (j != 0) {
            ahthok6usais.ooThuoloosh4(1, j);
        }
        if (!this.accessToken_.isEmpty()) {
            ahthok6usais.aech7ohPhooh(2, this.accessToken_);
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private Credential(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.id_ = 0L;
        this.accessToken_ = ohv5Shie7AeZ.f4876kuedujio7Aev;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(Credential credential) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(credential);
    }

    public static Credential parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (Credential) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static Credential parseFrom(ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (Credential) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static Credential parseFrom(ko7aiFeiqu3s ko7aifeiqu3s) {
        return (Credential) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public Credential getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static Credential parseFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (Credential) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static Credential parseFrom(InputStream inputStream) {
        return (Credential) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static Credential parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (Credential) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static Credential parseFrom(ByteBuffer byteBuffer) {
        return (Credential) PARSER.parseFrom(byteBuffer);
    }

    public static Credential parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (Credential) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static Credential parseFrom(byte[] bArr) {
        return (Credential) PARSER.parseFrom(bArr);
    }

    public static Credential parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (Credential) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
