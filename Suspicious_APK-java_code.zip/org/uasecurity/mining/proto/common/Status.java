package org.uasecurity.mining.proto.common;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.laej2zeez5Ja;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Status {
    private static AeJiPo4of6Sh.niah0Shohtha descriptor;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_Credential_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_Credential_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_Empty_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_Empty_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_StatusInfo_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_StatusInfo_fieldAccessorTable;

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, Status.class.getName());
        descriptor = AeJiPo4of6Sh.niah0Shohtha.eyei9eigh3Ie(new String[]{"\n\fstatus.proto\"-\n\nCredential\u0012\n\n\u0002id\u0018\u0001 \u0001(\u0003\u0012\u0013\n\u000baccessToken\u0018\u0002 \u0001(\f\"\u0007\n\u0005Empty\"Î\u0001\n\nStatusInfo\u0012\u0014\n\fisSuccessful\u0018\u0001 \u0001(\b\u0012\u000f\n\u0007message\u0018\u0002 \u0001(\t\u0012(\n\terrorType\u0018\u0003 \u0001(\u000e2\u0015.StatusInfo.ErrorType\"o\n\tErrorType\u0012\u000f\n\u000bUNSPECIFIED\u0010\u0000\u0012\u0011\n\rACCESS_DENIED\u0010\u0001\u0012\u0016\n\u0012RESOURCE_NOT_FOUND\u0010\u0002\u0012\u0012\n\u000eINTERNAL_ERROR\u0010\u0003\u0012\u0012\n\u000eRATE_THROTTLED\u0010\u0004B6\n\"org.uasecurity.mining.proto.commonP\u0001ª\u0002\rMining.Commonb\u0006proto3"}, new AeJiPo4of6Sh.niah0Shohtha[0]);
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(0);
        internal_static_Credential_descriptor = thoococi9zae;
        internal_static_Credential_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae, new String[]{"Id", "AccessToken"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae2 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(1);
        internal_static_Empty_descriptor = thoococi9zae2;
        internal_static_Empty_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae2, new String[0]);
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae3 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(2);
        internal_static_StatusInfo_descriptor = thoococi9zae3;
        internal_static_StatusInfo_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae3, new String[]{"IsSuccessful", "Message", "ErrorType"});
        descriptor.Ochoob6Ahvi2();
    }

    private Status() {
    }

    public static AeJiPo4of6Sh.niah0Shohtha getDescriptor() {
        return descriptor;
    }

    public static void registerAllExtensions(laej2zeez5Ja laej2zeez5ja) {
        registerAllExtensions((esohshee3Pau) laej2zeez5ja);
    }

    public static void registerAllExtensions(esohshee3Pau esohshee3pau) {
    }
}
