package org.uasecurity.mining.proto.common;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.AexaNg2eecie;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.ahk3OhSh9Ree;
import com.google.protobuf.ahthoK6usais;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ko7aiFeiqu3s;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.ohv5Shie7AeZ;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class StatusInfo extends IengaiSahh8H implements StatusInfoOrBuilder {
    private static final StatusInfo DEFAULT_INSTANCE;
    public static final int ERRORTYPE_FIELD_NUMBER = 3;
    public static final int ISSUCCESSFUL_FIELD_NUMBER = 1;
    public static final int MESSAGE_FIELD_NUMBER = 2;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private int errorType_;
    private boolean isSuccessful_;
    private byte memoizedIsInitialized;
    private volatile Object message_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements StatusInfoOrBuilder {
        private int bitField0_;
        private int errorType_;
        private boolean isSuccessful_;
        private Object message_;

        private Builder() {
            this.message_ = BuildConfig.FLAVOR;
            this.errorType_ = 0;
        }

        private void buildPartial0(StatusInfo statusInfo) {
            int i = this.bitField0_;
            if ((i & 1) != 0) {
                statusInfo.isSuccessful_ = this.isSuccessful_;
            }
            if ((i & 2) != 0) {
                statusInfo.message_ = this.message_;
            }
            if ((i & 4) != 0) {
                statusInfo.errorType_ = this.errorType_;
            }
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Status.internal_static_StatusInfo_descriptor;
        }

        public Builder clearErrorType() {
            this.bitField0_ &= -5;
            this.errorType_ = 0;
            onChanged();
            return this;
        }

        public Builder clearIsSuccessful() {
            this.bitField0_ &= -2;
            this.isSuccessful_ = false;
            onChanged();
            return this;
        }

        public Builder clearMessage() {
            this.message_ = StatusInfo.getDefaultInstance().getMessage();
            this.bitField0_ &= -3;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Status.internal_static_StatusInfo_descriptor;
        }

        @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
        public ErrorType getErrorType() {
            ErrorType forNumber = ErrorType.forNumber(this.errorType_);
            return forNumber == null ? ErrorType.UNRECOGNIZED : forNumber;
        }

        @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
        public int getErrorTypeValue() {
            return this.errorType_;
        }

        @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
        public boolean getIsSuccessful() {
            return this.isSuccessful_;
        }

        @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
        public String getMessage() {
            Object obj = this.message_;
            if (obj instanceof String) {
                return (String) obj;
            }
            String IengaiSahh8H2 = ((ohv5Shie7AeZ) obj).IengaiSahh8H();
            this.message_ = IengaiSahh8H2;
            return IengaiSahh8H2;
        }

        @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
        public ohv5Shie7AeZ getMessageBytes() {
            Object obj = this.message_;
            if (!(obj instanceof String)) {
                return (ohv5Shie7AeZ) obj;
            }
            ohv5Shie7AeZ eetheKaevie82 = ohv5Shie7AeZ.eetheKaevie8((String) obj);
            this.message_ = eetheKaevie82;
            return eetheKaevie82;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Status.internal_static_StatusInfo_fieldAccessorTable.ieheiQu9sho5(StatusInfo.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder setErrorType(ErrorType errorType) {
            errorType.getClass();
            this.bitField0_ |= 4;
            this.errorType_ = errorType.getNumber();
            onChanged();
            return this;
        }

        public Builder setErrorTypeValue(int i) {
            this.errorType_ = i;
            this.bitField0_ |= 4;
            onChanged();
            return this;
        }

        public Builder setIsSuccessful(boolean z) {
            this.isSuccessful_ = z;
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setMessage(String str) {
            str.getClass();
            this.message_ = str;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setMessageBytes(ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            com.google.protobuf.thooCoci9zae.checkByteStringIsUtf8(ohv5shie7aez);
            this.message_ = ohv5shie7aez;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            this.message_ = BuildConfig.FLAVOR;
            this.errorType_ = 0;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public StatusInfo build() {
            StatusInfo buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public StatusInfo buildPartial() {
            StatusInfo statusInfo = new StatusInfo(this);
            if (this.bitField0_ != 0) {
                buildPartial0(statusInfo);
            }
            onBuilt();
            return statusInfo;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public StatusInfo getDefaultInstanceForType() {
            return StatusInfo.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m39clear() {
            super.m36clear();
            this.bitField0_ = 0;
            this.isSuccessful_ = false;
            this.message_ = BuildConfig.FLAVOR;
            this.errorType_ = 0;
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 8) {
                                this.isSuccessful_ = ko7aifeiqu3s.eetheKaevie8();
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                this.message_ = ko7aifeiqu3s.mi3Ozool1oa4();
                                this.bitField0_ |= 2;
                            } else if (io4laQuei7sa2 == 24) {
                                this.errorType_ = ko7aifeiqu3s.laej2zeez5Ja();
                                this.bitField0_ |= 4;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof StatusInfo) {
                return mergeFrom((StatusInfo) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(StatusInfo statusInfo) {
            if (statusInfo == StatusInfo.getDefaultInstance()) {
                return this;
            }
            if (statusInfo.getIsSuccessful()) {
                setIsSuccessful(statusInfo.getIsSuccessful());
            }
            if (!statusInfo.getMessage().isEmpty()) {
                this.message_ = statusInfo.message_;
                this.bitField0_ |= 2;
                onChanged();
            }
            if (statusInfo.errorType_ != 0) {
                setErrorTypeValue(statusInfo.getErrorTypeValue());
            }
            m8mergeUnknownFields(statusInfo.getUnknownFields());
            onChanged();
            return this;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum ErrorType implements AexaNg2eecie {
        UNSPECIFIED(0),
        ACCESS_DENIED(1),
        RESOURCE_NOT_FOUND(2),
        INTERNAL_ERROR(3),
        RATE_THROTTLED(4),
        UNRECOGNIZED(-1);

        public static final int ACCESS_DENIED_VALUE = 1;
        public static final int INTERNAL_ERROR_VALUE = 3;
        public static final int RATE_THROTTLED_VALUE = 4;
        public static final int RESOURCE_NOT_FOUND_VALUE = 2;
        public static final int UNSPECIFIED_VALUE = 0;
        private static final ErrorType[] VALUES;
        private static final ahk3OhSh9Ree.ieheiQu9sho5 internalValueMap;
        private final int value;

        static {
            Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, ErrorType.class.getName());
            internalValueMap = new ahk3OhSh9Ree.ieheiQu9sho5() { // from class: org.uasecurity.mining.proto.common.StatusInfo.ErrorType.1
                public ErrorType findValueByNumber(int i) {
                    return ErrorType.forNumber(i);
                }
            };
            VALUES = values();
        }

        ErrorType(int i) {
            this.value = i;
        }

        public static ErrorType forNumber(int i) {
            if (i == 0) {
                return UNSPECIFIED;
            }
            if (i == 1) {
                return ACCESS_DENIED;
            }
            if (i == 2) {
                return RESOURCE_NOT_FOUND;
            }
            if (i == 3) {
                return INTERNAL_ERROR;
            }
            if (i != 4) {
                return null;
            }
            return RATE_THROTTLED;
        }

        public static final AeJiPo4of6Sh.kuedujio7Aev getDescriptor() {
            return (AeJiPo4of6Sh.kuedujio7Aev) StatusInfo.getDescriptor().rojaiZ9aeRee().get(0);
        }

        public static ahk3OhSh9Ree.ieheiQu9sho5 internalGetValueMap() {
            return internalValueMap;
        }

        @Deprecated
        public static ErrorType valueOf(int i) {
            return forNumber(i);
        }

        public final AeJiPo4of6Sh.kuedujio7Aev getDescriptorForType() {
            return getDescriptor();
        }

        @Override // com.google.protobuf.ahk3OhSh9Ree.keiL1EiShomu
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }

        public final AeJiPo4of6Sh.Aicohm8ieYoo getValueDescriptor() {
            if (this != UNRECOGNIZED) {
                return (AeJiPo4of6Sh.Aicohm8ieYoo) getDescriptor().laej2zeez5Ja().get(ordinal());
            }
            throw new IllegalStateException("Can't get the descriptor of an unrecognized enum value.");
        }

        public static ErrorType valueOf(AeJiPo4of6Sh.Aicohm8ieYoo aicohm8ieYoo) {
            if (aicohm8ieYoo.zoojiiKaht3i() == getDescriptor()) {
                return aicohm8ieYoo.oYe2ma2she1j() == -1 ? UNRECOGNIZED : VALUES[aicohm8ieYoo.oYe2ma2she1j()];
            }
            throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, StatusInfo.class.getName());
        DEFAULT_INSTANCE = new StatusInfo();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.common.StatusInfo.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public StatusInfo parsePartialFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = StatusInfo.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private StatusInfo() {
        this.isSuccessful_ = false;
        this.message_ = BuildConfig.FLAVOR;
        this.errorType_ = 0;
        this.memoizedIsInitialized = (byte) -1;
        this.message_ = BuildConfig.FLAVOR;
        this.errorType_ = 0;
    }

    public static StatusInfo getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Status.internal_static_StatusInfo_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static StatusInfo parseDelimitedFrom(InputStream inputStream) {
        return (StatusInfo) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static StatusInfo parseFrom(ohv5Shie7AeZ ohv5shie7aez) {
        return (StatusInfo) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof StatusInfo)) {
            return super.equals(obj);
        }
        StatusInfo statusInfo = (StatusInfo) obj;
        return getIsSuccessful() == statusInfo.getIsSuccessful() && getMessage().equals(statusInfo.getMessage()) && this.errorType_ == statusInfo.errorType_ && getUnknownFields().equals(statusInfo.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
    public ErrorType getErrorType() {
        ErrorType forNumber = ErrorType.forNumber(this.errorType_);
        return forNumber == null ? ErrorType.UNRECOGNIZED : forNumber;
    }

    @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
    public int getErrorTypeValue() {
        return this.errorType_;
    }

    @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
    public boolean getIsSuccessful() {
        return this.isSuccessful_;
    }

    @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
    public String getMessage() {
        Object obj = this.message_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String IengaiSahh8H2 = ((ohv5Shie7AeZ) obj).IengaiSahh8H();
        this.message_ = IengaiSahh8H2;
        return IengaiSahh8H2;
    }

    @Override // org.uasecurity.mining.proto.common.StatusInfoOrBuilder
    public ohv5Shie7AeZ getMessageBytes() {
        Object obj = this.message_;
        if (!(obj instanceof String)) {
            return (ohv5Shie7AeZ) obj;
        }
        ohv5Shie7AeZ eetheKaevie82 = ohv5Shie7AeZ.eetheKaevie8((String) obj);
        this.message_ = eetheKaevie82;
        return eetheKaevie82;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        boolean z = this.isSuccessful_;
        int kuedujio7Aev2 = z ? ahthoK6usais.kuedujio7Aev(1, z) : 0;
        if (!IengaiSahh8H.isStringEmpty(this.message_)) {
            kuedujio7Aev2 += IengaiSahh8H.computeStringSize(2, this.message_);
        }
        if (this.errorType_ != ErrorType.UNSPECIFIED.getNumber()) {
            kuedujio7Aev2 += ahthoK6usais.ahthoK6usais(3, this.errorType_);
        }
        int serializedSize = kuedujio7Aev2 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = ((((((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + ahk3OhSh9Ree.keiL1EiShomu(getIsSuccessful())) * 37) + 2) * 53) + getMessage().hashCode()) * 37) + 3) * 53) + this.errorType_) * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode;
        return hashCode;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Status.internal_static_StatusInfo_fieldAccessorTable.ieheiQu9sho5(StatusInfo.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(ahthoK6usais ahthok6usais) {
        boolean z = this.isSuccessful_;
        if (z) {
            ahthok6usais.quiBuGh8zigh(1, z);
        }
        if (!IengaiSahh8H.isStringEmpty(this.message_)) {
            IengaiSahh8H.writeString(ahthok6usais, 2, this.message_);
        }
        if (this.errorType_ != ErrorType.UNSPECIFIED.getNumber()) {
            ahthok6usais.Niethookee4d(3, this.errorType_);
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private StatusInfo(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.isSuccessful_ = false;
        this.message_ = BuildConfig.FLAVOR;
        this.errorType_ = 0;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(StatusInfo statusInfo) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(statusInfo);
    }

    public static StatusInfo parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (StatusInfo) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static StatusInfo parseFrom(ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (StatusInfo) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static StatusInfo parseFrom(ko7aiFeiqu3s ko7aifeiqu3s) {
        return (StatusInfo) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public StatusInfo getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static StatusInfo parseFrom(ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (StatusInfo) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static StatusInfo parseFrom(InputStream inputStream) {
        return (StatusInfo) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static StatusInfo parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (StatusInfo) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static StatusInfo parseFrom(ByteBuffer byteBuffer) {
        return (StatusInfo) PARSER.parseFrom(byteBuffer);
    }

    public static StatusInfo parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (StatusInfo) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static StatusInfo parseFrom(byte[] bArr) {
        return (StatusInfo) PARSER.parseFrom(bArr);
    }

    public static StatusInfo parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (StatusInfo) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
