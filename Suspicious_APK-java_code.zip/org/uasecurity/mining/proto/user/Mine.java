package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.laej2zeez5Ja;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Status;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Mine {
    private static AeJiPo4of6Sh.niah0Shohtha descriptor;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_CheckCredentialValidityRequest_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_CheckCredentialValidityRequest_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_CheckCredentialValidityResponse_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_CheckCredentialValidityResponse_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_DeviceProto_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_DeviceProto_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_GetMiningArgsRequest_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_GetMiningArgsRequest_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_GetMiningArgsResponse_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_GetMiningArgsResponse_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_MinerRegisterRequest_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_MinerRegisterRequest_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_MinerRegisterResponse_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_MinerRegisterResponse_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_MiningLogProto_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_MiningLogProto_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_RecordMiningLogRequest_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_RecordMiningLogRequest_fieldAccessorTable;
    static final AeJiPo4of6Sh.thooCoci9zae internal_static_RecordMiningLogResponse_descriptor;
    static final IengaiSahh8H.niah0Shohtha internal_static_RecordMiningLogResponse_fieldAccessorTable;

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, Mine.class.getName());
        descriptor = AeJiPo4of6Sh.niah0Shohtha.eyei9eigh3Ie(new String[]{"\n\nmine.proto\u001a\fstatus.proto\"÷\u0001\n\u000bDeviceProto\u0012'\n\bplatform\u0018\u0001 \u0001(\u000e2\u0015.DeviceProto.Platform\u0012\u0017\n\u000fplatformVersion\u0018\u0002 \u0001(\u0005\u0012\r\n\u0005model\u0018\u0003 \u0001(\t\u0012\u0014\n\fmanufacturer\u0018\u0004 \u0001(\t\u0012\u0010\n\bcpuModel\u0018\u0005 \u0001(\t\u0012\u0017\n\u000fmaxCpuFrequency\u0018\u0006 \u0001(\u0001\u0012\u0012\n\nnumOfCores\u0018\u0007 \u0001(\u0005\u0012\u0013\n\u000btotalMemory\u0018\b \u0001(\u0001\"-\n\bPlatform\u0012\u000b\n\u0007ANDROID\u0010\u0000\u0012\u0007\n\u0003IOS\u0010\u0001\u0012\u000b\n\u0007WINDOWS\u0010\u0002\"9\n\u0014MinerRegisterRequest\u0012!\n\u000bdeviceProto\u0018\u0001 \u0001(\u000b2\f.DeviceProto\"U\n\u0015MinerRegisterResponse\u0012\u001b\n\u0006status\u0018\u0001 \u0001(\u000b2\u000b.StatusInfo\u0012\u001f\n\ncredential\u0018\u0002 \u0001(\u000b2\u000b.Credential\"g\n\u000eMiningLogProto\u0012\u0012\n\nspeedIn15s\u0018\u0001 \u0001(\u0005\u0012\u0012\n\nspeedIn60s\u0018\u0002 \u0001(\u0005\u0012\u0011\n\tspeedIn1h\u0018\u0003 \u0001(\u0005\u0012\u001a\n\u0012miningTotalSeconds\u0018\u0004 \u0001(\u0005\"b\n\u0016RecordMiningLogRequest\u0012\u001f\n\ncredential\u0018\u0001 \u0001(\u000b2\u000b.Credential\u0012'\n\u000eminingLogProto\u0018\u0002 \u0001(\u000b2\u000f.MiningLogProto\"6\n\u0017RecordMiningLogResponse\u0012\u001b\n\u0006status\u0018\u0001 \u0001(\u000b2\u000b.StatusInfo\"7\n\u0014GetMiningArgsRequest\u0012\u001f\n\ncredential\u0018\u0001 \u0001(\u000b2\u000b.Credential\"E\n\u0015GetMiningArgsResponse\u0012\u001b\n\u0006status\u0018\u0001 \u0001(\u000b2\u000b.StatusInfo\u0012\u000f\n\u0007newArgs\u0018\u0002 \u0003(\t\"A\n\u001eCheckCredentialValidityRequest\u0012\u001f\n\ncredential\u0018\u0001 \u0001(\u000b2\u000b.Credential\">\n\u001fCheckCredentialValidityResponse\u0012\u001b\n\u0006status\u0018\u0001 \u0001(\u000b2\u000b.StatusInfo2»\u0002\n\rMiningService\u0012@\n\rMinerRegister\u0012\u0015.MinerRegisterRequest\u001a\u0016.MinerRegisterResponse\"\u0000\u0012^\n\u0017CheckCredentialValidity\u0012\u001f.CheckCredentialValidityRequest\u001a .CheckCredentialValidityResponse\"\u0000\u0012F\n\u000fRecordMiningLog\u0012\u0017.RecordMiningLogRequest\u001a\u0018.RecordMiningLogResponse\"\u0000\u0012@\n\rGetMiningArgs\u0012\u0015.GetMiningArgsRequest\u001a\u0016.GetMiningArgsResponse\"\u0000B2\n org.uasecurity.mining.proto.userP\u0001ª\u0002\u000bMining.Userb\u0006proto3"}, new AeJiPo4of6Sh.niah0Shohtha[]{Status.getDescriptor()});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(0);
        internal_static_DeviceProto_descriptor = thoococi9zae;
        internal_static_DeviceProto_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae, new String[]{"Platform", "PlatformVersion", "Model", "Manufacturer", "CpuModel", "MaxCpuFrequency", "NumOfCores", "TotalMemory"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae2 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(1);
        internal_static_MinerRegisterRequest_descriptor = thoococi9zae2;
        internal_static_MinerRegisterRequest_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae2, new String[]{"DeviceProto"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae3 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(2);
        internal_static_MinerRegisterResponse_descriptor = thoococi9zae3;
        internal_static_MinerRegisterResponse_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae3, new String[]{"Status", "Credential"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae4 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(3);
        internal_static_MiningLogProto_descriptor = thoococi9zae4;
        internal_static_MiningLogProto_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae4, new String[]{"SpeedIn15S", "SpeedIn60S", "SpeedIn1H", "MiningTotalSeconds"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae5 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(4);
        internal_static_RecordMiningLogRequest_descriptor = thoococi9zae5;
        internal_static_RecordMiningLogRequest_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae5, new String[]{"Credential", "MiningLogProto"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae6 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(5);
        internal_static_RecordMiningLogResponse_descriptor = thoococi9zae6;
        internal_static_RecordMiningLogResponse_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae6, new String[]{"Status"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae7 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(6);
        internal_static_GetMiningArgsRequest_descriptor = thoococi9zae7;
        internal_static_GetMiningArgsRequest_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae7, new String[]{"Credential"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae8 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(7);
        internal_static_GetMiningArgsResponse_descriptor = thoococi9zae8;
        internal_static_GetMiningArgsResponse_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae8, new String[]{"Status", "NewArgs"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae9 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(8);
        internal_static_CheckCredentialValidityRequest_descriptor = thoococi9zae9;
        internal_static_CheckCredentialValidityRequest_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae9, new String[]{"Credential"});
        AeJiPo4of6Sh.thooCoci9zae thoococi9zae10 = (AeJiPo4of6Sh.thooCoci9zae) getDescriptor().esohshee3Pau().get(9);
        internal_static_CheckCredentialValidityResponse_descriptor = thoococi9zae10;
        internal_static_CheckCredentialValidityResponse_fieldAccessorTable = new IengaiSahh8H.niah0Shohtha(thoococi9zae10, new String[]{"Status"});
        descriptor.Ochoob6Ahvi2();
        Status.getDescriptor();
    }

    private Mine() {
    }

    public static AeJiPo4of6Sh.niah0Shohtha getDescriptor() {
        return descriptor;
    }

    public static void registerAllExtensions(laej2zeez5Ja laej2zeez5ja) {
        registerAllExtensions((esohshee3Pau) laej2zeez5ja);
    }

    public static void registerAllExtensions(esohshee3Pau esohshee3pau) {
    }
}
