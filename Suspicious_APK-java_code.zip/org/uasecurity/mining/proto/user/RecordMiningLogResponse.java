package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.StatusInfo;
import org.uasecurity.mining.proto.common.StatusInfoOrBuilder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class RecordMiningLogResponse extends IengaiSahh8H implements RecordMiningLogResponseOrBuilder {
    private static final RecordMiningLogResponse DEFAULT_INSTANCE;
    private static final Id9uvaegh4ai PARSER;
    public static final int STATUS_FIELD_NUMBER = 1;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private byte memoizedIsInitialized;
    private StatusInfo status_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements RecordMiningLogResponseOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a statusBuilder_;
        private StatusInfo status_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(RecordMiningLogResponse recordMiningLogResponse) {
            int i = 1;
            if ((this.bitField0_ & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
                recordMiningLogResponse.status_ = aemuphahfe7a == null ? this.status_ : (StatusInfo) aemuphahfe7a.thooCoci9zae();
            } else {
                i = 0;
            }
            RecordMiningLogResponse.access$576(recordMiningLogResponse, i);
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_RecordMiningLogResponse_descriptor;
        }

        private aeMuPhahFe7a getStatusFieldBuilder() {
            if (this.statusBuilder_ == null) {
                this.statusBuilder_ = new aeMuPhahFe7a(getStatus(), getParentForChildren(), isClean());
                this.status_ = null;
            }
            return this.statusBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getStatusFieldBuilder();
            }
        }

        public Builder clearStatus() {
            this.bitField0_ &= -2;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_RecordMiningLogResponse_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
        public StatusInfo getStatus() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfo) aemuphahfe7a.kuedujio7Aev();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        public StatusInfo.Builder getStatusBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (StatusInfo.Builder) getStatusFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
        public StatusInfoOrBuilder getStatusOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
        public boolean hasStatus() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_RecordMiningLogResponse_fieldAccessorTable.ieheiQu9sho5(RecordMiningLogResponse.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeStatus(StatusInfo statusInfo) {
            StatusInfo statusInfo2;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(statusInfo);
            } else if ((this.bitField0_ & 1) == 0 || (statusInfo2 = this.status_) == null || statusInfo2 == StatusInfo.getDefaultInstance()) {
                this.status_ = statusInfo;
            } else {
                getStatusBuilder().mergeFrom(statusInfo);
            }
            if (this.status_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setStatus(StatusInfo.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            StatusInfo build = builder.build();
            if (aemuphahfe7a == null) {
                this.status_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setStatus(StatusInfo statusInfo) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a == null) {
                statusInfo.getClass();
                this.status_ = statusInfo;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(statusInfo);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public RecordMiningLogResponse build() {
            RecordMiningLogResponse buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public RecordMiningLogResponse buildPartial() {
            RecordMiningLogResponse recordMiningLogResponse = new RecordMiningLogResponse(this);
            if (this.bitField0_ != 0) {
                buildPartial0(recordMiningLogResponse);
            }
            onBuilt();
            return recordMiningLogResponse;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public RecordMiningLogResponse getDefaultInstanceForType() {
            return RecordMiningLogResponse.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m80clear() {
            super.m39clear();
            this.bitField0_ = 0;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getStatusFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof RecordMiningLogResponse) {
                return mergeFrom((RecordMiningLogResponse) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(RecordMiningLogResponse recordMiningLogResponse) {
            if (recordMiningLogResponse == RecordMiningLogResponse.getDefaultInstance()) {
                return this;
            }
            if (recordMiningLogResponse.hasStatus()) {
                mergeStatus(recordMiningLogResponse.getStatus());
            }
            m8mergeUnknownFields(recordMiningLogResponse.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, RecordMiningLogResponse.class.getName());
        DEFAULT_INSTANCE = new RecordMiningLogResponse();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.RecordMiningLogResponse.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public RecordMiningLogResponse parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = RecordMiningLogResponse.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private RecordMiningLogResponse() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$576(RecordMiningLogResponse recordMiningLogResponse, int i) {
        int i2 = i | recordMiningLogResponse.bitField0_;
        recordMiningLogResponse.bitField0_ = i2;
        return i2;
    }

    public static RecordMiningLogResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_RecordMiningLogResponse_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static RecordMiningLogResponse parseDelimitedFrom(InputStream inputStream) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static RecordMiningLogResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (RecordMiningLogResponse) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof RecordMiningLogResponse)) {
            return super.equals(obj);
        }
        RecordMiningLogResponse recordMiningLogResponse = (RecordMiningLogResponse) obj;
        if (hasStatus() != recordMiningLogResponse.hasStatus()) {
            return false;
        }
        return (!hasStatus() || getStatus().equals(recordMiningLogResponse.getStatus())) && getUnknownFields().equals(recordMiningLogResponse.getUnknownFields());
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = ((this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getStatus()) : 0) + getUnknownFields().getSerializedSize();
        this.memoizedSize = Meu0ophaeng12;
        return Meu0ophaeng12;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
    public StatusInfo getStatus() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
    public StatusInfoOrBuilder getStatusOrBuilder() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogResponseOrBuilder
    public boolean hasStatus() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasStatus()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getStatus().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_RecordMiningLogResponse_fieldAccessorTable.ieheiQu9sho5(RecordMiningLogResponse.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getStatus());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private RecordMiningLogResponse(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(RecordMiningLogResponse recordMiningLogResponse) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(recordMiningLogResponse);
    }

    public static RecordMiningLogResponse parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static RecordMiningLogResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static RecordMiningLogResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public RecordMiningLogResponse getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static RecordMiningLogResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static RecordMiningLogResponse parseFrom(InputStream inputStream) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static RecordMiningLogResponse parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static RecordMiningLogResponse parseFrom(ByteBuffer byteBuffer) {
        return (RecordMiningLogResponse) PARSER.parseFrom(byteBuffer);
    }

    public static RecordMiningLogResponse parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static RecordMiningLogResponse parseFrom(byte[] bArr) {
        return (RecordMiningLogResponse) PARSER.parseFrom(bArr);
    }

    public static RecordMiningLogResponse parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogResponse) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
