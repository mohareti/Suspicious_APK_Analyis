package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.StatusInfo;
import org.uasecurity.mining.proto.common.StatusInfoOrBuilder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class KeepAliveResponse extends IengaiSahh8H implements KeepAliveResponseOrBuilder {
    private static final KeepAliveResponse DEFAULT_INSTANCE;
    private static final Id9uvaegh4ai PARSER;
    public static final int STATUS_FIELD_NUMBER = 1;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private byte memoizedIsInitialized;
    private StatusInfo status_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements KeepAliveResponseOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a statusBuilder_;
        private StatusInfo status_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(KeepAliveResponse keepAliveResponse) {
            int i = 1;
            if ((this.bitField0_ & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
                keepAliveResponse.status_ = aemuphahfe7a == null ? this.status_ : (StatusInfo) aemuphahfe7a.thooCoci9zae();
            } else {
                i = 0;
            }
            KeepAliveResponse.access$576(keepAliveResponse, i);
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Keepalive.internal_static_KeepAliveResponse_descriptor;
        }

        private aeMuPhahFe7a getStatusFieldBuilder() {
            if (this.statusBuilder_ == null) {
                this.statusBuilder_ = new aeMuPhahFe7a(getStatus(), getParentForChildren(), isClean());
                this.status_ = null;
            }
            return this.statusBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getStatusFieldBuilder();
            }
        }

        public Builder clearStatus() {
            this.bitField0_ &= -2;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Keepalive.internal_static_KeepAliveResponse_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
        public StatusInfo getStatus() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfo) aemuphahfe7a.kuedujio7Aev();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        public StatusInfo.Builder getStatusBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (StatusInfo.Builder) getStatusFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
        public StatusInfoOrBuilder getStatusOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
        public boolean hasStatus() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Keepalive.internal_static_KeepAliveResponse_fieldAccessorTable.ieheiQu9sho5(KeepAliveResponse.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeStatus(StatusInfo statusInfo) {
            StatusInfo statusInfo2;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(statusInfo);
            } else if ((this.bitField0_ & 1) == 0 || (statusInfo2 = this.status_) == null || statusInfo2 == StatusInfo.getDefaultInstance()) {
                this.status_ = statusInfo;
            } else {
                getStatusBuilder().mergeFrom(statusInfo);
            }
            if (this.status_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setStatus(StatusInfo.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            StatusInfo build = builder.build();
            if (aemuphahfe7a == null) {
                this.status_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setStatus(StatusInfo statusInfo) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a == null) {
                statusInfo.getClass();
                this.status_ = statusInfo;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(statusInfo);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveResponse build() {
            KeepAliveResponse buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public KeepAliveResponse buildPartial() {
            KeepAliveResponse keepAliveResponse = new KeepAliveResponse(this);
            if (this.bitField0_ != 0) {
                buildPartial0(keepAliveResponse);
            }
            onBuilt();
            return keepAliveResponse;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public KeepAliveResponse getDefaultInstanceForType() {
            return KeepAliveResponse.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m65clear() {
            super.m39clear();
            this.bitField0_ = 0;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getStatusFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof KeepAliveResponse) {
                return mergeFrom((KeepAliveResponse) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(KeepAliveResponse keepAliveResponse) {
            if (keepAliveResponse == KeepAliveResponse.getDefaultInstance()) {
                return this;
            }
            if (keepAliveResponse.hasStatus()) {
                mergeStatus(keepAliveResponse.getStatus());
            }
            m8mergeUnknownFields(keepAliveResponse.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, KeepAliveResponse.class.getName());
        DEFAULT_INSTANCE = new KeepAliveResponse();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.KeepAliveResponse.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public KeepAliveResponse parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = KeepAliveResponse.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private KeepAliveResponse() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$576(KeepAliveResponse keepAliveResponse, int i) {
        int i2 = i | keepAliveResponse.bitField0_;
        keepAliveResponse.bitField0_ = i2;
        return i2;
    }

    public static KeepAliveResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Keepalive.internal_static_KeepAliveResponse_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static KeepAliveResponse parseDelimitedFrom(InputStream inputStream) {
        return (KeepAliveResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static KeepAliveResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (KeepAliveResponse) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof KeepAliveResponse)) {
            return super.equals(obj);
        }
        KeepAliveResponse keepAliveResponse = (KeepAliveResponse) obj;
        if (hasStatus() != keepAliveResponse.hasStatus()) {
            return false;
        }
        return (!hasStatus() || getStatus().equals(keepAliveResponse.getStatus())) && getUnknownFields().equals(keepAliveResponse.getUnknownFields());
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = ((this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getStatus()) : 0) + getUnknownFields().getSerializedSize();
        this.memoizedSize = Meu0ophaeng12;
        return Meu0ophaeng12;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
    public StatusInfo getStatus() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
    public StatusInfoOrBuilder getStatusOrBuilder() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.KeepAliveResponseOrBuilder
    public boolean hasStatus() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasStatus()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getStatus().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Keepalive.internal_static_KeepAliveResponse_fieldAccessorTable.ieheiQu9sho5(KeepAliveResponse.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getStatus());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private KeepAliveResponse(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(KeepAliveResponse keepAliveResponse) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(keepAliveResponse);
    }

    public static KeepAliveResponse parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static KeepAliveResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (KeepAliveResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public KeepAliveResponse getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static KeepAliveResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static KeepAliveResponse parseFrom(InputStream inputStream) {
        return (KeepAliveResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static KeepAliveResponse parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static KeepAliveResponse parseFrom(ByteBuffer byteBuffer) {
        return (KeepAliveResponse) PARSER.parseFrom(byteBuffer);
    }

    public static KeepAliveResponse parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static KeepAliveResponse parseFrom(byte[] bArr) {
        return (KeepAliveResponse) PARSER.parseFrom(bArr);
    }

    public static KeepAliveResponse parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (KeepAliveResponse) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
