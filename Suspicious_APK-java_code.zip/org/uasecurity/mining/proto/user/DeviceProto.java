package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.AexaNg2eecie;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.ahk3OhSh9Ree;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class DeviceProto extends IengaiSahh8H implements DeviceProtoOrBuilder {
    public static final int CPUMODEL_FIELD_NUMBER = 5;
    private static final DeviceProto DEFAULT_INSTANCE;
    public static final int MANUFACTURER_FIELD_NUMBER = 4;
    public static final int MAXCPUFREQUENCY_FIELD_NUMBER = 6;
    public static final int MODEL_FIELD_NUMBER = 3;
    public static final int NUMOFCORES_FIELD_NUMBER = 7;
    private static final Id9uvaegh4ai PARSER;
    public static final int PLATFORMVERSION_FIELD_NUMBER = 2;
    public static final int PLATFORM_FIELD_NUMBER = 1;
    public static final int TOTALMEMORY_FIELD_NUMBER = 8;
    private static final long serialVersionUID = 0;
    private volatile Object cpuModel_;
    private volatile Object manufacturer_;
    private double maxCpuFrequency_;
    private byte memoizedIsInitialized;
    private volatile Object model_;
    private int numOfCores_;
    private int platformVersion_;
    private int platform_;
    private double totalMemory_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements DeviceProtoOrBuilder {
        private int bitField0_;
        private Object cpuModel_;
        private Object manufacturer_;
        private double maxCpuFrequency_;
        private Object model_;
        private int numOfCores_;
        private int platformVersion_;
        private int platform_;
        private double totalMemory_;

        private Builder() {
            this.platform_ = 0;
            this.model_ = BuildConfig.FLAVOR;
            this.manufacturer_ = BuildConfig.FLAVOR;
            this.cpuModel_ = BuildConfig.FLAVOR;
        }

        private void buildPartial0(DeviceProto deviceProto) {
            int i = this.bitField0_;
            if ((i & 1) != 0) {
                deviceProto.platform_ = this.platform_;
            }
            if ((i & 2) != 0) {
                deviceProto.platformVersion_ = this.platformVersion_;
            }
            if ((i & 4) != 0) {
                deviceProto.model_ = this.model_;
            }
            if ((i & 8) != 0) {
                deviceProto.manufacturer_ = this.manufacturer_;
            }
            if ((i & 16) != 0) {
                deviceProto.cpuModel_ = this.cpuModel_;
            }
            if ((i & 32) != 0) {
                deviceProto.maxCpuFrequency_ = this.maxCpuFrequency_;
            }
            if ((i & 64) != 0) {
                deviceProto.numOfCores_ = this.numOfCores_;
            }
            if ((i & 128) != 0) {
                deviceProto.totalMemory_ = this.totalMemory_;
            }
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_DeviceProto_descriptor;
        }

        public Builder clearCpuModel() {
            this.cpuModel_ = DeviceProto.getDefaultInstance().getCpuModel();
            this.bitField0_ &= -17;
            onChanged();
            return this;
        }

        public Builder clearManufacturer() {
            this.manufacturer_ = DeviceProto.getDefaultInstance().getManufacturer();
            this.bitField0_ &= -9;
            onChanged();
            return this;
        }

        public Builder clearMaxCpuFrequency() {
            this.bitField0_ &= -33;
            this.maxCpuFrequency_ = 0.0d;
            onChanged();
            return this;
        }

        public Builder clearModel() {
            this.model_ = DeviceProto.getDefaultInstance().getModel();
            this.bitField0_ &= -5;
            onChanged();
            return this;
        }

        public Builder clearNumOfCores() {
            this.bitField0_ &= -65;
            this.numOfCores_ = 0;
            onChanged();
            return this;
        }

        public Builder clearPlatform() {
            this.bitField0_ &= -2;
            this.platform_ = 0;
            onChanged();
            return this;
        }

        public Builder clearPlatformVersion() {
            this.bitField0_ &= -3;
            this.platformVersion_ = 0;
            onChanged();
            return this;
        }

        public Builder clearTotalMemory() {
            this.bitField0_ &= -129;
            this.totalMemory_ = 0.0d;
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public String getCpuModel() {
            Object obj = this.cpuModel_;
            if (obj instanceof String) {
                return (String) obj;
            }
            String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
            this.cpuModel_ = IengaiSahh8H2;
            return IengaiSahh8H2;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public com.google.protobuf.ohv5Shie7AeZ getCpuModelBytes() {
            Object obj = this.cpuModel_;
            if (!(obj instanceof String)) {
                return (com.google.protobuf.ohv5Shie7AeZ) obj;
            }
            com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
            this.cpuModel_ = eetheKaevie82;
            return eetheKaevie82;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_DeviceProto_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public String getManufacturer() {
            Object obj = this.manufacturer_;
            if (obj instanceof String) {
                return (String) obj;
            }
            String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
            this.manufacturer_ = IengaiSahh8H2;
            return IengaiSahh8H2;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public com.google.protobuf.ohv5Shie7AeZ getManufacturerBytes() {
            Object obj = this.manufacturer_;
            if (!(obj instanceof String)) {
                return (com.google.protobuf.ohv5Shie7AeZ) obj;
            }
            com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
            this.manufacturer_ = eetheKaevie82;
            return eetheKaevie82;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public double getMaxCpuFrequency() {
            return this.maxCpuFrequency_;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public String getModel() {
            Object obj = this.model_;
            if (obj instanceof String) {
                return (String) obj;
            }
            String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
            this.model_ = IengaiSahh8H2;
            return IengaiSahh8H2;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public com.google.protobuf.ohv5Shie7AeZ getModelBytes() {
            Object obj = this.model_;
            if (!(obj instanceof String)) {
                return (com.google.protobuf.ohv5Shie7AeZ) obj;
            }
            com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
            this.model_ = eetheKaevie82;
            return eetheKaevie82;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public int getNumOfCores() {
            return this.numOfCores_;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public Platform getPlatform() {
            Platform forNumber = Platform.forNumber(this.platform_);
            return forNumber == null ? Platform.UNRECOGNIZED : forNumber;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public int getPlatformValue() {
            return this.platform_;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public int getPlatformVersion() {
            return this.platformVersion_;
        }

        @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
        public double getTotalMemory() {
            return this.totalMemory_;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_DeviceProto_fieldAccessorTable.ieheiQu9sho5(DeviceProto.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder setCpuModel(String str) {
            str.getClass();
            this.cpuModel_ = str;
            this.bitField0_ |= 16;
            onChanged();
            return this;
        }

        public Builder setCpuModelBytes(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            com.google.protobuf.thooCoci9zae.checkByteStringIsUtf8(ohv5shie7aez);
            this.cpuModel_ = ohv5shie7aez;
            this.bitField0_ |= 16;
            onChanged();
            return this;
        }

        public Builder setManufacturer(String str) {
            str.getClass();
            this.manufacturer_ = str;
            this.bitField0_ |= 8;
            onChanged();
            return this;
        }

        public Builder setManufacturerBytes(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            com.google.protobuf.thooCoci9zae.checkByteStringIsUtf8(ohv5shie7aez);
            this.manufacturer_ = ohv5shie7aez;
            this.bitField0_ |= 8;
            onChanged();
            return this;
        }

        public Builder setMaxCpuFrequency(double d) {
            this.maxCpuFrequency_ = d;
            this.bitField0_ |= 32;
            onChanged();
            return this;
        }

        public Builder setModel(String str) {
            str.getClass();
            this.model_ = str;
            this.bitField0_ |= 4;
            onChanged();
            return this;
        }

        public Builder setModelBytes(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            com.google.protobuf.thooCoci9zae.checkByteStringIsUtf8(ohv5shie7aez);
            this.model_ = ohv5shie7aez;
            this.bitField0_ |= 4;
            onChanged();
            return this;
        }

        public Builder setNumOfCores(int i) {
            this.numOfCores_ = i;
            this.bitField0_ |= 64;
            onChanged();
            return this;
        }

        public Builder setPlatform(Platform platform) {
            platform.getClass();
            this.bitField0_ |= 1;
            this.platform_ = platform.getNumber();
            onChanged();
            return this;
        }

        public Builder setPlatformValue(int i) {
            this.platform_ = i;
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setPlatformVersion(int i) {
            this.platformVersion_ = i;
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setTotalMemory(double d) {
            this.totalMemory_ = d;
            this.bitField0_ |= 128;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            this.platform_ = 0;
            this.model_ = BuildConfig.FLAVOR;
            this.manufacturer_ = BuildConfig.FLAVOR;
            this.cpuModel_ = BuildConfig.FLAVOR;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public DeviceProto build() {
            DeviceProto buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public DeviceProto buildPartial() {
            DeviceProto deviceProto = new DeviceProto(this);
            if (this.bitField0_ != 0) {
                buildPartial0(deviceProto);
            }
            onBuilt();
            return deviceProto;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public DeviceProto getDefaultInstanceForType() {
            return DeviceProto.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m49clear() {
            super.m36clear();
            this.bitField0_ = 0;
            this.platform_ = 0;
            this.platformVersion_ = 0;
            this.model_ = BuildConfig.FLAVOR;
            this.manufacturer_ = BuildConfig.FLAVOR;
            this.cpuModel_ = BuildConfig.FLAVOR;
            this.maxCpuFrequency_ = 0.0d;
            this.numOfCores_ = 0;
            this.totalMemory_ = 0.0d;
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 8) {
                                this.platform_ = ko7aifeiqu3s.laej2zeez5Ja();
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 16) {
                                this.platformVersion_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 2;
                            } else if (io4laQuei7sa2 == 26) {
                                this.model_ = ko7aifeiqu3s.mi3Ozool1oa4();
                                this.bitField0_ |= 4;
                            } else if (io4laQuei7sa2 == 34) {
                                this.manufacturer_ = ko7aifeiqu3s.mi3Ozool1oa4();
                                this.bitField0_ |= 8;
                            } else if (io4laQuei7sa2 == 42) {
                                this.cpuModel_ = ko7aifeiqu3s.mi3Ozool1oa4();
                                this.bitField0_ |= 16;
                            } else if (io4laQuei7sa2 == 49) {
                                this.maxCpuFrequency_ = ko7aifeiqu3s.aac1eTaexee6();
                                this.bitField0_ |= 32;
                            } else if (io4laQuei7sa2 == 56) {
                                this.numOfCores_ = ko7aifeiqu3s.eyei9eigh3Ie();
                                this.bitField0_ |= 64;
                            } else if (io4laQuei7sa2 == 65) {
                                this.totalMemory_ = ko7aifeiqu3s.aac1eTaexee6();
                                this.bitField0_ |= 128;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof DeviceProto) {
                return mergeFrom((DeviceProto) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(DeviceProto deviceProto) {
            if (deviceProto == DeviceProto.getDefaultInstance()) {
                return this;
            }
            if (deviceProto.platform_ != 0) {
                setPlatformValue(deviceProto.getPlatformValue());
            }
            if (deviceProto.getPlatformVersion() != 0) {
                setPlatformVersion(deviceProto.getPlatformVersion());
            }
            if (!deviceProto.getModel().isEmpty()) {
                this.model_ = deviceProto.model_;
                this.bitField0_ |= 4;
                onChanged();
            }
            if (!deviceProto.getManufacturer().isEmpty()) {
                this.manufacturer_ = deviceProto.manufacturer_;
                this.bitField0_ |= 8;
                onChanged();
            }
            if (!deviceProto.getCpuModel().isEmpty()) {
                this.cpuModel_ = deviceProto.cpuModel_;
                this.bitField0_ |= 16;
                onChanged();
            }
            if (deviceProto.getMaxCpuFrequency() != 0.0d) {
                setMaxCpuFrequency(deviceProto.getMaxCpuFrequency());
            }
            if (deviceProto.getNumOfCores() != 0) {
                setNumOfCores(deviceProto.getNumOfCores());
            }
            if (deviceProto.getTotalMemory() != 0.0d) {
                setTotalMemory(deviceProto.getTotalMemory());
            }
            m8mergeUnknownFields(deviceProto.getUnknownFields());
            onChanged();
            return this;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum Platform implements AexaNg2eecie {
        ANDROID(0),
        IOS(1),
        WINDOWS(2),
        UNRECOGNIZED(-1);

        public static final int ANDROID_VALUE = 0;
        public static final int IOS_VALUE = 1;
        private static final Platform[] VALUES;
        public static final int WINDOWS_VALUE = 2;
        private static final ahk3OhSh9Ree.ieheiQu9sho5 internalValueMap;
        private final int value;

        static {
            Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, Platform.class.getName());
            internalValueMap = new ahk3OhSh9Ree.ieheiQu9sho5() { // from class: org.uasecurity.mining.proto.user.DeviceProto.Platform.1
                public Platform findValueByNumber(int i) {
                    return Platform.forNumber(i);
                }
            };
            VALUES = values();
        }

        Platform(int i) {
            this.value = i;
        }

        public static Platform forNumber(int i) {
            if (i == 0) {
                return ANDROID;
            }
            if (i == 1) {
                return IOS;
            }
            if (i != 2) {
                return null;
            }
            return WINDOWS;
        }

        public static final AeJiPo4of6Sh.kuedujio7Aev getDescriptor() {
            return (AeJiPo4of6Sh.kuedujio7Aev) DeviceProto.getDescriptor().rojaiZ9aeRee().get(0);
        }

        public static ahk3OhSh9Ree.ieheiQu9sho5 internalGetValueMap() {
            return internalValueMap;
        }

        @Deprecated
        public static Platform valueOf(int i) {
            return forNumber(i);
        }

        public final AeJiPo4of6Sh.kuedujio7Aev getDescriptorForType() {
            return getDescriptor();
        }

        @Override // com.google.protobuf.ahk3OhSh9Ree.keiL1EiShomu
        public final int getNumber() {
            if (this != UNRECOGNIZED) {
                return this.value;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }

        public final AeJiPo4of6Sh.Aicohm8ieYoo getValueDescriptor() {
            if (this != UNRECOGNIZED) {
                return (AeJiPo4of6Sh.Aicohm8ieYoo) getDescriptor().laej2zeez5Ja().get(ordinal());
            }
            throw new IllegalStateException("Can't get the descriptor of an unrecognized enum value.");
        }

        public static Platform valueOf(AeJiPo4of6Sh.Aicohm8ieYoo aicohm8ieYoo) {
            if (aicohm8ieYoo.zoojiiKaht3i() == getDescriptor()) {
                return aicohm8ieYoo.oYe2ma2she1j() == -1 ? UNRECOGNIZED : VALUES[aicohm8ieYoo.oYe2ma2she1j()];
            }
            throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, DeviceProto.class.getName());
        DEFAULT_INSTANCE = new DeviceProto();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.DeviceProto.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public DeviceProto parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = DeviceProto.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private DeviceProto() {
        this.platform_ = 0;
        this.platformVersion_ = 0;
        this.model_ = BuildConfig.FLAVOR;
        this.manufacturer_ = BuildConfig.FLAVOR;
        this.cpuModel_ = BuildConfig.FLAVOR;
        this.maxCpuFrequency_ = 0.0d;
        this.numOfCores_ = 0;
        this.totalMemory_ = 0.0d;
        this.memoizedIsInitialized = (byte) -1;
        this.platform_ = 0;
        this.model_ = BuildConfig.FLAVOR;
        this.manufacturer_ = BuildConfig.FLAVOR;
        this.cpuModel_ = BuildConfig.FLAVOR;
    }

    public static DeviceProto getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_DeviceProto_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static DeviceProto parseDelimitedFrom(InputStream inputStream) {
        return (DeviceProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static DeviceProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (DeviceProto) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof DeviceProto)) {
            return super.equals(obj);
        }
        DeviceProto deviceProto = (DeviceProto) obj;
        return this.platform_ == deviceProto.platform_ && getPlatformVersion() == deviceProto.getPlatformVersion() && getModel().equals(deviceProto.getModel()) && getManufacturer().equals(deviceProto.getManufacturer()) && getCpuModel().equals(deviceProto.getCpuModel()) && Double.doubleToLongBits(getMaxCpuFrequency()) == Double.doubleToLongBits(deviceProto.getMaxCpuFrequency()) && getNumOfCores() == deviceProto.getNumOfCores() && Double.doubleToLongBits(getTotalMemory()) == Double.doubleToLongBits(deviceProto.getTotalMemory()) && getUnknownFields().equals(deviceProto.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public String getCpuModel() {
        Object obj = this.cpuModel_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
        this.cpuModel_ = IengaiSahh8H2;
        return IengaiSahh8H2;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public com.google.protobuf.ohv5Shie7AeZ getCpuModelBytes() {
        Object obj = this.cpuModel_;
        if (!(obj instanceof String)) {
            return (com.google.protobuf.ohv5Shie7AeZ) obj;
        }
        com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
        this.cpuModel_ = eetheKaevie82;
        return eetheKaevie82;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public String getManufacturer() {
        Object obj = this.manufacturer_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
        this.manufacturer_ = IengaiSahh8H2;
        return IengaiSahh8H2;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public com.google.protobuf.ohv5Shie7AeZ getManufacturerBytes() {
        Object obj = this.manufacturer_;
        if (!(obj instanceof String)) {
            return (com.google.protobuf.ohv5Shie7AeZ) obj;
        }
        com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
        this.manufacturer_ = eetheKaevie82;
        return eetheKaevie82;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public double getMaxCpuFrequency() {
        return this.maxCpuFrequency_;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public String getModel() {
        Object obj = this.model_;
        if (obj instanceof String) {
            return (String) obj;
        }
        String IengaiSahh8H2 = ((com.google.protobuf.ohv5Shie7AeZ) obj).IengaiSahh8H();
        this.model_ = IengaiSahh8H2;
        return IengaiSahh8H2;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public com.google.protobuf.ohv5Shie7AeZ getModelBytes() {
        Object obj = this.model_;
        if (!(obj instanceof String)) {
            return (com.google.protobuf.ohv5Shie7AeZ) obj;
        }
        com.google.protobuf.ohv5Shie7AeZ eetheKaevie82 = com.google.protobuf.ohv5Shie7AeZ.eetheKaevie8((String) obj);
        this.model_ = eetheKaevie82;
        return eetheKaevie82;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public int getNumOfCores() {
        return this.numOfCores_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public Platform getPlatform() {
        Platform forNumber = Platform.forNumber(this.platform_);
        return forNumber == null ? Platform.UNRECOGNIZED : forNumber;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public int getPlatformValue() {
        return this.platform_;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public int getPlatformVersion() {
        return this.platformVersion_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int ahthoK6usais2 = this.platform_ != Platform.ANDROID.getNumber() ? com.google.protobuf.ahthoK6usais.ahthoK6usais(1, this.platform_) : 0;
        int i2 = this.platformVersion_;
        if (i2 != 0) {
            ahthoK6usais2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(2, i2);
        }
        if (!IengaiSahh8H.isStringEmpty(this.model_)) {
            ahthoK6usais2 += IengaiSahh8H.computeStringSize(3, this.model_);
        }
        if (!IengaiSahh8H.isStringEmpty(this.manufacturer_)) {
            ahthoK6usais2 += IengaiSahh8H.computeStringSize(4, this.manufacturer_);
        }
        if (!IengaiSahh8H.isStringEmpty(this.cpuModel_)) {
            ahthoK6usais2 += IengaiSahh8H.computeStringSize(5, this.cpuModel_);
        }
        if (Double.doubleToRawLongBits(this.maxCpuFrequency_) != 0) {
            ahthoK6usais2 += com.google.protobuf.ahthoK6usais.ko7aiFeiqu3s(6, this.maxCpuFrequency_);
        }
        int i3 = this.numOfCores_;
        if (i3 != 0) {
            ahthoK6usais2 += com.google.protobuf.ahthoK6usais.ohthie9thieG(7, i3);
        }
        if (Double.doubleToRawLongBits(this.totalMemory_) != 0) {
            ahthoK6usais2 += com.google.protobuf.ahthoK6usais.ko7aiFeiqu3s(8, this.totalMemory_);
        }
        int serializedSize = ahthoK6usais2 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.DeviceProtoOrBuilder
    public double getTotalMemory() {
        return this.totalMemory_;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = ((((((((((((((((((((((((((((((((((779 + getDescriptor().hashCode()) * 37) + 1) * 53) + this.platform_) * 37) + 2) * 53) + getPlatformVersion()) * 37) + 3) * 53) + getModel().hashCode()) * 37) + 4) * 53) + getManufacturer().hashCode()) * 37) + 5) * 53) + getCpuModel().hashCode()) * 37) + 6) * 53) + ahk3OhSh9Ree.niah0Shohtha(Double.doubleToLongBits(getMaxCpuFrequency()))) * 37) + 7) * 53) + getNumOfCores()) * 37) + 8) * 53) + ahk3OhSh9Ree.niah0Shohtha(Double.doubleToLongBits(getTotalMemory()))) * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode;
        return hashCode;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_DeviceProto_fieldAccessorTable.ieheiQu9sho5(DeviceProto.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if (this.platform_ != Platform.ANDROID.getNumber()) {
            ahthok6usais.Niethookee4d(1, this.platform_);
        }
        int i = this.platformVersion_;
        if (i != 0) {
            ahthok6usais.AexaNg2eecie(2, i);
        }
        if (!IengaiSahh8H.isStringEmpty(this.model_)) {
            IengaiSahh8H.writeString(ahthok6usais, 3, this.model_);
        }
        if (!IengaiSahh8H.isStringEmpty(this.manufacturer_)) {
            IengaiSahh8H.writeString(ahthok6usais, 4, this.manufacturer_);
        }
        if (!IengaiSahh8H.isStringEmpty(this.cpuModel_)) {
            IengaiSahh8H.writeString(ahthok6usais, 5, this.cpuModel_);
        }
        if (Double.doubleToRawLongBits(this.maxCpuFrequency_) != 0) {
            ahthok6usais.eik1oetahvuF(6, this.maxCpuFrequency_);
        }
        int i2 = this.numOfCores_;
        if (i2 != 0) {
            ahthok6usais.AexaNg2eecie(7, i2);
        }
        if (Double.doubleToRawLongBits(this.totalMemory_) != 0) {
            ahthok6usais.eik1oetahvuF(8, this.totalMemory_);
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private DeviceProto(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.platform_ = 0;
        this.platformVersion_ = 0;
        this.model_ = BuildConfig.FLAVOR;
        this.manufacturer_ = BuildConfig.FLAVOR;
        this.cpuModel_ = BuildConfig.FLAVOR;
        this.maxCpuFrequency_ = 0.0d;
        this.numOfCores_ = 0;
        this.totalMemory_ = 0.0d;
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(DeviceProto deviceProto) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(deviceProto);
    }

    public static DeviceProto parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (DeviceProto) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static DeviceProto parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (DeviceProto) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static DeviceProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (DeviceProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public DeviceProto getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static DeviceProto parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (DeviceProto) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static DeviceProto parseFrom(InputStream inputStream) {
        return (DeviceProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static DeviceProto parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (DeviceProto) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static DeviceProto parseFrom(ByteBuffer byteBuffer) {
        return (DeviceProto) PARSER.parseFrom(byteBuffer);
    }

    public static DeviceProto parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (DeviceProto) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static DeviceProto parseFrom(byte[] bArr) {
        return (DeviceProto) PARSER.parseFrom(bArr);
    }

    public static DeviceProto parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (DeviceProto) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
