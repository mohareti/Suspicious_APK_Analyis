package org.uasecurity.mining.proto.user;

import Vae0ahx6Cuoj.kuedujio7Aev;
import XoN2Ii3eiqu0.GieBae8eiNge;
import XoN2Ii3eiqu0.chuYaeghie9C;
import XoN2Ii3eiqu0.quiBuGh8zigh;
import com.google.protobuf.AeJiPo4of6Sh;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class MiningServiceGrpc {
    private static final int METHODID_CHECK_CREDENTIAL_VALIDITY = 1;
    private static final int METHODID_GET_MINING_ARGS = 3;
    private static final int METHODID_MINER_REGISTER = 0;
    private static final int METHODID_RECORD_MINING_LOG = 2;
    public static final GieBae8eiNge METHOD_CHECK_CREDENTIAL_VALIDITY;
    public static final GieBae8eiNge METHOD_GET_MINING_ARGS;
    public static final GieBae8eiNge METHOD_MINER_REGISTER;
    public static final GieBae8eiNge METHOD_RECORD_MINING_LOG;
    public static final String SERVICE_NAME = "MiningService";
    private static volatile chuYaeghie9C serviceDescriptor;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MethodHandlers<Req, Resp> implements kuedujio7Aev.ieseir3Choge, kuedujio7Aev.thooCoci9zae {
        private final int methodId;
        private final MiningServiceImplBase serviceImpl;

        public MethodHandlers(MiningServiceImplBase miningServiceImplBase, int i) {
            this.serviceImpl = miningServiceImplBase;
            this.methodId = i;
        }

        public Vae0ahx6Cuoj.Aicohm8ieYoo invoke(Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            throw new AssertionError();
        }

        /* JADX WARN: Multi-variable type inference failed */
        public void invoke(Req req, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            int i = this.methodId;
            if (i == 0) {
                this.serviceImpl.minerRegister((MinerRegisterRequest) req, aicohm8ieYoo);
                return;
            }
            if (i == 1) {
                this.serviceImpl.checkCredentialValidity((CheckCredentialValidityRequest) req, aicohm8ieYoo);
            } else if (i == 2) {
                this.serviceImpl.recordMiningLog((RecordMiningLogRequest) req, aicohm8ieYoo);
            } else {
                if (i != 3) {
                    throw new AssertionError();
                }
                this.serviceImpl.getMiningArgs((GetMiningArgsRequest) req, aicohm8ieYoo);
            }
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class MiningServiceBaseDescriptorSupplier {
        public AeJiPo4of6Sh.niah0Shohtha getFileDescriptor() {
            return Mine.getDescriptor();
        }

        public AeJiPo4of6Sh.mi5Iecheimie getServiceDescriptor() {
            return getFileDescriptor().zoojiiKaht3i(MiningServiceGrpc.SERVICE_NAME);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MiningServiceBlockingStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private MiningServiceBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public CheckCredentialValidityResponse checkCredentialValidity(CheckCredentialValidityRequest checkCredentialValidityRequest) {
            return (CheckCredentialValidityResponse) Vae0ahx6Cuoj.ieheiQu9sho5.ieheiQu9sho5(getChannel(), MiningServiceGrpc.METHOD_CHECK_CREDENTIAL_VALIDITY, getCallOptions(), checkCredentialValidityRequest);
        }

        public GetMiningArgsResponse getMiningArgs(GetMiningArgsRequest getMiningArgsRequest) {
            return (GetMiningArgsResponse) Vae0ahx6Cuoj.ieheiQu9sho5.ieheiQu9sho5(getChannel(), MiningServiceGrpc.METHOD_GET_MINING_ARGS, getCallOptions(), getMiningArgsRequest);
        }

        public MinerRegisterResponse minerRegister(MinerRegisterRequest minerRegisterRequest) {
            return (MinerRegisterResponse) Vae0ahx6Cuoj.ieheiQu9sho5.ieheiQu9sho5(getChannel(), MiningServiceGrpc.METHOD_MINER_REGISTER, getCallOptions(), minerRegisterRequest);
        }

        public RecordMiningLogResponse recordMiningLog(RecordMiningLogRequest recordMiningLogRequest) {
            return (RecordMiningLogResponse) Vae0ahx6Cuoj.ieheiQu9sho5.ieheiQu9sho5(getChannel(), MiningServiceGrpc.METHOD_RECORD_MINING_LOG, getCallOptions(), recordMiningLogRequest);
        }

        private MiningServiceBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public MiningServiceBlockingStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new MiningServiceBlockingStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MiningServiceFileDescriptorSupplier extends MiningServiceBaseDescriptorSupplier {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MiningServiceFutureStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private MiningServiceFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public aP7aChee7eid.kuedujio7Aev checkCredentialValidity(CheckCredentialValidityRequest checkCredentialValidityRequest) {
            return Vae0ahx6Cuoj.ieheiQu9sho5.Aicohm8ieYoo(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_CHECK_CREDENTIAL_VALIDITY, getCallOptions()), checkCredentialValidityRequest);
        }

        public aP7aChee7eid.kuedujio7Aev getMiningArgs(GetMiningArgsRequest getMiningArgsRequest) {
            return Vae0ahx6Cuoj.ieheiQu9sho5.Aicohm8ieYoo(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_GET_MINING_ARGS, getCallOptions()), getMiningArgsRequest);
        }

        public aP7aChee7eid.kuedujio7Aev minerRegister(MinerRegisterRequest minerRegisterRequest) {
            return Vae0ahx6Cuoj.ieheiQu9sho5.Aicohm8ieYoo(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_MINER_REGISTER, getCallOptions()), minerRegisterRequest);
        }

        public aP7aChee7eid.kuedujio7Aev recordMiningLog(RecordMiningLogRequest recordMiningLogRequest) {
            return Vae0ahx6Cuoj.ieheiQu9sho5.Aicohm8ieYoo(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_RECORD_MINING_LOG, getCallOptions()), recordMiningLogRequest);
        }

        private MiningServiceFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public MiningServiceFutureStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new MiningServiceFutureStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class MiningServiceImplBase {
        public final quiBuGh8zigh bindService() {
            return quiBuGh8zigh.ieseir3Choge(MiningServiceGrpc.getServiceDescriptor()).ieseir3Choge(MiningServiceGrpc.METHOD_MINER_REGISTER, Vae0ahx6Cuoj.kuedujio7Aev.ieseir3Choge(new MethodHandlers(this, 0))).ieseir3Choge(MiningServiceGrpc.METHOD_CHECK_CREDENTIAL_VALIDITY, Vae0ahx6Cuoj.kuedujio7Aev.ieseir3Choge(new MethodHandlers(this, 1))).ieseir3Choge(MiningServiceGrpc.METHOD_RECORD_MINING_LOG, Vae0ahx6Cuoj.kuedujio7Aev.ieseir3Choge(new MethodHandlers(this, 2))).ieseir3Choge(MiningServiceGrpc.METHOD_GET_MINING_ARGS, Vae0ahx6Cuoj.kuedujio7Aev.ieseir3Choge(new MethodHandlers(this, 3))).keiL1EiShomu();
        }

        public void checkCredentialValidity(CheckCredentialValidityRequest checkCredentialValidityRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.kuedujio7Aev.thooCoci9zae(MiningServiceGrpc.METHOD_CHECK_CREDENTIAL_VALIDITY, aicohm8ieYoo);
        }

        public void getMiningArgs(GetMiningArgsRequest getMiningArgsRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.kuedujio7Aev.thooCoci9zae(MiningServiceGrpc.METHOD_GET_MINING_ARGS, aicohm8ieYoo);
        }

        public void minerRegister(MinerRegisterRequest minerRegisterRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.kuedujio7Aev.thooCoci9zae(MiningServiceGrpc.METHOD_MINER_REGISTER, aicohm8ieYoo);
        }

        public void recordMiningLog(RecordMiningLogRequest recordMiningLogRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.kuedujio7Aev.thooCoci9zae(MiningServiceGrpc.METHOD_RECORD_MINING_LOG, aicohm8ieYoo);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MiningServiceMethodDescriptorSupplier extends MiningServiceBaseDescriptorSupplier {
        private final String methodName;

        public MiningServiceMethodDescriptorSupplier(String str) {
            this.methodName = str;
        }

        public AeJiPo4of6Sh.ko7aiFeiqu3s getMethodDescriptor() {
            return getServiceDescriptor().zoojiiKaht3i(this.methodName);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MiningServiceStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private MiningServiceStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public void checkCredentialValidity(CheckCredentialValidityRequest checkCredentialValidityRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.ieheiQu9sho5.ieseir3Choge(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_CHECK_CREDENTIAL_VALIDITY, getCallOptions()), checkCredentialValidityRequest, aicohm8ieYoo);
        }

        public void getMiningArgs(GetMiningArgsRequest getMiningArgsRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.ieheiQu9sho5.ieseir3Choge(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_GET_MINING_ARGS, getCallOptions()), getMiningArgsRequest, aicohm8ieYoo);
        }

        public void minerRegister(MinerRegisterRequest minerRegisterRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.ieheiQu9sho5.ieseir3Choge(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_MINER_REGISTER, getCallOptions()), minerRegisterRequest, aicohm8ieYoo);
        }

        public void recordMiningLog(RecordMiningLogRequest recordMiningLogRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.ieheiQu9sho5.ieseir3Choge(getChannel().thooCoci9zae(MiningServiceGrpc.METHOD_RECORD_MINING_LOG, getCallOptions()), recordMiningLogRequest, aicohm8ieYoo);
        }

        private MiningServiceStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public MiningServiceStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new MiningServiceStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    static {
        GieBae8eiNge.thooCoci9zae Jah0aiP1ki6y2 = GieBae8eiNge.Jah0aiP1ki6y();
        GieBae8eiNge.ieheiQu9sho5 ieheiqu9sho5 = GieBae8eiNge.ieheiQu9sho5.UNARY;
        METHOD_MINER_REGISTER = Jah0aiP1ki6y2.Aicohm8ieYoo(ieheiqu9sho5).thooCoci9zae(GieBae8eiNge.thooCoci9zae(SERVICE_NAME, "MinerRegister")).keiL1EiShomu(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(MinerRegisterRequest.getDefaultInstance())).ieheiQu9sho5(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(MinerRegisterResponse.getDefaultInstance())).kuedujio7Aev(new MiningServiceMethodDescriptorSupplier("MinerRegister")).ieseir3Choge();
        METHOD_CHECK_CREDENTIAL_VALIDITY = GieBae8eiNge.Jah0aiP1ki6y().Aicohm8ieYoo(ieheiqu9sho5).thooCoci9zae(GieBae8eiNge.thooCoci9zae(SERVICE_NAME, "CheckCredentialValidity")).keiL1EiShomu(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(CheckCredentialValidityRequest.getDefaultInstance())).ieheiQu9sho5(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(CheckCredentialValidityResponse.getDefaultInstance())).kuedujio7Aev(new MiningServiceMethodDescriptorSupplier("CheckCredentialValidity")).ieseir3Choge();
        METHOD_RECORD_MINING_LOG = GieBae8eiNge.Jah0aiP1ki6y().Aicohm8ieYoo(ieheiqu9sho5).thooCoci9zae(GieBae8eiNge.thooCoci9zae(SERVICE_NAME, "RecordMiningLog")).keiL1EiShomu(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(RecordMiningLogRequest.getDefaultInstance())).ieheiQu9sho5(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(RecordMiningLogResponse.getDefaultInstance())).kuedujio7Aev(new MiningServiceMethodDescriptorSupplier("RecordMiningLog")).ieseir3Choge();
        METHOD_GET_MINING_ARGS = GieBae8eiNge.Jah0aiP1ki6y().Aicohm8ieYoo(ieheiqu9sho5).thooCoci9zae(GieBae8eiNge.thooCoci9zae(SERVICE_NAME, "GetMiningArgs")).keiL1EiShomu(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(GetMiningArgsRequest.getDefaultInstance())).ieheiQu9sho5(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(GetMiningArgsResponse.getDefaultInstance())).kuedujio7Aev(new MiningServiceMethodDescriptorSupplier("GetMiningArgs")).ieseir3Choge();
    }

    private MiningServiceGrpc() {
    }

    public static chuYaeghie9C getServiceDescriptor() {
        chuYaeghie9C chuyaeghie9c = serviceDescriptor;
        if (chuyaeghie9c == null) {
            synchronized (MiningServiceGrpc.class) {
                try {
                    chuyaeghie9c = serviceDescriptor;
                    if (chuyaeghie9c == null) {
                        chuyaeghie9c = chuYaeghie9C.keiL1EiShomu(SERVICE_NAME).ohv5Shie7AeZ(new MiningServiceFileDescriptorSupplier()).Aicohm8ieYoo(METHOD_MINER_REGISTER).Aicohm8ieYoo(METHOD_CHECK_CREDENTIAL_VALIDITY).Aicohm8ieYoo(METHOD_RECORD_MINING_LOG).Aicohm8ieYoo(METHOD_GET_MINING_ARGS).Jah0aiP1ki6y();
                        serviceDescriptor = chuyaeghie9c;
                    }
                } finally {
                }
            }
        }
        return chuyaeghie9c;
    }

    public static MiningServiceBlockingStub newBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new MiningServiceBlockingStub(ieheiqu9sho5);
    }

    public static MiningServiceFutureStub newFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new MiningServiceFutureStub(ieheiqu9sho5);
    }

    public static MiningServiceStub newStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new MiningServiceStub(ieheiqu9sho5);
    }
}
