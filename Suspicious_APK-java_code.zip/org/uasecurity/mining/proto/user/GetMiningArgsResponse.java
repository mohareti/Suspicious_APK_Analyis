package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.eeG8Uuy5ohdo;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieph3Uteimah;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.thooCoci9zae;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.StatusInfo;
import org.uasecurity.mining.proto.common.StatusInfoOrBuilder;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class GetMiningArgsResponse extends IengaiSahh8H implements GetMiningArgsResponseOrBuilder {
    private static final GetMiningArgsResponse DEFAULT_INSTANCE;
    public static final int NEWARGS_FIELD_NUMBER = 2;
    private static final Id9uvaegh4ai PARSER;
    public static final int STATUS_FIELD_NUMBER = 1;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private byte memoizedIsInitialized;
    private ieph3Uteimah newArgs_;
    private StatusInfo status_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements GetMiningArgsResponseOrBuilder {
        private int bitField0_;
        private ieph3Uteimah newArgs_;
        private aeMuPhahFe7a statusBuilder_;
        private StatusInfo status_;

        private Builder() {
            this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(GetMiningArgsResponse getMiningArgsResponse) {
            int i;
            int i2 = this.bitField0_;
            if ((i2 & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
                getMiningArgsResponse.status_ = aemuphahfe7a == null ? this.status_ : (StatusInfo) aemuphahfe7a.thooCoci9zae();
                i = 1;
            } else {
                i = 0;
            }
            if ((i2 & 2) != 0) {
                this.newArgs_.thooCoci9zae();
                getMiningArgsResponse.newArgs_ = this.newArgs_;
            }
            GetMiningArgsResponse.access$676(getMiningArgsResponse, i);
        }

        private void ensureNewArgsIsMutable() {
            if (!this.newArgs_.niah0Shohtha()) {
                this.newArgs_ = new ieph3Uteimah(this.newArgs_);
            }
            this.bitField0_ |= 2;
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_GetMiningArgsResponse_descriptor;
        }

        private aeMuPhahFe7a getStatusFieldBuilder() {
            if (this.statusBuilder_ == null) {
                this.statusBuilder_ = new aeMuPhahFe7a(getStatus(), getParentForChildren(), isClean());
                this.status_ = null;
            }
            return this.statusBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getStatusFieldBuilder();
            }
        }

        public Builder addAllNewArgs(Iterable<String> iterable) {
            ensureNewArgsIsMutable();
            thooCoci9zae.ieseir3Choge.addAll((Iterable) iterable, (List) this.newArgs_);
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder addNewArgs(String str) {
            str.getClass();
            ensureNewArgsIsMutable();
            this.newArgs_.add(str);
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder addNewArgsBytes(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
            ohv5shie7aez.getClass();
            com.google.protobuf.thooCoci9zae.checkByteStringIsUtf8(ohv5shie7aez);
            ensureNewArgsIsMutable();
            this.newArgs_.kuedujio7Aev(ohv5shie7aez);
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder clearNewArgs() {
            this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
            this.bitField0_ &= -3;
            onChanged();
            return this;
        }

        public Builder clearStatus() {
            this.bitField0_ &= -2;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_GetMiningArgsResponse_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public String getNewArgs(int i) {
            return this.newArgs_.get(i);
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public com.google.protobuf.ohv5Shie7AeZ getNewArgsBytes(int i) {
            return this.newArgs_.eetheKaevie8(i);
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public int getNewArgsCount() {
            return this.newArgs_.size();
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public eeG8Uuy5ohdo getNewArgsList() {
            this.newArgs_.thooCoci9zae();
            return this.newArgs_;
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public StatusInfo getStatus() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfo) aemuphahfe7a.kuedujio7Aev();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        public StatusInfo.Builder getStatusBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (StatusInfo.Builder) getStatusFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public StatusInfoOrBuilder getStatusOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                return (StatusInfoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            StatusInfo statusInfo = this.status_;
            return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
        }

        @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
        public boolean hasStatus() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_GetMiningArgsResponse_fieldAccessorTable.ieheiQu9sho5(GetMiningArgsResponse.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeStatus(StatusInfo statusInfo) {
            StatusInfo statusInfo2;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(statusInfo);
            } else if ((this.bitField0_ & 1) == 0 || (statusInfo2 = this.status_) == null || statusInfo2 == StatusInfo.getDefaultInstance()) {
                this.status_ = statusInfo;
            } else {
                getStatusBuilder().mergeFrom(statusInfo);
            }
            if (this.status_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setNewArgs(int i, String str) {
            str.getClass();
            ensureNewArgsIsMutable();
            this.newArgs_.set(i, str);
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        public Builder setStatus(StatusInfo.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            StatusInfo build = builder.build();
            if (aemuphahfe7a == null) {
                this.status_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
            maybeForceBuilderInitialization();
        }

        public Builder setStatus(StatusInfo statusInfo) {
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a == null) {
                statusInfo.getClass();
                this.status_ = statusInfo;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(statusInfo);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public GetMiningArgsResponse build() {
            GetMiningArgsResponse buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public GetMiningArgsResponse buildPartial() {
            GetMiningArgsResponse getMiningArgsResponse = new GetMiningArgsResponse(this);
            if (this.bitField0_ != 0) {
                buildPartial0(getMiningArgsResponse);
            }
            onBuilt();
            return getMiningArgsResponse;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public GetMiningArgsResponse getDefaultInstanceForType() {
            return GetMiningArgsResponse.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m56clear() {
            super.m56clear();
            this.bitField0_ = 0;
            this.status_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.statusBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.statusBuilder_ = null;
            }
            this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getStatusFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                String mi3Ozool1oa42 = ko7aifeiqu3s.mi3Ozool1oa4();
                                ensureNewArgsIsMutable();
                                this.newArgs_.add(mi3Ozool1oa42);
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof GetMiningArgsResponse) {
                return mergeFrom((GetMiningArgsResponse) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(GetMiningArgsResponse getMiningArgsResponse) {
            if (getMiningArgsResponse == GetMiningArgsResponse.getDefaultInstance()) {
                return this;
            }
            if (getMiningArgsResponse.hasStatus()) {
                mergeStatus(getMiningArgsResponse.getStatus());
            }
            if (!getMiningArgsResponse.newArgs_.isEmpty()) {
                if (this.newArgs_.isEmpty()) {
                    this.newArgs_ = getMiningArgsResponse.newArgs_;
                    this.bitField0_ |= 2;
                } else {
                    ensureNewArgsIsMutable();
                    this.newArgs_.addAll(getMiningArgsResponse.newArgs_);
                }
                onChanged();
            }
            m8mergeUnknownFields(getMiningArgsResponse.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, GetMiningArgsResponse.class.getName());
        DEFAULT_INSTANCE = new GetMiningArgsResponse();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.GetMiningArgsResponse.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public GetMiningArgsResponse parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = GetMiningArgsResponse.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private GetMiningArgsResponse() {
        this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
        this.memoizedIsInitialized = (byte) -1;
        this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
    }

    public static /* synthetic */ int access$676(GetMiningArgsResponse getMiningArgsResponse, int i) {
        int i2 = i | getMiningArgsResponse.bitField0_;
        getMiningArgsResponse.bitField0_ = i2;
        return i2;
    }

    public static GetMiningArgsResponse getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_GetMiningArgsResponse_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static GetMiningArgsResponse parseDelimitedFrom(InputStream inputStream) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static GetMiningArgsResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (GetMiningArgsResponse) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GetMiningArgsResponse)) {
            return super.equals(obj);
        }
        GetMiningArgsResponse getMiningArgsResponse = (GetMiningArgsResponse) obj;
        if (hasStatus() != getMiningArgsResponse.hasStatus()) {
            return false;
        }
        return (!hasStatus() || getStatus().equals(getMiningArgsResponse.getStatus())) && getNewArgsList().equals(getMiningArgsResponse.getNewArgsList()) && getUnknownFields().equals(getMiningArgsResponse.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public String getNewArgs(int i) {
        return this.newArgs_.get(i);
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public com.google.protobuf.ohv5Shie7AeZ getNewArgsBytes(int i) {
        return this.newArgs_.eetheKaevie8(i);
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public int getNewArgsCount() {
        return this.newArgs_.size();
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public eeG8Uuy5ohdo getNewArgsList() {
        return this.newArgs_;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = (this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getStatus()) : 0;
        int i2 = 0;
        for (int i3 = 0; i3 < this.newArgs_.size(); i3++) {
            i2 += IengaiSahh8H.computeStringSizeNoTag(this.newArgs_.keiL1EiShomu(i3));
        }
        int size = Meu0ophaeng12 + i2 + getNewArgsList().size() + getUnknownFields().getSerializedSize();
        this.memoizedSize = size;
        return size;
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public StatusInfo getStatus() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public StatusInfoOrBuilder getStatusOrBuilder() {
        StatusInfo statusInfo = this.status_;
        return statusInfo == null ? StatusInfo.getDefaultInstance() : statusInfo;
    }

    @Override // org.uasecurity.mining.proto.user.GetMiningArgsResponseOrBuilder
    public boolean hasStatus() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasStatus()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getStatus().hashCode();
        }
        if (getNewArgsCount() > 0) {
            hashCode = (((hashCode * 37) + 2) * 53) + getNewArgsList().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_GetMiningArgsResponse_fieldAccessorTable.ieheiQu9sho5(GetMiningArgsResponse.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getStatus());
        }
        for (int i = 0; i < this.newArgs_.size(); i++) {
            IengaiSahh8H.writeString(ahthok6usais, 2, this.newArgs_.keiL1EiShomu(i));
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private GetMiningArgsResponse(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.newArgs_ = ieph3Uteimah.AeJiPo4of6Sh();
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(GetMiningArgsResponse getMiningArgsResponse) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(getMiningArgsResponse);
    }

    public static GetMiningArgsResponse parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static GetMiningArgsResponse parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static GetMiningArgsResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public GetMiningArgsResponse getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static GetMiningArgsResponse parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static GetMiningArgsResponse parseFrom(InputStream inputStream) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static GetMiningArgsResponse parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static GetMiningArgsResponse parseFrom(ByteBuffer byteBuffer) {
        return (GetMiningArgsResponse) PARSER.parseFrom(byteBuffer);
    }

    public static GetMiningArgsResponse parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static GetMiningArgsResponse parseFrom(byte[] bArr) {
        return (GetMiningArgsResponse) PARSER.parseFrom(bArr);
    }

    public static GetMiningArgsResponse parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (GetMiningArgsResponse) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
