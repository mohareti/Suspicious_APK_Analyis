package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.user.DeviceProto;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class MinerRegisterRequest extends IengaiSahh8H implements MinerRegisterRequestOrBuilder {
    private static final MinerRegisterRequest DEFAULT_INSTANCE;
    public static final int DEVICEPROTO_FIELD_NUMBER = 1;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private DeviceProto deviceProto_;
    private byte memoizedIsInitialized;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements MinerRegisterRequestOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a deviceProtoBuilder_;
        private DeviceProto deviceProto_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(MinerRegisterRequest minerRegisterRequest) {
            int i = 1;
            if ((this.bitField0_ & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
                minerRegisterRequest.deviceProto_ = aemuphahfe7a == null ? this.deviceProto_ : (DeviceProto) aemuphahfe7a.thooCoci9zae();
            } else {
                i = 0;
            }
            MinerRegisterRequest.access$576(minerRegisterRequest, i);
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_MinerRegisterRequest_descriptor;
        }

        private aeMuPhahFe7a getDeviceProtoFieldBuilder() {
            if (this.deviceProtoBuilder_ == null) {
                this.deviceProtoBuilder_ = new aeMuPhahFe7a(getDeviceProto(), getParentForChildren(), isClean());
                this.deviceProto_ = null;
            }
            return this.deviceProtoBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getDeviceProtoFieldBuilder();
            }
        }

        public Builder clearDeviceProto() {
            this.bitField0_ &= -2;
            this.deviceProto_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.deviceProtoBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_MinerRegisterRequest_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
        public DeviceProto getDeviceProto() {
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (DeviceProto) aemuphahfe7a.kuedujio7Aev();
            }
            DeviceProto deviceProto = this.deviceProto_;
            return deviceProto == null ? DeviceProto.getDefaultInstance() : deviceProto;
        }

        public DeviceProto.Builder getDeviceProtoBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (DeviceProto.Builder) getDeviceProtoFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
        public DeviceProtoOrBuilder getDeviceProtoOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (DeviceProtoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            DeviceProto deviceProto = this.deviceProto_;
            return deviceProto == null ? DeviceProto.getDefaultInstance() : deviceProto;
        }

        @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
        public boolean hasDeviceProto() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_MinerRegisterRequest_fieldAccessorTable.ieheiQu9sho5(MinerRegisterRequest.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeDeviceProto(DeviceProto deviceProto) {
            DeviceProto deviceProto2;
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(deviceProto);
            } else if ((this.bitField0_ & 1) == 0 || (deviceProto2 = this.deviceProto_) == null || deviceProto2 == DeviceProto.getDefaultInstance()) {
                this.deviceProto_ = deviceProto;
            } else {
                getDeviceProtoBuilder().mergeFrom(deviceProto);
            }
            if (this.deviceProto_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder setDeviceProto(DeviceProto.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            DeviceProto build = builder.build();
            if (aemuphahfe7a == null) {
                this.deviceProto_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setDeviceProto(DeviceProto deviceProto) {
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a == null) {
                deviceProto.getClass();
                this.deviceProto_ = deviceProto;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(deviceProto);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MinerRegisterRequest build() {
            MinerRegisterRequest buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public MinerRegisterRequest buildPartial() {
            MinerRegisterRequest minerRegisterRequest = new MinerRegisterRequest(this);
            if (this.bitField0_ != 0) {
                buildPartial0(minerRegisterRequest);
            }
            onBuilt();
            return minerRegisterRequest;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public MinerRegisterRequest getDefaultInstanceForType() {
            return MinerRegisterRequest.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m68clear() {
            super.m49clear();
            this.bitField0_ = 0;
            this.deviceProto_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.deviceProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.deviceProtoBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getDeviceProtoFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof MinerRegisterRequest) {
                return mergeFrom((MinerRegisterRequest) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(MinerRegisterRequest minerRegisterRequest) {
            if (minerRegisterRequest == MinerRegisterRequest.getDefaultInstance()) {
                return this;
            }
            if (minerRegisterRequest.hasDeviceProto()) {
                mergeDeviceProto(minerRegisterRequest.getDeviceProto());
            }
            m8mergeUnknownFields(minerRegisterRequest.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, MinerRegisterRequest.class.getName());
        DEFAULT_INSTANCE = new MinerRegisterRequest();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.MinerRegisterRequest.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public MinerRegisterRequest parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = MinerRegisterRequest.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private MinerRegisterRequest() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$576(MinerRegisterRequest minerRegisterRequest, int i) {
        int i2 = i | minerRegisterRequest.bitField0_;
        minerRegisterRequest.bitField0_ = i2;
        return i2;
    }

    public static MinerRegisterRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_MinerRegisterRequest_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static MinerRegisterRequest parseDelimitedFrom(InputStream inputStream) {
        return (MinerRegisterRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static MinerRegisterRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (MinerRegisterRequest) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MinerRegisterRequest)) {
            return super.equals(obj);
        }
        MinerRegisterRequest minerRegisterRequest = (MinerRegisterRequest) obj;
        if (hasDeviceProto() != minerRegisterRequest.hasDeviceProto()) {
            return false;
        }
        return (!hasDeviceProto() || getDeviceProto().equals(minerRegisterRequest.getDeviceProto())) && getUnknownFields().equals(minerRegisterRequest.getUnknownFields());
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
    public DeviceProto getDeviceProto() {
        DeviceProto deviceProto = this.deviceProto_;
        return deviceProto == null ? DeviceProto.getDefaultInstance() : deviceProto;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
    public DeviceProtoOrBuilder getDeviceProtoOrBuilder() {
        DeviceProto deviceProto = this.deviceProto_;
        return deviceProto == null ? DeviceProto.getDefaultInstance() : deviceProto;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = ((this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getDeviceProto()) : 0) + getUnknownFields().getSerializedSize();
        this.memoizedSize = Meu0ophaeng12;
        return Meu0ophaeng12;
    }

    @Override // org.uasecurity.mining.proto.user.MinerRegisterRequestOrBuilder
    public boolean hasDeviceProto() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasDeviceProto()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getDeviceProto().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_MinerRegisterRequest_fieldAccessorTable.ieheiQu9sho5(MinerRegisterRequest.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getDeviceProto());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private MinerRegisterRequest(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(MinerRegisterRequest minerRegisterRequest) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(minerRegisterRequest);
    }

    public static MinerRegisterRequest parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MinerRegisterRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static MinerRegisterRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (MinerRegisterRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public MinerRegisterRequest getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static MinerRegisterRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static MinerRegisterRequest parseFrom(InputStream inputStream) {
        return (MinerRegisterRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static MinerRegisterRequest parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static MinerRegisterRequest parseFrom(ByteBuffer byteBuffer) {
        return (MinerRegisterRequest) PARSER.parseFrom(byteBuffer);
    }

    public static MinerRegisterRequest parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static MinerRegisterRequest parseFrom(byte[] bArr) {
        return (MinerRegisterRequest) PARSER.parseFrom(bArr);
    }

    public static MinerRegisterRequest parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (MinerRegisterRequest) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
