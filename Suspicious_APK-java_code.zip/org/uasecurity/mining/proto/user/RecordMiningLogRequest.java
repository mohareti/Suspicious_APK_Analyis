package org.uasecurity.mining.proto.user;

import com.google.protobuf.AeJiPo4of6Sh;
import com.google.protobuf.Do5Ierepupup;
import com.google.protobuf.Id9uvaegh4ai;
import com.google.protobuf.IengaiSahh8H;
import com.google.protobuf.aeMuPhahFe7a;
import com.google.protobuf.esohshee3Pau;
import com.google.protobuf.ieseir3Choge;
import com.google.protobuf.io4laQuei7sa;
import com.google.protobuf.ohBoophood9o;
import com.google.protobuf.woizoTie7shi;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import org.conscrypt.BuildConfig;
import org.uasecurity.mining.proto.common.Credential;
import org.uasecurity.mining.proto.common.CredentialOrBuilder;
import org.uasecurity.mining.proto.user.MiningLogProto;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class RecordMiningLogRequest extends IengaiSahh8H implements RecordMiningLogRequestOrBuilder {
    public static final int CREDENTIAL_FIELD_NUMBER = 1;
    private static final RecordMiningLogRequest DEFAULT_INSTANCE;
    public static final int MININGLOGPROTO_FIELD_NUMBER = 2;
    private static final Id9uvaegh4ai PARSER;
    private static final long serialVersionUID = 0;
    private int bitField0_;
    private Credential credential_;
    private byte memoizedIsInitialized;
    private MiningLogProto miningLogProto_;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class Builder extends IengaiSahh8H.keiL1EiShomu implements RecordMiningLogRequestOrBuilder {
        private int bitField0_;
        private aeMuPhahFe7a credentialBuilder_;
        private Credential credential_;
        private aeMuPhahFe7a miningLogProtoBuilder_;
        private MiningLogProto miningLogProto_;

        private Builder() {
            maybeForceBuilderInitialization();
        }

        private void buildPartial0(RecordMiningLogRequest recordMiningLogRequest) {
            int i;
            int i2 = this.bitField0_;
            if ((i2 & 1) != 0) {
                aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
                recordMiningLogRequest.credential_ = aemuphahfe7a == null ? this.credential_ : (Credential) aemuphahfe7a.thooCoci9zae();
                i = 1;
            } else {
                i = 0;
            }
            if ((i2 & 2) != 0) {
                aeMuPhahFe7a aemuphahfe7a2 = this.miningLogProtoBuilder_;
                recordMiningLogRequest.miningLogProto_ = aemuphahfe7a2 == null ? this.miningLogProto_ : (MiningLogProto) aemuphahfe7a2.thooCoci9zae();
                i |= 2;
            }
            RecordMiningLogRequest.access$676(recordMiningLogRequest, i);
        }

        private aeMuPhahFe7a getCredentialFieldBuilder() {
            if (this.credentialBuilder_ == null) {
                this.credentialBuilder_ = new aeMuPhahFe7a(getCredential(), getParentForChildren(), isClean());
                this.credential_ = null;
            }
            return this.credentialBuilder_;
        }

        public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
            return Mine.internal_static_RecordMiningLogRequest_descriptor;
        }

        private aeMuPhahFe7a getMiningLogProtoFieldBuilder() {
            if (this.miningLogProtoBuilder_ == null) {
                this.miningLogProtoBuilder_ = new aeMuPhahFe7a(getMiningLogProto(), getParentForChildren(), isClean());
                this.miningLogProto_ = null;
            }
            return this.miningLogProtoBuilder_;
        }

        private void maybeForceBuilderInitialization() {
            if (IengaiSahh8H.alwaysUseFieldBuilders) {
                getCredentialFieldBuilder();
                getMiningLogProtoFieldBuilder();
            }
        }

        public Builder clearCredential() {
            this.bitField0_ &= -2;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            onChanged();
            return this;
        }

        public Builder clearMiningLogProto() {
            this.bitField0_ &= -3;
            this.miningLogProto_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.miningLogProtoBuilder_ = null;
            }
            onChanged();
            return this;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public Credential getCredential() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (Credential) aemuphahfe7a.kuedujio7Aev();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        public Credential.Builder getCredentialBuilder() {
            this.bitField0_ |= 1;
            onChanged();
            return (Credential.Builder) getCredentialFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public CredentialOrBuilder getCredentialOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                return (CredentialOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            Credential credential = this.credential_;
            return credential == null ? Credential.getDefaultInstance() : credential;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu, com.google.protobuf.woizoTie7shi.ieseir3Choge, com.google.protobuf.chuYaeghie9C
        public AeJiPo4of6Sh.thooCoci9zae getDescriptorForType() {
            return Mine.internal_static_RecordMiningLogRequest_descriptor;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public MiningLogProto getMiningLogProto() {
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (MiningLogProto) aemuphahfe7a.kuedujio7Aev();
            }
            MiningLogProto miningLogProto = this.miningLogProto_;
            return miningLogProto == null ? MiningLogProto.getDefaultInstance() : miningLogProto;
        }

        public MiningLogProto.Builder getMiningLogProtoBuilder() {
            this.bitField0_ |= 2;
            onChanged();
            return (MiningLogProto.Builder) getMiningLogProtoFieldBuilder().ieheiQu9sho5();
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public MiningLogProtoOrBuilder getMiningLogProtoOrBuilder() {
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            if (aemuphahfe7a != null) {
                return (MiningLogProtoOrBuilder) aemuphahfe7a.Aicohm8ieYoo();
            }
            MiningLogProto miningLogProto = this.miningLogProto_;
            return miningLogProto == null ? MiningLogProto.getDefaultInstance() : miningLogProto;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public boolean hasCredential() {
            return (this.bitField0_ & 1) != 0;
        }

        @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
        public boolean hasMiningLogProto() {
            return (this.bitField0_ & 2) != 0;
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
            return Mine.internal_static_RecordMiningLogRequest_fieldAccessorTable.ieheiQu9sho5(RecordMiningLogRequest.class, Builder.class);
        }

        @Override // com.google.protobuf.ooJahquoo9ei
        public final boolean isInitialized() {
            return true;
        }

        public Builder mergeCredential(Credential credential) {
            Credential credential2;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(credential);
            } else if ((this.bitField0_ & 1) == 0 || (credential2 = this.credential_) == null || credential2 == Credential.getDefaultInstance()) {
                this.credential_ = credential;
            } else {
                getCredentialBuilder().mergeFrom(credential);
            }
            if (this.credential_ != null) {
                this.bitField0_ |= 1;
                onChanged();
            }
            return this;
        }

        public Builder mergeMiningLogProto(MiningLogProto miningLogProto) {
            MiningLogProto miningLogProto2;
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.Jah0aiP1ki6y(miningLogProto);
            } else if ((this.bitField0_ & 2) == 0 || (miningLogProto2 = this.miningLogProto_) == null || miningLogProto2 == MiningLogProto.getDefaultInstance()) {
                this.miningLogProto_ = miningLogProto;
            } else {
                getMiningLogProtoBuilder().mergeFrom(miningLogProto);
            }
            if (this.miningLogProto_ != null) {
                this.bitField0_ |= 2;
                onChanged();
            }
            return this;
        }

        public Builder setCredential(Credential.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            Credential build = builder.build();
            if (aemuphahfe7a == null) {
                this.credential_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setMiningLogProto(MiningLogProto.Builder builder) {
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            MiningLogProto build = builder.build();
            if (aemuphahfe7a == null) {
                this.miningLogProto_ = build;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(build);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        private Builder(ieseir3Choge.thooCoci9zae thoococi9zae) {
            super(thoococi9zae);
            maybeForceBuilderInitialization();
        }

        public Builder setCredential(Credential credential) {
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a == null) {
                credential.getClass();
                this.credential_ = credential;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(credential);
            }
            this.bitField0_ |= 1;
            onChanged();
            return this;
        }

        public Builder setMiningLogProto(MiningLogProto miningLogProto) {
            aeMuPhahFe7a aemuphahfe7a = this.miningLogProtoBuilder_;
            if (aemuphahfe7a == null) {
                miningLogProto.getClass();
                this.miningLogProto_ = miningLogProto;
            } else {
                aemuphahfe7a.ohv5Shie7AeZ(miningLogProto);
            }
            this.bitField0_ |= 2;
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public RecordMiningLogRequest build() {
            RecordMiningLogRequest buildPartial = buildPartial();
            if (buildPartial.isInitialized()) {
                return buildPartial;
            }
            throw ieseir3Choge.AbstractC0067ieseir3Choge.newUninitializedMessageException((woizoTie7shi) buildPartial);
        }

        @Override // com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public RecordMiningLogRequest buildPartial() {
            RecordMiningLogRequest recordMiningLogRequest = new RecordMiningLogRequest(this);
            if (this.bitField0_ != 0) {
                buildPartial0(recordMiningLogRequest);
            }
            onBuilt();
            return recordMiningLogRequest;
        }

        @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
        public RecordMiningLogRequest getDefaultInstanceForType() {
            return RecordMiningLogRequest.getDefaultInstance();
        }

        @Override // com.google.protobuf.IengaiSahh8H.keiL1EiShomu
        /* renamed from: clear, reason: merged with bridge method [inline-methods] and merged with bridge method [inline-methods] and merged with bridge method [inline-methods] */
        public Builder m77clear() {
            super.m74clear();
            this.bitField0_ = 0;
            this.credential_ = null;
            aeMuPhahFe7a aemuphahfe7a = this.credentialBuilder_;
            if (aemuphahfe7a != null) {
                aemuphahfe7a.keiL1EiShomu();
                this.credentialBuilder_ = null;
            }
            this.miningLogProto_ = null;
            aeMuPhahFe7a aemuphahfe7a2 = this.miningLogProtoBuilder_;
            if (aemuphahfe7a2 != null) {
                aemuphahfe7a2.keiL1EiShomu();
                this.miningLogProtoBuilder_ = null;
            }
            return this;
        }

        @Override // com.google.protobuf.ieseir3Choge.AbstractC0067ieseir3Choge, com.google.protobuf.Wee2wi3pheim.ieseir3Choge
        public Builder mergeFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
            esohshee3pau.getClass();
            boolean z = false;
            while (!z) {
                try {
                    try {
                        int io4laQuei7sa2 = ko7aifeiqu3s.io4laQuei7sa();
                        if (io4laQuei7sa2 != 0) {
                            if (io4laQuei7sa2 == 10) {
                                ko7aifeiqu3s.ahz5eechei8U(getCredentialFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 1;
                            } else if (io4laQuei7sa2 == 18) {
                                ko7aifeiqu3s.ahz5eechei8U(getMiningLogProtoFieldBuilder().ieheiQu9sho5(), esohshee3pau);
                                this.bitField0_ |= 2;
                            } else if (!super.parseUnknownField(ko7aifeiqu3s, esohshee3pau, io4laQuei7sa2)) {
                            }
                        }
                        z = true;
                    } catch (io4laQuei7sa e) {
                        throw e.mi5Iecheimie();
                    }
                } catch (Throwable th) {
                    onChanged();
                    throw th;
                }
            }
            onChanged();
            return this;
        }

        @Override // com.google.protobuf.woizoTie7shi.ieseir3Choge
        public Builder mergeFrom(woizoTie7shi woizotie7shi) {
            if (woizotie7shi instanceof RecordMiningLogRequest) {
                return mergeFrom((RecordMiningLogRequest) woizotie7shi);
            }
            super.mergeFrom(woizotie7shi);
            return this;
        }

        public Builder mergeFrom(RecordMiningLogRequest recordMiningLogRequest) {
            if (recordMiningLogRequest == RecordMiningLogRequest.getDefaultInstance()) {
                return this;
            }
            if (recordMiningLogRequest.hasCredential()) {
                mergeCredential(recordMiningLogRequest.getCredential());
            }
            if (recordMiningLogRequest.hasMiningLogProto()) {
                mergeMiningLogProto(recordMiningLogRequest.getMiningLogProto());
            }
            m8mergeUnknownFields(recordMiningLogRequest.getUnknownFields());
            onChanged();
            return this;
        }
    }

    static {
        Do5Ierepupup.thooCoci9zae(Do5Ierepupup.thooCoci9zae.PUBLIC, 4, 29, 2, BuildConfig.FLAVOR, RecordMiningLogRequest.class.getName());
        DEFAULT_INSTANCE = new RecordMiningLogRequest();
        PARSER = new com.google.protobuf.keiL1EiShomu() { // from class: org.uasecurity.mining.proto.user.RecordMiningLogRequest.1
            @Override // com.google.protobuf.Id9uvaegh4ai
            public RecordMiningLogRequest parsePartialFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
                Builder newBuilder = RecordMiningLogRequest.newBuilder();
                try {
                    newBuilder.mergeFrom(ko7aifeiqu3s, esohshee3pau);
                    return newBuilder.buildPartial();
                } catch (io4laQuei7sa e) {
                    throw e.ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (ohBoophood9o e2) {
                    throw e2.ieseir3Choge().ko7aiFeiqu3s(newBuilder.buildPartial());
                } catch (IOException e3) {
                    throw new io4laQuei7sa(e3).ko7aiFeiqu3s(newBuilder.buildPartial());
                }
            }
        };
    }

    private RecordMiningLogRequest() {
        this.memoizedIsInitialized = (byte) -1;
    }

    public static /* synthetic */ int access$676(RecordMiningLogRequest recordMiningLogRequest, int i) {
        int i2 = i | recordMiningLogRequest.bitField0_;
        recordMiningLogRequest.bitField0_ = i2;
        return i2;
    }

    public static RecordMiningLogRequest getDefaultInstance() {
        return DEFAULT_INSTANCE;
    }

    public static final AeJiPo4of6Sh.thooCoci9zae getDescriptor() {
        return Mine.internal_static_RecordMiningLogRequest_descriptor;
    }

    public static Builder newBuilder() {
        return DEFAULT_INSTANCE.toBuilder();
    }

    public static RecordMiningLogRequest parseDelimitedFrom(InputStream inputStream) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream);
    }

    public static RecordMiningLogRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez) {
        return (RecordMiningLogRequest) PARSER.parseFrom(ohv5shie7aez);
    }

    public static Id9uvaegh4ai parser() {
        return PARSER;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof RecordMiningLogRequest)) {
            return super.equals(obj);
        }
        RecordMiningLogRequest recordMiningLogRequest = (RecordMiningLogRequest) obj;
        if (hasCredential() != recordMiningLogRequest.hasCredential()) {
            return false;
        }
        if ((!hasCredential() || getCredential().equals(recordMiningLogRequest.getCredential())) && hasMiningLogProto() == recordMiningLogRequest.hasMiningLogProto()) {
            return (!hasMiningLogProto() || getMiningLogProto().equals(recordMiningLogRequest.getMiningLogProto())) && getUnknownFields().equals(recordMiningLogRequest.getUnknownFields());
        }
        return false;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public Credential getCredential() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public CredentialOrBuilder getCredentialOrBuilder() {
        Credential credential = this.credential_;
        return credential == null ? Credential.getDefaultInstance() : credential;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public MiningLogProto getMiningLogProto() {
        MiningLogProto miningLogProto = this.miningLogProto_;
        return miningLogProto == null ? MiningLogProto.getDefaultInstance() : miningLogProto;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public MiningLogProtoOrBuilder getMiningLogProtoOrBuilder() {
        MiningLogProto miningLogProto = this.miningLogProto_;
        return miningLogProto == null ? MiningLogProto.getDefaultInstance() : miningLogProto;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Id9uvaegh4ai getParserForType() {
        return PARSER;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public int getSerializedSize() {
        int i = this.memoizedSize;
        if (i != -1) {
            return i;
        }
        int Meu0ophaeng12 = (this.bitField0_ & 1) != 0 ? com.google.protobuf.ahthoK6usais.Meu0ophaeng1(1, getCredential()) : 0;
        if ((this.bitField0_ & 2) != 0) {
            Meu0ophaeng12 += com.google.protobuf.ahthoK6usais.Meu0ophaeng1(2, getMiningLogProto());
        }
        int serializedSize = Meu0ophaeng12 + getUnknownFields().getSerializedSize();
        this.memoizedSize = serializedSize;
        return serializedSize;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public boolean hasCredential() {
        return (this.bitField0_ & 1) != 0;
    }

    @Override // org.uasecurity.mining.proto.user.RecordMiningLogRequestOrBuilder
    public boolean hasMiningLogProto() {
        return (this.bitField0_ & 2) != 0;
    }

    @Override // com.google.protobuf.ieseir3Choge
    public int hashCode() {
        int i = this.memoizedHashCode;
        if (i != 0) {
            return i;
        }
        int hashCode = 779 + getDescriptor().hashCode();
        if (hasCredential()) {
            hashCode = (((hashCode * 37) + 1) * 53) + getCredential().hashCode();
        }
        if (hasMiningLogProto()) {
            hashCode = (((hashCode * 37) + 2) * 53) + getMiningLogProto().hashCode();
        }
        int hashCode2 = (hashCode * 29) + getUnknownFields().hashCode();
        this.memoizedHashCode = hashCode2;
        return hashCode2;
    }

    @Override // com.google.protobuf.IengaiSahh8H
    public IengaiSahh8H.niah0Shohtha internalGetFieldAccessorTable() {
        return Mine.internal_static_RecordMiningLogRequest_fieldAccessorTable.ieheiQu9sho5(RecordMiningLogRequest.class, Builder.class);
    }

    @Override // com.google.protobuf.ooJahquoo9ei
    public final boolean isInitialized() {
        byte b = this.memoizedIsInitialized;
        if (b == 1) {
            return true;
        }
        if (b == 0) {
            return false;
        }
        this.memoizedIsInitialized = (byte) 1;
        return true;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public void writeTo(com.google.protobuf.ahthoK6usais ahthok6usais) {
        if ((this.bitField0_ & 1) != 0) {
            ahthok6usais.Do5Ierepupup(1, getCredential());
        }
        if ((this.bitField0_ & 2) != 0) {
            ahthok6usais.Do5Ierepupup(2, getMiningLogProto());
        }
        getUnknownFields().writeTo(ahthok6usais);
    }

    private RecordMiningLogRequest(IengaiSahh8H.keiL1EiShomu keil1eishomu) {
        super(keil1eishomu);
        this.memoizedIsInitialized = (byte) -1;
    }

    public static Builder newBuilder(RecordMiningLogRequest recordMiningLogRequest) {
        return DEFAULT_INSTANCE.toBuilder().mergeFrom(recordMiningLogRequest);
    }

    public static RecordMiningLogRequest parseDelimitedFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseDelimitedWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static RecordMiningLogRequest parseFrom(com.google.protobuf.ohv5Shie7AeZ ohv5shie7aez, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) PARSER.parseFrom(ohv5shie7aez, esohshee3pau);
    }

    public static RecordMiningLogRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s);
    }

    @Override // com.google.protobuf.ooJahquoo9ei, com.google.protobuf.chuYaeghie9C
    public RecordMiningLogRequest getDefaultInstanceForType() {
        return DEFAULT_INSTANCE;
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder toBuilder() {
        return this == DEFAULT_INSTANCE ? new Builder() : new Builder().mergeFrom(this);
    }

    public static RecordMiningLogRequest parseFrom(com.google.protobuf.ko7aiFeiqu3s ko7aifeiqu3s, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseWithIOException(PARSER, ko7aifeiqu3s, esohshee3pau);
    }

    @Override // com.google.protobuf.Wee2wi3pheim
    public Builder newBuilderForType() {
        return newBuilder();
    }

    public static RecordMiningLogRequest parseFrom(InputStream inputStream) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream);
    }

    @Override // com.google.protobuf.ieseir3Choge
    public Builder newBuilderForType(ieseir3Choge.thooCoci9zae thoococi9zae) {
        return new Builder(thoococi9zae);
    }

    public static RecordMiningLogRequest parseFrom(InputStream inputStream, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) IengaiSahh8H.parseWithIOException(PARSER, inputStream, esohshee3pau);
    }

    public static RecordMiningLogRequest parseFrom(ByteBuffer byteBuffer) {
        return (RecordMiningLogRequest) PARSER.parseFrom(byteBuffer);
    }

    public static RecordMiningLogRequest parseFrom(ByteBuffer byteBuffer, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) PARSER.parseFrom(byteBuffer, esohshee3pau);
    }

    public static RecordMiningLogRequest parseFrom(byte[] bArr) {
        return (RecordMiningLogRequest) PARSER.parseFrom(bArr);
    }

    public static RecordMiningLogRequest parseFrom(byte[] bArr, esohshee3Pau esohshee3pau) {
        return (RecordMiningLogRequest) PARSER.parseFrom(bArr, esohshee3pau);
    }
}
