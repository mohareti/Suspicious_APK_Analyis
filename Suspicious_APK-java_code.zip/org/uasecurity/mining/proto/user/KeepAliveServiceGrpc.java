package org.uasecurity.mining.proto.user;

import Vae0ahx6Cuoj.kuedujio7Aev;
import XoN2Ii3eiqu0.GieBae8eiNge;
import XoN2Ii3eiqu0.chuYaeghie9C;
import XoN2Ii3eiqu0.quiBuGh8zigh;
import com.google.protobuf.AeJiPo4of6Sh;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class KeepAliveServiceGrpc {
    private static final int METHODID_KEEP_ALIVE = 0;
    private static volatile chuYaeghie9C serviceDescriptor;
    public static final String SERVICE_NAME = "KeepAliveService";
    public static final GieBae8eiNge METHOD_KEEP_ALIVE = GieBae8eiNge.Jah0aiP1ki6y().Aicohm8ieYoo(GieBae8eiNge.ieheiQu9sho5.UNARY).thooCoci9zae(GieBae8eiNge.thooCoci9zae(SERVICE_NAME, "KeepAlive")).keiL1EiShomu(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(KeepAliveRequest.getDefaultInstance())).ieheiQu9sho5(aim8aux9aJu5.ieseir3Choge.ieseir3Choge(KeepAliveResponse.getDefaultInstance())).kuedujio7Aev(new KeepAliveServiceMethodDescriptorSupplier("KeepAlive")).ieseir3Choge();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class KeepAliveServiceBaseDescriptorSupplier {
        public AeJiPo4of6Sh.niah0Shohtha getFileDescriptor() {
            return Keepalive.getDescriptor();
        }

        public AeJiPo4of6Sh.mi5Iecheimie getServiceDescriptor() {
            return getFileDescriptor().zoojiiKaht3i(KeepAliveServiceGrpc.SERVICE_NAME);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class KeepAliveServiceBlockingStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private KeepAliveServiceBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public KeepAliveResponse keepAlive(KeepAliveRequest keepAliveRequest) {
            return (KeepAliveResponse) Vae0ahx6Cuoj.ieheiQu9sho5.ieheiQu9sho5(getChannel(), KeepAliveServiceGrpc.METHOD_KEEP_ALIVE, getCallOptions(), keepAliveRequest);
        }

        private KeepAliveServiceBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public KeepAliveServiceBlockingStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new KeepAliveServiceBlockingStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class KeepAliveServiceFileDescriptorSupplier extends KeepAliveServiceBaseDescriptorSupplier {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class KeepAliveServiceFutureStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private KeepAliveServiceFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public aP7aChee7eid.kuedujio7Aev keepAlive(KeepAliveRequest keepAliveRequest) {
            return Vae0ahx6Cuoj.ieheiQu9sho5.Aicohm8ieYoo(getChannel().thooCoci9zae(KeepAliveServiceGrpc.METHOD_KEEP_ALIVE, getCallOptions()), keepAliveRequest);
        }

        private KeepAliveServiceFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public KeepAliveServiceFutureStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new KeepAliveServiceFutureStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class KeepAliveServiceImplBase {
        public final quiBuGh8zigh bindService() {
            return quiBuGh8zigh.ieseir3Choge(KeepAliveServiceGrpc.getServiceDescriptor()).ieseir3Choge(KeepAliveServiceGrpc.METHOD_KEEP_ALIVE, Vae0ahx6Cuoj.kuedujio7Aev.ieseir3Choge(new MethodHandlers(this, 0))).keiL1EiShomu();
        }

        public void keepAlive(KeepAliveRequest keepAliveRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.kuedujio7Aev.thooCoci9zae(KeepAliveServiceGrpc.METHOD_KEEP_ALIVE, aicohm8ieYoo);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class KeepAliveServiceMethodDescriptorSupplier extends KeepAliveServiceBaseDescriptorSupplier {
        private final String methodName;

        public KeepAliveServiceMethodDescriptorSupplier(String str) {
            this.methodName = str;
        }

        public AeJiPo4of6Sh.ko7aiFeiqu3s getMethodDescriptor() {
            return getServiceDescriptor().zoojiiKaht3i(this.methodName);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class KeepAliveServiceStub extends Vae0ahx6Cuoj.ieseir3Choge {
        private KeepAliveServiceStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
            super(ieheiqu9sho5);
        }

        public void keepAlive(KeepAliveRequest keepAliveRequest, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            Vae0ahx6Cuoj.ieheiQu9sho5.ieseir3Choge(getChannel().thooCoci9zae(KeepAliveServiceGrpc.METHOD_KEEP_ALIVE, getCallOptions()), keepAliveRequest, aicohm8ieYoo);
        }

        private KeepAliveServiceStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            super(ieheiqu9sho5, keil1eishomu);
        }

        @Override // Vae0ahx6Cuoj.ieseir3Choge
        public KeepAliveServiceStub build(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5, XoN2Ii3eiqu0.keiL1EiShomu keil1eishomu) {
            return new KeepAliveServiceStub(ieheiqu9sho5, keil1eishomu);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class MethodHandlers<Req, Resp> implements kuedujio7Aev.ieseir3Choge, kuedujio7Aev.thooCoci9zae {
        private final int methodId;
        private final KeepAliveServiceImplBase serviceImpl;

        public MethodHandlers(KeepAliveServiceImplBase keepAliveServiceImplBase, int i) {
            this.serviceImpl = keepAliveServiceImplBase;
            this.methodId = i;
        }

        public Vae0ahx6Cuoj.Aicohm8ieYoo invoke(Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            throw new AssertionError();
        }

        /* JADX WARN: Multi-variable type inference failed */
        public void invoke(Req req, Vae0ahx6Cuoj.Aicohm8ieYoo aicohm8ieYoo) {
            if (this.methodId != 0) {
                throw new AssertionError();
            }
            this.serviceImpl.keepAlive((KeepAliveRequest) req, aicohm8ieYoo);
        }
    }

    private KeepAliveServiceGrpc() {
    }

    public static chuYaeghie9C getServiceDescriptor() {
        chuYaeghie9C chuyaeghie9c = serviceDescriptor;
        if (chuyaeghie9c == null) {
            synchronized (KeepAliveServiceGrpc.class) {
                try {
                    chuyaeghie9c = serviceDescriptor;
                    if (chuyaeghie9c == null) {
                        chuyaeghie9c = chuYaeghie9C.keiL1EiShomu(SERVICE_NAME).ohv5Shie7AeZ(new KeepAliveServiceFileDescriptorSupplier()).Aicohm8ieYoo(METHOD_KEEP_ALIVE).Jah0aiP1ki6y();
                        serviceDescriptor = chuyaeghie9c;
                    }
                } finally {
                }
            }
        }
        return chuyaeghie9c;
    }

    public static KeepAliveServiceBlockingStub newBlockingStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new KeepAliveServiceBlockingStub(ieheiqu9sho5);
    }

    public static KeepAliveServiceFutureStub newFutureStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new KeepAliveServiceFutureStub(ieheiqu9sho5);
    }

    public static KeepAliveServiceStub newStub(XoN2Ii3eiqu0.ieheiQu9sho5 ieheiqu9sho5) {
        return new KeepAliveServiceStub(ieheiqu9sho5);
    }
}
