package Eikuh5Phaeth;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class keiL1EiShomu {
    public static /* synthetic */ void ieheiQu9sho5(Context context, Exception exc) {
        Log.d("FCMSubscriber", "failed to subscribe. reason: " + exc);
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException unused) {
        }
        kuedujio7Aev(context);
    }

    public static /* synthetic */ void keiL1EiShomu(SharedPreferences sharedPreferences, Void r2) {
        sharedPreferences.edit().putBoolean("subscription_successful", true).apply();
        Log.i("FCMSubscriber", "subscribed, we'll receive messages");
    }

    public static void kuedujio7Aev(final Context context) {
        final SharedPreferences sharedPreferences = context.getSharedPreferences("fcm", 0);
        if (sharedPreferences.getBoolean("subscription_successful", false)) {
            return;
        }
        FirebaseMessaging.AeJiPo4of6Sh().HaeYeFaep1if("all").Jah0aiP1ki6y(new vaeVoh2dei5I.Aicohm8ieYoo() { // from class: Eikuh5Phaeth.ieseir3Choge
            @Override // vaeVoh2dei5I.Aicohm8ieYoo
            public final void ieheiQu9sho5(Object obj) {
                keiL1EiShomu.keiL1EiShomu(sharedPreferences, (Void) obj);
            }
        }).kuedujio7Aev(new vaeVoh2dei5I.kuedujio7Aev() { // from class: Eikuh5Phaeth.thooCoci9zae
            @Override // vaeVoh2dei5I.kuedujio7Aev
            public final void keiL1EiShomu(Exception exc) {
                keiL1EiShomu.ieheiQu9sho5(context, exc);
            }
        });
    }
}
