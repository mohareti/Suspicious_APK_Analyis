package Eikuh5Phaeth;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.util.Log;
import com.example.fcmexpr.App;
import com.example.fcmexpr.keepalive.FirebaseMessagingKeepAliveService;
import java.util.concurrent.Callable;
import org.uasecurity.mining.proto.user.KeepAliveRecordProto;
import org.uasecurity.mining.proto.user.KeepAliveRequest;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ahthoK6usais implements Callable {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final long f1367ieseir3Choge;

    public ahthoK6usais(long j) {
        this.f1367ieseir3Choge = j;
    }

    @Override // java.util.concurrent.Callable
    /* renamed from: ieseir3Choge, reason: merged with bridge method [inline-methods] */
    public Void call() {
        int currentTimeMillis = (int) ((System.currentTimeMillis() - this.f1367ieseir3Choge) / 1000);
        int intProperty = ((BatteryManager) App.f4166ieseir3Choge.getSystemService("batterymanager")).getIntProperty(4);
        KeepAliveRequest build = KeepAliveRequest.newBuilder().setCredential(ohx8eem3Ahph.kuedujio7Aev.ieseir3Choge()).setKeepAliveRecordProto(KeepAliveRecordProto.newBuilder().setSessionAliveSeconds(currentTimeMillis).setDeviceBatteryLevel(intProperty).setIsOnMobileNetwork(thooCoci9zae(App.f4166ieseir3Choge)).setIsMining(ohx8eem3Ahph.niah0Shohtha.mi5Iecheimie(App.f4166ieseir3Choge).AeJiPo4of6Sh()).setIsHighPriorityFCMReceived(FirebaseMessagingKeepAliveService.oph9lahCh6uo(App.f4166ieseir3Choge)).build()).build();
        Log.i("KeepAliveStatusReporter", String.format("keep alive: request: %s\nresponse: %s", build, Xix0Vei5vo3j.keiL1EiShomu.ieseir3Choge().keepAlive(build)));
        return null;
    }

    public boolean thooCoci9zae(Context context) {
        NetworkInfo networkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        Network activeNetwork = connectivityManager.getActiveNetwork();
        if (activeNetwork == null || (networkInfo = connectivityManager.getNetworkInfo(activeNetwork)) == null || networkInfo.getType() != 0) {
            return false;
        }
        return true;
    }
}
