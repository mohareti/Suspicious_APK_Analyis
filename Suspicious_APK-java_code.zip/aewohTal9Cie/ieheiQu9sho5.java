package aewohTal9Cie;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieheiQu9sho5 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f2762ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final long f2763thooCoci9zae;

    public ieheiQu9sho5(String str, long j) {
        this.f2762ieseir3Choge = str;
        this.f2763thooCoci9zae = j;
    }
}
