package aewohTal9Cie;

import org.conscrypt.BuildConfig;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ieseir3Choge {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ieheiQu9sho5 f2764ieseir3Choge = new ieheiQu9sho5(BuildConfig.FLAVOR, Long.MIN_VALUE);

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final thooCoci9zae f2765thooCoci9zae = new thooCoci9zae(Long.MIN_VALUE);

    public ieseir3Choge(ieheiQu9sho5 ieheiqu9sho5) {
        if (ieheiqu9sho5 == f2764ieseir3Choge) {
        } else {
            throw new AssertionError("nope");
        }
    }

    public thooCoci9zae kuedujio7Aev() {
        return f2765thooCoci9zae;
    }

    public ieheiQu9sho5 thooCoci9zae(String str, long j) {
        return f2764ieseir3Choge;
    }

    public void Jah0aiP1ki6y() {
    }

    public void Aicohm8ieYoo(String str) {
    }

    public void ieheiQu9sho5(thooCoci9zae thoococi9zae) {
    }

    public void ieseir3Choge(ieheiQu9sho5 ieheiqu9sho5) {
    }

    public void keiL1EiShomu(String str, ieheiQu9sho5 ieheiqu9sho5) {
    }
}
