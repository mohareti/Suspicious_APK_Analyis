package aiL2see7giec;

import android.util.Base64;
import android.util.JsonWriter;
import java.io.Writer;
import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import thai5ichoM2a.Aicohm8ieYoo;
import thai5ichoM2a.Jah0aiP1ki6y;
import thai5ichoM2a.niah0Shohtha;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class kuedujio7Aev implements Aicohm8ieYoo, niah0Shohtha {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final thai5ichoM2a.kuedujio7Aev f2860Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final boolean f2861Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Map f2862ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final JsonWriter f2864keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final Map f2865kuedujio7Aev;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public kuedujio7Aev f2863ieseir3Choge = null;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public boolean f2866thooCoci9zae = true;

    public kuedujio7Aev(Writer writer, Map map, Map map2, thai5ichoM2a.kuedujio7Aev kuedujio7aev, boolean z) {
        this.f2864keiL1EiShomu = new JsonWriter(writer);
        this.f2862ieheiQu9sho5 = map;
        this.f2865kuedujio7Aev = map2;
        this.f2860Aicohm8ieYoo = kuedujio7aev;
        this.f2861Jah0aiP1ki6y = z;
    }

    public final boolean AeJiPo4of6Sh(Object obj) {
        if (obj != null && !obj.getClass().isArray() && !(obj instanceof Collection) && !(obj instanceof Date) && !(obj instanceof Enum) && !(obj instanceof Number)) {
            return false;
        }
        return true;
    }

    public kuedujio7Aev Aicohm8ieYoo(int i) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.value(i);
        return this;
    }

    public kuedujio7Aev Jah0aiP1ki6y(long j) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.value(j);
        return this;
    }

    public final kuedujio7Aev aac1eTaexee6(String str, Object obj) {
        if (obj == null) {
            return this;
        }
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.name(str);
        return niah0Shohtha(obj, false);
    }

    public kuedujio7Aev ahthoK6usais(String str, Object obj) {
        if (this.f2861Jah0aiP1ki6y) {
            return aac1eTaexee6(str, obj);
        }
        return zoojiiKaht3i(str, obj);
    }

    public kuedujio7Aev eetheKaevie8(thai5ichoM2a.kuedujio7Aev kuedujio7aev, Object obj, boolean z) {
        if (!z) {
            this.f2864keiL1EiShomu.beginObject();
        }
        kuedujio7aev.ieseir3Choge(obj, this);
        if (!z) {
            this.f2864keiL1EiShomu.endObject();
        }
        return this;
    }

    @Override // thai5ichoM2a.Aicohm8ieYoo
    public Aicohm8ieYoo ieheiQu9sho5(thai5ichoM2a.ieheiQu9sho5 ieheiqu9sho5, long j) {
        return ruNgecai1pae(ieheiqu9sho5.thooCoci9zae(), j);
    }

    @Override // thai5ichoM2a.Aicohm8ieYoo
    public Aicohm8ieYoo keiL1EiShomu(thai5ichoM2a.ieheiQu9sho5 ieheiqu9sho5, int i) {
        return ko7aiFeiqu3s(ieheiqu9sho5.thooCoci9zae(), i);
    }

    public kuedujio7Aev ko7aiFeiqu3s(String str, int i) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.name(str);
        return Aicohm8ieYoo(i);
    }

    @Override // thai5ichoM2a.Aicohm8ieYoo
    public Aicohm8ieYoo kuedujio7Aev(thai5ichoM2a.ieheiQu9sho5 ieheiqu9sho5, Object obj) {
        return ahthoK6usais(ieheiqu9sho5.thooCoci9zae(), obj);
    }

    public final void laej2zeez5Ja() {
        if (this.f2866thooCoci9zae) {
            kuedujio7Aev kuedujio7aev = this.f2863ieseir3Choge;
            if (kuedujio7aev != null) {
                kuedujio7aev.laej2zeez5Ja();
                this.f2863ieseir3Choge.f2866thooCoci9zae = false;
                this.f2863ieseir3Choge = null;
                this.f2864keiL1EiShomu.endObject();
                return;
            }
            return;
        }
        throw new IllegalStateException("Parent context used since this context was created. Cannot use this context anymore.");
    }

    @Override // thai5ichoM2a.niah0Shohtha
    /* renamed from: mi5Iecheimie, reason: merged with bridge method [inline-methods] */
    public kuedujio7Aev thooCoci9zae(boolean z) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.value(z);
        return this;
    }

    public kuedujio7Aev niah0Shohtha(Object obj, boolean z) {
        int i = 0;
        if (z && AeJiPo4of6Sh(obj)) {
            throw new thai5ichoM2a.keiL1EiShomu(String.format("%s cannot be encoded inline", obj == null ? null : obj.getClass()));
        }
        if (obj == null) {
            this.f2864keiL1EiShomu.nullValue();
            return this;
        }
        if (obj instanceof Number) {
            this.f2864keiL1EiShomu.value((Number) obj);
            return this;
        }
        if (!obj.getClass().isArray()) {
            if (obj instanceof Collection) {
                this.f2864keiL1EiShomu.beginArray();
                Iterator it = ((Collection) obj).iterator();
                while (it.hasNext()) {
                    niah0Shohtha(it.next(), false);
                }
                this.f2864keiL1EiShomu.endArray();
                return this;
            }
            if (obj instanceof Map) {
                this.f2864keiL1EiShomu.beginObject();
                for (Map.Entry entry : ((Map) obj).entrySet()) {
                    Object key = entry.getKey();
                    try {
                        ahthoK6usais((String) key, entry.getValue());
                    } catch (ClassCastException e) {
                        throw new thai5ichoM2a.keiL1EiShomu(String.format("Only String keys are currently supported in maps, got %s of type %s instead.", key, key.getClass()), e);
                    }
                }
                this.f2864keiL1EiShomu.endObject();
                return this;
            }
            thai5ichoM2a.kuedujio7Aev kuedujio7aev = (thai5ichoM2a.kuedujio7Aev) this.f2862ieheiQu9sho5.get(obj.getClass());
            if (kuedujio7aev != null) {
                return eetheKaevie8(kuedujio7aev, obj, z);
            }
            Jah0aiP1ki6y jah0aiP1ki6y = (Jah0aiP1ki6y) this.f2865kuedujio7Aev.get(obj.getClass());
            if (jah0aiP1ki6y != null) {
                jah0aiP1ki6y.ieseir3Choge(obj, this);
                return this;
            }
            if (!(obj instanceof Enum)) {
                return eetheKaevie8(this.f2860Aicohm8ieYoo, obj, z);
            }
            ieseir3Choge(((Enum) obj).name());
            return this;
        }
        if (obj instanceof byte[]) {
            return ruwiepo7ooVu((byte[]) obj);
        }
        this.f2864keiL1EiShomu.beginArray();
        if (obj instanceof int[]) {
            int length = ((int[]) obj).length;
            while (i < length) {
                this.f2864keiL1EiShomu.value(r7[i]);
                i++;
            }
        } else if (obj instanceof long[]) {
            long[] jArr = (long[]) obj;
            int length2 = jArr.length;
            while (i < length2) {
                Jah0aiP1ki6y(jArr[i]);
                i++;
            }
        } else if (obj instanceof double[]) {
            double[] dArr = (double[]) obj;
            int length3 = dArr.length;
            while (i < length3) {
                this.f2864keiL1EiShomu.value(dArr[i]);
                i++;
            }
        } else if (obj instanceof boolean[]) {
            boolean[] zArr = (boolean[]) obj;
            int length4 = zArr.length;
            while (i < length4) {
                this.f2864keiL1EiShomu.value(zArr[i]);
                i++;
            }
        } else if (obj instanceof Number[]) {
            for (Number number : (Number[]) obj) {
                niah0Shohtha(number, false);
            }
        } else {
            for (Object obj2 : (Object[]) obj) {
                niah0Shohtha(obj2, false);
            }
        }
        this.f2864keiL1EiShomu.endArray();
        return this;
    }

    public void oYe2ma2she1j() {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.flush();
    }

    @Override // thai5ichoM2a.niah0Shohtha
    /* renamed from: ohv5Shie7AeZ, reason: merged with bridge method [inline-methods] */
    public kuedujio7Aev ieseir3Choge(String str) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.value(str);
        return this;
    }

    public kuedujio7Aev ruNgecai1pae(String str, long j) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.name(str);
        return Jah0aiP1ki6y(j);
    }

    public kuedujio7Aev ruwiepo7ooVu(byte[] bArr) {
        laej2zeez5Ja();
        if (bArr == null) {
            this.f2864keiL1EiShomu.nullValue();
        } else {
            this.f2864keiL1EiShomu.value(Base64.encodeToString(bArr, 2));
        }
        return this;
    }

    public final kuedujio7Aev zoojiiKaht3i(String str, Object obj) {
        laej2zeez5Ja();
        this.f2864keiL1EiShomu.name(str);
        if (obj == null) {
            this.f2864keiL1EiShomu.nullValue();
            return this;
        }
        return niah0Shohtha(obj, false);
    }
}
