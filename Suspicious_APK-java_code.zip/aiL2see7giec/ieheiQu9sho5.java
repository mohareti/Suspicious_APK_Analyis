package aiL2see7giec;

import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import thai5ichoM2a.Aicohm8ieYoo;
import thai5ichoM2a.Jah0aiP1ki6y;
import thai5ichoM2a.niah0Shohtha;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieheiQu9sho5 implements aeTh5ATha5te.thooCoci9zae {

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final thai5ichoM2a.kuedujio7Aev f2852kuedujio7Aev = new thai5ichoM2a.kuedujio7Aev() { // from class: aiL2see7giec.ieseir3Choge
        @Override // thai5ichoM2a.thooCoci9zae
        public final void ieseir3Choge(Object obj, Object obj2) {
            ieheiQu9sho5.ahthoK6usais(obj, (Aicohm8ieYoo) obj2);
        }
    };

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static final Jah0aiP1ki6y f2850Aicohm8ieYoo = new Jah0aiP1ki6y() { // from class: aiL2see7giec.thooCoci9zae
        @Override // thai5ichoM2a.thooCoci9zae
        public final void ieseir3Choge(Object obj, Object obj2) {
            ((niah0Shohtha) obj2).ieseir3Choge((String) obj);
        }
    };

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final Jah0aiP1ki6y f2851Jah0aiP1ki6y = new Jah0aiP1ki6y() { // from class: aiL2see7giec.keiL1EiShomu
        @Override // thai5ichoM2a.thooCoci9zae
        public final void ieseir3Choge(Object obj, Object obj2) {
            ieheiQu9sho5.ruwiepo7ooVu((Boolean) obj, (niah0Shohtha) obj2);
        }
    };

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public static final thooCoci9zae f2853niah0Shohtha = new thooCoci9zae(null);

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Map f2855ieseir3Choge = new HashMap();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Map f2857thooCoci9zae = new HashMap();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public thai5ichoM2a.kuedujio7Aev f2856keiL1EiShomu = f2852kuedujio7Aev;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public boolean f2854ieheiQu9sho5 = false;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements thai5ichoM2a.ieseir3Choge {
        public ieseir3Choge() {
        }

        @Override // thai5ichoM2a.ieseir3Choge
        public void ieseir3Choge(Object obj, Writer writer) {
            kuedujio7Aev kuedujio7aev = new kuedujio7Aev(writer, ieheiQu9sho5.this.f2855ieseir3Choge, ieheiQu9sho5.this.f2857thooCoci9zae, ieheiQu9sho5.this.f2856keiL1EiShomu, ieheiQu9sho5.this.f2854ieheiQu9sho5);
            kuedujio7aev.niah0Shohtha(obj, false);
            kuedujio7aev.oYe2ma2she1j();
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae implements Jah0aiP1ki6y {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final DateFormat f2859ieseir3Choge;

        static {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            f2859ieseir3Choge = simpleDateFormat;
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        }

        public thooCoci9zae() {
        }

        @Override // thai5ichoM2a.thooCoci9zae
        /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
        public void ieseir3Choge(Date date, niah0Shohtha niah0shohtha) {
            niah0shohtha.ieseir3Choge(f2859ieseir3Choge.format(date));
        }

        public /* synthetic */ thooCoci9zae(ieseir3Choge ieseir3choge) {
            this();
        }
    }

    public ieheiQu9sho5() {
        oYe2ma2she1j(String.class, f2850Aicohm8ieYoo);
        oYe2ma2she1j(Boolean.class, f2851Jah0aiP1ki6y);
        oYe2ma2she1j(Date.class, f2853niah0Shohtha);
    }

    public static /* synthetic */ void ahthoK6usais(Object obj, Aicohm8ieYoo aicohm8ieYoo) {
        throw new thai5ichoM2a.keiL1EiShomu("Couldn't find encoder for type " + obj.getClass().getCanonicalName());
    }

    public static /* synthetic */ void ruwiepo7ooVu(Boolean bool, niah0Shohtha niah0shohtha) {
        niah0shohtha.thooCoci9zae(bool.booleanValue());
    }

    @Override // aeTh5ATha5te.thooCoci9zae
    /* renamed from: AeJiPo4of6Sh, reason: merged with bridge method [inline-methods] */
    public ieheiQu9sho5 ieseir3Choge(Class cls, thai5ichoM2a.kuedujio7Aev kuedujio7aev) {
        this.f2855ieseir3Choge.put(cls, kuedujio7aev);
        this.f2857thooCoci9zae.remove(cls);
        return this;
    }

    public ieheiQu9sho5 ko7aiFeiqu3s(aeTh5ATha5te.ieseir3Choge ieseir3choge) {
        ieseir3choge.ieseir3Choge(this);
        return this;
    }

    public ieheiQu9sho5 oYe2ma2she1j(Class cls, Jah0aiP1ki6y jah0aiP1ki6y) {
        this.f2857thooCoci9zae.put(cls, jah0aiP1ki6y);
        this.f2855ieseir3Choge.remove(cls);
        return this;
    }

    public thai5ichoM2a.ieseir3Choge ohv5Shie7AeZ() {
        return new ieseir3Choge();
    }

    public ieheiQu9sho5 ruNgecai1pae(boolean z) {
        this.f2854ieheiQu9sho5 = z;
        return this;
    }
}
