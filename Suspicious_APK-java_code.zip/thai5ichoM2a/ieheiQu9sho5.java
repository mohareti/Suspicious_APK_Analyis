package thai5ichoM2a;

import java.lang.annotation.Annotation;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ieheiQu9sho5 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f8042ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Map f8043thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f8044ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public Map f8045thooCoci9zae = null;

        public thooCoci9zae(String str) {
            this.f8044ieseir3Choge = str;
        }

        public ieheiQu9sho5 ieseir3Choge() {
            Map unmodifiableMap;
            String str = this.f8044ieseir3Choge;
            if (this.f8045thooCoci9zae == null) {
                unmodifiableMap = Collections.emptyMap();
            } else {
                unmodifiableMap = Collections.unmodifiableMap(new HashMap(this.f8045thooCoci9zae));
            }
            return new ieheiQu9sho5(str, unmodifiableMap);
        }

        public thooCoci9zae thooCoci9zae(Annotation annotation) {
            if (this.f8045thooCoci9zae == null) {
                this.f8045thooCoci9zae = new HashMap();
            }
            this.f8045thooCoci9zae.put(annotation.annotationType(), annotation);
            return this;
        }
    }

    public ieheiQu9sho5(String str, Map map) {
        this.f8042ieseir3Choge = str;
        this.f8043thooCoci9zae = map;
    }

    public static ieheiQu9sho5 ieheiQu9sho5(String str) {
        return new ieheiQu9sho5(str, Collections.emptyMap());
    }

    public static thooCoci9zae ieseir3Choge(String str) {
        return new thooCoci9zae(str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ieheiQu9sho5)) {
            return false;
        }
        ieheiQu9sho5 ieheiqu9sho5 = (ieheiQu9sho5) obj;
        if (this.f8042ieseir3Choge.equals(ieheiqu9sho5.f8042ieseir3Choge) && this.f8043thooCoci9zae.equals(ieheiqu9sho5.f8043thooCoci9zae)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return (this.f8042ieseir3Choge.hashCode() * 31) + this.f8043thooCoci9zae.hashCode();
    }

    public Annotation keiL1EiShomu(Class cls) {
        return (Annotation) this.f8043thooCoci9zae.get(cls);
    }

    public String thooCoci9zae() {
        return this.f8042ieseir3Choge;
    }

    public String toString() {
        return "FieldDescriptor{name=" + this.f8042ieseir3Choge + ", properties=" + this.f8043thooCoci9zae.values() + "}";
    }
}
