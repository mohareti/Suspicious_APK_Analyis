package XoN2Ii3eiqu0;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class quiBuGh8zigh {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final chuYaeghie9C f2572ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Map f2573thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f2574ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Map f2575keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final chuYaeghie9C f2576thooCoci9zae;

        public thooCoci9zae(chuYaeghie9C chuyaeghie9c) {
            this.f2575keiL1EiShomu = new HashMap();
            this.f2576thooCoci9zae = (chuYaeghie9C) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(chuyaeghie9c, "serviceDescriptor");
            this.f2574ieseir3Choge = chuyaeghie9c.thooCoci9zae();
        }

        public thooCoci9zae ieseir3Choge(GieBae8eiNge gieBae8eiNge, chie7aequa3C chie7aequa3c) {
            return thooCoci9zae(Wee2wi3pheim.ieseir3Choge((GieBae8eiNge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(gieBae8eiNge, "method must not be null"), (chie7aequa3C) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(chie7aequa3c, "handler must not be null")));
        }

        public quiBuGh8zigh keiL1EiShomu() {
            chuYaeghie9C chuyaeghie9c = this.f2576thooCoci9zae;
            if (chuyaeghie9c == null) {
                ArrayList arrayList = new ArrayList(this.f2575keiL1EiShomu.size());
                Iterator it = this.f2575keiL1EiShomu.values().iterator();
                while (it.hasNext()) {
                    arrayList.add(((Wee2wi3pheim) it.next()).thooCoci9zae());
                }
                chuyaeghie9c = new chuYaeghie9C(this.f2574ieseir3Choge, arrayList);
            }
            HashMap hashMap = new HashMap(this.f2575keiL1EiShomu);
            for (GieBae8eiNge gieBae8eiNge : chuyaeghie9c.ieseir3Choge()) {
                Wee2wi3pheim wee2wi3pheim = (Wee2wi3pheim) hashMap.remove(gieBae8eiNge.keiL1EiShomu());
                if (wee2wi3pheim != null) {
                    if (wee2wi3pheim.thooCoci9zae() != gieBae8eiNge) {
                        throw new IllegalStateException("Bound method for " + gieBae8eiNge.keiL1EiShomu() + " not same instance as method in service descriptor");
                    }
                } else {
                    throw new IllegalStateException("No method bound for descriptor entry " + gieBae8eiNge.keiL1EiShomu());
                }
            }
            if (hashMap.size() <= 0) {
                return new quiBuGh8zigh(chuyaeghie9c, this.f2575keiL1EiShomu);
            }
            throw new IllegalStateException("No entry in descriptor matching bound method " + ((Wee2wi3pheim) hashMap.values().iterator().next()).thooCoci9zae().keiL1EiShomu());
        }

        public thooCoci9zae thooCoci9zae(Wee2wi3pheim wee2wi3pheim) {
            GieBae8eiNge thooCoci9zae2 = wee2wi3pheim.thooCoci9zae();
            Vaig0nohza7i.ko7aiFeiqu3s.ruNgecai1pae(this.f2574ieseir3Choge.equals(thooCoci9zae2.ieheiQu9sho5()), "Method name should be prefixed with service name and separated with '/'. Expected service name: '%s'. Actual fully qualifed method name: '%s'.", this.f2574ieseir3Choge, thooCoci9zae2.keiL1EiShomu());
            String keiL1EiShomu2 = thooCoci9zae2.keiL1EiShomu();
            Vaig0nohza7i.ko7aiFeiqu3s.oph9lahCh6uo(!this.f2575keiL1EiShomu.containsKey(keiL1EiShomu2), "Method by same name already registered: %s", keiL1EiShomu2);
            this.f2575keiL1EiShomu.put(keiL1EiShomu2, wee2wi3pheim);
            return this;
        }
    }

    public quiBuGh8zigh(chuYaeghie9C chuyaeghie9c, Map map) {
        this.f2572ieseir3Choge = (chuYaeghie9C) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(chuyaeghie9c, "serviceDescriptor");
        this.f2573thooCoci9zae = Collections.unmodifiableMap(new HashMap(map));
    }

    public static thooCoci9zae ieseir3Choge(chuYaeghie9C chuyaeghie9c) {
        return new thooCoci9zae(chuyaeghie9c);
    }
}
