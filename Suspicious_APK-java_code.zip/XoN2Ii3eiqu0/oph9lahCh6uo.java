package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ahthoK6usais;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class oph9lahCh6uo {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Map f2540ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final byte[] f2541thooCoci9zae;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final Vaig0nohza7i.kuedujio7Aev f2539keiL1EiShomu = Vaig0nohza7i.kuedujio7Aev.kuedujio7Aev(',');

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final oph9lahCh6uo f2538ieheiQu9sho5 = ieseir3Choge().Aicohm8ieYoo(new ahthoK6usais.ieseir3Choge(), true).Aicohm8ieYoo(ahthoK6usais.thooCoci9zae.f2400ieseir3Choge, false);

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final esohshee3Pau f2542ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final boolean f2543thooCoci9zae;

        public ieseir3Choge(esohshee3Pau esohshee3pau, boolean z) {
            this.f2542ieseir3Choge = (esohshee3Pau) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(esohshee3pau, "decompressor");
            this.f2543thooCoci9zae = z;
        }
    }

    public oph9lahCh6uo() {
        this.f2540ieseir3Choge = new LinkedHashMap(0);
        this.f2541thooCoci9zae = new byte[0];
    }

    public static oph9lahCh6uo ieseir3Choge() {
        return new oph9lahCh6uo();
    }

    public static oph9lahCh6uo keiL1EiShomu() {
        return f2538ieheiQu9sho5;
    }

    public oph9lahCh6uo Aicohm8ieYoo(esohshee3Pau esohshee3pau, boolean z) {
        return new oph9lahCh6uo(esohshee3pau, z, this);
    }

    public byte[] ieheiQu9sho5() {
        return this.f2541thooCoci9zae;
    }

    public esohshee3Pau kuedujio7Aev(String str) {
        ieseir3Choge ieseir3choge = (ieseir3Choge) this.f2540ieseir3Choge.get(str);
        if (ieseir3choge != null) {
            return ieseir3choge.f2542ieseir3Choge;
        }
        return null;
    }

    public Set thooCoci9zae() {
        HashSet hashSet = new HashSet(this.f2540ieseir3Choge.size());
        for (Map.Entry entry : this.f2540ieseir3Choge.entrySet()) {
            if (((ieseir3Choge) entry.getValue()).f2543thooCoci9zae) {
                hashSet.add((String) entry.getKey());
            }
        }
        return Collections.unmodifiableSet(hashSet);
    }

    public oph9lahCh6uo(esohshee3Pau esohshee3pau, boolean z, oph9lahCh6uo oph9lahch6uo) {
        String ieseir3Choge2 = esohshee3pau.ieseir3Choge();
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!ieseir3Choge2.contains(","), "Comma is currently not allowed in message encoding");
        int size = oph9lahch6uo.f2540ieseir3Choge.size();
        LinkedHashMap linkedHashMap = new LinkedHashMap(oph9lahch6uo.f2540ieseir3Choge.containsKey(esohshee3pau.ieseir3Choge()) ? size : size + 1);
        for (ieseir3Choge ieseir3choge : oph9lahch6uo.f2540ieseir3Choge.values()) {
            String ieseir3Choge3 = ieseir3choge.f2542ieseir3Choge.ieseir3Choge();
            if (!ieseir3Choge3.equals(ieseir3Choge2)) {
                linkedHashMap.put(ieseir3Choge3, new ieseir3Choge(ieseir3choge.f2542ieseir3Choge, ieseir3choge.f2543thooCoci9zae));
            }
        }
        linkedHashMap.put(ieseir3Choge2, new ieseir3Choge(esohshee3pau, z));
        this.f2540ieseir3Choge = Collections.unmodifiableMap(linkedHashMap);
        this.f2541thooCoci9zae = f2539keiL1EiShomu.keiL1EiShomu(thooCoci9zae()).getBytes(Charset.forName("US-ASCII"));
    }
}
