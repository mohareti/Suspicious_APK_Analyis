package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class baexaike8KuV extends Jah0aiP1ki6y {
    public abstract Jah0aiP1ki6y Aicohm8ieYoo();

    @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
    public void keiL1EiShomu(int i) {
        Aicohm8ieYoo().keiL1EiShomu(i);
    }

    @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
    public void thooCoci9zae() {
        Aicohm8ieYoo().thooCoci9zae();
    }

    public String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("delegate", Aicohm8ieYoo()).toString();
    }
}
