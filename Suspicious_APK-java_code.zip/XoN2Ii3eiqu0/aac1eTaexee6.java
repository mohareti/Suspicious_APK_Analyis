package XoN2Ii3eiqu0;

import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class aac1eTaexee6 {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final int f2396ieseir3Choge = 0;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final Logger f2395thooCoci9zae = Logger.getLogger(aac1eTaexee6.class.getName());

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final aac1eTaexee6 f2394keiL1EiShomu = new aac1eTaexee6();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ieseir3Choge {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class keiL1EiShomu {
        public abstract aac1eTaexee6 ieseir3Choge();

        public abstract aac1eTaexee6 keiL1EiShomu(aac1eTaexee6 aac1etaexee6);

        public abstract void thooCoci9zae(aac1eTaexee6 aac1etaexee6, aac1eTaexee6 aac1etaexee62);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final keiL1EiShomu f2397ieseir3Choge;

        static {
            AtomicReference atomicReference = new AtomicReference();
            f2397ieseir3Choge = ieseir3Choge(atomicReference);
            Throwable th = (Throwable) atomicReference.get();
            if (th != null) {
                aac1eTaexee6.f2395thooCoci9zae.log(Level.FINE, "Storage override doesn't exist. Using default", th);
            }
        }

        public static keiL1EiShomu ieseir3Choge(AtomicReference atomicReference) {
            try {
                return (keiL1EiShomu) Class.forName("io.grpc.override.ContextStorageOverride").asSubclass(keiL1EiShomu.class).getConstructor(null).newInstance(null);
            } catch (ClassNotFoundException e) {
                atomicReference.set(e);
                return new mie4oahuCi2O();
            } catch (Exception e2) {
                throw new RuntimeException("Storage override failed to initialize", e2);
            }
        }
    }

    public aac1eTaexee6() {
        ruNgecai1pae(0);
    }

    public static Object ieheiQu9sho5(Object obj, Object obj2) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException(String.valueOf(obj2));
    }

    public static keiL1EiShomu ko7aiFeiqu3s() {
        return thooCoci9zae.f2397ieseir3Choge;
    }

    public static aac1eTaexee6 kuedujio7Aev() {
        aac1eTaexee6 ieseir3Choge2 = ko7aiFeiqu3s().ieseir3Choge();
        if (ieseir3Choge2 == null) {
            return f2394keiL1EiShomu;
        }
        return ieseir3Choge2;
    }

    public static void ruNgecai1pae(int i) {
        if (i == 1000) {
            f2395thooCoci9zae.log(Level.SEVERE, "Context ancestry chain length is abnormally long. This suggests an error in application code. Length exceeded: 1000", (Throwable) new Exception());
        }
    }

    public void Aicohm8ieYoo(aac1eTaexee6 aac1etaexee6) {
        ieheiQu9sho5(aac1etaexee6, "toAttach");
        ko7aiFeiqu3s().thooCoci9zae(this, aac1etaexee6);
    }

    public rojaiZ9aeRee Jah0aiP1ki6y() {
        return null;
    }

    public void ieseir3Choge(ieseir3Choge ieseir3choge, Executor executor) {
        ieheiQu9sho5(ieseir3choge, "cancellationListener");
        ieheiQu9sho5(executor, "executor");
    }

    public Throwable keiL1EiShomu() {
        return null;
    }

    public boolean niah0Shohtha() {
        return false;
    }

    public aac1eTaexee6 thooCoci9zae() {
        aac1eTaexee6 keiL1EiShomu2 = ko7aiFeiqu3s().keiL1EiShomu(this);
        if (keiL1EiShomu2 == null) {
            return f2394keiL1EiShomu;
        }
        return keiL1EiShomu2;
    }

    public void ohv5Shie7AeZ(ieseir3Choge ieseir3choge) {
    }
}
