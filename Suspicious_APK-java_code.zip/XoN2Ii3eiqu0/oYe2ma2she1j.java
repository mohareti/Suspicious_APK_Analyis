package XoN2Ii3eiqu0;

import java.util.Collections;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class oYe2ma2she1j {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static oYe2ma2she1j f2519ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public boolean f2520ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public List f2521keiL1EiShomu = Collections.emptyList();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public boolean f2522thooCoci9zae;

    public static synchronized oYe2ma2she1j thooCoci9zae() {
        oYe2ma2she1j oye2ma2she1j;
        synchronized (oYe2ma2she1j.class) {
            try {
                if (f2519ieheiQu9sho5 == null) {
                    f2519ieheiQu9sho5 = new oYe2ma2she1j();
                }
                oye2ma2she1j = f2519ieheiQu9sho5;
            } catch (Throwable th) {
                throw th;
            }
        }
        return oye2ma2she1j;
    }

    public synchronized List ieseir3Choge() {
        this.f2522thooCoci9zae = true;
        return this.f2521keiL1EiShomu;
    }

    public synchronized boolean keiL1EiShomu() {
        return this.f2520ieseir3Choge;
    }
}
