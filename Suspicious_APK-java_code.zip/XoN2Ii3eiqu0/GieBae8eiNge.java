package XoN2Ii3eiqu0;

import java.io.InputStream;
import java.util.concurrent.atomic.AtomicReferenceArray;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class GieBae8eiNge {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final Object f2261Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public final boolean f2262Jah0aiP1ki6y;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final keiL1EiShomu f2263ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ieheiQu9sho5 f2264ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f2265keiL1EiShomu;

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public final AtomicReferenceArray f2266ko7aiFeiqu3s;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final keiL1EiShomu f2267kuedujio7Aev;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final boolean f2268niah0Shohtha;

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public final boolean f2269ohv5Shie7AeZ;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f2270thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum ieheiQu9sho5 {
        UNARY,
        CLIENT_STREAMING,
        SERVER_STREAMING,
        BIDI_STREAMING,
        UNKNOWN;

        public final boolean ieseir3Choge() {
            if (this != UNARY && this != SERVER_STREAMING) {
                return false;
            }
            return true;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface keiL1EiShomu {
        Object ieseir3Choge(InputStream inputStream);

        InputStream thooCoci9zae(Object obj);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public boolean f2277Aicohm8ieYoo;

        /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
        public Object f2278Jah0aiP1ki6y;

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public String f2279ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public keiL1EiShomu f2280ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public ieheiQu9sho5 f2281keiL1EiShomu;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public boolean f2282kuedujio7Aev;

        /* renamed from: niah0Shohtha, reason: collision with root package name */
        public boolean f2283niah0Shohtha;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public keiL1EiShomu f2284thooCoci9zae;

        public thooCoci9zae() {
        }

        public thooCoci9zae Aicohm8ieYoo(ieheiQu9sho5 ieheiqu9sho5) {
            this.f2281keiL1EiShomu = ieheiqu9sho5;
            return this;
        }

        public thooCoci9zae ieheiQu9sho5(keiL1EiShomu keil1eishomu) {
            this.f2284thooCoci9zae = keil1eishomu;
            return this;
        }

        public GieBae8eiNge ieseir3Choge() {
            return new GieBae8eiNge(this.f2281keiL1EiShomu, this.f2279ieheiQu9sho5, this.f2280ieseir3Choge, this.f2284thooCoci9zae, this.f2278Jah0aiP1ki6y, this.f2282kuedujio7Aev, this.f2277Aicohm8ieYoo, this.f2283niah0Shohtha);
        }

        public thooCoci9zae keiL1EiShomu(keiL1EiShomu keil1eishomu) {
            this.f2280ieseir3Choge = keil1eishomu;
            return this;
        }

        public thooCoci9zae kuedujio7Aev(Object obj) {
            this.f2278Jah0aiP1ki6y = obj;
            return this;
        }

        public thooCoci9zae thooCoci9zae(String str) {
            this.f2279ieheiQu9sho5 = str;
            return this;
        }
    }

    public GieBae8eiNge(ieheiQu9sho5 ieheiqu9sho5, String str, keiL1EiShomu keil1eishomu, keiL1EiShomu keil1eishomu2, Object obj, boolean z, boolean z2, boolean z3) {
        this.f2266ko7aiFeiqu3s = new AtomicReferenceArray(2);
        this.f2264ieseir3Choge = (ieheiQu9sho5) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieheiqu9sho5, "type");
        this.f2270thooCoci9zae = (String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "fullMethodName");
        this.f2265keiL1EiShomu = ieseir3Choge(str);
        this.f2263ieheiQu9sho5 = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(keil1eishomu, "requestMarshaller");
        this.f2267kuedujio7Aev = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(keil1eishomu2, "responseMarshaller");
        this.f2261Aicohm8ieYoo = obj;
        this.f2262Jah0aiP1ki6y = z;
        this.f2268niah0Shohtha = z2;
        this.f2269ohv5Shie7AeZ = z3;
    }

    public static thooCoci9zae Jah0aiP1ki6y() {
        return niah0Shohtha(null, null);
    }

    public static String ieseir3Choge(String str) {
        int lastIndexOf = ((String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "fullMethodName")).lastIndexOf(47);
        if (lastIndexOf == -1) {
            return null;
        }
        return str.substring(0, lastIndexOf);
    }

    public static thooCoci9zae niah0Shohtha(keiL1EiShomu keil1eishomu, keiL1EiShomu keil1eishomu2) {
        return new thooCoci9zae().keiL1EiShomu(keil1eishomu).ieheiQu9sho5(keil1eishomu2);
    }

    public static String thooCoci9zae(String str, String str2) {
        return ((String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "fullServiceName")) + "/" + ((String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str2, "methodName"));
    }

    public boolean Aicohm8ieYoo() {
        return this.f2268niah0Shohtha;
    }

    public String ieheiQu9sho5() {
        return this.f2265keiL1EiShomu;
    }

    public String keiL1EiShomu() {
        return this.f2270thooCoci9zae;
    }

    public InputStream ko7aiFeiqu3s(Object obj) {
        return this.f2263ieheiQu9sho5.thooCoci9zae(obj);
    }

    public ieheiQu9sho5 kuedujio7Aev() {
        return this.f2264ieseir3Choge;
    }

    public Object ohv5Shie7AeZ(InputStream inputStream) {
        return this.f2267kuedujio7Aev.ieseir3Choge(inputStream);
    }

    public String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("fullMethodName", this.f2270thooCoci9zae).ieheiQu9sho5("type", this.f2264ieseir3Choge).kuedujio7Aev("idempotent", this.f2262Jah0aiP1ki6y).kuedujio7Aev("safe", this.f2268niah0Shohtha).kuedujio7Aev("sampledToLocalTracing", this.f2269ohv5Shie7AeZ).ieheiQu9sho5("requestMarshaller", this.f2263ieheiQu9sho5).ieheiQu9sho5("responseMarshaller", this.f2267kuedujio7Aev).ieheiQu9sho5("schemaDescriptor", this.f2261Aicohm8ieYoo).ruNgecai1pae().toString();
    }
}
