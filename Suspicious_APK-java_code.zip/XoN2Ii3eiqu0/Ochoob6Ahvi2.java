package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Ochoob6Ahvi2 extends baexaike8KuV {
    @Override // XoN2Ii3eiqu0.baexaike8KuV
    public abstract Jah0aiP1ki6y Aicohm8ieYoo();

    @Override // XoN2Ii3eiqu0.Jah0aiP1ki6y
    public void ieheiQu9sho5(Object obj) {
        Aicohm8ieYoo().ieheiQu9sho5(obj);
    }

    @Override // XoN2Ii3eiqu0.baexaike8KuV, XoN2Ii3eiqu0.Jah0aiP1ki6y
    public /* bridge */ /* synthetic */ void keiL1EiShomu(int i) {
        super.keiL1EiShomu(i);
    }

    @Override // XoN2Ii3eiqu0.baexaike8KuV, XoN2Ii3eiqu0.Jah0aiP1ki6y
    public /* bridge */ /* synthetic */ void thooCoci9zae() {
        super.thooCoci9zae();
    }

    @Override // XoN2Ii3eiqu0.baexaike8KuV
    public /* bridge */ /* synthetic */ String toString() {
        return super.toString();
    }
}
