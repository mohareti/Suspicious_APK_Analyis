package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ohx8eem3Ahph;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class HaeYeFaep1if {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ohx8eem3Ahph.Jah0aiP1ki6y f2285ieseir3Choge = Xe6mangaekai.f2363ohthie9thieG;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ohx8eem3Ahph.Jah0aiP1ki6y f2286thooCoci9zae = Xe6mangaekai.f2355esohshee3Pau;
}
