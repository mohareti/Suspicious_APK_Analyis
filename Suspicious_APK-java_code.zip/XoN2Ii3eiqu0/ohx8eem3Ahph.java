package XoN2Ii3eiqu0;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class ohx8eem3Ahph {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public Object[] f2527ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public int f2528thooCoci9zae;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final Logger f2525keiL1EiShomu = Logger.getLogger(ohx8eem3Ahph.class.getName());

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final kuedujio7Aev f2524ieheiQu9sho5 = new ieseir3Choge();

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final ieheiQu9sho5 f2526kuedujio7Aev = new thooCoci9zae();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static final ux6Aejaishae.ieseir3Choge f2523Aicohm8ieYoo = ux6Aejaishae.ieseir3Choge.ieseir3Choge().ruNgecai1pae();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface Aicohm8ieYoo {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class Jah0aiP1ki6y {

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public static final BitSet f2529kuedujio7Aev = thooCoci9zae();

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final Object f2530ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f2531ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final byte[] f2532keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final String f2533thooCoci9zae;

        public Jah0aiP1ki6y(String str, boolean z, Object obj) {
            String str2 = (String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "name");
            this.f2531ieseir3Choge = str2;
            String ruNgecai1pae2 = ruNgecai1pae(str2.toLowerCase(Locale.ROOT), z);
            this.f2533thooCoci9zae = ruNgecai1pae2;
            this.f2532keiL1EiShomu = ruNgecai1pae2.getBytes(StandardCharsets.US_ASCII);
            this.f2530ieheiQu9sho5 = obj;
        }

        public static Jah0aiP1ki6y Aicohm8ieYoo(String str, boolean z, ieheiQu9sho5 ieheiqu9sho5) {
            return new keiL1EiShomu(str, z, ieheiqu9sho5, null);
        }

        public static Jah0aiP1ki6y Jah0aiP1ki6y(String str, boolean z, ko7aiFeiqu3s ko7aifeiqu3s) {
            return new ohv5Shie7AeZ(str, z, ko7aifeiqu3s, null);
        }

        public static Jah0aiP1ki6y kuedujio7Aev(String str, ieheiQu9sho5 ieheiqu9sho5) {
            return Aicohm8ieYoo(str, false, ieheiqu9sho5);
        }

        public static String ruNgecai1pae(String str, boolean z) {
            Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(str, "name");
            Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!str.isEmpty(), "token must have at least 1 tchar");
            if (str.equals("connection")) {
                ohx8eem3Ahph.f2525keiL1EiShomu.log(Level.WARNING, "Metadata key is 'Connection', which should not be used. That is used by HTTP/1 for connection-specific headers which are not to be forwarded. There is probably an HTTP/1 conversion bug. Simply removing the Connection header is not enough; you should remove all headers it references as well. See RFC 7230 section 6.1", (Throwable) new RuntimeException("exception to show backtrace"));
            }
            for (int i = 0; i < str.length(); i++) {
                char charAt = str.charAt(i);
                if (!z || charAt != ':' || i != 0) {
                    Vaig0nohza7i.ko7aiFeiqu3s.Jah0aiP1ki6y(f2529kuedujio7Aev.get(charAt), "Invalid character '%s' in key name '%s'", charAt, str);
                }
            }
            return str;
        }

        public static BitSet thooCoci9zae() {
            BitSet bitSet = new BitSet(127);
            bitSet.set(45);
            bitSet.set(95);
            bitSet.set(46);
            for (char c = '0'; c <= '9'; c = (char) (c + 1)) {
                bitSet.set(c);
            }
            for (char c2 = 'a'; c2 <= 'z'; c2 = (char) (c2 + 1)) {
                bitSet.set(c2);
            }
            return bitSet;
        }

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj != null && getClass() == obj.getClass()) {
                return this.f2533thooCoci9zae.equals(((Jah0aiP1ki6y) obj).f2533thooCoci9zae);
            }
            return false;
        }

        public final int hashCode() {
            return this.f2533thooCoci9zae.hashCode();
        }

        public final String ieheiQu9sho5() {
            return this.f2533thooCoci9zae;
        }

        public byte[] ieseir3Choge() {
            return this.f2532keiL1EiShomu;
        }

        public final Object keiL1EiShomu(Class cls) {
            if (cls.isInstance(this.f2530ieheiQu9sho5)) {
                return cls.cast(this.f2530ieheiQu9sho5);
            }
            return null;
        }

        public abstract byte[] ko7aiFeiqu3s(Object obj);

        public abstract Object niah0Shohtha(byte[] bArr);

        public boolean ohv5Shie7AeZ() {
            return false;
        }

        public String toString() {
            return "Key{name='" + this.f2533thooCoci9zae + "'}";
        }

        public /* synthetic */ Jah0aiP1ki6y(String str, boolean z, Object obj, ieseir3Choge ieseir3choge) {
            this(str, z, obj);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ieheiQu9sho5 {
        String ieseir3Choge(Object obj);

        Object thooCoci9zae(String str);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements kuedujio7Aev {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class keiL1EiShomu extends Jah0aiP1ki6y {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public final ieheiQu9sho5 f2534Aicohm8ieYoo;

        public keiL1EiShomu(String str, boolean z, ieheiQu9sho5 ieheiqu9sho5) {
            super(str, z, ieheiqu9sho5, null);
            Vaig0nohza7i.ko7aiFeiqu3s.ruNgecai1pae(!str.endsWith("-bin"), "ASCII header is named %s.  Only binary headers may end with %s", str, "-bin");
            this.f2534Aicohm8ieYoo = (ieheiQu9sho5) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieheiqu9sho5, "marshaller");
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.Jah0aiP1ki6y
        public byte[] ko7aiFeiqu3s(Object obj) {
            return ((String) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(this.f2534Aicohm8ieYoo.ieseir3Choge(obj), "null marshaller.toAsciiString()")).getBytes(StandardCharsets.US_ASCII);
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.Jah0aiP1ki6y
        public Object niah0Shohtha(byte[] bArr) {
            return this.f2534Aicohm8ieYoo.thooCoci9zae(new String(bArr, StandardCharsets.US_ASCII));
        }

        public /* synthetic */ keiL1EiShomu(String str, boolean z, ieheiQu9sho5 ieheiqu9sho5, ieseir3Choge ieseir3choge) {
            this(str, z, ieheiqu9sho5);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ko7aiFeiqu3s {
        byte[] ieseir3Choge(Object obj);

        Object thooCoci9zae(byte[] bArr);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface kuedujio7Aev {
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class niah0Shohtha {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Object f2535ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public volatile byte[] f2536thooCoci9zae;

        public niah0Shohtha(Aicohm8ieYoo aicohm8ieYoo, Object obj) {
            this.f2535ieseir3Choge = obj;
        }

        public static niah0Shohtha ieseir3Choge(Jah0aiP1ki6y jah0aiP1ki6y, Object obj) {
            thooCoci9zae(jah0aiP1ki6y);
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(null));
            return new niah0Shohtha(null, obj);
        }

        public static Aicohm8ieYoo thooCoci9zae(Jah0aiP1ki6y jah0aiP1ki6y) {
            Aicohm8ieYoo.keiL1EiShomu.ieseir3Choge(jah0aiP1ki6y.keiL1EiShomu(Aicohm8ieYoo.class));
            return null;
        }

        public Object ieheiQu9sho5(Jah0aiP1ki6y jah0aiP1ki6y) {
            if (jah0aiP1ki6y.ohv5Shie7AeZ()) {
                thooCoci9zae(jah0aiP1ki6y);
            }
            return jah0aiP1ki6y.niah0Shohtha(keiL1EiShomu());
        }

        public byte[] keiL1EiShomu() {
            if (this.f2536thooCoci9zae == null) {
                synchronized (this) {
                    try {
                        if (this.f2536thooCoci9zae == null) {
                            this.f2536thooCoci9zae = ohx8eem3Ahph.eetheKaevie8(kuedujio7Aev());
                        }
                    } finally {
                    }
                }
            }
            return this.f2536thooCoci9zae;
        }

        public InputStream kuedujio7Aev() {
            throw null;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ohv5Shie7AeZ extends Jah0aiP1ki6y {

        /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
        public final ko7aiFeiqu3s f2537Aicohm8ieYoo;

        public ohv5Shie7AeZ(String str, boolean z, ko7aiFeiqu3s ko7aifeiqu3s) {
            super(str, z, ko7aifeiqu3s, null);
            Vaig0nohza7i.ko7aiFeiqu3s.ruNgecai1pae(!str.endsWith("-bin"), "ASCII header is named %s.  Only binary headers may end with %s", str, "-bin");
            this.f2537Aicohm8ieYoo = (ko7aiFeiqu3s) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ko7aifeiqu3s, "marshaller");
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.Jah0aiP1ki6y
        public byte[] ko7aiFeiqu3s(Object obj) {
            return (byte[]) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(this.f2537Aicohm8ieYoo.ieseir3Choge(obj), "null marshaller.toAsciiString()");
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.Jah0aiP1ki6y
        public Object niah0Shohtha(byte[] bArr) {
            return this.f2537Aicohm8ieYoo.thooCoci9zae(bArr);
        }

        public /* synthetic */ ohv5Shie7AeZ(String str, boolean z, ko7aiFeiqu3s ko7aifeiqu3s, ieseir3Choge ieseir3choge) {
            this(str, z, ko7aifeiqu3s);
        }
    }

    public ohx8eem3Ahph() {
    }

    public static byte[] eetheKaevie8(InputStream inputStream) {
        try {
            return ux6Aejaishae.thooCoci9zae.ieheiQu9sho5(inputStream);
        } catch (IOException e) {
            throw new RuntimeException("failure reading serialized stream", e);
        }
    }

    public void AeJiPo4of6Sh(Jah0aiP1ki6y jah0aiP1ki6y, Object obj) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(jah0aiP1ki6y, "key");
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "value");
        ruNgecai1pae();
        mi5Iecheimie(this.f2528thooCoci9zae, jah0aiP1ki6y.ieseir3Choge());
        if (jah0aiP1ki6y.ohv5Shie7AeZ()) {
            aac1eTaexee6(this.f2528thooCoci9zae, niah0Shohtha.ieseir3Choge(jah0aiP1ki6y, obj));
        } else {
            laej2zeez5Ja(this.f2528thooCoci9zae, jah0aiP1ki6y.ko7aiFeiqu3s(obj));
        }
        this.f2528thooCoci9zae++;
    }

    public final void Aicohm8ieYoo(int i) {
        Object[] objArr = new Object[i];
        if (!ohv5Shie7AeZ()) {
            System.arraycopy(this.f2527ieseir3Choge, 0, objArr, 0, ko7aiFeiqu3s());
        }
        this.f2527ieseir3Choge = objArr;
    }

    public Object Jah0aiP1ki6y(Jah0aiP1ki6y jah0aiP1ki6y) {
        for (int i = this.f2528thooCoci9zae - 1; i >= 0; i--) {
            if (keiL1EiShomu(jah0aiP1ki6y.ieseir3Choge(), ruwiepo7ooVu(i))) {
                return esohshee3Pau(i, jah0aiP1ki6y);
            }
        }
        return null;
    }

    public final void aac1eTaexee6(int i, Object obj) {
        if (this.f2527ieseir3Choge instanceof byte[][]) {
            Aicohm8ieYoo(ieheiQu9sho5());
        }
        this.f2527ieseir3Choge[(i * 2) + 1] = obj;
    }

    public void ahthoK6usais(ohx8eem3Ahph ohx8eem3ahph) {
        if (ohx8eem3ahph.ohv5Shie7AeZ()) {
            return;
        }
        int ieheiQu9sho52 = ieheiQu9sho5() - ko7aiFeiqu3s();
        if (ohv5Shie7AeZ() || ieheiQu9sho52 < ohx8eem3ahph.ko7aiFeiqu3s()) {
            Aicohm8ieYoo(ko7aiFeiqu3s() + ohx8eem3ahph.ko7aiFeiqu3s());
        }
        System.arraycopy(ohx8eem3ahph.f2527ieseir3Choge, 0, this.f2527ieseir3Choge, ko7aiFeiqu3s(), ohx8eem3ahph.ko7aiFeiqu3s());
        this.f2528thooCoci9zae += ohx8eem3ahph.f2528thooCoci9zae;
    }

    public final Object esohshee3Pau(int i, Jah0aiP1ki6y jah0aiP1ki6y) {
        Object zoojiiKaht3i2 = zoojiiKaht3i(i);
        if (zoojiiKaht3i2 instanceof byte[]) {
            return jah0aiP1ki6y.niah0Shohtha((byte[]) zoojiiKaht3i2);
        }
        return ((niah0Shohtha) zoojiiKaht3i2).ieheiQu9sho5(jah0aiP1ki6y);
    }

    public final int ieheiQu9sho5() {
        Object[] objArr = this.f2527ieseir3Choge;
        if (objArr != null) {
            return objArr.length;
        }
        return 0;
    }

    public final boolean keiL1EiShomu(byte[] bArr, byte[] bArr2) {
        return Arrays.equals(bArr, bArr2);
    }

    public final int ko7aiFeiqu3s() {
        return this.f2528thooCoci9zae * 2;
    }

    public void kuedujio7Aev(Jah0aiP1ki6y jah0aiP1ki6y) {
        if (ohv5Shie7AeZ()) {
            return;
        }
        int i = 0;
        for (int i2 = 0; i2 < this.f2528thooCoci9zae; i2++) {
            if (!keiL1EiShomu(jah0aiP1ki6y.ieseir3Choge(), ruwiepo7ooVu(i2))) {
                mi5Iecheimie(i, ruwiepo7ooVu(i2));
                aac1eTaexee6(i, zoojiiKaht3i(i2));
                i++;
            }
        }
        Arrays.fill(this.f2527ieseir3Choge, i * 2, ko7aiFeiqu3s(), (Object) null);
        this.f2528thooCoci9zae = i;
    }

    public final void laej2zeez5Ja(int i, byte[] bArr) {
        this.f2527ieseir3Choge[(i * 2) + 1] = bArr;
    }

    public final void mi5Iecheimie(int i, byte[] bArr) {
        this.f2527ieseir3Choge[i * 2] = bArr;
    }

    public int niah0Shohtha() {
        return this.f2528thooCoci9zae;
    }

    public byte[][] oYe2ma2she1j() {
        byte[][] bArr = new byte[ko7aiFeiqu3s()];
        Object[] objArr = this.f2527ieseir3Choge;
        if (objArr instanceof byte[][]) {
            System.arraycopy(objArr, 0, bArr, 0, ko7aiFeiqu3s());
        } else {
            for (int i = 0; i < this.f2528thooCoci9zae; i++) {
                int i2 = i * 2;
                bArr[i2] = ruwiepo7ooVu(i);
                bArr[i2 + 1] = rojaiZ9aeRee(i);
            }
        }
        return bArr;
    }

    public final boolean ohv5Shie7AeZ() {
        if (this.f2528thooCoci9zae == 0) {
            return true;
        }
        return false;
    }

    public final byte[] rojaiZ9aeRee(int i) {
        Object zoojiiKaht3i2 = zoojiiKaht3i(i);
        if (zoojiiKaht3i2 instanceof byte[]) {
            return (byte[]) zoojiiKaht3i2;
        }
        return ((niah0Shohtha) zoojiiKaht3i2).keiL1EiShomu();
    }

    public final void ruNgecai1pae() {
        if (ko7aiFeiqu3s() == 0 || ko7aiFeiqu3s() == ieheiQu9sho5()) {
            Aicohm8ieYoo(Math.max(ko7aiFeiqu3s() * 2, 8));
        }
    }

    public final byte[] ruwiepo7ooVu(int i) {
        return (byte[]) this.f2527ieseir3Choge[i * 2];
    }

    public String toString() {
        String str;
        StringBuilder sb = new StringBuilder("Metadata(");
        for (int i = 0; i < this.f2528thooCoci9zae; i++) {
            if (i != 0) {
                sb.append(',');
            }
            byte[] ruwiepo7ooVu2 = ruwiepo7ooVu(i);
            Charset charset = StandardCharsets.US_ASCII;
            String str2 = new String(ruwiepo7ooVu2, charset);
            sb.append(str2);
            sb.append('=');
            if (str2.endsWith("-bin")) {
                str = f2523Aicohm8ieYoo.kuedujio7Aev(rojaiZ9aeRee(i));
            } else {
                str = new String(rojaiZ9aeRee(i), charset);
            }
            sb.append(str);
        }
        sb.append(')');
        return sb.toString();
    }

    public final Object zoojiiKaht3i(int i) {
        return this.f2527ieseir3Choge[(i * 2) + 1];
    }

    public ohx8eem3Ahph(int i, Object[] objArr) {
        this.f2528thooCoci9zae = i;
        this.f2527ieseir3Choge = objArr;
    }

    public ohx8eem3Ahph(int i, byte[]... bArr) {
        this(i, (Object[]) bArr);
    }

    public ohx8eem3Ahph(byte[]... bArr) {
        this(bArr.length / 2, bArr);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class thooCoci9zae implements ieheiQu9sho5 {
        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ieheiQu9sho5
        /* renamed from: ieheiQu9sho5, reason: merged with bridge method [inline-methods] */
        public String ieseir3Choge(String str) {
            return str;
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ieheiQu9sho5
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public String thooCoci9zae(String str) {
            return str;
        }
    }
}
