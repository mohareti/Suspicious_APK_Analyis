package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class zoojiiKaht3i {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final eetheKaevie8 f2591ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Xe6mangaekai f2592thooCoci9zae;

    public zoojiiKaht3i(eetheKaevie8 eethekaevie8, Xe6mangaekai xe6mangaekai) {
        this.f2591ieseir3Choge = (eetheKaevie8) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(eethekaevie8, "state is null");
        this.f2592thooCoci9zae = (Xe6mangaekai) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(xe6mangaekai, "status is null");
    }

    public static zoojiiKaht3i ieseir3Choge(eetheKaevie8 eethekaevie8) {
        boolean z;
        if (eethekaevie8 != eetheKaevie8.TRANSIENT_FAILURE) {
            z = true;
        } else {
            z = false;
        }
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(z, "state is TRANSIENT_ERROR. Use forError() instead");
        return new zoojiiKaht3i(eethekaevie8, Xe6mangaekai.f2358kuedujio7Aev);
    }

    public static zoojiiKaht3i thooCoci9zae(Xe6mangaekai xe6mangaekai) {
        Vaig0nohza7i.ko7aiFeiqu3s.kuedujio7Aev(!xe6mangaekai.oYe2ma2she1j(), "The error status must not be OK");
        return new zoojiiKaht3i(eetheKaevie8.TRANSIENT_FAILURE, xe6mangaekai);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof zoojiiKaht3i)) {
            return false;
        }
        zoojiiKaht3i zoojiikaht3i = (zoojiiKaht3i) obj;
        if (!this.f2591ieseir3Choge.equals(zoojiikaht3i.f2591ieseir3Choge) || !this.f2592thooCoci9zae.equals(zoojiikaht3i.f2592thooCoci9zae)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.f2591ieseir3Choge.hashCode() ^ this.f2592thooCoci9zae.hashCode();
    }

    public Xe6mangaekai ieheiQu9sho5() {
        return this.f2592thooCoci9zae;
    }

    public eetheKaevie8 keiL1EiShomu() {
        return this.f2591ieseir3Choge;
    }

    public String toString() {
        if (this.f2592thooCoci9zae.oYe2ma2she1j()) {
            return this.f2591ieseir3Choge.toString();
        }
        return this.f2591ieseir3Choge + "(" + this.f2592thooCoci9zae + ")";
    }
}
