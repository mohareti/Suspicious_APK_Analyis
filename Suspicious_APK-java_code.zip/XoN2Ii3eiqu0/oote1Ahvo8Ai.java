package XoN2Ii3eiqu0;

import java.time.Duration;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class oote1Ahvo8Ai {
    public static long ieseir3Choge(Duration duration) {
        return Ahv6nai5fo5z.ieseir3Choge(duration);
    }
}
