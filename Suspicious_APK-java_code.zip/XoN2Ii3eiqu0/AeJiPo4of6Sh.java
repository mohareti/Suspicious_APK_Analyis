package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ahthoK6usais;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class AeJiPo4of6Sh {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final AeJiPo4of6Sh f2254thooCoci9zae = new AeJiPo4of6Sh(new ahthoK6usais.ieseir3Choge(), ahthoK6usais.thooCoci9zae.f2400ieseir3Choge);

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ConcurrentMap f2255ieseir3Choge = new ConcurrentHashMap();

    public AeJiPo4of6Sh(ruwiepo7ooVu... ruwiepo7oovuArr) {
        for (ruwiepo7ooVu ruwiepo7oovu : ruwiepo7oovuArr) {
            this.f2255ieseir3Choge.put(ruwiepo7oovu.ieseir3Choge(), ruwiepo7oovu);
        }
    }

    public static AeJiPo4of6Sh ieseir3Choge() {
        return f2254thooCoci9zae;
    }

    public ruwiepo7ooVu thooCoci9zae(String str) {
        return (ruwiepo7ooVu) this.f2255ieseir3Choge.get(str);
    }
}
