package XoN2Ii3eiqu0;

import java.security.cert.Certificate;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class kah6Uo2ooji4 {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static final Logger f2464Aicohm8ieYoo = Logger.getLogger(kah6Uo2ooji4.class.getName());

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final kah6Uo2ooji4 f2465Jah0aiP1ki6y = new kah6Uo2ooji4();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ConcurrentNavigableMap f2467ieseir3Choge = new ConcurrentSkipListMap();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final ConcurrentNavigableMap f2470thooCoci9zae = new ConcurrentSkipListMap();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final ConcurrentMap f2468keiL1EiShomu = new ConcurrentHashMap();

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final ConcurrentMap f2466ieheiQu9sho5 = new ConcurrentHashMap();

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final ConcurrentMap f2469kuedujio7Aev = new ConcurrentHashMap();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final String f2471ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final Certificate f2472keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Certificate f2473thooCoci9zae;

        public keiL1EiShomu(SSLSession sSLSession) {
            Certificate certificate;
            String cipherSuite = sSLSession.getCipherSuite();
            Certificate[] localCertificates = sSLSession.getLocalCertificates();
            Certificate certificate2 = null;
            if (localCertificates != null) {
                certificate = localCertificates[0];
            } else {
                certificate = null;
            }
            try {
                Certificate[] peerCertificates = sSLSession.getPeerCertificates();
                if (peerCertificates != null) {
                    certificate2 = peerCertificates[0];
                }
            } catch (SSLPeerUnverifiedException e) {
                kah6Uo2ooji4.f2464Aicohm8ieYoo.log(Level.FINE, String.format("Peer cert not available for peerHost=%s", sSLSession.getPeerHost()), (Throwable) e);
            }
            this.f2471ieseir3Choge = cipherSuite;
            this.f2473thooCoci9zae = certificate;
            this.f2472keiL1EiShomu = certificate2;
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final keiL1EiShomu f2474ieseir3Choge;

        public thooCoci9zae(keiL1EiShomu keil1eishomu) {
            this.f2474ieseir3Choge = (keiL1EiShomu) Vaig0nohza7i.ko7aiFeiqu3s.ruwiepo7ooVu(keil1eishomu);
        }
    }

    public static long Aicohm8ieYoo(lo8zieZoeseb lo8ziezoeseb) {
        return lo8ziezoeseb.ieheiQu9sho5().ieheiQu9sho5();
    }

    public static kah6Uo2ooji4 Jah0aiP1ki6y() {
        return f2465Jah0aiP1ki6y;
    }

    public static void niah0Shohtha(Map map, ahk3OhSh9Ree ahk3ohsh9ree) {
    }

    public static void thooCoci9zae(Map map, ahk3OhSh9Ree ahk3ohsh9ree) {
    }

    public void ieheiQu9sho5(ahk3OhSh9Ree ahk3ohsh9ree) {
        thooCoci9zae(this.f2470thooCoci9zae, ahk3ohsh9ree);
    }

    public void keiL1EiShomu(ahk3OhSh9Ree ahk3ohsh9ree) {
        thooCoci9zae(this.f2466ieheiQu9sho5, ahk3ohsh9ree);
    }

    public void ko7aiFeiqu3s(ahk3OhSh9Ree ahk3ohsh9ree) {
        niah0Shohtha(this.f2470thooCoci9zae, ahk3ohsh9ree);
    }

    public void kuedujio7Aev(ahk3OhSh9Ree ahk3ohsh9ree) {
        thooCoci9zae(this.f2468keiL1EiShomu, ahk3ohsh9ree);
    }

    public void ohv5Shie7AeZ(ahk3OhSh9Ree ahk3ohsh9ree) {
        niah0Shohtha(this.f2466ieheiQu9sho5, ahk3ohsh9ree);
    }

    public void ruNgecai1pae(ahk3OhSh9Ree ahk3ohsh9ree) {
        niah0Shohtha(this.f2468keiL1EiShomu, ahk3ohsh9ree);
    }
}
