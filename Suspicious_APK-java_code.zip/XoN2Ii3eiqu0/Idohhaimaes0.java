package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Idohhaimaes0 extends Xix0Vei5vo3j {
    @Override // XoN2Ii3eiqu0.Xix0Vei5vo3j
    public zoo3eifoe3Ae ieseir3Choge() {
        return thooCoci9zae().ieseir3Choge();
    }

    public abstract Xix0Vei5vo3j thooCoci9zae();

    public String toString() {
        return Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("delegate", thooCoci9zae()).toString();
    }
}
