package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ieph3Uteimah;
import XoN2Ii3eiqu0.ieseir3Choge;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Nieyie8tecah {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2323ieseir3Choge = ieseir3Choge.keiL1EiShomu.ieseir3Choge("internal:io.grpc.config-selector");

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class thooCoci9zae {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Xe6mangaekai f2324ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Object f2325thooCoci9zae;

        /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
        public static final class ieseir3Choge {

            /* renamed from: ieseir3Choge, reason: collision with root package name */
            public Object f2326ieseir3Choge;

            public ieseir3Choge() {
            }

            /* JADX WARN: Multi-variable type inference failed */
            public thooCoci9zae ieseir3Choge() {
                boolean z;
                if (this.f2326ieseir3Choge != null) {
                    z = true;
                } else {
                    z = false;
                }
                Vaig0nohza7i.ko7aiFeiqu3s.rojaiZ9aeRee(z, "config is not set");
                return new thooCoci9zae(Xe6mangaekai.f2358kuedujio7Aev, this.f2326ieseir3Choge, null);
            }

            public ieseir3Choge thooCoci9zae(Object obj) {
                this.f2326ieseir3Choge = Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(obj, "config");
                return this;
            }
        }

        public thooCoci9zae(Xe6mangaekai xe6mangaekai, Object obj, niah0Shohtha niah0shohtha) {
            this.f2324ieseir3Choge = (Xe6mangaekai) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(xe6mangaekai, "status");
            this.f2325thooCoci9zae = obj;
        }

        public static ieseir3Choge ieheiQu9sho5() {
            return new ieseir3Choge();
        }

        public Object ieseir3Choge() {
            return this.f2325thooCoci9zae;
        }

        public Xe6mangaekai keiL1EiShomu() {
            return this.f2324ieseir3Choge;
        }

        public niah0Shohtha thooCoci9zae() {
            return null;
        }
    }

    public abstract thooCoci9zae ieseir3Choge(ieph3Uteimah.niah0Shohtha niah0shohtha);
}
