package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ohx8eem3Ahph;
import java.nio.charset.Charset;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class io4laQuei7sa {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final Charset f2462ieseir3Choge = Charset.forName("US-ASCII");

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ux6Aejaishae.ieseir3Choge f2463thooCoci9zae = ohx8eem3Ahph.f2523Aicohm8ieYoo;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ieseir3Choge extends ohx8eem3Ahph.ko7aiFeiqu3s {
    }

    public static byte[][] ieheiQu9sho5(ohx8eem3Ahph ohx8eem3ahph) {
        return ohx8eem3ahph.oYe2ma2she1j();
    }

    public static int ieseir3Choge(ohx8eem3Ahph ohx8eem3ahph) {
        return ohx8eem3ahph.niah0Shohtha();
    }

    public static ohx8eem3Ahph keiL1EiShomu(byte[]... bArr) {
        return new ohx8eem3Ahph(bArr);
    }

    public static ohx8eem3Ahph.Jah0aiP1ki6y thooCoci9zae(String str, ieseir3Choge ieseir3choge) {
        boolean z = false;
        if (str != null && !str.isEmpty() && str.charAt(0) == ':') {
            z = true;
        }
        return ohx8eem3Ahph.Jah0aiP1ki6y.Jah0aiP1ki6y(str, z, ieseir3choge);
    }
}
