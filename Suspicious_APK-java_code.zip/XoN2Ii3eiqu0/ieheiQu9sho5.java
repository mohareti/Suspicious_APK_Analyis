package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {
    public abstract String ieseir3Choge();

    public abstract Jah0aiP1ki6y thooCoci9zae(GieBae8eiNge gieBae8eiNge, keiL1EiShomu keil1eishomu);
}
