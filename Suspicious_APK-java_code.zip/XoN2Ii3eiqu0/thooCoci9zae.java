package XoN2Ii3eiqu0;

import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class thooCoci9zae {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
    }

    /* renamed from: XoN2Ii3eiqu0.thooCoci9zae$thooCoci9zae, reason: collision with other inner class name */
    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class AbstractC0033thooCoci9zae {
    }

    public abstract void ieseir3Choge(AbstractC0033thooCoci9zae abstractC0033thooCoci9zae, Executor executor, ieseir3Choge ieseir3choge);
}
