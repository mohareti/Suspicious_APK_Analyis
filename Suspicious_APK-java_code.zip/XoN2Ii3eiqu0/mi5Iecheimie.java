package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.thooCoci9zae;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class mi5Iecheimie extends thooCoci9zae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final thooCoci9zae f2510ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final thooCoci9zae f2511thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public final class ieseir3Choge extends thooCoci9zae.ieseir3Choge {

        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final aac1eTaexee6 f2512ieheiQu9sho5;

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final thooCoci9zae.AbstractC0033thooCoci9zae f2513ieseir3Choge;

        /* renamed from: keiL1EiShomu, reason: collision with root package name */
        public final thooCoci9zae.ieseir3Choge f2514keiL1EiShomu;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final Executor f2516thooCoci9zae;

        public ieseir3Choge(thooCoci9zae.AbstractC0033thooCoci9zae abstractC0033thooCoci9zae, Executor executor, thooCoci9zae.ieseir3Choge ieseir3choge, aac1eTaexee6 aac1etaexee6) {
            this.f2513ieseir3Choge = abstractC0033thooCoci9zae;
            this.f2516thooCoci9zae = executor;
            this.f2514keiL1EiShomu = (thooCoci9zae.ieseir3Choge) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(ieseir3choge, "delegate");
            this.f2512ieheiQu9sho5 = (aac1eTaexee6) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(aac1etaexee6, "context");
        }
    }

    public mi5Iecheimie(thooCoci9zae thoococi9zae, thooCoci9zae thoococi9zae2) {
        this.f2510ieseir3Choge = (thooCoci9zae) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(thoococi9zae, "creds1");
        this.f2511thooCoci9zae = (thooCoci9zae) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(thoococi9zae2, "creds2");
    }

    @Override // XoN2Ii3eiqu0.thooCoci9zae
    public void ieseir3Choge(thooCoci9zae.AbstractC0033thooCoci9zae abstractC0033thooCoci9zae, Executor executor, thooCoci9zae.ieseir3Choge ieseir3choge) {
        this.f2510ieseir3Choge.ieseir3Choge(abstractC0033thooCoci9zae, executor, new ieseir3Choge(abstractC0033thooCoci9zae, executor, ieseir3choge, aac1eTaexee6.kuedujio7Aev()));
    }
}
