package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.ieseir3Choge;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ahz5eechei8U {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2401ieseir3Choge = ieseir3Choge.keiL1EiShomu.ieseir3Choge("io.grpc.Grpc.TRANSPORT_ATTR_REMOTE_ADDR");

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2403thooCoci9zae = ieseir3Choge.keiL1EiShomu.ieseir3Choge("io.grpc.Grpc.TRANSPORT_ATTR_LOCAL_ADDR");

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final ieseir3Choge.keiL1EiShomu f2402keiL1EiShomu = ieseir3Choge.keiL1EiShomu.ieseir3Choge("io.grpc.Grpc.TRANSPORT_ATTR_SSL_SESSION");
}
