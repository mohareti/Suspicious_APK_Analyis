package XoN2Ii3eiqu0;

import Vaig0nohza7i.Aicohm8ieYoo;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Laez5aeCooSh {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Xe6mangaekai f2302ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Object f2303thooCoci9zae;

    public Laez5aeCooSh(Xe6mangaekai xe6mangaekai, Object obj) {
        this.f2302ieseir3Choge = xe6mangaekai;
        this.f2303thooCoci9zae = obj;
    }

    public static Laez5aeCooSh ieseir3Choge(Xe6mangaekai xe6mangaekai) {
        Laez5aeCooSh laez5aeCooSh = new Laez5aeCooSh((Xe6mangaekai) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(xe6mangaekai, "status"), null);
        Vaig0nohza7i.ko7aiFeiqu3s.ko7aiFeiqu3s(!xe6mangaekai.oYe2ma2she1j(), "cannot use OK status: %s", xe6mangaekai);
        return laez5aeCooSh;
    }

    public static Laez5aeCooSh thooCoci9zae(Object obj) {
        return new Laez5aeCooSh(null, obj);
    }

    public boolean equals(Object obj) {
        Object obj2;
        Object obj3;
        if (!(obj instanceof Laez5aeCooSh)) {
            return false;
        }
        Laez5aeCooSh laez5aeCooSh = (Laez5aeCooSh) obj;
        if (kuedujio7Aev() != laez5aeCooSh.kuedujio7Aev()) {
            return false;
        }
        if (kuedujio7Aev()) {
            obj2 = this.f2303thooCoci9zae;
            obj3 = laez5aeCooSh.f2303thooCoci9zae;
        } else {
            obj2 = this.f2302ieseir3Choge;
            obj3 = laez5aeCooSh.f2302ieseir3Choge;
        }
        return Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(obj2, obj3);
    }

    public int hashCode() {
        return Vaig0nohza7i.Jah0aiP1ki6y.thooCoci9zae(this.f2302ieseir3Choge, this.f2303thooCoci9zae);
    }

    public Object ieheiQu9sho5() {
        if (this.f2302ieseir3Choge == null) {
            return this.f2303thooCoci9zae;
        }
        throw new IllegalStateException("No value present.");
    }

    public Xe6mangaekai keiL1EiShomu() {
        Xe6mangaekai xe6mangaekai = this.f2302ieseir3Choge;
        if (xe6mangaekai == null) {
            return Xe6mangaekai.f2358kuedujio7Aev;
        }
        return xe6mangaekai;
    }

    public boolean kuedujio7Aev() {
        if (this.f2302ieseir3Choge == null) {
            return true;
        }
        return false;
    }

    public String toString() {
        Aicohm8ieYoo.thooCoci9zae thooCoci9zae2 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this);
        Xe6mangaekai xe6mangaekai = this.f2302ieseir3Choge;
        if (xe6mangaekai == null) {
            thooCoci9zae2.ieheiQu9sho5("value", this.f2303thooCoci9zae);
        } else {
            thooCoci9zae2.ieheiQu9sho5("error", xe6mangaekai);
        }
        return thooCoci9zae2.toString();
    }
}
