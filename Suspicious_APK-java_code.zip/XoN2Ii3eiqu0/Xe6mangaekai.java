package XoN2Ii3eiqu0;

import Vaig0nohza7i.Aicohm8ieYoo;
import XoN2Ii3eiqu0.ohx8eem3Ahph;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class Xe6mangaekai {

    /* renamed from: esohshee3Pau, reason: collision with root package name */
    public static final ohx8eem3Ahph.Jah0aiP1ki6y f2355esohshee3Pau;

    /* renamed from: ohthie9thieG, reason: collision with root package name */
    public static final ohx8eem3Ahph.Jah0aiP1ki6y f2363ohthie9thieG;

    /* renamed from: oph9lahCh6uo, reason: collision with root package name */
    public static final ohx8eem3Ahph.ko7aiFeiqu3s f2365oph9lahCh6uo;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final thooCoci9zae f2370ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Throwable f2371keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f2372thooCoci9zae;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final List f2356ieheiQu9sho5 = Jah0aiP1ki6y();

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final Xe6mangaekai f2358kuedujio7Aev = thooCoci9zae.OK.Jah0aiP1ki6y();

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public static final Xe6mangaekai f2350Aicohm8ieYoo = thooCoci9zae.CANCELLED.Jah0aiP1ki6y();

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public static final Xe6mangaekai f2351Jah0aiP1ki6y = thooCoci9zae.UNKNOWN.Jah0aiP1ki6y();

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public static final Xe6mangaekai f2361niah0Shohtha = thooCoci9zae.INVALID_ARGUMENT.Jah0aiP1ki6y();

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final Xe6mangaekai f2364ohv5Shie7AeZ = thooCoci9zae.DEADLINE_EXCEEDED.Jah0aiP1ki6y();

    /* renamed from: ko7aiFeiqu3s, reason: collision with root package name */
    public static final Xe6mangaekai f2357ko7aiFeiqu3s = thooCoci9zae.NOT_FOUND.Jah0aiP1ki6y();

    /* renamed from: ruNgecai1pae, reason: collision with root package name */
    public static final Xe6mangaekai f2367ruNgecai1pae = thooCoci9zae.ALREADY_EXISTS.Jah0aiP1ki6y();

    /* renamed from: ahthoK6usais, reason: collision with root package name */
    public static final Xe6mangaekai f2353ahthoK6usais = thooCoci9zae.PERMISSION_DENIED.Jah0aiP1ki6y();

    /* renamed from: mi5Iecheimie, reason: collision with root package name */
    public static final Xe6mangaekai f2360mi5Iecheimie = thooCoci9zae.UNAUTHENTICATED.Jah0aiP1ki6y();

    /* renamed from: ruwiepo7ooVu, reason: collision with root package name */
    public static final Xe6mangaekai f2368ruwiepo7ooVu = thooCoci9zae.RESOURCE_EXHAUSTED.Jah0aiP1ki6y();

    /* renamed from: AeJiPo4of6Sh, reason: collision with root package name */
    public static final Xe6mangaekai f2349AeJiPo4of6Sh = thooCoci9zae.FAILED_PRECONDITION.Jah0aiP1ki6y();

    /* renamed from: oYe2ma2she1j, reason: collision with root package name */
    public static final Xe6mangaekai f2362oYe2ma2she1j = thooCoci9zae.ABORTED.Jah0aiP1ki6y();

    /* renamed from: eetheKaevie8, reason: collision with root package name */
    public static final Xe6mangaekai f2354eetheKaevie8 = thooCoci9zae.OUT_OF_RANGE.Jah0aiP1ki6y();

    /* renamed from: zoojiiKaht3i, reason: collision with root package name */
    public static final Xe6mangaekai f2369zoojiiKaht3i = thooCoci9zae.UNIMPLEMENTED.Jah0aiP1ki6y();

    /* renamed from: aac1eTaexee6, reason: collision with root package name */
    public static final Xe6mangaekai f2352aac1eTaexee6 = thooCoci9zae.INTERNAL.Jah0aiP1ki6y();

    /* renamed from: laej2zeez5Ja, reason: collision with root package name */
    public static final Xe6mangaekai f2359laej2zeez5Ja = thooCoci9zae.UNAVAILABLE.Jah0aiP1ki6y();

    /* renamed from: rojaiZ9aeRee, reason: collision with root package name */
    public static final Xe6mangaekai f2366rojaiZ9aeRee = thooCoci9zae.DATA_LOSS.Jah0aiP1ki6y();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class ieheiQu9sho5 implements ohx8eem3Ahph.ko7aiFeiqu3s {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public static final byte[] f2373ieseir3Choge = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70};

        public ieheiQu9sho5() {
        }

        public static byte[] Jah0aiP1ki6y(byte[] bArr, int i) {
            byte[] bArr2 = new byte[((bArr.length - i) * 3) + i];
            if (i != 0) {
                System.arraycopy(bArr, 0, bArr2, 0, i);
            }
            int i2 = i;
            while (i < bArr.length) {
                byte b = bArr[i];
                if (keiL1EiShomu(b)) {
                    bArr2[i2] = 37;
                    byte[] bArr3 = f2373ieseir3Choge;
                    bArr2[i2 + 1] = bArr3[(b >> 4) & 15];
                    bArr2[i2 + 2] = bArr3[b & 15];
                    i2 += 3;
                } else {
                    bArr2[i2] = b;
                    i2++;
                }
                i++;
            }
            return Arrays.copyOf(bArr2, i2);
        }

        public static boolean keiL1EiShomu(byte b) {
            if (b >= 32 && b < 126 && b != 37) {
                return false;
            }
            return true;
        }

        public static String kuedujio7Aev(byte[] bArr) {
            ByteBuffer allocate = ByteBuffer.allocate(bArr.length);
            int i = 0;
            while (i < bArr.length) {
                if (bArr[i] == 37 && i + 2 < bArr.length) {
                    try {
                        allocate.put((byte) Integer.parseInt(new String(bArr, i + 1, 2, StandardCharsets.US_ASCII), 16));
                        i += 3;
                    } catch (NumberFormatException unused) {
                    }
                }
                allocate.put(bArr[i]);
                i++;
            }
            return new String(allocate.array(), 0, allocate.position(), StandardCharsets.UTF_8);
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ko7aiFeiqu3s
        /* renamed from: Aicohm8ieYoo, reason: merged with bridge method [inline-methods] */
        public byte[] ieseir3Choge(String str) {
            byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
            for (int i = 0; i < bytes.length; i++) {
                if (keiL1EiShomu(bytes[i])) {
                    return Jah0aiP1ki6y(bytes, i);
                }
            }
            return bytes;
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ko7aiFeiqu3s
        /* renamed from: ieheiQu9sho5, reason: merged with bridge method [inline-methods] */
        public String thooCoci9zae(byte[] bArr) {
            for (int i = 0; i < bArr.length; i++) {
                byte b = bArr[i];
                if (b < 32 || b >= 126 || (b == 37 && i + 2 < bArr.length)) {
                    return kuedujio7Aev(bArr);
                }
            }
            return new String(bArr, 0);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static final class keiL1EiShomu implements ohx8eem3Ahph.ko7aiFeiqu3s {
        public keiL1EiShomu() {
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ko7aiFeiqu3s
        /* renamed from: ieheiQu9sho5, reason: merged with bridge method [inline-methods] */
        public byte[] ieseir3Choge(Xe6mangaekai xe6mangaekai) {
            return xe6mangaekai.ruwiepo7ooVu().ohv5Shie7AeZ();
        }

        @Override // XoN2Ii3eiqu0.ohx8eem3Ahph.ko7aiFeiqu3s
        /* renamed from: keiL1EiShomu, reason: merged with bridge method [inline-methods] */
        public Xe6mangaekai thooCoci9zae(byte[] bArr) {
            return Xe6mangaekai.ko7aiFeiqu3s(bArr);
        }
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        OK(0),
        CANCELLED(1),
        UNKNOWN(2),
        INVALID_ARGUMENT(3),
        DEADLINE_EXCEEDED(4),
        NOT_FOUND(5),
        ALREADY_EXISTS(6),
        PERMISSION_DENIED(7),
        RESOURCE_EXHAUSTED(8),
        FAILED_PRECONDITION(9),
        ABORTED(10),
        OUT_OF_RANGE(11),
        UNIMPLEMENTED(12),
        INTERNAL(13),
        UNAVAILABLE(14),
        DATA_LOSS(15),
        UNAUTHENTICATED(16);


        /* renamed from: ieheiQu9sho5, reason: collision with root package name */
        public final int f2392ieheiQu9sho5;

        /* renamed from: kuedujio7Aev, reason: collision with root package name */
        public final byte[] f2393kuedujio7Aev;

        thooCoci9zae(int i) {
            this.f2392ieheiQu9sho5 = i;
            this.f2393kuedujio7Aev = Integer.toString(i).getBytes(StandardCharsets.US_ASCII);
        }

        public Xe6mangaekai Jah0aiP1ki6y() {
            return (Xe6mangaekai) Xe6mangaekai.f2356ieheiQu9sho5.get(this.f2392ieheiQu9sho5);
        }

        public int niah0Shohtha() {
            return this.f2392ieheiQu9sho5;
        }

        public final byte[] ohv5Shie7AeZ() {
            return this.f2393kuedujio7Aev;
        }
    }

    static {
        f2355esohshee3Pau = ohx8eem3Ahph.Jah0aiP1ki6y.Jah0aiP1ki6y("grpc-status", false, new keiL1EiShomu());
        ieheiQu9sho5 ieheiqu9sho5 = new ieheiQu9sho5();
        f2365oph9lahCh6uo = ieheiqu9sho5;
        f2363ohthie9thieG = ohx8eem3Ahph.Jah0aiP1ki6y.Jah0aiP1ki6y("grpc-message", false, ieheiqu9sho5);
    }

    public Xe6mangaekai(thooCoci9zae thoococi9zae) {
        this(thoococi9zae, null, null);
    }

    public static List Jah0aiP1ki6y() {
        TreeMap treeMap = new TreeMap();
        for (thooCoci9zae thoococi9zae : thooCoci9zae.values()) {
            Xe6mangaekai xe6mangaekai = (Xe6mangaekai) treeMap.put(Integer.valueOf(thoococi9zae.niah0Shohtha()), new Xe6mangaekai(thoococi9zae));
            if (xe6mangaekai != null) {
                throw new IllegalStateException("Code value duplication between " + xe6mangaekai.ruwiepo7ooVu().name() + " & " + thoococi9zae.name());
            }
        }
        return Collections.unmodifiableList(new ArrayList(treeMap.values()));
    }

    public static Xe6mangaekai ahthoK6usais(Throwable th) {
        for (Throwable th2 = (Throwable) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(th, "t"); th2 != null; th2 = th2.getCause()) {
            if (th2 instanceof aech7ohPhooh) {
                return ((aech7ohPhooh) th2).ieseir3Choge();
            }
            if (th2 instanceof eik1oetahvuF) {
                return ((eik1oetahvuF) th2).ieseir3Choge();
            }
        }
        return f2351Jah0aiP1ki6y.eetheKaevie8(th);
    }

    public static Xe6mangaekai ko7aiFeiqu3s(byte[] bArr) {
        if (bArr.length == 1 && bArr[0] == 48) {
            return f2358kuedujio7Aev;
        }
        return ruNgecai1pae(bArr);
    }

    public static String niah0Shohtha(Xe6mangaekai xe6mangaekai) {
        if (xe6mangaekai.f2372thooCoci9zae == null) {
            return xe6mangaekai.f2370ieseir3Choge.toString();
        }
        return xe6mangaekai.f2370ieseir3Choge + ": " + xe6mangaekai.f2372thooCoci9zae;
    }

    public static Xe6mangaekai ohv5Shie7AeZ(int i) {
        if (i >= 0) {
            List list = f2356ieheiQu9sho5;
            if (i < list.size()) {
                return (Xe6mangaekai) list.get(i);
            }
        }
        return f2351Jah0aiP1ki6y.zoojiiKaht3i("Unknown code " + i);
    }

    public static Xe6mangaekai ruNgecai1pae(byte[] bArr) {
        byte b;
        int length = bArr.length;
        char c = 1;
        int i = 0;
        if (length != 1) {
            if (length == 2 && (b = bArr[0]) >= 48 && b <= 57) {
                i = (b - 48) * 10;
            }
            return f2351Jah0aiP1ki6y.zoojiiKaht3i("Unknown code " + new String(bArr, StandardCharsets.US_ASCII));
        }
        c = 0;
        byte b2 = bArr[c];
        if (b2 >= 48 && b2 <= 57) {
            int i2 = i + (b2 - 48);
            List list = f2356ieheiQu9sho5;
            if (i2 < list.size()) {
                return (Xe6mangaekai) list.get(i2);
            }
        }
        return f2351Jah0aiP1ki6y.zoojiiKaht3i("Unknown code " + new String(bArr, StandardCharsets.US_ASCII));
    }

    public String AeJiPo4of6Sh() {
        return this.f2372thooCoci9zae;
    }

    public Xe6mangaekai Aicohm8ieYoo(String str) {
        if (str == null) {
            return this;
        }
        if (this.f2372thooCoci9zae == null) {
            return new Xe6mangaekai(this.f2370ieseir3Choge, str, this.f2371keiL1EiShomu);
        }
        return new Xe6mangaekai(this.f2370ieseir3Choge, this.f2372thooCoci9zae + "\n" + str, this.f2371keiL1EiShomu);
    }

    public Xe6mangaekai eetheKaevie8(Throwable th) {
        if (Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2371keiL1EiShomu, th)) {
            return this;
        }
        return new Xe6mangaekai(this.f2370ieseir3Choge, this.f2372thooCoci9zae, th);
    }

    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    public int hashCode() {
        return super.hashCode();
    }

    public eik1oetahvuF ieheiQu9sho5() {
        return new eik1oetahvuF(this);
    }

    public aech7ohPhooh keiL1EiShomu() {
        return new aech7ohPhooh(this);
    }

    public eik1oetahvuF kuedujio7Aev(ohx8eem3Ahph ohx8eem3ahph) {
        return new eik1oetahvuF(this, ohx8eem3ahph);
    }

    public Throwable mi5Iecheimie() {
        return this.f2371keiL1EiShomu;
    }

    public boolean oYe2ma2she1j() {
        if (thooCoci9zae.OK == this.f2370ieseir3Choge) {
            return true;
        }
        return false;
    }

    public thooCoci9zae ruwiepo7ooVu() {
        return this.f2370ieseir3Choge;
    }

    public String toString() {
        Aicohm8ieYoo.thooCoci9zae ieheiQu9sho52 = Vaig0nohza7i.Aicohm8ieYoo.thooCoci9zae(this).ieheiQu9sho5("code", this.f2370ieseir3Choge.name()).ieheiQu9sho5("description", this.f2372thooCoci9zae);
        Throwable th = this.f2371keiL1EiShomu;
        Object obj = th;
        if (th != null) {
            obj = Vaig0nohza7i.AeJiPo4of6Sh.kuedujio7Aev(th);
        }
        return ieheiQu9sho52.ieheiQu9sho5("cause", obj).toString();
    }

    public Xe6mangaekai zoojiiKaht3i(String str) {
        if (Vaig0nohza7i.Jah0aiP1ki6y.ieseir3Choge(this.f2372thooCoci9zae, str)) {
            return this;
        }
        return new Xe6mangaekai(this.f2370ieseir3Choge, str, this.f2371keiL1EiShomu);
    }

    public Xe6mangaekai(thooCoci9zae thoococi9zae, String str, Throwable th) {
        this.f2370ieseir3Choge = (thooCoci9zae) Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(thoococi9zae, "code");
        this.f2372thooCoci9zae = str;
        this.f2371keiL1EiShomu = th;
    }
}
