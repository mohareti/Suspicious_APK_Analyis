package XoN2Ii3eiqu0;

import XoN2Ii3eiqu0.Xe6mangaekai;
import java.util.concurrent.TimeoutException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class laej2zeez5Ja {
    public static Xe6mangaekai ieseir3Choge(aac1eTaexee6 aac1etaexee6) {
        Vaig0nohza7i.ko7aiFeiqu3s.AeJiPo4of6Sh(aac1etaexee6, "context must not be null");
        if (!aac1etaexee6.niah0Shohtha()) {
            return null;
        }
        Throwable keiL1EiShomu2 = aac1etaexee6.keiL1EiShomu();
        if (keiL1EiShomu2 == null) {
            return Xe6mangaekai.f2350Aicohm8ieYoo.zoojiiKaht3i("io.grpc.Context was cancelled without error");
        }
        if (keiL1EiShomu2 instanceof TimeoutException) {
            return Xe6mangaekai.f2364ohv5Shie7AeZ.zoojiiKaht3i(keiL1EiShomu2.getMessage()).eetheKaevie8(keiL1EiShomu2);
        }
        Xe6mangaekai ahthoK6usais2 = Xe6mangaekai.ahthoK6usais(keiL1EiShomu2);
        if (Xe6mangaekai.thooCoci9zae.UNKNOWN.equals(ahthoK6usais2.ruwiepo7ooVu()) && ahthoK6usais2.mi5Iecheimie() == keiL1EiShomu2) {
            return Xe6mangaekai.f2350Aicohm8ieYoo.zoojiiKaht3i("Context cancelled").eetheKaevie8(keiL1EiShomu2);
        }
        return ahthoK6usais2.eetheKaevie8(keiL1EiShomu2);
    }
}
