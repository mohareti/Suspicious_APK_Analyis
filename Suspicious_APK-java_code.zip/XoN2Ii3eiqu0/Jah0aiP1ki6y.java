package XoN2Ii3eiqu0;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Jah0aiP1ki6y {
    public abstract void ieheiQu9sho5(Object obj);

    public abstract void ieseir3Choge(String str, Throwable th);

    public abstract void keiL1EiShomu(int i);

    public abstract void kuedujio7Aev(ieseir3Choge ieseir3choge, ohx8eem3Ahph ohx8eem3ahph);

    public abstract void thooCoci9zae();

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract void ieseir3Choge(Xe6mangaekai xe6mangaekai, ohx8eem3Ahph ohx8eem3ahph);

        public abstract void keiL1EiShomu(Object obj);

        public abstract void thooCoci9zae(ohx8eem3Ahph ohx8eem3ahph);

        public void ieheiQu9sho5() {
        }
    }
}
