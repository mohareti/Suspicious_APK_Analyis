package eabiePho2iu8;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;
import eabiePho2iu8.ooJahquoo9ei;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ooJahquoo9ei implements ServiceConnection {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public boolean f5915Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Queue f5916ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f5917ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final ScheduledExecutorService f5918keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public Naid2tee7aeb f5919kuedujio7Aev;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Intent f5920thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public final Intent f5921ieseir3Choge;

        /* renamed from: thooCoci9zae, reason: collision with root package name */
        public final vaeVoh2dei5I.ko7aiFeiqu3s f5922thooCoci9zae = new vaeVoh2dei5I.ko7aiFeiqu3s();

        public ieseir3Choge(Intent intent) {
            this.f5921ieseir3Choge = intent;
        }

        public final /* synthetic */ void Aicohm8ieYoo() {
            Log.w("FirebaseMessaging", "Service took too long to process intent: " + this.f5921ieseir3Choge.getAction() + " finishing.");
            ieheiQu9sho5();
        }

        public void ieheiQu9sho5() {
            this.f5922thooCoci9zae.kuedujio7Aev(null);
        }

        public void keiL1EiShomu(ScheduledExecutorService scheduledExecutorService) {
            final ScheduledFuture<?> schedule = scheduledExecutorService.schedule(new Runnable() { // from class: eabiePho2iu8.chie7aequa3C
                @Override // java.lang.Runnable
                public final void run() {
                    ooJahquoo9ei.ieseir3Choge.this.Aicohm8ieYoo();
                }
            }, 20L, TimeUnit.SECONDS);
            kuedujio7Aev().thooCoci9zae(scheduledExecutorService, new vaeVoh2dei5I.ieheiQu9sho5() { // from class: eabiePho2iu8.Wee2wi3pheim
                @Override // vaeVoh2dei5I.ieheiQu9sho5
                public final void ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                    schedule.cancel(false);
                }
            });
        }

        public vaeVoh2dei5I.ohv5Shie7AeZ kuedujio7Aev() {
            return this.f5922thooCoci9zae.ieseir3Choge();
        }
    }

    public ooJahquoo9ei(Context context, String str) {
        this(context, str, ieseir3Choge());
    }

    public static ScheduledThreadPoolExecutor ieseir3Choge() {
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor = new ScheduledThreadPoolExecutor(1);
        scheduledThreadPoolExecutor.setKeepAliveTime(40L, TimeUnit.SECONDS);
        scheduledThreadPoolExecutor.allowCoreThreadTimeOut(true);
        return scheduledThreadPoolExecutor;
    }

    public synchronized vaeVoh2dei5I.ohv5Shie7AeZ ieheiQu9sho5(Intent intent) {
        ieseir3Choge ieseir3choge;
        try {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "new intent queued in the bind-strategy delivery");
            }
            ieseir3choge = new ieseir3Choge(intent);
            ieseir3choge.keiL1EiShomu(this.f5918keiL1EiShomu);
            this.f5916ieheiQu9sho5.add(ieseir3choge);
            keiL1EiShomu();
        } catch (Throwable th) {
            throw th;
        }
        return ieseir3choge.kuedujio7Aev();
    }

    public final synchronized void keiL1EiShomu() {
        try {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "flush queue called");
            }
            while (!this.f5916ieheiQu9sho5.isEmpty()) {
                if (Log.isLoggable("FirebaseMessaging", 3)) {
                    Log.d("FirebaseMessaging", "found intent to be delivered");
                }
                Naid2tee7aeb naid2tee7aeb = this.f5919kuedujio7Aev;
                if (naid2tee7aeb != null && naid2tee7aeb.isBinderAlive()) {
                    if (Log.isLoggable("FirebaseMessaging", 3)) {
                        Log.d("FirebaseMessaging", "binder is alive, sending the intent.");
                    }
                    this.f5919kuedujio7Aev.keiL1EiShomu((ieseir3Choge) this.f5916ieheiQu9sho5.poll());
                } else {
                    kuedujio7Aev();
                    return;
                }
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void kuedujio7Aev() {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            StringBuilder sb = new StringBuilder();
            sb.append("binder is dead. start connection? ");
            sb.append(!this.f5915Aicohm8ieYoo);
            Log.d("FirebaseMessaging", sb.toString());
        }
        if (this.f5915Aicohm8ieYoo) {
            return;
        }
        this.f5915Aicohm8ieYoo = true;
        try {
        } catch (SecurityException e) {
            Log.e("FirebaseMessaging", "Exception while binding the service", e);
        }
        if (IPh5ahNg5Ooj.thooCoci9zae.thooCoci9zae().ieseir3Choge(this.f5917ieseir3Choge, this.f5920thooCoci9zae, this, 65)) {
            return;
        }
        Log.e("FirebaseMessaging", "binding to the service failed");
        this.f5915Aicohm8ieYoo = false;
        thooCoci9zae();
    }

    @Override // android.content.ServiceConnection
    public synchronized void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        try {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "onServiceConnected: " + componentName);
            }
            this.f5915Aicohm8ieYoo = false;
            if (!(iBinder instanceof Naid2tee7aeb)) {
                Log.e("FirebaseMessaging", "Invalid service connection: " + iBinder);
                thooCoci9zae();
                return;
            }
            this.f5919kuedujio7Aev = (Naid2tee7aeb) iBinder;
            keiL1EiShomu();
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // android.content.ServiceConnection
    public void onServiceDisconnected(ComponentName componentName) {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "onServiceDisconnected: " + componentName);
        }
        keiL1EiShomu();
    }

    public final void thooCoci9zae() {
        while (!this.f5916ieheiQu9sho5.isEmpty()) {
            ((ieseir3Choge) this.f5916ieheiQu9sho5.poll()).ieheiQu9sho5();
        }
    }

    public ooJahquoo9ei(Context context, String str, ScheduledExecutorService scheduledExecutorService) {
        this.f5916ieheiQu9sho5 = new ArrayDeque();
        this.f5915Aicohm8ieYoo = false;
        Context applicationContext = context.getApplicationContext();
        this.f5917ieseir3Choge = applicationContext;
        this.f5920thooCoci9zae = new Intent(str).setPackage(applicationContext.getPackageName());
        this.f5918keiL1EiShomu = scheduledExecutorService;
    }
}
