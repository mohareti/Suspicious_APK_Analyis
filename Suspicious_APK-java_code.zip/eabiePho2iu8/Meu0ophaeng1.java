package eabiePho2iu8;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.TextUtils;
import android.util.Log;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Meu0ophaeng1 implements Closeable {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public vaeVoh2dei5I.ohv5Shie7AeZ f5807Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final URL f5808ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public volatile Future f5809kuedujio7Aev;

    public Meu0ophaeng1(URL url) {
        this.f5808ieheiQu9sho5 = url;
    }

    public static Meu0ophaeng1 ohthie9thieG(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        try {
            return new Meu0ophaeng1(new URL(str));
        } catch (MalformedURLException unused) {
            Log.w("FirebaseMessaging", "Not downloading image, bad URL: " + str);
            return null;
        }
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ Ochoob6Ahvi2() {
        return (vaeVoh2dei5I.ohv5Shie7AeZ) Aebu8yohvea8.ruwiepo7ooVu.ko7aiFeiqu3s(this.f5807Aicohm8ieYoo);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f5809kuedujio7Aev.cancel(true);
    }

    public void doonge7ooYoe(ExecutorService executorService) {
        final vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s = new vaeVoh2dei5I.ko7aiFeiqu3s();
        this.f5809kuedujio7Aev = executorService.submit(new Runnable() { // from class: eabiePho2iu8.Nieyie8tecah
            @Override // java.lang.Runnable
            public final void run() {
                Meu0ophaeng1.this.iev8ainaiLae(ko7aifeiqu3s);
            }
        });
        this.f5807Aicohm8ieYoo = ko7aifeiqu3s.ieseir3Choge();
    }

    public final byte[] esohshee3Pau() {
        URLConnection openConnection = this.f5808ieheiQu9sho5.openConnection();
        if (openConnection.getContentLength() <= 1048576) {
            InputStream inputStream = openConnection.getInputStream();
            try {
                byte[] ieheiQu9sho52 = thooCoci9zae.ieheiQu9sho5(thooCoci9zae.thooCoci9zae(inputStream, 1048577L));
                if (inputStream != null) {
                    inputStream.close();
                }
                if (Log.isLoggable("FirebaseMessaging", 2)) {
                    Log.v("FirebaseMessaging", "Downloaded " + ieheiQu9sho52.length + " bytes from " + this.f5808ieheiQu9sho5);
                }
                if (ieheiQu9sho52.length <= 1048576) {
                    return ieheiQu9sho52;
                }
                throw new IOException("Image exceeds max size of 1048576");
            } catch (Throwable th) {
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        throw new IOException("Content-Length exceeds max size of 1048576");
    }

    public Bitmap ieheiQu9sho5() {
        if (Log.isLoggable("FirebaseMessaging", 4)) {
            Log.i("FirebaseMessaging", "Starting download of: " + this.f5808ieheiQu9sho5);
        }
        byte[] esohshee3Pau2 = esohshee3Pau();
        Bitmap decodeByteArray = BitmapFactory.decodeByteArray(esohshee3Pau2, 0, esohshee3Pau2.length);
        if (decodeByteArray != null) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Successfully downloaded image: " + this.f5808ieheiQu9sho5);
            }
            return decodeByteArray;
        }
        throw new IOException("Failed to decode image: " + this.f5808ieheiQu9sho5);
    }

    public final /* synthetic */ void iev8ainaiLae(vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s) {
        try {
            ko7aifeiqu3s.keiL1EiShomu(ieheiQu9sho5());
        } catch (Exception e) {
            ko7aifeiqu3s.thooCoci9zae(e);
        }
    }
}
