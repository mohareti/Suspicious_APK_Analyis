package eabiePho2iu8;

import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Bundle;
import android.util.Log;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class soiNgemai6Ie {
    public static vaeVoh2dei5I.ohv5Shie7AeZ Aicohm8ieYoo(Executor executor, final Context context, final boolean z) {
        if (!Id9uvaegh4ai.ohv5Shie7AeZ.ohv5Shie7AeZ()) {
            return vaeVoh2dei5I.ahthoK6usais.kuedujio7Aev(null);
        }
        final vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s = new vaeVoh2dei5I.ko7aiFeiqu3s();
        executor.execute(new Runnable() { // from class: eabiePho2iu8.lo8zieZoeseb
            @Override // java.lang.Runnable
            public final void run() {
                soiNgemai6Ie.kuedujio7Aev(context, z, ko7aifeiqu3s);
            }
        });
        return ko7aifeiqu3s.ieseir3Choge();
    }

    public static boolean Jah0aiP1ki6y(Context context) {
        ApplicationInfo applicationInfo;
        Bundle bundle;
        try {
            Context applicationContext = context.getApplicationContext();
            PackageManager packageManager = applicationContext.getPackageManager();
            if (packageManager != null && (applicationInfo = packageManager.getApplicationInfo(applicationContext.getPackageName(), 128)) != null && (bundle = applicationInfo.metaData) != null && bundle.containsKey("firebase_messaging_notification_delegation_enabled")) {
                return applicationInfo.metaData.getBoolean("firebase_messaging_notification_delegation_enabled");
            }
            return true;
        } catch (PackageManager.NameNotFoundException unused) {
            return true;
        }
    }

    public static boolean ieheiQu9sho5(Context context) {
        String notificationDelegate;
        if (!Id9uvaegh4ai.ohv5Shie7AeZ.ohv5Shie7AeZ()) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Platform doesn't support proxying.");
            }
            return false;
        }
        if (thooCoci9zae(context)) {
            notificationDelegate = ((NotificationManager) context.getSystemService(NotificationManager.class)).getNotificationDelegate();
            if (!"com.google.android.gms".equals(notificationDelegate)) {
                return false;
            }
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "GMS core is set for proxying");
                return true;
            }
            return true;
        }
        Log.e("FirebaseMessaging", "error retrieving notification delegate for package " + context.getPackageName());
        return false;
    }

    public static void keiL1EiShomu(Context context) {
        if (Ohah9Nai3tha.keiL1EiShomu(context)) {
            return;
        }
        Aicohm8ieYoo(new HaeYeFaep1if.Aicohm8ieYoo(), context, Jah0aiP1ki6y(context));
    }

    public static /* synthetic */ void kuedujio7Aev(Context context, boolean z, vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s) {
        String notificationDelegate;
        try {
            if (!thooCoci9zae(context)) {
                Log.e("FirebaseMessaging", "error configuring notification delegate for package " + context.getPackageName());
                return;
            }
            Ohah9Nai3tha.Aicohm8ieYoo(context, true);
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(NotificationManager.class);
            if (z) {
                notificationManager.setNotificationDelegate("com.google.android.gms");
            } else {
                notificationDelegate = notificationManager.getNotificationDelegate();
                if ("com.google.android.gms".equals(notificationDelegate)) {
                    notificationManager.setNotificationDelegate(null);
                }
            }
        } finally {
            ko7aifeiqu3s.kuedujio7Aev(null);
        }
    }

    public static boolean thooCoci9zae(Context context) {
        if (Binder.getCallingUid() == context.getApplicationInfo().uid) {
            return true;
        }
        return false;
    }
}
