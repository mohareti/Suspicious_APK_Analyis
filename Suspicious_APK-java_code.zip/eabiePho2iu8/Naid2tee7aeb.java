package eabiePho2iu8;

import android.content.Intent;
import android.os.Binder;
import android.os.Process;
import android.util.Log;
import eabiePho2iu8.ooJahquoo9ei;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Naid2tee7aeb extends Binder {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ieseir3Choge f5810ieseir3Choge;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public interface ieseir3Choge {
        vaeVoh2dei5I.ohv5Shie7AeZ ieseir3Choge(Intent intent);
    }

    public Naid2tee7aeb(ieseir3Choge ieseir3choge) {
        this.f5810ieseir3Choge = ieseir3choge;
    }

    public void keiL1EiShomu(final ooJahquoo9ei.ieseir3Choge ieseir3choge) {
        if (Binder.getCallingUid() == Process.myUid()) {
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "service received new intent via bind strategy");
            }
            this.f5810ieseir3Choge.ieseir3Choge(ieseir3choge.f5921ieseir3Choge).thooCoci9zae(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.ieheiQu9sho5() { // from class: eabiePho2iu8.woizoTie7shi
                @Override // vaeVoh2dei5I.ieheiQu9sho5
                public final void ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                    ooJahquoo9ei.ieseir3Choge.this.ieheiQu9sho5();
                }
            });
            return;
        }
        throw new SecurityException("Binding only allowed within app");
    }
}
