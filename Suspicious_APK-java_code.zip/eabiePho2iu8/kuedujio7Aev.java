package eabiePho2iu8;

import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class kuedujio7Aev {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final long f5883ieseir3Choge = TimeUnit.MINUTES.toMillis(3);
}
