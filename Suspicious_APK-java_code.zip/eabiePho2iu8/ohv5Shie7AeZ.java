package eabiePho2iu8;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;
import eabiePho2iu8.Naid2tee7aeb;
import java.util.concurrent.ExecutorService;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ohv5Shie7AeZ extends Service {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public int f5904ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ExecutorService f5905ieseir3Choge = AeJiPo4of6Sh.ieheiQu9sho5();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final Object f5906keiL1EiShomu = new Object();

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public int f5907kuedujio7Aev = 0;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public Binder f5908thooCoci9zae;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public class ieseir3Choge implements Naid2tee7aeb.ieseir3Choge {
        public ieseir3Choge() {
        }

        @Override // eabiePho2iu8.Naid2tee7aeb.ieseir3Choge
        public vaeVoh2dei5I.ohv5Shie7AeZ ieseir3Choge(Intent intent) {
            return ohv5Shie7AeZ.this.ko7aiFeiqu3s(intent);
        }
    }

    public abstract void Aicohm8ieYoo(Intent intent);

    public boolean Jah0aiP1ki6y(Intent intent) {
        return false;
    }

    public final void ieheiQu9sho5(Intent intent) {
        if (intent != null) {
            aed3pie3Chah.keiL1EiShomu(intent);
        }
        synchronized (this.f5906keiL1EiShomu) {
            try {
                int i = this.f5907kuedujio7Aev - 1;
                this.f5907kuedujio7Aev = i;
                if (i == 0) {
                    ruNgecai1pae(this.f5904ieheiQu9sho5);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final vaeVoh2dei5I.ohv5Shie7AeZ ko7aiFeiqu3s(final Intent intent) {
        if (Jah0aiP1ki6y(intent)) {
            return vaeVoh2dei5I.ahthoK6usais.kuedujio7Aev(null);
        }
        final vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s = new vaeVoh2dei5I.ko7aiFeiqu3s();
        this.f5905ieseir3Choge.execute(new Runnable() { // from class: eabiePho2iu8.niah0Shohtha
            @Override // java.lang.Runnable
            public final void run() {
                ohv5Shie7AeZ.this.ohv5Shie7AeZ(intent, ko7aifeiqu3s);
            }
        });
        return ko7aifeiqu3s.ieseir3Choge();
    }

    public abstract Intent kuedujio7Aev(Intent intent);

    public final /* synthetic */ void niah0Shohtha(Intent intent, vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        ieheiQu9sho5(intent);
    }

    public final /* synthetic */ void ohv5Shie7AeZ(Intent intent, vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s) {
        try {
            Aicohm8ieYoo(intent);
        } finally {
            ko7aifeiqu3s.keiL1EiShomu(null);
        }
    }

    @Override // android.app.Service
    public final synchronized IBinder onBind(Intent intent) {
        try {
            if (Log.isLoggable("EnhancedIntentService", 3)) {
                Log.d("EnhancedIntentService", "Service received bind request");
            }
            if (this.f5908thooCoci9zae == null) {
                this.f5908thooCoci9zae = new Naid2tee7aeb(new ieseir3Choge());
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.f5908thooCoci9zae;
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.f5905ieseir3Choge.shutdown();
        super.onDestroy();
    }

    @Override // android.app.Service
    public final int onStartCommand(final Intent intent, int i, int i2) {
        synchronized (this.f5906keiL1EiShomu) {
            this.f5904ieheiQu9sho5 = i2;
            this.f5907kuedujio7Aev++;
        }
        Intent kuedujio7Aev2 = kuedujio7Aev(intent);
        if (kuedujio7Aev2 == null) {
            ieheiQu9sho5(intent);
            return 2;
        }
        vaeVoh2dei5I.ohv5Shie7AeZ ko7aiFeiqu3s2 = ko7aiFeiqu3s(kuedujio7Aev2);
        if (ko7aiFeiqu3s2.ruwiepo7ooVu()) {
            ieheiQu9sho5(intent);
            return 2;
        }
        ko7aiFeiqu3s2.thooCoci9zae(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.ieheiQu9sho5() { // from class: eabiePho2iu8.Jah0aiP1ki6y
            @Override // vaeVoh2dei5I.ieheiQu9sho5
            public final void ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                ohv5Shie7AeZ.this.niah0Shohtha(intent, ohv5shie7aez);
            }
        });
        return 3;
    }

    public boolean ruNgecai1pae(int i) {
        return stopSelfResult(i);
    }
}
