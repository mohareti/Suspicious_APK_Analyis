package eabiePho2iu8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class maSie9ief8Ae implements Runnable {

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final FirebaseMessaging f5888Aicohm8ieYoo;

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public ExecutorService f5889Jah0aiP1ki6y = new ThreadPoolExecutor(0, 1, 30, TimeUnit.SECONDS, new LinkedBlockingQueue(), new Ahv6nai5fo5z.ieseir3Choge("firebase-iid-executor"));

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final long f5890ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final PowerManager.WakeLock f5891kuedujio7Aev;

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static class ieseir3Choge extends BroadcastReceiver {

        /* renamed from: ieseir3Choge, reason: collision with root package name */
        public maSie9ief8Ae f5892ieseir3Choge;

        public ieseir3Choge(maSie9ief8Ae masie9ief8ae) {
            this.f5892ieseir3Choge = masie9ief8ae;
        }

        public void ieseir3Choge() {
            if (maSie9ief8Ae.keiL1EiShomu()) {
                Log.d("FirebaseMessaging", "Connectivity change received registered");
            }
            this.f5892ieseir3Choge.thooCoci9zae().registerReceiver(this, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }

        @Override // android.content.BroadcastReceiver
        public void onReceive(Context context, Intent intent) {
            maSie9ief8Ae masie9ief8ae = this.f5892ieseir3Choge;
            if (masie9ief8ae == null || !masie9ief8ae.ieheiQu9sho5()) {
                return;
            }
            if (maSie9ief8Ae.keiL1EiShomu()) {
                Log.d("FirebaseMessaging", "Connectivity changed. Starting background sync.");
            }
            this.f5892ieseir3Choge.f5888Aicohm8ieYoo.mi5Iecheimie(this.f5892ieseir3Choge, 0L);
            this.f5892ieseir3Choge.thooCoci9zae().unregisterReceiver(this);
            this.f5892ieseir3Choge = null;
        }
    }

    public maSie9ief8Ae(FirebaseMessaging firebaseMessaging, long j) {
        this.f5888Aicohm8ieYoo = firebaseMessaging;
        this.f5890ieheiQu9sho5 = j;
        PowerManager.WakeLock newWakeLock = ((PowerManager) thooCoci9zae().getSystemService("power")).newWakeLock(1, "fiid-sync");
        this.f5891kuedujio7Aev = newWakeLock;
        newWakeLock.setReferenceCounted(false);
    }

    public static boolean keiL1EiShomu() {
        if (!Log.isLoggable("FirebaseMessaging", 3) && (Build.VERSION.SDK_INT != 23 || !Log.isLoggable("FirebaseMessaging", 3))) {
            return false;
        }
        return true;
    }

    public boolean ieheiQu9sho5() {
        NetworkInfo networkInfo;
        ConnectivityManager connectivityManager = (ConnectivityManager) thooCoci9zae().getSystemService("connectivity");
        if (connectivityManager != null) {
            networkInfo = connectivityManager.getActiveNetworkInfo();
        } else {
            networkInfo = null;
        }
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }

    public boolean kuedujio7Aev() {
        String str;
        try {
            if (this.f5888Aicohm8ieYoo.ahthoK6usais() == null) {
                Log.e("FirebaseMessaging", "Token retrieval failed: null");
                return false;
            }
            if (Log.isLoggable("FirebaseMessaging", 3)) {
                Log.d("FirebaseMessaging", "Token successfully retrieved");
                return true;
            }
            return true;
        } catch (IOException e) {
            if (IengaiSahh8H.niah0Shohtha(e.getMessage())) {
                str = "Token retrieval failed: " + e.getMessage() + ". Will retry token retrieval";
            } else if (e.getMessage() == null) {
                str = "Token retrieval failed without exception message. Will retry token retrieval";
            } else {
                throw e;
            }
            Log.w("FirebaseMessaging", str);
            return false;
        } catch (SecurityException unused) {
            str = "Token retrieval failed with SecurityException. Will retry token retrieval";
            Log.w("FirebaseMessaging", str);
            return false;
        }
    }

    @Override // java.lang.Runnable
    public void run() {
        if (ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
            this.f5891kuedujio7Aev.acquire();
        }
        try {
            try {
                this.f5888Aicohm8ieYoo.ahk3OhSh9Ree(true);
            } catch (IOException e) {
                Log.e("FirebaseMessaging", "Topic sync or token retrieval failed on hard failure exceptions: " + e.getMessage() + ". Won't retry the operation.");
                this.f5888Aicohm8ieYoo.ahk3OhSh9Ree(false);
                if (!ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
                    return;
                }
            }
            if (!this.f5888Aicohm8ieYoo.eyei9eigh3Ie()) {
                this.f5888Aicohm8ieYoo.ahk3OhSh9Ree(false);
                if (ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
                    this.f5891kuedujio7Aev.release();
                    return;
                }
                return;
            }
            if (ohx8eem3Ahph.thooCoci9zae().ieheiQu9sho5(thooCoci9zae()) && !ieheiQu9sho5()) {
                new ieseir3Choge(this).ieseir3Choge();
                if (ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
                    this.f5891kuedujio7Aev.release();
                    return;
                }
                return;
            }
            if (kuedujio7Aev()) {
                this.f5888Aicohm8ieYoo.ahk3OhSh9Ree(false);
            } else {
                this.f5888Aicohm8ieYoo.oote1Ahvo8Ai(this.f5890ieheiQu9sho5);
            }
            if (!ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
                return;
            }
            this.f5891kuedujio7Aev.release();
        } catch (Throwable th) {
            if (ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(thooCoci9zae())) {
                this.f5891kuedujio7Aev.release();
            }
            throw th;
        }
    }

    public Context thooCoci9zae() {
        return this.f5888Aicohm8ieYoo.ruwiepo7ooVu();
    }
}
