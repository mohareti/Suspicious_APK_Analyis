package eabiePho2iu8;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import eabiePho2iu8.ieheiQu9sho5;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import ruwiepo7ooVu.ieheiQu9sho5;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Aicohm8ieYoo {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final ExecutorService f5784ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final io4laQuei7sa f5785keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Context f5786thooCoci9zae;

    public Aicohm8ieYoo(Context context, io4laQuei7sa io4laquei7sa, ExecutorService executorService) {
        this.f5784ieseir3Choge = executorService;
        this.f5786thooCoci9zae = context;
        this.f5785keiL1EiShomu = io4laquei7sa;
    }

    public final Meu0ophaeng1 ieheiQu9sho5() {
        Meu0ophaeng1 ohthie9thieG2 = Meu0ophaeng1.ohthie9thieG(this.f5785keiL1EiShomu.oYe2ma2she1j("gcm.n.image"));
        if (ohthie9thieG2 != null) {
            ohthie9thieG2.doonge7ooYoe(this.f5784ieseir3Choge);
        }
        return ohthie9thieG2;
    }

    public boolean ieseir3Choge() {
        if (this.f5785keiL1EiShomu.ieseir3Choge("gcm.n.noui")) {
            return true;
        }
        if (thooCoci9zae()) {
            return false;
        }
        Meu0ophaeng1 ieheiQu9sho52 = ieheiQu9sho5();
        ieheiQu9sho5.ieseir3Choge kuedujio7Aev2 = ieheiQu9sho5.kuedujio7Aev(this.f5786thooCoci9zae, this.f5785keiL1EiShomu);
        kuedujio7Aev(kuedujio7Aev2.f5849ieseir3Choge, ieheiQu9sho52);
        keiL1EiShomu(kuedujio7Aev2);
        return true;
    }

    public final void keiL1EiShomu(ieheiQu9sho5.ieseir3Choge ieseir3choge) {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Showing notification");
        }
        ((NotificationManager) this.f5786thooCoci9zae.getSystemService("notification")).notify(ieseir3choge.f5851thooCoci9zae, ieseir3choge.f5850keiL1EiShomu, ieseir3choge.f5849ieseir3Choge.thooCoci9zae());
    }

    public final void kuedujio7Aev(ieheiQu9sho5.kuedujio7Aev kuedujio7aev, Meu0ophaeng1 meu0ophaeng1) {
        if (meu0ophaeng1 == null) {
            return;
        }
        try {
            Bitmap bitmap = (Bitmap) vaeVoh2dei5I.ahthoK6usais.thooCoci9zae(meu0ophaeng1.Ochoob6Ahvi2(), 5L, TimeUnit.SECONDS);
            kuedujio7aev.ruwiepo7ooVu(bitmap);
            kuedujio7aev.esohshee3Pau(new ieheiQu9sho5.thooCoci9zae().ohv5Shie7AeZ(bitmap).niah0Shohtha(null));
        } catch (InterruptedException unused) {
            Log.w("FirebaseMessaging", "Interrupted while downloading image, showing notification without it");
            meu0ophaeng1.close();
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            Log.w("FirebaseMessaging", "Failed to download image: " + e.getCause());
        } catch (TimeoutException unused2) {
            Log.w("FirebaseMessaging", "Failed to download image in time, showing notification without it");
            meu0ophaeng1.close();
        }
    }

    public final boolean thooCoci9zae() {
        if (((KeyguardManager) this.f5786thooCoci9zae.getSystemService("keyguard")).inKeyguardRestrictedInputMode()) {
            return false;
        }
        if (!Id9uvaegh4ai.ohv5Shie7AeZ.kuedujio7Aev()) {
            SystemClock.sleep(10L);
        }
        int myPid = Process.myPid();
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = ((ActivityManager) this.f5786thooCoci9zae.getSystemService("activity")).getRunningAppProcesses();
        if (runningAppProcesses == null) {
            return false;
        }
        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : runningAppProcesses) {
            if (runningAppProcessInfo.pid == myPid) {
                if (runningAppProcessInfo.importance != 100) {
                    return false;
                }
                return true;
            }
        }
        return false;
    }
}
