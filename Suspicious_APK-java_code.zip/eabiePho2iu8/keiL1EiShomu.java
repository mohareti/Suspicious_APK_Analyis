package eabiePho2iu8;

import android.graphics.drawable.AdaptiveIconDrawable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract /* synthetic */ class keiL1EiShomu {
    public static /* bridge */ /* synthetic */ boolean ieseir3Choge(Object obj) {
        return obj instanceof AdaptiveIconDrawable;
    }
}
