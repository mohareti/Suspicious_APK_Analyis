package eabiePho2iu8;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import com.google.firebase.messaging.FirebaseMessaging;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class Eipeibai2Aa0 {

    /* renamed from: ohv5Shie7AeZ, reason: collision with root package name */
    public static final long f5788ohv5Shie7AeZ = TimeUnit.HOURS.toSeconds(8);

    /* renamed from: Aicohm8ieYoo, reason: collision with root package name */
    public final ScheduledExecutorService f5789Aicohm8ieYoo;

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final FirebaseMessaging f5791ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f5792ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final IengaiSahh8H f5793keiL1EiShomu;

    /* renamed from: niah0Shohtha, reason: collision with root package name */
    public final doonge7ooYoe f5795niah0Shohtha;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final mi3Ozool1oa4 f5796thooCoci9zae;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final Map f5794kuedujio7Aev = new ruNgecai1pae.ieseir3Choge();

    /* renamed from: Jah0aiP1ki6y, reason: collision with root package name */
    public boolean f5790Jah0aiP1ki6y = false;

    public Eipeibai2Aa0(FirebaseMessaging firebaseMessaging, mi3Ozool1oa4 mi3ozool1oa4, doonge7ooYoe doonge7ooyoe, IengaiSahh8H iengaiSahh8H, Context context, ScheduledExecutorService scheduledExecutorService) {
        this.f5791ieheiQu9sho5 = firebaseMessaging;
        this.f5796thooCoci9zae = mi3ozool1oa4;
        this.f5795niah0Shohtha = doonge7ooyoe;
        this.f5793keiL1EiShomu = iengaiSahh8H;
        this.f5792ieseir3Choge = context;
        this.f5789Aicohm8ieYoo = scheduledExecutorService;
    }

    public static vaeVoh2dei5I.ohv5Shie7AeZ Aicohm8ieYoo(final FirebaseMessaging firebaseMessaging, final mi3Ozool1oa4 mi3ozool1oa4, final IengaiSahh8H iengaiSahh8H, final Context context, final ScheduledExecutorService scheduledExecutorService) {
        return vaeVoh2dei5I.ahthoK6usais.keiL1EiShomu(scheduledExecutorService, new Callable() { // from class: eabiePho2iu8.pho6iiPh5IaG
            @Override // java.util.concurrent.Callable
            public final Object call() {
                Eipeibai2Aa0 ko7aiFeiqu3s2;
                ko7aiFeiqu3s2 = Eipeibai2Aa0.ko7aiFeiqu3s(context, scheduledExecutorService, firebaseMessaging, mi3ozool1oa4, iengaiSahh8H);
                return ko7aiFeiqu3s2;
            }
        });
    }

    public static void keiL1EiShomu(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        try {
            vaeVoh2dei5I.ahthoK6usais.thooCoci9zae(ohv5shie7aez, 30L, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e = e;
            throw new IOException("SERVICE_NOT_AVAILABLE", e);
        } catch (ExecutionException e2) {
            Throwable cause = e2.getCause();
            if (!(cause instanceof IOException)) {
                if (cause instanceof RuntimeException) {
                    throw ((RuntimeException) cause);
                }
                throw new IOException(e2);
            }
            throw ((IOException) cause);
        } catch (TimeoutException e3) {
            e = e3;
            throw new IOException("SERVICE_NOT_AVAILABLE", e);
        }
    }

    public static /* synthetic */ Eipeibai2Aa0 ko7aiFeiqu3s(Context context, ScheduledExecutorService scheduledExecutorService, FirebaseMessaging firebaseMessaging, mi3Ozool1oa4 mi3ozool1oa4, IengaiSahh8H iengaiSahh8H) {
        return new Eipeibai2Aa0(firebaseMessaging, mi3ozool1oa4, doonge7ooYoe.thooCoci9zae(context, scheduledExecutorService), iengaiSahh8H, context, scheduledExecutorService);
    }

    public static boolean niah0Shohtha() {
        if (!Log.isLoggable("FirebaseMessaging", 3) && (Build.VERSION.SDK_INT != 23 || !Log.isLoggable("FirebaseMessaging", 3))) {
            return false;
        }
        return true;
    }

    public synchronized void AeJiPo4of6Sh(boolean z) {
        this.f5790Jah0aiP1ki6y = z;
    }

    public boolean Jah0aiP1ki6y() {
        if (this.f5795niah0Shohtha.keiL1EiShomu() != null) {
            return true;
        }
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x000d, code lost:
    
        if (niah0Shohtha() == false) goto L10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x000f, code lost:
    
        android.util.Log.d("FirebaseMessaging", "topic sync succeeded");
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x001a, code lost:
    
        return true;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean aac1eTaexee6() {
        while (true) {
            synchronized (this) {
                try {
                    iev8ainaiLae keiL1EiShomu2 = this.f5795niah0Shohtha.keiL1EiShomu();
                    if (keiL1EiShomu2 == null) {
                        break;
                    }
                    if (!ahthoK6usais(keiL1EiShomu2)) {
                        return false;
                    }
                    this.f5795niah0Shohtha.kuedujio7Aev(keiL1EiShomu2);
                    ruNgecai1pae(keiL1EiShomu2);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0079 A[Catch: IOException -> 0x001f, TryCatch #0 {IOException -> 0x001f, blocks: (B:3:0x0003, B:12:0x0033, B:14:0x0039, B:15:0x004f, B:19:0x0053, B:21:0x0060, B:22:0x0079, B:24:0x0086, B:25:0x0015, B:28:0x0022), top: B:2:0x0003 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean ahthoK6usais(iev8ainaiLae iev8ainailae) {
        String str;
        char c;
        String str2;
        try {
            String thooCoci9zae2 = iev8ainailae.thooCoci9zae();
            int hashCode = thooCoci9zae2.hashCode();
            if (hashCode != 83) {
                if (hashCode == 85 && thooCoci9zae2.equals("U")) {
                    c = 1;
                    if (c == 0) {
                        if (c != 1) {
                            if (niah0Shohtha()) {
                                str2 = "Unknown topic operation" + iev8ainailae + ".";
                                Log.d("FirebaseMessaging", str2);
                            }
                            return true;
                        }
                        kuedujio7Aev(iev8ainailae.keiL1EiShomu());
                        if (niah0Shohtha()) {
                            str2 = "Unsubscribe from topic: " + iev8ainailae.keiL1EiShomu() + " succeeded.";
                            Log.d("FirebaseMessaging", str2);
                        }
                        return true;
                    }
                    ieheiQu9sho5(iev8ainailae.keiL1EiShomu());
                    if (niah0Shohtha()) {
                        str2 = "Subscribe to topic: " + iev8ainailae.keiL1EiShomu() + " succeeded.";
                        Log.d("FirebaseMessaging", str2);
                    }
                    return true;
                }
                c = 65535;
                if (c == 0) {
                }
            } else {
                if (thooCoci9zae2.equals("S")) {
                    c = 0;
                    if (c == 0) {
                    }
                }
                c = 65535;
                if (c == 0) {
                }
            }
        } catch (IOException e) {
            if ("SERVICE_NOT_AVAILABLE".equals(e.getMessage())) {
            }
            str = "Topic operation failed: " + e.getMessage() + ". Will retry Topic operation.";
            Log.e("FirebaseMessaging", str);
            return false;
        }
        if ("SERVICE_NOT_AVAILABLE".equals(e.getMessage()) && !"INTERNAL_SERVER_ERROR".equals(e.getMessage()) && !"TOO_MANY_SUBSCRIBERS".equals(e.getMessage())) {
            if (e.getMessage() == null) {
                str = "Topic operation failed without exception message. Will retry Topic operation.";
            } else {
                throw e;
            }
        } else {
            str = "Topic operation failed: " + e.getMessage() + ". Will retry Topic operation.";
        }
        Log.e("FirebaseMessaging", str);
        return false;
    }

    public void eetheKaevie8() {
        if (Jah0aiP1ki6y()) {
            oYe2ma2she1j();
        }
    }

    public final void ieheiQu9sho5(String str) {
        keiL1EiShomu(this.f5793keiL1EiShomu.mi5Iecheimie(this.f5791ieheiQu9sho5.ahthoK6usais(), str));
    }

    public final void kuedujio7Aev(String str) {
        keiL1EiShomu(this.f5793keiL1EiShomu.ruwiepo7ooVu(this.f5791ieheiQu9sho5.ahthoK6usais(), str));
    }

    public void laej2zeez5Ja(long j) {
        mi5Iecheimie(new Ohgahseiw0ni(this, this.f5792ieseir3Choge, this.f5796thooCoci9zae, Math.min(Math.max(30L, 2 * j), f5788ohv5Shie7AeZ)), j);
        AeJiPo4of6Sh(true);
    }

    public void mi5Iecheimie(Runnable runnable, long j) {
        this.f5789Aicohm8ieYoo.schedule(runnable, j, TimeUnit.SECONDS);
    }

    public final void oYe2ma2she1j() {
        if (!ohv5Shie7AeZ()) {
            laej2zeez5Ja(0L);
        }
    }

    public synchronized boolean ohv5Shie7AeZ() {
        return this.f5790Jah0aiP1ki6y;
    }

    public final void ruNgecai1pae(iev8ainaiLae iev8ainailae) {
        synchronized (this.f5794kuedujio7Aev) {
            try {
                String kuedujio7Aev2 = iev8ainailae.kuedujio7Aev();
                if (!this.f5794kuedujio7Aev.containsKey(kuedujio7Aev2)) {
                    return;
                }
                ArrayDeque arrayDeque = (ArrayDeque) this.f5794kuedujio7Aev.get(kuedujio7Aev2);
                vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s = (vaeVoh2dei5I.ko7aiFeiqu3s) arrayDeque.poll();
                if (ko7aifeiqu3s != null) {
                    ko7aifeiqu3s.keiL1EiShomu(null);
                }
                if (arrayDeque.isEmpty()) {
                    this.f5794kuedujio7Aev.remove(kuedujio7Aev2);
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ ruwiepo7ooVu(iev8ainaiLae iev8ainailae) {
        this.f5795niah0Shohtha.ieseir3Choge(iev8ainailae);
        vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s = new vaeVoh2dei5I.ko7aiFeiqu3s();
        thooCoci9zae(iev8ainailae, ko7aifeiqu3s);
        return ko7aifeiqu3s.ieseir3Choge();
    }

    public final void thooCoci9zae(iev8ainaiLae iev8ainailae, vaeVoh2dei5I.ko7aiFeiqu3s ko7aifeiqu3s) {
        ArrayDeque arrayDeque;
        synchronized (this.f5794kuedujio7Aev) {
            try {
                String kuedujio7Aev2 = iev8ainailae.kuedujio7Aev();
                if (this.f5794kuedujio7Aev.containsKey(kuedujio7Aev2)) {
                    arrayDeque = (ArrayDeque) this.f5794kuedujio7Aev.get(kuedujio7Aev2);
                } else {
                    ArrayDeque arrayDeque2 = new ArrayDeque();
                    this.f5794kuedujio7Aev.put(kuedujio7Aev2, arrayDeque2);
                    arrayDeque = arrayDeque2;
                }
                arrayDeque.add(ko7aifeiqu3s);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ zoojiiKaht3i(String str) {
        vaeVoh2dei5I.ohv5Shie7AeZ ruwiepo7ooVu2 = ruwiepo7ooVu(iev8ainaiLae.Aicohm8ieYoo(str));
        eetheKaevie8();
        return ruwiepo7ooVu2;
    }
}
