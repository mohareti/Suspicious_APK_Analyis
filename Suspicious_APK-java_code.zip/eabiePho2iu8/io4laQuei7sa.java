package eabiePho2iu8;

import android.content.res.Resources;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import java.util.Arrays;
import java.util.MissingFormatArgumentException;
import org.json.JSONArray;
import org.json.JSONException;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class io4laQuei7sa {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Bundle f5879ieseir3Choge;

    public io4laQuei7sa(Bundle bundle) {
        if (bundle != null) {
            this.f5879ieseir3Choge = new Bundle(bundle);
            return;
        }
        throw new NullPointerException("data");
    }

    public static String Idohhaimaes0(String str) {
        if (str.startsWith("gcm.n.")) {
            return str.substring(6);
        }
        return str;
    }

    public static boolean aac1eTaexee6(String str) {
        if (!str.startsWith("google.c.a.") && !str.equals("from")) {
            return false;
        }
        return true;
    }

    public static String esohshee3Pau(String str) {
        if (!str.startsWith("gcm.n.")) {
            return str;
        }
        return str.replace("gcm.n.", "gcm.notification.");
    }

    public static int ieheiQu9sho5(String str) {
        int parseColor = Color.parseColor(str);
        if (parseColor != -16777216) {
            return parseColor;
        }
        throw new IllegalArgumentException("Transparent color is invalid");
    }

    public static boolean laej2zeez5Ja(Bundle bundle) {
        if (!"1".equals(bundle.getString("gcm.n.e")) && !"1".equals(bundle.getString(esohshee3Pau("gcm.n.e")))) {
            return false;
        }
        return true;
    }

    public static boolean rojaiZ9aeRee(String str) {
        if (!str.startsWith("google.c.") && !str.startsWith("gcm.n.") && !str.startsWith("gcm.notification.")) {
            return false;
        }
        return true;
    }

    public String AeJiPo4of6Sh() {
        String oYe2ma2she1j2 = oYe2ma2she1j("gcm.n.sound2");
        if (TextUtils.isEmpty(oYe2ma2she1j2)) {
            return oYe2ma2she1j("gcm.n.sound");
        }
        return oYe2ma2she1j2;
    }

    public Uri Aicohm8ieYoo() {
        String oYe2ma2she1j2 = oYe2ma2she1j("gcm.n.link_android");
        if (TextUtils.isEmpty(oYe2ma2she1j2)) {
            oYe2ma2she1j2 = oYe2ma2she1j("gcm.n.link");
        }
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            return Uri.parse(oYe2ma2she1j2);
        }
        return null;
    }

    public Object[] Jah0aiP1ki6y(String str) {
        JSONArray keiL1EiShomu2 = keiL1EiShomu(str + "_loc_args");
        if (keiL1EiShomu2 == null) {
            return null;
        }
        int length = keiL1EiShomu2.length();
        String[] strArr = new String[length];
        for (int i = 0; i < length; i++) {
            strArr[i] = keiL1EiShomu2.optString(i);
        }
        return strArr;
    }

    public Integer ahthoK6usais() {
        Integer thooCoci9zae2 = thooCoci9zae("gcm.n.notification_count");
        if (thooCoci9zae2 == null) {
            return null;
        }
        if (thooCoci9zae2.intValue() < 0) {
            Log.w("FirebaseMessaging", "notificationCount is invalid: " + thooCoci9zae2 + ". Skipping setting notificationCount.");
            return null;
        }
        return thooCoci9zae2;
    }

    public long[] eetheKaevie8() {
        JSONArray keiL1EiShomu2 = keiL1EiShomu("gcm.n.vibrate_timings");
        if (keiL1EiShomu2 == null) {
            return null;
        }
        try {
            if (keiL1EiShomu2.length() > 1) {
                int length = keiL1EiShomu2.length();
                long[] jArr = new long[length];
                for (int i = 0; i < length; i++) {
                    jArr[i] = keiL1EiShomu2.optLong(i);
                }
                return jArr;
            }
            throw new JSONException("vibrateTimings have invalid length");
        } catch (NumberFormatException | JSONException unused) {
            Log.w("NotificationParams", "User defined vibrateTimings is invalid: " + keiL1EiShomu2 + ". Skipping setting vibrateTimings.");
            return null;
        }
    }

    public Bundle eyei9eigh3Ie() {
        Bundle bundle = new Bundle(this.f5879ieseir3Choge);
        for (String str : this.f5879ieseir3Choge.keySet()) {
            if (rojaiZ9aeRee(str)) {
                bundle.remove(str);
            }
        }
        return bundle;
    }

    public boolean ieseir3Choge(String str) {
        String oYe2ma2she1j2 = oYe2ma2she1j(str);
        if (!"1".equals(oYe2ma2she1j2) && !Boolean.parseBoolean(oYe2ma2she1j2)) {
            return false;
        }
        return true;
    }

    public JSONArray keiL1EiShomu(String str) {
        String oYe2ma2she1j2 = oYe2ma2she1j(str);
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            try {
                return new JSONArray(oYe2ma2she1j2);
            } catch (JSONException unused) {
                Log.w("NotificationParams", "Malformed JSON for key " + Idohhaimaes0(str) + ": " + oYe2ma2she1j2 + ", falling back to default");
                return null;
            }
        }
        return null;
    }

    public Long ko7aiFeiqu3s(String str) {
        String oYe2ma2she1j2 = oYe2ma2she1j(str);
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            try {
                return Long.valueOf(Long.parseLong(oYe2ma2she1j2));
            } catch (NumberFormatException unused) {
                Log.w("NotificationParams", "Couldn't parse value of " + Idohhaimaes0(str) + "(" + oYe2ma2she1j2 + ") into a long");
                return null;
            }
        }
        return null;
    }

    public int[] kuedujio7Aev() {
        String str;
        JSONArray keiL1EiShomu2 = keiL1EiShomu("gcm.n.light_settings");
        if (keiL1EiShomu2 == null) {
            return null;
        }
        int[] iArr = new int[3];
        try {
            if (keiL1EiShomu2.length() == 3) {
                iArr[0] = ieheiQu9sho5(keiL1EiShomu2.optString(0));
                iArr[1] = keiL1EiShomu2.optInt(1);
                iArr[2] = keiL1EiShomu2.optInt(2);
                return iArr;
            }
            throw new JSONException("lightSettings don't have all three fields");
        } catch (IllegalArgumentException e) {
            str = "LightSettings is invalid: " + keiL1EiShomu2 + ". " + e.getMessage() + ". Skipping setting LightSettings";
            Log.w("NotificationParams", str);
            return null;
        } catch (JSONException unused) {
            str = "LightSettings is invalid: " + keiL1EiShomu2 + ". Skipping setting LightSettings";
            Log.w("NotificationParams", str);
            return null;
        }
    }

    public Integer mi5Iecheimie() {
        Integer thooCoci9zae2 = thooCoci9zae("gcm.n.notification_priority");
        if (thooCoci9zae2 == null) {
            return null;
        }
        if (thooCoci9zae2.intValue() >= -2 && thooCoci9zae2.intValue() <= 2) {
            return thooCoci9zae2;
        }
        Log.w("FirebaseMessaging", "notificationPriority is invalid " + thooCoci9zae2 + ". Skipping setting notificationPriority.");
        return null;
    }

    public String niah0Shohtha(String str) {
        return oYe2ma2she1j(str + "_loc_key");
    }

    public String oYe2ma2she1j(String str) {
        return this.f5879ieseir3Choge.getString(oph9lahCh6uo(str));
    }

    public Bundle ohthie9thieG() {
        Bundle bundle = new Bundle(this.f5879ieseir3Choge);
        for (String str : this.f5879ieseir3Choge.keySet()) {
            if (!aac1eTaexee6(str)) {
                bundle.remove(str);
            }
        }
        return bundle;
    }

    public String ohv5Shie7AeZ(Resources resources, String str, String str2) {
        String niah0Shohtha2 = niah0Shohtha(str2);
        if (TextUtils.isEmpty(niah0Shohtha2)) {
            return null;
        }
        int identifier = resources.getIdentifier(niah0Shohtha2, "string", str);
        if (identifier == 0) {
            Log.w("NotificationParams", Idohhaimaes0(str2 + "_loc_key") + " resource not found: " + str2 + " Default value will be used.");
            return null;
        }
        Object[] Jah0aiP1ki6y2 = Jah0aiP1ki6y(str2);
        if (Jah0aiP1ki6y2 == null) {
            return resources.getString(identifier);
        }
        try {
            return resources.getString(identifier, Jah0aiP1ki6y2);
        } catch (MissingFormatArgumentException e) {
            Log.w("NotificationParams", "Missing format argument for " + Idohhaimaes0(str2) + ": " + Arrays.toString(Jah0aiP1ki6y2) + " Default value will be used.", e);
            return null;
        }
    }

    public final String oph9lahCh6uo(String str) {
        if (!this.f5879ieseir3Choge.containsKey(str) && str.startsWith("gcm.n.")) {
            String esohshee3Pau2 = esohshee3Pau(str);
            if (this.f5879ieseir3Choge.containsKey(esohshee3Pau2)) {
                return esohshee3Pau2;
            }
        }
        return str;
    }

    public String ruNgecai1pae() {
        return oYe2ma2she1j("gcm.n.android_channel_id");
    }

    public String ruwiepo7ooVu(Resources resources, String str, String str2) {
        String oYe2ma2she1j2 = oYe2ma2she1j(str2);
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            return oYe2ma2she1j2;
        }
        return ohv5Shie7AeZ(resources, str, str2);
    }

    public Integer thooCoci9zae(String str) {
        String oYe2ma2she1j2 = oYe2ma2she1j(str);
        if (!TextUtils.isEmpty(oYe2ma2she1j2)) {
            try {
                return Integer.valueOf(Integer.parseInt(oYe2ma2she1j2));
            } catch (NumberFormatException unused) {
                Log.w("NotificationParams", "Couldn't parse value of " + Idohhaimaes0(str) + "(" + oYe2ma2she1j2 + ") into an int");
                return null;
            }
        }
        return null;
    }

    public Integer zoojiiKaht3i() {
        Integer thooCoci9zae2 = thooCoci9zae("gcm.n.visibility");
        if (thooCoci9zae2 == null) {
            return null;
        }
        if (thooCoci9zae2.intValue() >= -1 && thooCoci9zae2.intValue() <= 1) {
            return thooCoci9zae2;
        }
        Log.w("NotificationParams", "visibility is invalid: " + thooCoci9zae2 + ". Skipping setting visibility.");
        return null;
    }
}
