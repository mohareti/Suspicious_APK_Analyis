package eabiePho2iu8;

import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import android.util.Log;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ruwiepo7ooVu {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static ooJahquoo9ei f5934ieheiQu9sho5;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public static final Object f5935keiL1EiShomu = new Object();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f5936ieseir3Choge;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final Executor f5937thooCoci9zae = new HaeYeFaep1if.Aicohm8ieYoo();

    public ruwiepo7ooVu(Context context) {
        this.f5936ieseir3Choge = context;
    }

    public static ooJahquoo9ei Aicohm8ieYoo(Context context, String str) {
        ooJahquoo9ei oojahquoo9ei;
        synchronized (f5935keiL1EiShomu) {
            try {
                if (f5934ieheiQu9sho5 == null) {
                    f5934ieheiQu9sho5 = new ooJahquoo9ei(context, str);
                }
                oojahquoo9ei = f5934ieheiQu9sho5;
            } catch (Throwable th) {
                throw th;
            }
        }
        return oojahquoo9ei;
    }

    public static /* synthetic */ Integer Jah0aiP1ki6y(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        return -1;
    }

    public static /* synthetic */ vaeVoh2dei5I.ohv5Shie7AeZ ko7aiFeiqu3s(Context context, Intent intent, boolean z, vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        if (Id9uvaegh4ai.ohv5Shie7AeZ.Jah0aiP1ki6y() && ((Integer) ohv5shie7aez.ruNgecai1pae()).intValue() == 402) {
            return kuedujio7Aev(context, intent, z).niah0Shohtha(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.ieseir3Choge() { // from class: eabiePho2iu8.ahthoK6usais
                @Override // vaeVoh2dei5I.ieseir3Choge
                public final Object ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez2) {
                    Integer ohv5Shie7AeZ2;
                    ohv5Shie7AeZ2 = ruwiepo7ooVu.ohv5Shie7AeZ(ohv5shie7aez2);
                    return ohv5Shie7AeZ2;
                }
            });
        }
        return ohv5shie7aez;
    }

    public static vaeVoh2dei5I.ohv5Shie7AeZ kuedujio7Aev(Context context, Intent intent, boolean z) {
        if (Log.isLoggable("FirebaseMessaging", 3)) {
            Log.d("FirebaseMessaging", "Binding to service");
        }
        ooJahquoo9ei Aicohm8ieYoo2 = Aicohm8ieYoo(context, "com.google.firebase.MESSAGING_EVENT");
        if (z) {
            if (ohx8eem3Ahph.thooCoci9zae().kuedujio7Aev(context)) {
                aed3pie3Chah.Aicohm8ieYoo(context, Aicohm8ieYoo2, intent);
            } else {
                Aicohm8ieYoo2.ieheiQu9sho5(intent);
            }
            return vaeVoh2dei5I.ahthoK6usais.kuedujio7Aev(-1);
        }
        return Aicohm8ieYoo2.ieheiQu9sho5(intent).niah0Shohtha(new HaeYeFaep1if.Aicohm8ieYoo(), new vaeVoh2dei5I.ieseir3Choge() { // from class: eabiePho2iu8.mi5Iecheimie
            @Override // vaeVoh2dei5I.ieseir3Choge
            public final Object ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                Integer Jah0aiP1ki6y2;
                Jah0aiP1ki6y2 = ruwiepo7ooVu.Jah0aiP1ki6y(ohv5shie7aez);
                return Jah0aiP1ki6y2;
            }
        });
    }

    public static /* synthetic */ Integer niah0Shohtha(Context context, Intent intent) {
        return Integer.valueOf(ohx8eem3Ahph.thooCoci9zae().Jah0aiP1ki6y(context, intent));
    }

    public static /* synthetic */ Integer ohv5Shie7AeZ(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
        return 403;
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ ahthoK6usais(final Context context, final Intent intent) {
        boolean z;
        final boolean z2 = false;
        if (Id9uvaegh4ai.ohv5Shie7AeZ.Jah0aiP1ki6y() && context.getApplicationInfo().targetSdkVersion >= 26) {
            z = true;
        } else {
            z = false;
        }
        if ((intent.getFlags() & 268435456) != 0) {
            z2 = true;
        }
        if (z && !z2) {
            return kuedujio7Aev(context, intent, z2);
        }
        return vaeVoh2dei5I.ahthoK6usais.keiL1EiShomu(this.f5937thooCoci9zae, new Callable() { // from class: eabiePho2iu8.ko7aiFeiqu3s
            @Override // java.util.concurrent.Callable
            public final Object call() {
                Integer niah0Shohtha2;
                niah0Shohtha2 = ruwiepo7ooVu.niah0Shohtha(context, intent);
                return niah0Shohtha2;
            }
        }).ohv5Shie7AeZ(this.f5937thooCoci9zae, new vaeVoh2dei5I.ieseir3Choge() { // from class: eabiePho2iu8.ruNgecai1pae
            @Override // vaeVoh2dei5I.ieseir3Choge
            public final Object ieseir3Choge(vaeVoh2dei5I.ohv5Shie7AeZ ohv5shie7aez) {
                vaeVoh2dei5I.ohv5Shie7AeZ ko7aiFeiqu3s2;
                ko7aiFeiqu3s2 = ruwiepo7ooVu.ko7aiFeiqu3s(context, intent, z2, ohv5shie7aez);
                return ko7aiFeiqu3s2;
            }
        });
    }

    public vaeVoh2dei5I.ohv5Shie7AeZ ruNgecai1pae(Intent intent) {
        String stringExtra = intent.getStringExtra("gcm.rawData64");
        if (stringExtra != null) {
            intent.putExtra("rawData", Base64.decode(stringExtra, 0));
            intent.removeExtra("gcm.rawData64");
        }
        return ahthoK6usais(this.f5936ieseir3Choge, intent);
    }
}
