package eabiePho2iu8;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class zoo3eifoe3Ae implements Parcelable.Creator {
    public static void keiL1EiShomu(eewoo9thaiCe eewoo9thaice, Parcel parcel, int i) {
        int ieseir3Choge2 = Niethookee4d.keiL1EiShomu.ieseir3Choge(parcel);
        Niethookee4d.keiL1EiShomu.ieheiQu9sho5(parcel, 2, eewoo9thaice.f5842ieseir3Choge, false);
        Niethookee4d.keiL1EiShomu.thooCoci9zae(parcel, ieseir3Choge2);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: ieseir3Choge, reason: merged with bridge method [inline-methods] */
    public eewoo9thaiCe createFromParcel(Parcel parcel) {
        int eetheKaevie82 = Niethookee4d.thooCoci9zae.eetheKaevie8(parcel);
        Bundle bundle = null;
        while (parcel.dataPosition() < eetheKaevie82) {
            int ruNgecai1pae2 = Niethookee4d.thooCoci9zae.ruNgecai1pae(parcel);
            if (Niethookee4d.thooCoci9zae.ohv5Shie7AeZ(ruNgecai1pae2) != 2) {
                Niethookee4d.thooCoci9zae.oYe2ma2she1j(parcel, ruNgecai1pae2);
            } else {
                bundle = Niethookee4d.thooCoci9zae.ieseir3Choge(parcel, ruNgecai1pae2);
            }
        }
        Niethookee4d.thooCoci9zae.niah0Shohtha(parcel, eetheKaevie82);
        return new eewoo9thaiCe(bundle);
    }

    @Override // android.os.Parcelable.Creator
    /* renamed from: thooCoci9zae, reason: merged with bridge method [inline-methods] */
    public eewoo9thaiCe[] newArray(int i) {
        return new eewoo9thaiCe[i];
    }
}
