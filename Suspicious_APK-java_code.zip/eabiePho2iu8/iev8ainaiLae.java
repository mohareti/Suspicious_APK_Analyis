package eabiePho2iu8;

import android.text.TextUtils;
import android.util.Log;
import java.util.regex.Pattern;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class iev8ainaiLae {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final Pattern f5875ieheiQu9sho5 = Pattern.compile("[a-zA-Z0-9-_.~%]{1,900}");

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final String f5876ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final String f5877keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final String f5878thooCoci9zae;

    public iev8ainaiLae(String str, String str2) {
        this.f5876ieseir3Choge = ieheiQu9sho5(str2, str);
        this.f5878thooCoci9zae = str;
        this.f5877keiL1EiShomu = str + "!" + str2;
    }

    public static iev8ainaiLae Aicohm8ieYoo(String str) {
        return new iev8ainaiLae("S", str);
    }

    public static String ieheiQu9sho5(String str, String str2) {
        if (str != null && str.startsWith("/topics/")) {
            Log.w("FirebaseMessaging", String.format("Format /topics/topic-name is deprecated. Only 'topic-name' should be used in %s.", str2));
            str = str.substring(8);
        }
        if (str != null && f5875ieheiQu9sho5.matcher(str).matches()) {
            return str;
        }
        throw new IllegalArgumentException(String.format("Invalid topic name: %s does not match the allowed format %s.", str, "[a-zA-Z0-9-_.~%]{1,900}"));
    }

    public static iev8ainaiLae ieseir3Choge(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        String[] split = str.split("!", -1);
        if (split.length != 2) {
            return null;
        }
        return new iev8ainaiLae(split[0], split[1]);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof iev8ainaiLae)) {
            return false;
        }
        iev8ainaiLae iev8ainailae = (iev8ainaiLae) obj;
        if (!this.f5876ieseir3Choge.equals(iev8ainailae.f5876ieseir3Choge) || !this.f5878thooCoci9zae.equals(iev8ainailae.f5878thooCoci9zae)) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return Aebu8yohvea8.mi5Iecheimie.thooCoci9zae(this.f5878thooCoci9zae, this.f5876ieseir3Choge);
    }

    public String keiL1EiShomu() {
        return this.f5876ieseir3Choge;
    }

    public String kuedujio7Aev() {
        return this.f5877keiL1EiShomu;
    }

    public String thooCoci9zae() {
        return this.f5878thooCoci9zae;
    }
}
