package eabiePho2iu8;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.util.Log;
import java.util.List;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class mi3Ozool1oa4 {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public int f5893ieheiQu9sho5;

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f5894ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public String f5895keiL1EiShomu;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public int f5896kuedujio7Aev = 0;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public String f5897thooCoci9zae;

    public mi3Ozool1oa4(Context context) {
        this.f5894ieseir3Choge = context;
    }

    public static String keiL1EiShomu(ohBoophood9o.kuedujio7Aev kuedujio7aev) {
        String ieheiQu9sho52 = kuedujio7aev.mi5Iecheimie().ieheiQu9sho5();
        if (ieheiQu9sho52 != null) {
            return ieheiQu9sho52;
        }
        String keiL1EiShomu2 = kuedujio7aev.mi5Iecheimie().keiL1EiShomu();
        if (!keiL1EiShomu2.startsWith("1:")) {
            return keiL1EiShomu2;
        }
        String[] split = keiL1EiShomu2.split(":");
        if (split.length < 2) {
            return null;
        }
        String str = split[1];
        if (str.isEmpty()) {
            return null;
        }
        return str;
    }

    public final PackageInfo Aicohm8ieYoo(String str) {
        try {
            return this.f5894ieseir3Choge.getPackageManager().getPackageInfo(str, 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.w("FirebaseMessaging", "Failed to find package " + e);
            return null;
        }
    }

    public boolean Jah0aiP1ki6y() {
        if (kuedujio7Aev() != 0) {
            return true;
        }
        return false;
    }

    public synchronized int ieheiQu9sho5() {
        PackageInfo Aicohm8ieYoo2;
        try {
            if (this.f5893ieheiQu9sho5 == 0 && (Aicohm8ieYoo2 = Aicohm8ieYoo("com.google.android.gms")) != null) {
                this.f5893ieheiQu9sho5 = Aicohm8ieYoo2.versionCode;
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.f5893ieheiQu9sho5;
    }

    public synchronized String ieseir3Choge() {
        try {
            if (this.f5897thooCoci9zae == null) {
                niah0Shohtha();
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.f5897thooCoci9zae;
    }

    public synchronized int kuedujio7Aev() {
        int i = this.f5896kuedujio7Aev;
        if (i != 0) {
            return i;
        }
        PackageManager packageManager = this.f5894ieseir3Choge.getPackageManager();
        if (packageManager.checkPermission("com.google.android.c2dm.permission.SEND", "com.google.android.gms") == -1) {
            Log.e("FirebaseMessaging", "Google Play services missing or without correct permission.");
            return 0;
        }
        if (!Id9uvaegh4ai.ohv5Shie7AeZ.Jah0aiP1ki6y()) {
            Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
            intent.setPackage("com.google.android.gms");
            List<ResolveInfo> queryIntentServices = packageManager.queryIntentServices(intent, 0);
            if (queryIntentServices != null && queryIntentServices.size() > 0) {
                this.f5896kuedujio7Aev = 1;
                return 1;
            }
        }
        Intent intent2 = new Intent("com.google.iid.TOKEN_REQUEST");
        intent2.setPackage("com.google.android.gms");
        List<ResolveInfo> queryBroadcastReceivers = packageManager.queryBroadcastReceivers(intent2, 0);
        if (queryBroadcastReceivers != null && queryBroadcastReceivers.size() > 0) {
            this.f5896kuedujio7Aev = 2;
            return 2;
        }
        Log.w("FirebaseMessaging", "Failed to resolve IID implementation package, falling back");
        if (Id9uvaegh4ai.ohv5Shie7AeZ.Jah0aiP1ki6y()) {
            this.f5896kuedujio7Aev = 2;
        } else {
            this.f5896kuedujio7Aev = 1;
        }
        return this.f5896kuedujio7Aev;
    }

    public final synchronized void niah0Shohtha() {
        PackageInfo Aicohm8ieYoo2 = Aicohm8ieYoo(this.f5894ieseir3Choge.getPackageName());
        if (Aicohm8ieYoo2 != null) {
            this.f5897thooCoci9zae = Integer.toString(Aicohm8ieYoo2.versionCode);
            this.f5895keiL1EiShomu = Aicohm8ieYoo2.versionName;
        }
    }

    public synchronized String thooCoci9zae() {
        try {
            if (this.f5895keiL1EiShomu == null) {
                niah0Shohtha();
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.f5895keiL1EiShomu;
    }
}
