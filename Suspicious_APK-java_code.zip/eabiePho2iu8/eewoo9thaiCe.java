package eabiePho2iu8;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class eewoo9thaiCe extends Niethookee4d.ieseir3Choge {
    public static final Parcelable.Creator<eewoo9thaiCe> CREATOR = new zoo3eifoe3Ae();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public Bundle f5842ieseir3Choge;

    public eewoo9thaiCe(Bundle bundle) {
        this.f5842ieseir3Choge = bundle;
    }

    public final int ieseir3Choge(String str) {
        if ("high".equals(str)) {
            return 1;
        }
        if ("normal".equals(str)) {
            return 2;
        }
        return 0;
    }

    public int thooCoci9zae() {
        String string = this.f5842ieseir3Choge.getString("google.delivered_priority");
        if (string == null) {
            if ("1".equals(this.f5842ieseir3Choge.getString("google.priority_reduced"))) {
                return 2;
            }
            string = this.f5842ieseir3Choge.getString("google.priority");
        }
        return ieseir3Choge(string);
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        zoo3eifoe3Ae.keiL1EiShomu(this, parcel, i);
    }
}
