package waita4vool1K;

import java.util.concurrent.TimeUnit;
import sieChi1iehoo.oYe2ma2she1j;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class kuedujio7Aev {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final long f8277ieheiQu9sho5 = TimeUnit.HOURS.toMillis(24);

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final long f8278kuedujio7Aev = TimeUnit.MINUTES.toMillis(30);

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final oYe2ma2she1j f8279ieseir3Choge = oYe2ma2she1j.keiL1EiShomu();

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public int f8280keiL1EiShomu;

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public long f8281thooCoci9zae;

    public static boolean ieheiQu9sho5(int i) {
        if ((i < 200 || i >= 300) && i != 401 && i != 404) {
            return false;
        }
        return true;
    }

    public static boolean keiL1EiShomu(int i) {
        if (i != 429 && (i < 500 || i >= 600)) {
            return false;
        }
        return true;
    }

    public synchronized void Aicohm8ieYoo(int i) {
        if (ieheiQu9sho5(i)) {
            kuedujio7Aev();
            return;
        }
        this.f8280keiL1EiShomu++;
        this.f8281thooCoci9zae = this.f8279ieseir3Choge.ieseir3Choge() + ieseir3Choge(i);
    }

    public final synchronized long ieseir3Choge(int i) {
        if (!keiL1EiShomu(i)) {
            return f8277ieheiQu9sho5;
        }
        return (long) Math.min(Math.pow(2.0d, this.f8280keiL1EiShomu) + this.f8279ieseir3Choge.kuedujio7Aev(), f8278kuedujio7Aev);
    }

    public final synchronized void kuedujio7Aev() {
        this.f8280keiL1EiShomu = 0;
    }

    public synchronized boolean thooCoci9zae() {
        boolean z;
        if (this.f8280keiL1EiShomu != 0) {
            if (this.f8279ieseir3Choge.ieseir3Choge() <= this.f8281thooCoci9zae) {
                z = false;
            }
        }
        z = true;
        return z;
    }
}
