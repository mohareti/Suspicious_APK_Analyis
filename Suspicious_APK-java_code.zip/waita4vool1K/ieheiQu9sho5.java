package waita4vool1K;

import waita4vool1K.ieseir3Choge;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ieseir3Choge Aicohm8ieYoo(String str);

        public abstract ieseir3Choge ieheiQu9sho5(String str);

        public abstract ieheiQu9sho5 ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(String str);

        public abstract ieseir3Choge kuedujio7Aev(thooCoci9zae thoococi9zae);

        public abstract ieseir3Choge thooCoci9zae(Aicohm8ieYoo aicohm8ieYoo);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        OK,
        BAD_CONFIG
    }

    public static ieseir3Choge ieseir3Choge() {
        return new ieseir3Choge.thooCoci9zae();
    }

    public abstract String Aicohm8ieYoo();

    public abstract String ieheiQu9sho5();

    public abstract String keiL1EiShomu();

    public abstract thooCoci9zae kuedujio7Aev();

    public abstract Aicohm8ieYoo thooCoci9zae();
}
