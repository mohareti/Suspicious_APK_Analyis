package waita4vool1K;

import Aebu8yohvea8.ruwiepo7ooVu;
import Id9uvaegh4ai.Jah0aiP1ki6y;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.TrafficStats;
import android.text.TextUtils;
import android.util.JsonReader;
import android.util.Log;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import org.conscrypt.BuildConfig;
import org.json.JSONException;
import org.json.JSONObject;
import sieChi1iehoo.ohv5Shie7AeZ;
import vaeVoh2dei5I.ahthoK6usais;
import waita4vool1K.Aicohm8ieYoo;
import waita4vool1K.ieheiQu9sho5;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class keiL1EiShomu {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public static final Pattern f8272ieheiQu9sho5 = Pattern.compile("[0-9]+s");

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public static final Charset f8273kuedujio7Aev = Charset.forName("UTF-8");

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public final Context f8274ieseir3Choge;

    /* renamed from: keiL1EiShomu, reason: collision with root package name */
    public final kuedujio7Aev f8275keiL1EiShomu = new kuedujio7Aev();

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public final oWouk4seiqua.thooCoci9zae f8276thooCoci9zae;

    public keiL1EiShomu(Context context, oWouk4seiqua.thooCoci9zae thoococi9zae) {
        this.f8274ieseir3Choge = context;
        this.f8276thooCoci9zae = thoococi9zae;
    }

    public static String AeJiPo4of6Sh(HttpURLConnection httpURLConnection) {
        InputStream errorStream = httpURLConnection.getErrorStream();
        if (errorStream == null) {
            return null;
        }
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(errorStream, f8273kuedujio7Aev));
        try {
            try {
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine == null) {
                        break;
                    }
                    sb.append(readLine);
                    sb.append('\n');
                }
                String format = String.format("Error when communicating with the Firebase Installations server API. HTTP response: [%d %s: %s]", Integer.valueOf(httpURLConnection.getResponseCode()), httpURLConnection.getResponseMessage(), sb);
                try {
                    bufferedReader.close();
                } catch (IOException unused) {
                }
                return format;
            } catch (IOException unused2) {
                return null;
            }
        } catch (IOException unused3) {
            bufferedReader.close();
            return null;
        } catch (Throwable th) {
            try {
                bufferedReader.close();
            } catch (IOException unused4) {
            }
            throw th;
        }
    }

    public static void aac1eTaexee6(URLConnection uRLConnection, byte[] bArr) {
        OutputStream outputStream = uRLConnection.getOutputStream();
        if (outputStream != null) {
            GZIPOutputStream gZIPOutputStream = new GZIPOutputStream(outputStream);
            try {
                gZIPOutputStream.write(bArr);
                try {
                    return;
                } catch (IOException unused) {
                    return;
                }
            } finally {
                try {
                    gZIPOutputStream.close();
                    outputStream.close();
                } catch (IOException unused2) {
                }
            }
        }
        throw new IOException("Cannot send request to FIS servers. No OutputStream available.");
    }

    public static String ieseir3Choge(String str, String str2, String str3) {
        String str4;
        if (TextUtils.isEmpty(str)) {
            str4 = BuildConfig.FLAVOR;
        } else {
            str4 = ", " + str;
        }
        return String.format("Firebase options used while communicating with Firebase server APIs: %s, %s%s", str2, str3, str4);
    }

    public static JSONObject keiL1EiShomu() {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("sdkVersion", "a:18.0.0");
            JSONObject jSONObject2 = new JSONObject();
            jSONObject2.put("installation", jSONObject);
            return jSONObject2;
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
    }

    public static void ko7aiFeiqu3s() {
        Log.e("Firebase-Installations", "Firebase Installations can not communicate with Firebase server APIs due to invalid configuration. Please update your Firebase initialization process and set valid Firebase options (API key, Project ID, Application ID) when initializing Firebase.");
    }

    public static long mi5Iecheimie(String str) {
        ruwiepo7ooVu.thooCoci9zae(f8272ieheiQu9sho5.matcher(str).matches(), "Invalid Expiration Timestamp.");
        if (str != null && str.length() != 0) {
            return Long.parseLong(str.substring(0, str.length() - 1));
        }
        return 0L;
    }

    public static byte[] niah0Shohtha(JSONObject jSONObject) {
        return jSONObject.toString().getBytes("UTF-8");
    }

    public static boolean ohv5Shie7AeZ(int i) {
        if (i >= 200 && i < 300) {
            return true;
        }
        return false;
    }

    public static void ruNgecai1pae(HttpURLConnection httpURLConnection, String str, String str2, String str3) {
        String AeJiPo4of6Sh2 = AeJiPo4of6Sh(httpURLConnection);
        if (!TextUtils.isEmpty(AeJiPo4of6Sh2)) {
            Log.w("Firebase-Installations", AeJiPo4of6Sh2);
            Log.w("Firebase-Installations", ieseir3Choge(str, str2, str3));
        }
    }

    public static JSONObject thooCoci9zae(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("fid", str);
            jSONObject.put("appId", str2);
            jSONObject.put("authVersion", "FIS_v2");
            jSONObject.put("sdkVersion", "a:18.0.0");
            return jSONObject;
        } catch (JSONException e) {
            throw new IllegalStateException(e);
        }
    }

    public final String Aicohm8ieYoo() {
        try {
            Context context = this.f8274ieseir3Choge;
            byte[] ieseir3Choge2 = Id9uvaegh4ai.ieseir3Choge.ieseir3Choge(context, context.getPackageName());
            if (ieseir3Choge2 == null) {
                Log.e("ContentValues", "Could not get fingerprint hash for package: " + this.f8274ieseir3Choge.getPackageName());
                return null;
            }
            return Jah0aiP1ki6y.ieseir3Choge(ieseir3Choge2, false);
        } catch (PackageManager.NameNotFoundException e) {
            Log.e("ContentValues", "No such package: " + this.f8274ieseir3Choge.getPackageName(), e);
            return null;
        }
    }

    public final URL Jah0aiP1ki6y(String str) {
        try {
            return new URL(String.format("https://%s/%s/%s", "firebaseinstallations.googleapis.com", "v1", str));
        } catch (MalformedURLException e) {
            throw new ohv5Shie7AeZ(e.getMessage(), ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
        }
    }

    public final HttpURLConnection ahthoK6usais(URL url, String str) {
        try {
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setConnectTimeout(10000);
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.addRequestProperty("Content-Type", "application/json");
            httpURLConnection.addRequestProperty("Accept", "application/json");
            httpURLConnection.addRequestProperty("Content-Encoding", "gzip");
            httpURLConnection.addRequestProperty("Cache-Control", "no-cache");
            httpURLConnection.addRequestProperty("X-Android-Package", this.f8274ieseir3Choge.getPackageName());
            rieVei3pei5O.ohv5Shie7AeZ ohv5shie7aez = (rieVei3pei5O.ohv5Shie7AeZ) this.f8276thooCoci9zae.get();
            if (ohv5shie7aez != null) {
                try {
                    httpURLConnection.addRequestProperty("x-firebase-client", (String) ahthoK6usais.ieseir3Choge(ohv5shie7aez.ieseir3Choge()));
                } catch (InterruptedException e) {
                    e = e;
                    Thread.currentThread().interrupt();
                    Log.w("ContentValues", "Failed to get heartbeats header", e);
                    httpURLConnection.addRequestProperty("X-Android-Cert", Aicohm8ieYoo());
                    httpURLConnection.addRequestProperty("x-goog-api-key", str);
                    return httpURLConnection;
                } catch (ExecutionException e2) {
                    e = e2;
                    Log.w("ContentValues", "Failed to get heartbeats header", e);
                    httpURLConnection.addRequestProperty("X-Android-Cert", Aicohm8ieYoo());
                    httpURLConnection.addRequestProperty("x-goog-api-key", str);
                    return httpURLConnection;
                }
            }
            httpURLConnection.addRequestProperty("X-Android-Cert", Aicohm8ieYoo());
            httpURLConnection.addRequestProperty("x-goog-api-key", str);
            return httpURLConnection;
        } catch (IOException unused) {
            throw new ohv5Shie7AeZ("Firebase Installations Service is unavailable. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
        }
    }

    public final void eetheKaevie8(HttpURLConnection httpURLConnection, String str, String str2) {
        aac1eTaexee6(httpURLConnection, niah0Shohtha(thooCoci9zae(str, str2)));
    }

    public ieheiQu9sho5 ieheiQu9sho5(String str, String str2, String str3, String str4, String str5) {
        int responseCode;
        ieheiQu9sho5 ruwiepo7ooVu2;
        if (this.f8275keiL1EiShomu.thooCoci9zae()) {
            URL Jah0aiP1ki6y2 = Jah0aiP1ki6y(String.format("projects/%s/installations", str3));
            for (int i = 0; i <= 1; i++) {
                TrafficStats.setThreadStatsTag(32769);
                HttpURLConnection ahthoK6usais2 = ahthoK6usais(Jah0aiP1ki6y2, str);
                try {
                    try {
                        ahthoK6usais2.setRequestMethod("POST");
                        ahthoK6usais2.setDoOutput(true);
                        if (str5 != null) {
                            ahthoK6usais2.addRequestProperty("x-goog-fis-android-iid-migration-auth", str5);
                        }
                        eetheKaevie8(ahthoK6usais2, str2, str4);
                        responseCode = ahthoK6usais2.getResponseCode();
                        this.f8275keiL1EiShomu.Aicohm8ieYoo(responseCode);
                    } catch (IOException | AssertionError unused) {
                    }
                    if (ohv5Shie7AeZ(responseCode)) {
                        ruwiepo7ooVu2 = ruwiepo7ooVu(ahthoK6usais2);
                    } else {
                        ruNgecai1pae(ahthoK6usais2, str4, str, str3);
                        if (responseCode != 429) {
                            if (responseCode < 500 || responseCode >= 600) {
                                ko7aiFeiqu3s();
                                ruwiepo7ooVu2 = ieheiQu9sho5.ieseir3Choge().kuedujio7Aev(ieheiQu9sho5.thooCoci9zae.BAD_CONFIG).ieseir3Choge();
                            }
                            ahthoK6usais2.disconnect();
                            TrafficStats.clearThreadStatsTag();
                        } else {
                            throw new ohv5Shie7AeZ("Firebase servers have received too many requests from this client in a short period of time. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.TOO_MANY_REQUESTS);
                        }
                    }
                    ahthoK6usais2.disconnect();
                    TrafficStats.clearThreadStatsTag();
                    return ruwiepo7ooVu2;
                } catch (Throwable th) {
                    ahthoK6usais2.disconnect();
                    TrafficStats.clearThreadStatsTag();
                    throw th;
                }
            }
            throw new ohv5Shie7AeZ("Firebase Installations Service is unavailable. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
        }
        throw new ohv5Shie7AeZ("Firebase Installations Service is unavailable. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
    }

    public Aicohm8ieYoo kuedujio7Aev(String str, String str2, String str3, String str4) {
        int responseCode;
        Aicohm8ieYoo oYe2ma2she1j2;
        Aicohm8ieYoo.ieseir3Choge thooCoci9zae2;
        if (this.f8275keiL1EiShomu.thooCoci9zae()) {
            URL Jah0aiP1ki6y2 = Jah0aiP1ki6y(String.format("projects/%s/installations/%s/authTokens:generate", str3, str2));
            for (int i = 0; i <= 1; i++) {
                TrafficStats.setThreadStatsTag(32771);
                HttpURLConnection ahthoK6usais2 = ahthoK6usais(Jah0aiP1ki6y2, str);
                try {
                    try {
                        ahthoK6usais2.setRequestMethod("POST");
                        ahthoK6usais2.addRequestProperty("Authorization", "FIS_v2 " + str4);
                        ahthoK6usais2.setDoOutput(true);
                        zoojiiKaht3i(ahthoK6usais2);
                        responseCode = ahthoK6usais2.getResponseCode();
                        this.f8275keiL1EiShomu.Aicohm8ieYoo(responseCode);
                    } finally {
                        ahthoK6usais2.disconnect();
                        TrafficStats.clearThreadStatsTag();
                    }
                } catch (IOException | AssertionError unused) {
                }
                if (ohv5Shie7AeZ(responseCode)) {
                    oYe2ma2she1j2 = oYe2ma2she1j(ahthoK6usais2);
                } else {
                    ruNgecai1pae(ahthoK6usais2, null, str, str3);
                    if (responseCode != 401 && responseCode != 404) {
                        if (responseCode != 429) {
                            if (responseCode < 500 || responseCode >= 600) {
                                ko7aiFeiqu3s();
                                thooCoci9zae2 = Aicohm8ieYoo.ieseir3Choge().thooCoci9zae(Aicohm8ieYoo.thooCoci9zae.BAD_CONFIG);
                            }
                        } else {
                            throw new ohv5Shie7AeZ("Firebase servers have received too many requests from this client in a short period of time. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.TOO_MANY_REQUESTS);
                        }
                    } else {
                        thooCoci9zae2 = Aicohm8ieYoo.ieseir3Choge().thooCoci9zae(Aicohm8ieYoo.thooCoci9zae.AUTH_ERROR);
                    }
                    oYe2ma2she1j2 = thooCoci9zae2.ieseir3Choge();
                }
                return oYe2ma2she1j2;
            }
            throw new ohv5Shie7AeZ("Firebase Installations Service is unavailable. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
        }
        throw new ohv5Shie7AeZ("Firebase Installations Service is unavailable. Please try again later.", ohv5Shie7AeZ.ieseir3Choge.UNAVAILABLE);
    }

    public final Aicohm8ieYoo oYe2ma2she1j(HttpURLConnection httpURLConnection) {
        InputStream inputStream = httpURLConnection.getInputStream();
        JsonReader jsonReader = new JsonReader(new InputStreamReader(inputStream, f8273kuedujio7Aev));
        Aicohm8ieYoo.ieseir3Choge ieseir3Choge2 = Aicohm8ieYoo.ieseir3Choge();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String nextName = jsonReader.nextName();
            if (nextName.equals("token")) {
                ieseir3Choge2.keiL1EiShomu(jsonReader.nextString());
            } else if (nextName.equals("expiresIn")) {
                ieseir3Choge2.ieheiQu9sho5(mi5Iecheimie(jsonReader.nextString()));
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        jsonReader.close();
        inputStream.close();
        return ieseir3Choge2.thooCoci9zae(Aicohm8ieYoo.thooCoci9zae.OK).ieseir3Choge();
    }

    public final ieheiQu9sho5 ruwiepo7ooVu(HttpURLConnection httpURLConnection) {
        InputStream inputStream = httpURLConnection.getInputStream();
        JsonReader jsonReader = new JsonReader(new InputStreamReader(inputStream, f8273kuedujio7Aev));
        Aicohm8ieYoo.ieseir3Choge ieseir3Choge2 = Aicohm8ieYoo.ieseir3Choge();
        ieheiQu9sho5.ieseir3Choge ieseir3Choge3 = ieheiQu9sho5.ieseir3Choge();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String nextName = jsonReader.nextName();
            if (nextName.equals("name")) {
                ieseir3Choge3.Aicohm8ieYoo(jsonReader.nextString());
            } else if (nextName.equals("fid")) {
                ieseir3Choge3.keiL1EiShomu(jsonReader.nextString());
            } else if (nextName.equals("refreshToken")) {
                ieseir3Choge3.ieheiQu9sho5(jsonReader.nextString());
            } else if (nextName.equals("authToken")) {
                jsonReader.beginObject();
                while (jsonReader.hasNext()) {
                    String nextName2 = jsonReader.nextName();
                    if (nextName2.equals("token")) {
                        ieseir3Choge2.keiL1EiShomu(jsonReader.nextString());
                    } else if (nextName2.equals("expiresIn")) {
                        ieseir3Choge2.ieheiQu9sho5(mi5Iecheimie(jsonReader.nextString()));
                    } else {
                        jsonReader.skipValue();
                    }
                }
                ieseir3Choge3.thooCoci9zae(ieseir3Choge2.ieseir3Choge());
                jsonReader.endObject();
            } else {
                jsonReader.skipValue();
            }
        }
        jsonReader.endObject();
        jsonReader.close();
        inputStream.close();
        return ieseir3Choge3.kuedujio7Aev(ieheiQu9sho5.thooCoci9zae.OK).ieseir3Choge();
    }

    public final void zoojiiKaht3i(HttpURLConnection httpURLConnection) {
        aac1eTaexee6(httpURLConnection, niah0Shohtha(keiL1EiShomu()));
    }
}
