package waita4vool1K;

import waita4vool1K.thooCoci9zae;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class Aicohm8ieYoo {

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public static abstract class ieseir3Choge {
        public abstract ieseir3Choge ieheiQu9sho5(long j);

        public abstract Aicohm8ieYoo ieseir3Choge();

        public abstract ieseir3Choge keiL1EiShomu(String str);

        public abstract ieseir3Choge thooCoci9zae(thooCoci9zae thoococi9zae);
    }

    /* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
    public enum thooCoci9zae {
        OK,
        BAD_CONFIG,
        AUTH_ERROR
    }

    public static ieseir3Choge ieseir3Choge() {
        return new thooCoci9zae.C0117thooCoci9zae().ieheiQu9sho5(0L);
    }

    public abstract long ieheiQu9sho5();

    public abstract String keiL1EiShomu();

    public abstract thooCoci9zae thooCoci9zae();
}
