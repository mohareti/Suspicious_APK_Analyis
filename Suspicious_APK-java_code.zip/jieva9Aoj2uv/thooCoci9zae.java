package jieva9Aoj2uv;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class thooCoci9zae {

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public static final thooCoci9zae f6907ieseir3Choge = new thooCoci9zae();

    public static final ieseir3Choge ieseir3Choge() {
        return new ieseir3Choge(2, 0, 20);
    }
}
