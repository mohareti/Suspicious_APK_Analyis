package jieva9Aoj2uv;

import java.io.Serializable;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public final class kuedujio7Aev implements Serializable {

    /* renamed from: ieheiQu9sho5, reason: collision with root package name */
    public final Object f6903ieheiQu9sho5;

    /* renamed from: kuedujio7Aev, reason: collision with root package name */
    public final Object f6904kuedujio7Aev;

    public kuedujio7Aev(Object obj, Object obj2) {
        this.f6903ieheiQu9sho5 = obj;
        this.f6904kuedujio7Aev = obj2;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof kuedujio7Aev)) {
            return false;
        }
        kuedujio7Aev kuedujio7aev = (kuedujio7Aev) obj;
        if (thiet5ees7Wu.Aicohm8ieYoo.ieseir3Choge(this.f6903ieheiQu9sho5, kuedujio7aev.f6903ieheiQu9sho5) && thiet5ees7Wu.Aicohm8ieYoo.ieseir3Choge(this.f6904kuedujio7Aev, kuedujio7aev.f6904kuedujio7Aev)) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        int hashCode;
        Object obj = this.f6903ieheiQu9sho5;
        int i = 0;
        if (obj == null) {
            hashCode = 0;
        } else {
            hashCode = obj.hashCode();
        }
        int i2 = hashCode * 31;
        Object obj2 = this.f6904kuedujio7Aev;
        if (obj2 != null) {
            i = obj2.hashCode();
        }
        return i2 + i;
    }

    public final Object ieheiQu9sho5() {
        return this.f6904kuedujio7Aev;
    }

    public final Object ieseir3Choge() {
        return this.f6903ieheiQu9sho5;
    }

    public final Object keiL1EiShomu() {
        return this.f6903ieheiQu9sho5;
    }

    public final Object thooCoci9zae() {
        return this.f6904kuedujio7Aev;
    }

    public String toString() {
        return '(' + this.f6903ieheiQu9sho5 + ", " + this.f6904kuedujio7Aev + ')';
    }
}
