package jieva9Aoj2uv;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public abstract class ieheiQu9sho5 {
    public static keiL1EiShomu ieseir3Choge(ieth4gahmaH8.ieseir3Choge ieseir3choge) {
        thiet5ees7Wu.Aicohm8ieYoo.kuedujio7Aev(ieseir3choge, "initializer");
        return new Aicohm8ieYoo(ieseir3choge, null, 2, null);
    }
}
