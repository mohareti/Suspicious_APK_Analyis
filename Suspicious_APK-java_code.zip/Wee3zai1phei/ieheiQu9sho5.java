package Wee3zai1phei;

import android.content.Context;

/* loaded from: /home/mobsf/.MobSF/uploads/81b3c8d299ee772c4ca62695cdbe9f47/classes.dex */
public class ieheiQu9sho5 {

    /* renamed from: thooCoci9zae, reason: collision with root package name */
    public static final ieheiQu9sho5 f2177thooCoci9zae = new ieheiQu9sho5();

    /* renamed from: ieseir3Choge, reason: collision with root package name */
    public keiL1EiShomu f2178ieseir3Choge = null;

    public static keiL1EiShomu ieseir3Choge(Context context) {
        return f2177thooCoci9zae.thooCoci9zae(context);
    }

    public final synchronized keiL1EiShomu thooCoci9zae(Context context) {
        try {
            if (this.f2178ieseir3Choge == null) {
                if (context.getApplicationContext() != null) {
                    context = context.getApplicationContext();
                }
                this.f2178ieseir3Choge = new keiL1EiShomu(context);
            }
        } catch (Throwable th) {
            throw th;
        }
        return this.f2178ieseir3Choge;
    }
}
